"""
scorm.py - e-learning courses (SCORM 1.2 / 2004, also xAPI and cmi5 packages) in data/input, as .zip files or
unpacked folders, at any depth (zips inside zips too), turned into what the rest of the pipeline already reads:

  data/input/_scorm/<course>/<course>.md          the course's text in page order: headings and paragraphs from the
                                                  package's data (JSON, XML, data in scripts, pages). Quizzes are
                                                  left out; only KNOWLEDGE_LANGS (default en: German parts go)
  data/input/_scorm/<course>/<course> - 01 ...mp4 each video of the course, with its English captions beside it
                                                  under the same name (.vtt): the captions are its transcript. A video
                                                  without English captions is transcribed (pipeline --mode all)
  data/input/_scorm/<course>/screens/...          the course's pictures: those with text (screenshots, diagrams) are
                                                  read with OCR by documents.py, the others are left out there
  data/input/_scorm/<course>/attachments/...      documents inside the package (PDF, Word, PowerPoint, Excel, text,
                                                  SVG drawings): read by documents.py like any other document

The package's own files (player scripts, fonts, styles, raw data, the original videos) are not read again by the
other steps. A package is read again only when it changes. inventory.py runs this first, so `uv run -m studio
pipeline` does everything; alone (to see what is found and made):

  uv run -m studio scorm
"""
from __future__ import annotations

import base64
import binascii
import hashlib
import html
import json
import logging
import os
import re
import shutil
import sys
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from xml.etree import ElementTree

from studio.core import config
from studio.knowledge import documents

log = logging.getLogger("scorm")

OUT = "_scorm"                         # under data/input: what is made from the packages
UNPACKED = ".packages"                 # under it: the .zip packages, unpacked
MANIFESTS = ("imsmanifest.xml", "tincan.xml", "cmi5.xml")
MAX_UNPACK = 20 * 1024 ** 3            # bytes: a package that unpacks to more is left alone (a broken or hostile zip)
MIN_MEDIA = 1024 ** 2                  # bytes: smaller videos and sounds are clicks, jingles and animations
MIN_PICTURE = 15 * 1024                # bytes: smaller pictures are icons and buttons
DATA_EXT = {".json", ".xml", ".js", ".html", ".htm"}
CAPTION_EXT = {".vtt", ".srt"}
PICTURE_EXT = {".png", ".jpg", ".jpeg", ".gif", ".webp"}
ATTACHMENT_EXT = {".pdf", ".docx", ".pptx", ".xlsx", ".xlsm", ".csv", ".txt", ".md", ".rtf", ".svg"}   # documents.py reads them
PLAYER = re.compile(r"(^|/)(lib|libs|vendor|vendors|runtime|polyfills?|player|framework|scormdriver|"
                    r"scorm_api|pipwerks|apiwrapper)(/|\.|_|-)|(bundle|chunk|vendor|runtime|main\.[0-9a-f]{6,})", re.I)
SKIP_KEYS = re.compile(r"^(id|_?id|guid|uuid|key|type|kind|class|classname|style|styles|css|theme|color|colou?r|"
                       r"font|fontfamily|icon|image|img|src|url|href|link|path|file|filename|poster|thumbnail|"
                       r"audio|video|media|duration|width|height|x|y|left|top|lang|language|locale|version|"
                       r"settings|config|options|layout|template|animation|transition|easing|alt|aria.*|"
                       r"tracking|completion|score|points|weight|status|created|updated|author|date)$", re.I)
HEADING_KEYS = re.compile(r"^(title|heading|header|headline|name|label|caption|chapter|section|lesson)$", re.I)
QUIZ_WORDS = re.compile(r"quiz|question|assessment|knowledge.?check|\bmcq\b|\bmrq\b|\btest\b|\bexam\b|survey|frage|prüfung|"
                        r"multiple.?choice|true.?false|matching|drag.?and.?drop|fill.?in", re.I)
QUIZ_KEYS = re.compile(r"^(questions?|answers?|choices?|options?|distractors?|correct.*|is_?correct|feedback.*|"
                       r"incorrect.*|attempts?|passing.*|mastery.*)$", re.I)
LANG_TOKENS = {"en": re.compile(r"(^|[^a-z])(en|eng|english|en-us|en-gb|en_us|en_gb)([^a-z]|$)", re.I),
               "de": re.compile(r"(^|[^a-z])(de|deu|ger|german|deutsch|de-de|de_de)([^a-z]|$)", re.I)}
BLOCK_TAGS = re.compile(r"</?(p|div|li|ul|ol|br|h[1-6]|tr|td|th|section|article|blockquote)\b[^>]*>", re.I)


KEPT = "kept"
QUIZ = "quiz"
SETTING = "settings field"
LABEL = "not a sentence (label, button, code)"
LANGUAGE = "other language"
REPEATED = "repeated"
LONE_HEADING = "heading without text under it"


@dataclass
class Piece:
    """One text found in a package and what happened to it (the extraction report lists them)."""
    kind: str        # "h" heading | "p" paragraph
    text: str
    file: str        # the package's file it is in (path inside the package)
    where: str       # where in that file (e.g. course.modules[0].components[2].body)
    outcome: str = KEPT   # KEPT, or why it was left out: QUIZ, SETTING, LABEL, LANGUAGE, REPEATED, LONE_HEADING
    detail: str = ""      # e.g. the settings field's name, the language

    @property
    def words(self) -> int:
        """How many words the text has."""
        return len(self.text.split())


@dataclass
class Course:
    """One e-learning package and what was made from it."""
    folder: Path                                   # the unpacked package (where its manifest is)
    title: str = ""
    language: str = ""
    blocks: list[tuple[str, str]] = field(default_factory=list)   # ("h" | "p", text), in page order
    pieces: list[Piece] = field(default_factory=list)              # every text found, kept or left out (why)
    files: list[dict] = field(default_factory=list)                # every file of the package: its role, what happened
    quizzes: int = 0                               # quiz parts left out
    other_language: int = 0                        # text parts left out for their language
    videos: list[Path] = field(default_factory=list)
    captions: list[Path] = field(default_factory=list)
    pictures: list[Path] = field(default_factory=list)
    attachments: list[Path] = field(default_factory=list)
    name: str = ""                                 # its folder under data/input/_scorm (plan)
    text_file: str = ""                            # the course text made from it, under data/input ('' = too little)
    made_from: dict[str, str] = field(default_factory=dict)   # package file -> what was made of it, under data/input
    made: list[Path] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)


# --- where the packages are -----------------------------------------------------------------------------------
def out_dir() -> Path:
    """data/input/_scorm: what is made from the packages."""
    return config.INPUT_DIR / OUT


def _safe_members(z: zipfile.ZipFile, target: Path) -> list[zipfile.ZipInfo]:
    """The files of a zip that unpack inside `target` (no '..', no absolute paths), Mac and Windows junk left out."""
    out = []
    root = target.resolve()
    for info in z.infolist():
        name = info.filename.replace("\\", "/")
        if info.is_dir() or "__MACOSX/" in name or Path(name).name.startswith("._") or Path(name).name.lower() in (
                ".ds_store", "thumbs.db", "desktop.ini"):
            continue
        dest = (target / name).resolve()
        if root not in dest.parents:
            log.warning("left out %s: it would unpack outside its folder", name)
            continue
        out.append(info)
    return out


def _zip_has_course(z: zipfile.ZipFile) -> bool:
    names = [n.replace("\\", "/").lower() for n in z.namelist()]
    return any(n.rsplit("/", 1)[-1] in MANIFESTS for n in names) or any(n.endswith(".zip") for n in names)


def _unpack(zip_path: Path, target: Path, depth: int = 0) -> None:
    """A .zip into `target`; zips inside it into folders of the same name, down to 4 levels."""
    with zipfile.ZipFile(zip_path) as z:
        members = _safe_members(z, target)
        if sum(m.file_size for m in members) > MAX_UNPACK:
            raise ValueError(f"{zip_path.name} would unpack to more than {MAX_UNPACK // 1024 ** 3} GB")
        for m in members:
            z.extract(m, target)
    if depth >= 4:
        return
    for inner in sorted(target.rglob("*.zip")):
        if not inner.exists():   # already unpacked one level down
            continue
        try:
            with zipfile.ZipFile(inner) as z:
                if not _zip_has_course(z):
                    continue
            _unpack(inner, inner.with_suffix(""), depth + 1)
            inner.unlink()
        except (zipfile.BadZipFile, ValueError, OSError) as e:
            log.warning("could not unpack %s: %s", inner.name, e)


def _stamp(path: Path) -> str:
    st = path.stat()
    return f"{st.st_size}:{int(st.st_mtime)}"


def unpack_zips() -> None:
    """Every .zip in data/input with a course in it (also in a zip inside), unpacked once into _scorm/.packages."""
    base = out_dir() / UNPACKED
    for zp in sorted(config.INPUT_DIR.rglob("*.zip")):
        if out_dir() in zp.parents:
            continue
        try:
            with zipfile.ZipFile(zp) as z:
                if not _zip_has_course(z):
                    continue
        except (zipfile.BadZipFile, OSError):
            continue
        rel = zp.relative_to(config.INPUT_DIR).with_suffix("")
        target = base / rel
        done = target / ".from"
        if done.exists() and done.read_text(encoding="utf-8") == _stamp(zp):
            continue
        shutil.rmtree(target, ignore_errors=True)
        target.mkdir(parents=True)
        try:
            _unpack(zp, target)
        except (zipfile.BadZipFile, ValueError, OSError) as e:
            log.warning("could not unpack %s: %s", zp.name, e)
            continue
        done.write_text(_stamp(zp), encoding="utf-8")
        log.info("unpacked %s", rel.as_posix())


def package_folders() -> list[Path]:
    """Every folder in data/input that holds a course's manifest (unpacked zips included), outermost only."""
    found: list[Path] = []
    for name in MANIFESTS:
        found += [p.parent for p in config.INPUT_DIR.rglob(name) if p.is_file()]
    made = out_dir()
    found = sorted({f for f in found if not (made in f.parents and UNPACKED not in f.relative_to(made).parts[:1])
                    and not {x.lower() for x in f.parts} & documents.JUNK_DIRS})
    return [f for f in found if not any(o in f.parents for o in found)]


def inside_package(path: Path) -> bool:
    """A file of a course package itself (its player, data, original videos) or of an unpacked .zip: the other
    steps leave it alone (they read what prepare() made of it)."""
    return (out_dir() / UNPACKED) in path.parents or any(folder in path.parents for folder in _folders_now())


_FOLDERS: dict[str, list[Path]] = {}


def _folders_now() -> list[Path]:
    key = str(config.INPUT_DIR)
    if key not in _FOLDERS:
        _FOLDERS[key] = package_folders() if config.INPUT_DIR.exists() else []
    return _FOLDERS[key]


# --- the manifest -------------------------------------------------------------------------------------------
def _local(tag: str) -> str:
    return tag.split("}")[-1] if isinstance(tag, str) else ""


def manifest_facts(folder: Path) -> tuple[str, str]:
    """(the course's title, its language code or '') from its manifest."""
    for name in MANIFESTS:
        path = folder / name
        if not path.exists():
            continue
        try:
            root = ElementTree.parse(path).getroot()   # noqa: S314 - a local file the person put there
        except ElementTree.ParseError:
            continue
        title = ""
        for el in root.iter():
            if _local(el.tag) in ("organization", "activity", "course"):
                t = next((c for c in el.iter() if _local(c.tag) in ("title", "name")), None)
                text = " ".join("".join(t.itertext()).split()) if t is not None else ""
                if text:
                    title = text
                    break
        lang = next((" ".join("".join(el.itertext()).split()) for el in root.iter() if _local(el.tag) == "language"), "")
        return title, lang[:2].lower()
    return "", ""


# --- the course's text ----------------------------------------------------------------------------------
def _paragraphs(value: str) -> list[str]:
    """A text from the data (often HTML) as clean paragraphs."""
    text = BLOCK_TAGS.sub("\n", value)
    text = re.sub(r"<[^>]+>", " ", text)
    return [p for p in (" ".join(html.unescape(x).split()) for x in text.split("\n")) if p]


def _is_quiz(obj: dict) -> bool:
    """A quiz part: its type says so, or it has a question with answers, or answers with the right one marked.
    (A lesson with a title and a list of items is not one.)"""
    keys = {str(k).lower() for k in obj}
    kind = " ".join(str(obj.get(k, "")) for k in ("type", "kind", "component", "_component", "blockType", "category")
                    if isinstance(obj.get(k), str))
    if QUIZ_WORDS.search(kind):
        return True
    question = any(re.match(r"^(question|questiontext|prompt|stem|frage)$", k) for k in keys)
    options = any(re.match(r"^(answers?|options?|choices?|distractors?|antworten)$", k) for k in keys)
    marked = any(documents.CORRECT_KEYS.match(k) for k in keys) or any(
        isinstance(o, dict) and any(documents.CORRECT_KEYS.match(str(x)) for x in o)
        for v in obj.values() if isinstance(v, list) for o in v)
    return (question and (options or marked)) or (options and marked)


def _decoded(s: str) -> Any:
    """Data hidden in a string: JSON, or base64 of JSON (some tools keep the whole course so). None when it is not."""
    t = s.strip()
    if t[:1] in "[{" and t[-1:] in "]}":
        try:
            return json.loads(t)
        except ValueError:
            return None
    if len(t) > 100 and re.fullmatch(r"[A-Za-z0-9+/=\s]+", t[:2000]):
        try:
            raw = base64.b64decode(t, validate=False)
            return json.loads(raw.decode("utf-8"))
        except (binascii.Error, ValueError, UnicodeDecodeError):
            return None
    return None


class _Walker:
    """Headings and paragraphs from a course's data, in order; quizzes and settings left out. Every text it meets is
    kept as a Piece with what happened to it."""

    def __init__(self) -> None:
        self.pieces: list[Piece] = []
        self.quizzes = 0
        self.file = ""

    def _texts(self, obj: Any, where: str, outcome: str, detail: str = "") -> None:
        """The texts under a part that is left out whole (a quiz, a settings field), for the report."""
        if isinstance(obj, dict):
            for k, v in obj.items():
                self._texts(v, f"{where}.{k}", outcome, detail)
        elif isinstance(obj, list):
            for i, v in enumerate(obj):
                self._texts(v, f"{where}[{i}]", outcome, detail)
        elif isinstance(obj, str):
            inner = _decoded(obj)
            if inner is not None:
                self._texts(inner, where, outcome, detail)
                return
            for p in _paragraphs(obj):
                if len(p.split()) >= 2 and documents.natural_ratio(p) >= 0.5:
                    self.pieces.append(Piece("p", p, self.file, where, outcome, detail))

    def walk(self, obj: Any, key: str = "", where: str = "") -> None:
        if isinstance(obj, dict):
            if _is_quiz(obj):
                self.quizzes += 1
                self._texts(obj, where, QUIZ)
                return
            for k, v in obj.items():
                k = str(k)
                here = f"{where}.{k}" if where else k
                if QUIZ_KEYS.match(k):
                    self._texts(v, here, QUIZ)
                elif SKIP_KEYS.match(k):
                    self._texts(v, here, SETTING, k)
                else:
                    self.walk(v, k, here)
        elif isinstance(obj, list):
            for i, v in enumerate(obj):
                self.walk(v, key, f"{where}[{i}]")
        elif isinstance(obj, str):
            inner = _decoded(obj)
            if inner is not None:
                self.walk(inner, key, where)
                return
            for p in _paragraphs(obj):
                self.add(p, where, heading=bool(HEADING_KEYS.match(key)))

    def add(self, p: str, where: str, heading: bool = False) -> None:
        """One text: a heading, a paragraph, or a label (left out; listed when it has two words or more)."""
        if heading and len(p) <= 120 and documents.natural_ratio(p) >= 0.5:
            self.pieces.append(Piece("h", p, self.file, where))
        elif documents.is_natural_text(p):
            self.pieces.append(Piece("p", p, self.file, where))
        elif len(p.split()) >= 2:
            self.pieces.append(Piece("p", p, self.file, where, LABEL))


def _data_files(folder: Path) -> list[Path]:
    """The package's files that may hold its text, in a stable order (pages and data before scripts)."""
    out = []
    for p in sorted(folder.rglob("*")):
        rel = p.relative_to(folder).as_posix()
        if not p.is_file() or p.suffix.lower() not in DATA_EXT or p.name.lower() in MANIFESTS:
            continue
        if p.suffix.lower() == ".js" and (PLAYER.search(rel) or documents.LIBRARY.search(p.name)):
            continue
        out.append(p)
    return sorted(out, key=lambda p: (p.suffix.lower() == ".js", -p.stat().st_size))


def _read_script(raw: str, walker: _Walker) -> None:
    """Data in a script: objects, arrays, and long strings of JSON or base64 JSON."""
    decoder = json.JSONDecoder()
    covered = -1
    for m in re.finditer(r"[=(:,]\s*([\[{\"'])", raw):
        if m.start(1) < covered:
            continue
        if m.group(1) in "\"'":
            end = raw.find(m.group(1), m.start(1) + 1)
            if end > m.start(1) + 100:
                inner = _decoded(raw[m.start(1) + 1:end])
                if inner is not None:
                    walker.walk(inner, where=f"script data at character {m.start(1)}")
                    covered = end
            continue
        try:
            obj, length = decoder.raw_decode(raw[m.start(1):])
        except ValueError:
            continue
        covered = m.start(1) + length
        walker.walk(obj, where=f"script data at character {m.start(1)}")


def _read_file(path: Path, walker: _Walker) -> None:
    raw = path.read_text(encoding="utf-8-sig", errors="replace")
    ext = path.suffix.lower()
    if ext == ".json":
        try:
            walker.walk(json.loads(raw))
        except ValueError:
            return
    elif ext == ".xml":
        try:
            walker.walk(documents._xml_to_data(ElementTree.fromstring(raw)))   # noqa: SLF001, S314
        except ElementTree.ParseError:
            return
    elif ext == ".js":
        _read_script(raw, walker)
    else:   # a page: its own text and the data in its own scripts (not the player it loads)
        page = documents._HTMLText()   # noqa: SLF001 - the same page reader as for other documents
        page.feed(raw)
        for n, line in enumerate(page.lines, 1):
            for p in _paragraphs(line):
                walker.add(p, f"page line {n}")
        for script in page.scripts:
            _read_script(script, walker)


def _mark_languages(pieces: list[Piece]) -> None:
    """Only the parts in KNOWLEDGE_LANGS stay: each paragraph by its own words, a short one and a heading by the
    paragraphs around it. The others are marked LANGUAGE."""
    langs = [documents.detect_language(p.text) if p.kind == "p" else "unknown" for p in pieces]
    last = "unknown"
    for i, lang in enumerate(langs):   # short parts take the language of what comes before (else after)
        if lang == "unknown":
            langs[i] = last
        else:
            last = lang
    nxt = "unknown"
    for i in range(len(langs) - 1, -1, -1):
        if langs[i] == "unknown":
            langs[i] = nxt
        else:
            nxt = langs[i]
    keep = set(config.KNOWLEDGE_LANGS)
    for piece, lang in zip(pieces, langs, strict=True):
        if lang not in keep and lang != "unknown":
            piece.outcome, piece.detail = LANGUAGE, lang


def _mark_tidy(pieces: list[Piece], title: str = "") -> None:
    """Each text once (players repeat titles and buttons; the course title is the text's own title), and no heading
    without text under it: a heading stays when a paragraph follows it, or a heading and then a paragraph (a chapter
    and its first section); a run of three headings is a menu."""
    seen: set[str] = {title.lower()} if title else set()
    for p in pieces:
        if p.text.lower() in seen:
            p.outcome = REPEATED
            p.detail = "the course title" if p.text.lower() == title.lower() else ""
        seen.add(p.text.lower())
    kept = [p for p in pieces if p.outcome == KEPT]
    kinds = [p.kind for p in kept] + ["", ""]
    for i, p in enumerate(kept):
        if p.kind == "h" and not (kinds[i + 1] == "p" or kinds[i + 1:i + 3] == ["h", "p"]):
            p.outcome = LONE_HEADING


def read_course(folder: Path) -> Course:
    """A package's title, text, videos, captions and pictures."""
    c = Course(folder=folder)
    c.title, c.language = manifest_facts(folder)
    walker = _Walker()
    for f in _data_files(folder):
        walker.file = f.relative_to(folder).as_posix()
        try:
            _read_file(f, walker)
        except (OSError, RecursionError) as e:
            c.notes.append(f"could not read {f.name}: {e}")
    c.quizzes = walker.quizzes
    c.pieces = walker.pieces
    candidates = [p for p in c.pieces if p.outcome == KEPT]
    _mark_languages(candidates)
    _mark_tidy([p for p in candidates if p.outcome == KEPT], c.title)
    c.other_language = sum(p.outcome == LANGUAGE for p in candidates)
    c.blocks = [(p.kind, p.text) for p in c.pieces if p.outcome == KEPT]
    if not c.title:
        c.title = next((t for k, t in c.blocks if k == "h"), "") or folder.name
    files = [p for p in sorted(folder.rglob("*")) if p.is_file()]
    c.videos = [p for p in files if p.suffix.lower() in config.MEDIA_EXT and p.stat().st_size >= MIN_MEDIA]
    c.captions = [p for p in files if p.suffix.lower() in CAPTION_EXT]
    c.pictures = [p for p in files if p.suffix.lower() in PICTURE_EXT and p.stat().st_size >= MIN_PICTURE]
    c.attachments = [p for p in files if p.suffix.lower() in ATTACHMENT_EXT
                     and (p.suffix.lower() != ".svg" or p.stat().st_size >= MIN_PICTURE)]
    c.files = _file_roles(c, files)
    return c


STRING = re.compile(r'"((?:[^"\\\n]|\\.){20,})"|\'((?:[^\'\\\n]|\\.){20,})\'')


def sentence_words(path: Path) -> int:
    """How many words of sentences a script's strings hold (a player has few; a script with the course in it many)."""
    try:
        raw = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return 0
    unique = {m.group(1) or m.group(2) for m in STRING.finditer(raw)}   # each text once: a player repeats its labels
    return sum(len(s.split()) for s in unique if documents.is_natural_text(s))


def _media_role(c: Course, f: Path, pairs: dict[Path, Path], used: dict[Path, Path]) -> tuple[str, str]:
    """A video, sound or captions file: what happened to it."""
    if f.suffix.lower() in CAPTION_EXT:
        lang = _caption_language(f)
        return "captions", (f"used as the transcript of {used[f].relative_to(c.folder).as_posix()}" if f in used
                            else f"left out: language {lang}" if lang not in config.KNOWLEDGE_LANGS
                            else "left out: no video of the same name")
    if f.stat().st_size < MIN_MEDIA:
        return "video or sound", "left out: under 1 MB (a click, jingle or animation)"
    if f in pairs:
        return "video or sound", f"used: transcript from its captions {pairs[f].relative_to(c.folder).as_posix()}"
    return "video or sound", "used: no English captions, to transcribe (pipeline --mode all)"


def _other_role(c: Course, f: Path) -> tuple[str, str]:
    """A script not read, a picture, a document, a style: what happened to it."""
    ext, size = f.suffix.lower(), f.stat().st_size
    if ext == ".js":
        what = "not read: the course player, not its content"
        sentences = sentence_words(f)
        if sentences >= 30:   # a player says little; many sentences may be the course's text
            what += f" - but it holds {sentences} words of sentences: check"
        return "player script", what
    if ext in (".xsd", ".dtd"):
        return "schema", "not read: no content"
    if ext in (".css", ".woff", ".woff2", ".ttf", ".otf", ".eot"):
        return "style or font", "not read: no content"
    if ext in PICTURE_EXT:
        return "picture", ("copied to screens: read with OCR in the documents step" if size >= MIN_PICTURE
                           else "left out: under 15 KB (an icon or button)")
    if f in c.attachments:
        return ("document" if ext != ".svg" else "picture (SVG)"), "copied to attachments: read in the documents step"
    if ext == ".svg":
        return "picture (SVG)", "left out: under 15 KB (an icon)"
    return "other", "not read"


def _file_roles(c: Course, files: list[Path]) -> list[dict]:
    """Every file of the package: what it is and what happened to it, with the words found and kept in it."""
    found: dict[str, int] = {}
    kept: dict[str, int] = {}
    for p in c.pieces:
        found[p.file] = found.get(p.file, 0) + p.words
        kept[p.file] = kept.get(p.file, 0) + (p.words if p.outcome == KEPT else 0)
    read = {f.relative_to(c.folder).as_posix() for f in _data_files(c.folder)}
    pairs = pair_captions(c.videos, c.captions)
    used = {cap: v for v, cap in pairs.items()}
    rows = []
    for f in files:
        rel, ext = f.relative_to(c.folder).as_posix(), f.suffix.lower()
        if f.name.lower() in MANIFESTS:
            role, what = "manifest", "read: title and language"
        elif rel in read:
            role = "text data" if ext in (".json", ".xml", ".js") else "page"
            what = "read" if found.get(rel) else "read: no text in it"
        elif ext in config.MEDIA_EXT or ext in CAPTION_EXT:
            role, what = _media_role(c, f, pairs, used)
        else:
            role, what = _other_role(c, f)
        rows.append({"file": rel, "role": role, "what happened": what, "size_kb": round(f.stat().st_size / 1024, 1),
                     "words found": found.get(rel, 0), "words kept": kept.get(rel, 0)})
    return rows


# --- videos and their captions ------------------------------------------------------------------------------
def _caption_language(path: Path) -> str:
    for lang, rx in LANG_TOKENS.items():
        if rx.search(path.stem):
            return lang
    text = re.sub(r"\d\d:\d\d[:.,\d]*\s*-->\s*[\d:.,]+", " ", path.read_text(encoding="utf-8-sig", errors="replace"))
    return documents.detect_language(text)


def _stem_key(path: Path) -> str:
    s = path.stem.lower()
    for rx in LANG_TOKENS.values():
        s = rx.sub(" ", s)
    return re.sub(r"[^a-z0-9]+", "", s)


def pair_captions(videos: list[Path], captions: list[Path]) -> dict[Path, Path]:
    """Each video's captions in a language of KNOWLEDGE_LANGS: by name (video1.mp4 <-> video1_en.vtt); a course with one
    video takes the captions it has."""
    wanted = [c for c in captions if _caption_language(c) in config.KNOWLEDGE_LANGS]
    out: dict[Path, Path] = {}
    for v in videos:
        match = next((c for c in wanted if _stem_key(c) == _stem_key(v)), None)
        if not match:
            match = next((c for c in wanted if _stem_key(v) in _stem_key(c) or _stem_key(c) in _stem_key(v)), None)
        if match:
            out[v] = match
    if len(videos) == 1 and videos[0] not in out and wanted:
        out[videos[0]] = wanted[0]
    return out


def _as_vtt(path: Path) -> str:
    """Captions as WebVTT (an .srt's commas in the times become dots)."""
    text = path.read_text(encoding="utf-8-sig", errors="replace").replace("\r\n", "\n")
    if path.suffix.lower() == ".srt":
        text = re.sub(r"(\d\d:\d\d:\d\d),(\d{3})", r"\1.\2", text)
    return text if text.lstrip().startswith("WEBVTT") else "WEBVTT\n\n" + text


def _link_or_copy(src: Path, dst: Path) -> None:
    if dst.exists() and dst.stat().st_size == src.stat().st_size:
        return
    dst.unlink(missing_ok=True)
    try:
        os.link(src, dst)        # the same file twice, no extra space
    except OSError:
        shutil.copy2(src, dst)


# --- what is made --------------------------------------------------------------------------------------
def _slug(text: str) -> str:
    s = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', " ", text)
    return " ".join(s.split())[:80].strip(" .") or "course"


def _markdown(c: Course) -> str:
    lines = [f"# {c.title}", ""]
    for kind, text in c.blocks:
        lines += [f"## {text}" if kind == "h" else text, ""]
    return "\n".join(lines)


def plan(c: Course, used: set[str]) -> None:
    """Where each part of a course goes under data/input/_scorm (c.name, c.text_file, c.made_from), nothing written.
    `used`: the folder names given to the courses before it (the same order gives the same names)."""
    name = _slug(c.title)
    n = 2
    while name.lower() in used:
        name = f"{_slug(c.title)} ({n})"
        n += 1
    used.add(name.lower())
    c.name, base = name, f"{OUT}/{name}"
    c.text_file = f"{base}/{name}.md" if sum(len(t.split()) for _, t in c.blocks) >= documents.MIN_WORDS else ""
    c.made_from = {}

    def rel(p: Path) -> str:
        return p.relative_to(c.folder).as_posix()
    pairs = pair_captions(c.videos, c.captions)
    for i, v in enumerate(c.videos, 1):
        label = re.sub(r"[_\-]+", " ", v.stem).strip()
        stem = f"{name} - {i:02d} {label}"[:150].strip()
        c.made_from[rel(v)] = f"{base}/{stem}{v.suffix.lower()}"
        if v in pairs:
            c.made_from[rel(pairs[v])] = f"{base}/{stem}.vtt"
    for i, p in enumerate(c.pictures, 1):
        c.made_from[rel(p)] = f"{base}/screens/{i:03d} {p.name}"
    for i, p in enumerate(c.attachments, 1):
        c.made_from[rel(p)] = f"{base}/attachments/{i:03d} {p.name}"


def write_course(c: Course, used: set[str]) -> Path:
    """The course's text, videos with captions, pictures and documents into data/input/_scorm/<course>/."""
    plan(c, used)
    target = out_dir() / c.name
    target.mkdir(parents=True, exist_ok=True)
    keep: set[Path] = set()
    if c.text_file:
        md = config.INPUT_DIR / c.text_file
        md.write_text(_markdown(c), encoding="utf-8")
        keep.add(md)
    for src, made in c.made_from.items():
        dst, original = config.INPUT_DIR / made, c.folder / src
        dst.parent.mkdir(parents=True, exist_ok=True)
        if dst.suffix == ".vtt":
            dst.write_text(_as_vtt(original), encoding="utf-8")
        else:
            _link_or_copy(original, dst)
        keep.add(dst)
    for old in target.rglob("*"):   # what an earlier version of the package left
        if old.is_file() and old not in keep:
            old.unlink()
    c.made = sorted(keep)
    return target


def prepare() -> list[Course]:
    """Every course package in data/input: unpacked, read and written to data/input/_scorm (inventory runs this)."""
    if not config.INPUT_DIR.exists():
        return []
    unpack_zips()
    _FOLDERS.clear()
    courses: list[Course] = []
    used: set[str] = set()
    for folder in _folders_now():
        c = read_course(folder)
        write_course(c, used)
        courses.append(c)
        log.info("course %s: %s words of text, %s videos (%s with captions), %s pictures; left out: %s quiz parts, "
                 "%s parts in another language", c.title, sum(len(t.split()) for _, t in c.blocks), len(c.videos),
                 len(pair_captions(c.videos, c.captions)), len(c.pictures), c.quizzes, c.other_language)
    return courses


def main() -> int:
    """Command line: find, read and write the courses; print what was made."""
    config.setup_logging()
    courses = prepare()
    if not courses:
        print(f"No e-learning package (a folder or .zip with {MANIFESTS[0]}) in {config.INPUT_DIR}")
        return 0
    for c in courses:
        words = sum(len(t.split()) for _, t in c.blocks)
        captioned = len(pair_captions(c.videos, c.captions))
        digest = hashlib.sha1(c.folder.as_posix().encode()).hexdigest()[:6]   # noqa: S324 - a label, not security
        print(f"\n{c.title}  [{digest}]\n  text: {words} words in {sum(k == 'h' for k, _ in c.blocks)} sections"
              f"{' (too little: not used)' if words < documents.MIN_WORDS else ''}\n"
              f"  videos: {len(c.videos)}, {captioned} with English captions"
              + (f"; {len(c.videos) - captioned} need transcribing (pipeline --mode all)" if len(c.videos) > captioned else "")
              + f"\n  pictures: {len(c.pictures)}\n  left out: {c.quizzes} quiz parts, {c.other_language} parts in another"
              f" language" + "".join(f"\n  note: {n}" for n in c.notes))
    print(f"\nMade in {out_dir()}. Next: uv run -m studio pipeline (--mode all for videos without captions)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
