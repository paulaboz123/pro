"""scorm_report.py: for each e-learning package, every file and every text with what happened to it and why, so the
extraction can be checked by hand (data/scorm_report.xlsx)."""
from __future__ import annotations

from test_scorm import DE, EN, QUIZ, _input

from studio.core import config
from studio.knowledge import inventory, scorm_report


def _sheet(path, name):
    from openpyxl import load_workbook
    ws = load_workbook(path)[name]
    rows = list(ws.iter_rows(values_only=True))
    return [dict(zip(rows[0], r, strict=True)) for r in rows[1:]]


def test_the_report_shows_what_was_taken_from_each_package_and_why_not(project, capsys):
    _input()
    inventory.main()                                                        # the later steps' results too
    capsys.readouterr()
    assert scorm_report.main() == 0
    printed = capsys.readouterr().out
    assert "Agile basics" in printed and "coverage: 100.0 %" in printed and "Report:" in printed
    path = config.DATA_DIR / "scorm_report.xlsx"

    courses = {r["course"]: r for r in _sheet(path, "Courses")}
    assert set(courses) == {"Agile basics", "Daily scrum", "Retrospective"}
    agile = courses["Agile basics"]
    assert agile["made in"] == "_scorm/Agile basics" and agile["words kept"] < agile["words found"]
    assert agile["quiz"] > 0 and agile["other language"] == len(DE.split()) and agile["coverage %"] == 100.0
    assert agile["videos"] == 1 and agile["videos with captions"] == 1 and agile["documents inside"] == 1
    assert "content.bundle.js" in agile["look at"]                          # sentences in a script: check
    assert "2 videos without English captions" in courses["Daily scrum"]["look at"]

    files = {(r["course"], r["file"]): r for r in _sheet(path, "Files")}
    data = files[("Agile basics", "data/course.json")]
    assert data["role"] == "text data" and data["coverage %"] == 100.0 and data["left out on purpose"] > 0
    video = files[("Agile basics", "media/intro.mp4")]
    assert video["made"] == "_scorm/Agile basics/Agile basics - 01 intro.mp4"
    assert "transcript: _scorm/Agile basics/Agile basics - 01 intro.vtt" in video["later steps"]
    assert files[("Agile basics", "resources/Handout.txt")]["later steps"].startswith("used")   # read as a document
    assert files[("Agile basics", "lib/content.bundle.js")]["check"] == "yes"
    assert not files[("Agile basics", "fonts/brand.eot")]["check"]
    assert files[("Agile basics", "(the course text)")]["later steps"].startswith("used")

    left = _sheet(path, "Left out")
    why = {r["text"]: r for r in left}
    assert why[DE]["why"] == "other language (de)" and not why[DE]["to check"]
    assert why["Agile basics"]["why"] == "repeated (the course title)"
    quiz = [r for r in left if r["text"] == QUIZ]                            # both places it is in
    assert {r["why"] for r in quiz} == {"quiz"} and {r["where"] for r in quiz} == {
        "course.modules[0].components[2].question", "course.modules[1].questions[0].text"}
    kept = {r["text"] for r in _sheet(path, "Kept")}
    assert set(EN) <= kept
