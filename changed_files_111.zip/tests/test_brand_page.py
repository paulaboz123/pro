"""The page's Company look (the settings behind the gear at the top right): single files and the .zip packages of the company's brand site go to
data/brand (only what is needed is taken from a package) and the next result uses them."""
from __future__ import annotations

import io
import zipfile

import pytest
from helpers import serve_app
from test_brand import _template

from studio.core import config
from studio.video import brand


def _png(colour: tuple[int, int, int], size: tuple[int, int] = (300, 100)) -> bytes:
    from PIL import Image
    buf = io.BytesIO()
    Image.new("RGBA", size, colour + (255,)).save(buf, "PNG")
    return buf.getvalue()


SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/></svg>'


def _packages(tmp_path):
    logos = tmp_path / "Logo package.zip"
    with zipfile.ZipFile(logos, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("Logo/CMYK/Logo_CMYK_colour_horizontal.png", _png((200, 0, 0)))     # print
        z.writestr("Logo/RGB/Logo_RGB_colour_horizontal.png", _png((11, 65, 205)))     # the one for screens
        z.writestr("Logo/RGB/Logo_RGB_white_negative.png", _png((255, 255, 255)))       # for dark backgrounds
        z.writestr("Logo/RGB/Logo_motto_RGB_colour.png", _png((0, 120, 0)))             # a variant
        z.writestr("Logo/Symbol/Symbol_RGB_colour.png", _png((11, 65, 205), (64, 64)))  # the square mark: browser tab
        z.writestr("Logo/Symbol/Symbol_CMYK_colour.png", _png((200, 0, 0), (64, 64)))
        z.writestr("Logo/Logo.eps", b"%!PS-Adobe")
        z.writestr("__MACOSX/Logo/RGB/._Logo_RGB_colour_horizontal.png", b"junk")
    masters = tmp_path / "PowerPoint master.zip"
    with zipfile.ZipFile(masters, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("PowerPoint/Presentation checklist.pptx", _template(tmp_path / "c.pptx", "111111", "222222").read_bytes())
        z.writestr("PowerPoint/Corporate Master.potx", _template(tmp_path / "m.pptx").read_bytes())
    icons = tmp_path / "PowerPoint Icons.zip"
    with zipfile.ZipFile(icons, "w", zipfile.ZIP_STORED) as z:
        z.writestr("Icons/Money.svg", SVG)
        z.writestr("Icons/Team.svg", SVG)
        z.writestr("Icons/Unsafe.svg", '<svg xmlns="http://www.w3.org/2000/svg" onload="alert(1)"></svg>')
    return logos, masters, icons


def test_the_company_look_takes_files_and_whole_packages(project, tmp_path):
    pytest.importorskip("playwright")
    from playwright.sync_api import sync_playwright
    logos, masters, icons = _packages(tmp_path)
    server, base = serve_app()
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page(viewport={"width": 1280, "height": 900})
            errors = []
            page.on("pageerror", lambda e: errors.append(str(e)))
            page.goto(base + "/")
            page.click("#settings-open")                                     # the gear at the top right
            page.wait_for_selector("#settings[open] #brand-now:has-text('No company files yet')")

            page.set_input_files("#brand-section input[data-kind=logo]", str(logos))
            page.wait_for_selector("#brand-msg:has-text('used Logo_RGB_colour_horizontal.png')")
            with zipfile.ZipFile(logos) as z:
                assert (config.BRAND_DIR / "logo.png").read_bytes() == z.read("Logo/RGB/Logo_RGB_colour_horizontal.png")
            page.wait_for_selector("#brand-msg:has-text('square mark for the browser tab')")
            with zipfile.ZipFile(logos) as z:
                assert (config.BRAND_DIR / "favicon.png").read_bytes() == z.read("Logo/Symbol/Symbol_RGB_colour.png")
            assert brand.logo().name == "logo.png" and brand.favicon().name == "favicon.png"
            page.wait_for_selector("header .brand img")                       # the logo in the page header too
            assert "/brand/favicon?v=" in page.get_attribute("link[rel=icon]", "href")   # and in the browser tab

            page.set_input_files("#brand-section input[data-kind=template]", str(masters))
            page.wait_for_selector("#brand-msg:has-text('used Corporate Master.potx')")
            assert brand.template().name == "template.potx" and config.THEME_ACCENT == "#0b41cd"

            page.set_input_files("#brand-section input[data-kind=icon]", str(icons))
            page.wait_for_selector("#brand-msg:has-text('saved 2 files')")
            assert "1 left out" in page.inner_text("#brand-msg") and set(brand.icons()) == {"money", "team"}
            assert page.locator(".brandfiles li").count() == 5
            assert "Template: template.potx" in page.inner_text("#brand-now")

            page.click(".brandfiles button[data-del='icons/team.svg']")
            page.wait_for_selector("#brand-msg:has-text('Removed icons/team.svg')")
            assert set(brand.icons()) == {"money"} and page.locator(".brandfiles li").count() == 4
            page.keyboard.press("Escape")                                       # closes like any window
            page.wait_for_selector("#settings", state="hidden")
            assert not errors, errors
            browser.close()
    finally:
        server.shutdown()
