# Lesson Studio

Architecture overview: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

A person asks in plain words and gets a lesson made **only from the company's training recordings and
documents**: an **answer with its sources**, a **document**, a **slide deck**, a **narrated video**, a
**video with two talking characters**, or **audio**. Every result is checked (facts, safety, layout, sound),
gets a verdict (OK / CHECK / FAIL), its cost, the time it took and a run card (what it was made from and with).

The product is **Claude (Amazon Bedrock EU, through the Bifrost gateway) + the Kokoro voice + HTML slides**.
Voice, slides and video are made locally and cost nothing; only Claude is paid.
Optional renderers and voices for comparison are described in [Experiments](#experiments).

## Project rules

| Rule | How the code keeps it |
|---|---|
| Claude only on Bedrock **EU** (`eu.` model ids); no OpenAI; no models of Chinese origin (also offline) | every model call refuses OpenAI and Chinese-origin ids (`safety.model_not_allowed`); the EU ids come from `.env` |
| Keys only in `.env` (never in code, the image, S3 or a chat) | `.env` is in `.gitignore` and `.dockerignore` |
| Spending lock | `DAILY_BUDGET_USD` (default 20, never above 100), `RUN_BUDGET_USD` (default 5) |
| No real-looking (photographic) presenters | not in the code; presenters are drawn (bear, fox, the company's characters as 2D parts) |
| Personal data stays in | speaker names masked before anything leaves; company pictures stay local |
| Shared only with the data owner's approval and `APP_PASSWORD` | a shared link without a password is refused |
| Costs only from measured tokens and the AWS Pricing Calculator | no guessed prices in the code (`docs/COSTS.md`) |

## How it works

```
data/input  (recordings + transcripts, documents, quizzes, e-learning packages (SCORM), description.xlsx)
   │  pipeline: read, cut into sections, describe the slides, index        (once per recording)
   ▼
web app (uv run -m studio) / uv run -m studio ask "request"
   1 understand  format, topic, length, level; off-topic requests stopped before any paid call
   2 find        meaning search + word search (BM25), each with the excerpt's search context, fused;
                 Claude keeps the excerpts that answer; none? searched again in the material's terms
   3 write       Claude writes the answer / document / storyboard from those excerpts only; an answer is
                 then checked sentence by sentence (unsupported removed, partly supported corrected)
   4 make        HTML slides (Chromium) + Kokoro voice + ffmpeg → video; or the document / deck / audio
   5 check       numbers vs sources, claim check, safety, personal data, layout, sound → verdict
   6 run card    input, sources, models, cost, time
```

## Run it locally

### Once

1. **Programs:** `ffmpeg` (and Tesseract OCR) on PATH, or their paths in `.env`. Check: `ffmpeg -version`.
2. **Python packages:** `uv sync` (or `uv add httpx python-dotenv python-docx python-pptx numpy pillow pydantic
   openpyxl pypdf kokoro-onnx playwright`, and `uv add --dev pytest ruff`).
3. **Browser for the slides:** `uv run playwright install chromium` (if blocked, the installed Edge is used).
4. **Settings:** copy `.env.bifrost.example` to `.env` and fill in the three values from the platform team:
   `BIFROST_BASE_URL`, `BIFROST_API_KEY`, `CHAT_MODEL` (the EU Sonnet id). HTTP 401: `BIFROST_AUTH_HEADER=x-bf-vk`.
5. **Voice** (~120 MB, once): `uv run -m studio tts --download`, then `uv run -m studio tts "A short test."`. If GitHub is
   blocked, download `kokoro-v1.0.int8.onnx` and `voices-v1.0.bin` from the kokoro-onnx release
   `model-files-v1.0` into `models/`.
6. **Check:** `uv run -m studio doctor --models` (every line `[OK]`) and `uv run pytest` (offline, free).

Search runs locally with Ollama's `nomic-embed-text` (`EMBED_BACKEND=ollama`), or on Bedrock Titan
(`EMBED_BACKEND=bifrost`). After changing it: `uv run -m studio index build`. If the meaning search is unavailable,
the word search alone is used and a warning is logged.

### Prepare the recordings

1. Put the videos (`.mp4`), their transcripts (`.vtt`/`.docx`, same name) and `description.xlsx`
   (`id`, `name`, `description`) into `data/input/`.
2. `uv run -m studio inventory`: set `include` to `yes` in `data/manifest.csv` for the videos to use.
3. Slide area of one video: `uv run -m studio slides --video <id> --preview`, then `SLIDE_CROP` / `SLIDE_MASK` in
   `.env` if a presenter or Teams panel covers the slide.
4. `uv run -m studio pipeline --mode easy --vision` (Claude reads the slides), then check the search:
   `uv run -m studio index search "how to join two tables" -k 5`.
5. Search contexts (once; better search): `uv run -m studio contextual` shows the price, `uv run -m studio contextual --yes`
   writes them and rebuilds the index.

### E-learning packages (SCORM, xAPI, cmi5)

Put them into `data/input/` as they are: `.zip` files (also zips inside zips) or unpacked folders. `inventory` (so
also `pipeline`) turns each into `data/input/_scorm/<course>/`: the course's text in page order (`<course>.md`, quizzes
left out, only `KNOWLEDGE_LANGS`: German parts go), its videos with their English captions as transcripts, and its
pictures (read with OCR when they have text) and the documents inside it (PDF, Word, PowerPoint, Excel). The
package's own files are not read again. Videos without English captions need `--mode all` (transcribed with Whisper).
To see what is found: `uv run -m studio scorm`.

German text, quiz questions and captions are translated into English once, when they are read (`translate.py`,
`TRANSLATE_LANGS=de` by default; kept in `data/processed/translations.json`, so nothing is paid for twice). The
course text says "Translated from German into English by AI."; the report's Kept sheet shows the original beside it.

To check what was taken and what was not, file by file: `uv run -m studio scorm_report` (after `inventory` or
`pipeline`) writes `data/scorm_report.xlsx`:

| Sheet | One row per | Look at |
|---|---|---|
| Courses | package | coverage (words kept of the course's own text), words left out by reason, `look at` |
| Files | file of a package | `what happened`, `coverage %`, `later steps` (OCR, reading, transcript); filter `check` = yes |
| Left out | text left out | `why`: quiz, other language, repeated (on purpose); settings field, label, heading without text (`to check` = yes) |
| Kept | text kept | its file and place, to compare with the package |

### Lesson Studio

`uv run -m studio app` opens http://localhost:8765.

| Tab | What it does |
|---|---|
| **Ask** | one box like a chat; pick the output (Read / Present / Watch), narrator and level, or let the words decide; while it is made, how long such a request usually takes here. Every chat is kept (`data/output/chats`), per browser |
| **Data** | what the material covers: its topics in categories, each with its sources (and the minutes in a recording), a filter, "Ask about this"; and every source (type, length, translated or not). Made by `uv run -m studio topics` (topic map per source, then one call that groups them; cached, a re-run is free) |
| **Prices & results** | spent today and in total, quality and health of the last 7 days, every result with its links and cost (Excel export) |
| **⚙ Settings** (top right) | the Company look: logo, browser tab icon, PowerPoint template, fonts, icons, pictures |

The page offers only the HTML slides tool (`PAGE_TOOLS` in `.env`: tool ids, or `all` for every tool, also those not
set up here). The renderer comparison is made from the command line (see [Experiments](#experiments)).

Requests wait in line: one is made at a time, the page shows "Waiting in line: N ahead". Each browser sees only
its own requests; at most 3 may wait per browser.

**Sharing for a test** (with the data owner's approval): `APP_PASSWORD=<long>` in `.env`, restart (the first line
says "password on"), VS Code > Ports > Forward `8765` > Port Visibility > Public. Send the address and the password.
The sign-in lasts 30 days, then the password is asked again; over https the cookies are `Secure`. Requests are
limited in size (64 KB, pictures 12 MB) and every answer carries security headers. `<address>/status` (no sign-in)
tells whether the link reaches the app; every request is logged in `data/output/app_access.log`.

## What you can ask for

| Ask for... | You get | Made by |
|---|---|---|
| a question (what is, how do I, why) | a short answer, the source of every sentence (recording, time, exact words) | `answer.py` |
| a document, lecture notes | `lesson.html` (Ctrl+P = PDF) + `lesson.md` | `lesson.py` |
| slides to present myself | `slides.pdf`, `slides.pptx` (in the company template when it is in `data/brand/`), speaker notes | `deck.py` |
| a video | `lesson_video.mp4` + `lesson_audio.mp3`; 4+ minutes: a course with chapters | `make_video.py`, `course.py` |
| two people talking | the same video, a host asks and an expert explains, two voices | `make_video.py --style dialogue` |
| something to listen to | `lesson_audio.mp3` | as video |
| a topic the material doesn't cover (brownies) | "not in the training material", no Claude call | `ask.py` |

```
uv run -m studio ask "A 3-minute video where two people talk about the daily scrum"
uv run -m studio make_video --recording 13 --minutes 2 --plan-only     # check script.md, then:
uv run -m studio make_video --rerender "data/output/<folder>"
```

To fix a word in a video: edit `storyboard.json` in its folder and `--rerender` (no model call).
Look: `STYLE=clean | illustrated | presenter`; presenters `CHARACTERS=cartoon | people`,
`CARTOON_PRESENTER=bear | parts:ai:<name>` (a company character drawn in parts, `avatar_parts.py`).
Company look: logo, PowerPoint template, fonts and `brand.json` in `data/brand/` (`uv run -m studio brand --preview`),
or on the page: ⚙ Settings (top right) > Company look > Add company files: the brand site's download as it is (one
`.zip` with zips inside, ZIP64 too) or the folder it was unpacked to ("Choose a folder", or drop it on the box). The
browser opens the packages, sorts the files (screen logo, browser tab icon, PowerPoint master, icons, fonts), sends
only those (`/api/brand/raw`, up to 100 MB each) and says where each came from and what was left out and why (print
versions, PDF, EPS, DWG, DXF, Mac copies, backgrounds, packages packed in a way a browser cannot open).
With a PowerPoint template there, "Slides to present" (`slides.pdf`, `slides.pptx`) are drawn on the template's
background: its colour or picture, logo, bars and shapes (`template_look.py`). The headings, text, charts and diagrams
stay as they are. Beside them, `slides_editable.pptx` is made in the template itself: the headings editable, each
slide's content as a picture. Videos keep their own background. `TEMPLATE_SLIDES=off` in `.env` turns it off.
On the page, "Look" beside the narrator (shown once there are company files): Default = as before the company files
(no company colours, logo or template); Domain = the company's colours, logo, font, icons and the template's background.
The page itself takes the company's colours and font (`/brand/page.css`).

Every slide of a video or presentation has a footnote with its source (the training and the time), and the page
lists the sources under each result, as under an answer.
Pronunciation: a row in `settings/pronunciation.csv` (`KPI,K P I`).

## Costs

**Per video only Claude costs money.** Every model call is logged in `cost_log.csv` with its fresh, cache-write,
cache-read and output tokens. The long instructions are cached (`PROMPT_CACHE=yes`): a cache read costs 10% of
the input price, a cache write 125%.

- **Measure:** `uv run -m studio length_costs "<a topic the recordings cover>"` makes 3, 5, 10 and 15-minute videos
  and writes `data/output/length_costs/length_costs.md` + `.xlsx` (shown in Prices & results).
  `--from 1m` extends an existing video step by step; `--report` only redoes the tables.
- **Price:** `PRICE_IN_PER_MTOK` / `PRICE_OUT_PER_MTOK` in `.env` = what the AWS Pricing Calculator's Bedrock
  entry shows (EU). Empty = list prices in `config.py` (+10% for EU ids).
- **AWS a month (optional):** an AWS Pricing Calculator export (groups Prod and Dev) in `data/aws/` is shown on
  the page.
- **Measured** (Claude only; measure again with `length_costs.py` after prompt or model changes): 1 min ~$0.20,
  3 min ~$0.69, 5 min ~$1.04, 10 min ~$1.70, 15 min ~$2.27.
- **Cheaper relevance check:** `RERANK_MODEL=<Haiku EU id>`; check the answers stay as good with `qa_eval.py`.

`uv run -m studio usage` shows today's spend against the limit; `uv run -m studio usage --steps` where the money goes, step by step. A question asked again with the same material and settings is answered from the cache ($0, `ANSWER_CACHE`). What costs what, what was cut and what stays for quality: `docs/COSTS.md`.

## Quality

| What | Command |
|---|---|
| Does everything work, with the real model (~$1) | `uv run -m studio smoke` (or `--quick`) → `data/output/smoke_report.md` |
| Answer quality on a test set (retrieval, hallucination, correctness, declines, copying) | `uv run -m studio qa_eval --draft 20`, then `uv run -m studio qa_eval` → `qa_report.html` |
| A test plan in Excel, as it is | `uv run -m studio qa_eval --set "<plan>.xlsx"` → `<plan>_results.xlsx` |
| Checks of any result (`--review`: claim by claim; `--listen`: Whisper hears the voice) | `uv run -m studio quality <folder>` / `--all` |
| Can the judge be trusted | `uv run -m studio calibrate export`, fill in your verdicts, `uv run -m studio calibrate score <file>` |
| Lessons and videos against a golden set | `uv run -m studio evaluate --draft`, then `uv run -m studio evaluate` |

Use a judge that is not the writer (`JUDGE_MODEL`, e.g. Opus when Sonnet writes). What the answers do against
hallucination, the settings and how to measure before and after: `docs/RAG_QUALITY.md`.

## Run it on AWS

One container (page, Kokoro, HTML slides, ffmpeg) in one pod on Kubernetes (EKS): `Dockerfile`, the Helm chart
`charts/proto-learning-agent/`, the GitLab pipeline `.gitlab-ci.yml` (checks, image build to ECR, GitOps image
tag bump into `main` by an auto-merged merge request). Details: `docs/DEPLOY.md`.

## Tests and code quality

```
uv run pytest                          # the product's tests (offline, stand-in models, free); -n auto: all cores
uv run pytest -m "slow or not slow"    # everything, including the long renders and the comparison
uv run --with ruff ruff check .        # style, complexity, docstrings, annotations
uv run --with mypy mypy                # types
```

What is tested and how, the layers (tests, eval gate, smoke) and how to make it faster: `docs/TESTING.md`.
Monitoring and answer evaluation in use (the page's "Quality and health", `/metrics`, alerts, the weekly test plan run):
`docs/MONITORING.md`.

## Commands (product)

| Command | What it does |
|---|---|
| `uv run -m studio app [--port 8765] [--host 0.0.0.0] [--no-browser]` | Lesson Studio |
| `uv run -m studio ask "what, how long, which level"` | one result from the terminal |
| `uv run -m studio answer "question"` / `uv run -m studio retrieval "question"` | an answer with sources / only what would be used |
| `uv run -m studio lesson "topic" --minutes 5 --level beginner` | document |
| `uv run -m studio deck "topic" --minutes 4` | slides |
| `uv run -m studio make_video "topic" --minutes 2 [--style dialogue] [--plan-only]` / `--rerender <folder>` | video |
| `uv run -m studio course "request" --minutes 8` / `--redo-chapter N <folder>` | course with chapters |
| `uv run -m studio extend <folder or 1m> --minutes 5` | a longer video built on a shorter one |
| `uv run -m studio pipeline --mode easy [--vision] [--force]` | prepare all included recordings |
| `uv run -m studio documents` / `catalog.py` / `topics.py` / `glossary.py` | what was found besides recordings / description.xlsx checked / topics per recording / terms |
| `uv run -m studio index build` / `search "..."` | rebuild / test the search |
| `uv run -m studio contextual [--yes]` | search contexts for every excerpt: price / write them (once) |
| `uv run -m studio length_costs "topic"` / `uv run -m studio aws_estimate` | cost by length / what was read from the calculator export |
| `uv run -m studio doctor [--models]` / `uv run -m studio usage` / `uv run -m studio llm` | setup check / spend / model smoke test |
| `uv run -m studio compare` | every result side by side from the run cards |

Levels: `beginner`, `intermediate`, `expert`.

## When something fails

| Message | Fix |
|---|---|
| `HTTP 401/403 ... rejected` | wrong key or model not allowed: check `.env`, ask the platform team |
| `HTTP 404 ... model id unknown` | copy the exact id from `uv run -m studio doctor --models` |
| `CERTIFICATE_VERIFY_FAILED` | company TLS inspection: `CA_BUNDLE` = the company `.pem` |
| `Can this machine reach the gateway` | VPN/proxy, or the URL works only inside the cluster |
| `Is Ollama running?` | start Ollama (search falls back to word search meanwhile) |
| `Index was built with ...` | embedding model changed: `uv run -m studio index build` |
| `Spending lock: ...` | daily or per-command limit reached; raise it only if expected (max 100/day) |
| `You already have 3 requests waiting` (HTTP 429) | wait until one of this browser's requests is finished |
| presenter visible on the slides | `SLIDE_MASK`, then `--rerender` |

## Repo map

```
studio/            the application (Python package)
  web/             web app: server, job line, views, page (app_page.html + static/)
  generation/      requests to results: understanding, answers, documents, slides, storyboards, courses
  knowledge/       knowledge base: reading recordings and documents, chunking, index, retrieval
  video/           voice, designer slides, animation, characters, video encoding
  quality/         checks, evaluation, smoke test, environment check, monitoring
  costs/           token usage, cost measurement, cost and time report (Excel)
  core/            settings, model calls, files, safety rules, run cards, result library, job timing
  experiments/     optional renderers, voices and comparisons
assets/            fonts, icons, illustrations, animation libraries
charts/            Helm chart (proto-learning-agent)
docs/              documentation (index: docs/README.md)
eval/              golden set for evaluation
experiments/       optional Node.js renderer projects
settings/          editable settings files (pronunciation, cost assumptions)
skills/            prompts
tests/             offline tests
tools/             helper scripts (check_deploy.py, add_lottie.py)
```

Every tool runs as `uv run -m studio <command>` (`uv run -m studio --list` shows them all); without a command it
starts the web app.

## Experiments

Optional renderers and voices, compared on the same content: Remotion, Remotion Pro, Manim, Revideo, Motion
Canvas, HyperFrames, ElevenLabs, generated scenery clips, and the earlier cost models. The default product path
(Kokoro + HTML slides) needs none of them and no Node.js. Usage: `docs/EXPERIMENTS.md`.
