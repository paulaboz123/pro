"""scorm.py: e-learning packages (as .zip, zips inside zips, or unpacked folders) become one course text (page order,
quizzes and German left out), videos with their English captions as transcripts, and pictures - and the package's
own files are not read again as separate documents."""
from __future__ import annotations

import base64
import io
import json
import zipfile

from studio.core import config, store
from studio.knowledge import inventory, scorm

MANIFEST = """<?xml version="1.0" encoding="UTF-8"?>
<manifest identifier="m1" version="1.2" xmlns="http://www.imsproject.org/xsd/imscp_rootv1p1p2"
          xmlns:adlcp="http://www.adlnet.org/xsd/adlcp_rootv1p2">
  <metadata><schema>ADL SCORM</schema><schemaversion>1.2</schemaversion></metadata>
  <organizations default="o1"><organization identifier="o1"><title>{title}</title>
    <item identifier="i1" identifierref="r1"><title>{title}</title></item></organization></organizations>
  <resources><resource identifier="r1" type="webcontent" adlcp:scormtype="sco" href="index.html"/></resources>
</manifest>"""
EN = ["Sprint planning is the meeting where the whole team agrees on what to deliver in the coming sprint.",
      "The product owner brings the ordered backlog and explains why each item matters to the customers.",
      "The developers decide how much work fits, because they are the people who will actually do it."]
DE = "Die Sprintplanung ist das Meeting, in dem das ganze Team festlegt, was im nächsten Sprint geliefert wird und wie."
QUIZ = "Who decides how much work fits into the sprint during the planning meeting?"
VIDEO = b"\x00\x00\x00\x18ftypmp42" + b"\x00" * (1024 * 1024 + 10)   # over 1 MB: a real video, not a click
CLICK = b"ID3" + b"\x00" * 200_000
VTT_EN = "WEBVTT\n\n00:00:01.000 --> 00:00:04.000\nWelcome to the sprint planning video of this course.\n"
SRT_DE = "1\n00:00:01,000 --> 00:00:04,000\nWillkommen zum Video über die Sprintplanung in diesem Kurs.\n"


def _zip(files: dict[str, bytes | str]) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for name, data in files.items():
            z.writestr(name, data)
    return buf.getvalue()


def _picture() -> bytes:
    from PIL import Image
    buf = io.BytesIO()
    Image.effect_noise((400, 300), 60).convert("RGB").save(buf, "PNG")
    return buf.getvalue()


def _course_json() -> dict:
    return {"course": {"id": "c1", "title": "Agile basics", "modules": [
        {"id": "m1", "title": "Sprint planning", "theme": {"color": "#ff0000"}, "components": [
            {"type": "text", "body": f"<p>{EN[0]}</p><p>{EN[1]}</p>"},
            {"type": "text", "body": f"<p>{DE}</p>"},
            {"type": "mcq", "question": QUIZ, "answers": [{"text": "The developers", "correct": True},
                                                         {"text": "The manager"}]},
            {"type": "text", "body": EN[2], "src": "media/intro.mp4"}]},
        {"id": "m2", "title": "Knowledge check", "type": "assessment", "questions": [{"text": QUIZ}]}]}}


def _input():
    root = config.INPUT_DIR / "Scrum"
    # 1: a zip as the tool exports it: data in JSON, a player, fonts, a video with English and German captions
    (root / "1").mkdir(parents=True)
    (root / "1" / "Agile basics.zip").write_bytes(_zip({
        "imsmanifest.xml": MANIFEST.format(title="Agile basics"), "adlcp_rootv1p2.xsd": "<xs/>",
        "index.html": "<html><head><title>Course</title><script src='lib/player.bundle.js'></script></head>"
                      "<body><div id='app'></div></body></html>",
        "data/course.json": json.dumps(_course_json()),
        "lib/player.bundle.js": 'var ui={next:"Click here to go to the next page of the course"};' * 50,
        "fonts/brand.eot": b"\x00" * 100,
        "media/intro.mp4": VIDEO, "media/intro_en.vtt": VTT_EN, "media/intro_de.srt": SRT_DE,
        "media/click.mp3": CLICK, "images/diagram.png": _picture(), "images/icon.png": b"\x89PNG" + b"\x00" * 50,
        "resources/Handout.txt": " ".join(EN),                                   # a document inside the package
        "lib/content.bundle.js": "var t=[" + ",".join(f'"{s}"' for s in EN * 4) + "];"}))   # sentences in a player
    # 2: unpacked, the whole course as base64 JSON inside a script, two videos without captions
    data = base64.b64encode(json.dumps({"lessons": [{"title": "Daily scrum", "items": [
        {"text": "The daily scrum is a short meeting where developers inspect progress toward the sprint goal."},
        {"text": "It is held at the same time and place every working day to keep things simple for everyone."},
        {"text": "The developers plan the next day together and raise anything that blocks them from the goal."}]}]})
        .encode()).decode()
    pkg = root / "2" / "Daily scrum"
    (pkg / "scormcontent").mkdir(parents=True)
    (pkg / "imsmanifest.xml").write_text(MANIFEST.format(title="Daily scrum"), encoding="utf-8")
    (pkg / "scormcontent" / "data.js").write_text(f'window.courseData = "{data}";', encoding="utf-8")
    for n in ("a", "b"):
        (pkg / "scormcontent" / f"lesson_{n}.mp4").write_bytes(VIDEO)
    # 3: a zip inside a zip
    (root / "3").mkdir()
    inner = _zip({"imsmanifest.xml": MANIFEST.format(title="Retrospective"),
                  "content.json": json.dumps({"pages": [{"heading": "Retrospective", "paragraphs": [
                      "In the retrospective the team looks back at the sprint and agrees on improvements to try next.",
                      "Everyone speaks openly about what went well and what should change in the next sprint.",
                      "The team picks one or two changes and checks at the next retrospective whether they helped."]}]})})
    (root / "3" / "Export.zip").write_bytes(_zip({"Retrospective SCORM.zip": inner, "readme.txt": "export"}))
    return root


def test_packages_become_a_course_text_videos_with_captions_and_pictures(project):
    _input()
    courses = {c.title: c for c in scorm.prepare()}
    assert set(courses) == {"Agile basics", "Daily scrum", "Retrospective"}
    out = config.INPUT_DIR / "_scorm"

    text = (out / "Agile basics" / "Agile basics.md").read_text(encoding="utf-8")
    assert text.startswith("# Agile basics") and "## Sprint planning" in text
    assert all(p in text for p in EN) and text.index(EN[0]) < text.index(EN[2])       # every part, in page order
    assert DE not in text and courses["Agile basics"].other_language == 1             # German left out
    assert QUIZ not in text and courses["Agile basics"].quizzes >= 2                 # quizzes not in the course text
    questions = (out / "Agile basics" / "Agile basics - questions.md").read_text(encoding="utf-8")
    assert f"Question: {QUIZ}\nAnswer: The developers" in questions and "The manager" not in questions   # right one only
    assert "Click here" not in text and "#ff0000" not in text                          # the player and settings
    video = out / "Agile basics" / "Agile basics - 01 intro.mp4"
    assert video.read_bytes() == VIDEO
    assert (out / "Agile basics" / "Agile basics - 01 intro.vtt").read_text(encoding="utf-8") == VTT_EN   # English
    assert not list((out / "Agile basics").glob("*click*"))                           # a click sound is not a recording
    assert [p.name for p in (out / "Agile basics" / "screens").iterdir()] == ["001 diagram.png"]   # no icon

    daily = (out / "Daily scrum" / "Daily scrum.md").read_text(encoding="utf-8")
    assert daily.count("Daily scrum\n") == 1 and "same time and place" in daily    # base64 data in a script
    assert "## Daily scrum" not in daily                                              # the course title once
    assert sorted(p.name for p in (out / "Daily scrum").glob("*.mp4")) == [
        "Daily scrum - 01 lesson a.mp4", "Daily scrum - 02 lesson b.mp4"]
    assert not list((out / "Daily scrum").glob("*.vtt"))                              # to be transcribed
    assert "looks back at the sprint" in (out / "Retrospective" / "Retrospective.md").read_text(encoding="utf-8")

    again = {c.title: c for c in scorm.prepare()}                                       # run again: the same, no doubles
    assert set(again) == set(courses) and len(list((out / "Agile basics").glob("*.mp4"))) == 1


def test_the_pipeline_reads_the_course_not_the_package_files(project):
    _input()
    assert inventory.main() == 0
    rows = store.read_manifest()
    files = {r.get("source_file") or r.get("video_file") or r.get("transcript_file") for r in rows}
    assert "_scorm/Agile basics/Agile basics.md" in files
    docs = {r["source_file"]: r for r in rows if r["media_type"] == "document"}
    assert docs["_scorm/Agile basics/Agile basics.md"]["include"] == "yes"
    assert docs["_scorm/Agile basics/Agile basics.md"]["lang"] == "en"
    videos = {r["video_file"]: r for r in rows if r["media_type"] == "video"}
    assert set(videos) == {"_scorm/Agile basics/Agile basics - 01 intro.mp4", "_scorm/Daily scrum/Daily scrum - 01 lesson a.mp4",
                           "_scorm/Daily scrum/Daily scrum - 02 lesson b.mp4"}
    assert videos["_scorm/Agile basics/Agile basics - 01 intro.mp4"]["transcript_file"] == \
        "_scorm/Agile basics/Agile basics - 01 intro.vtt"                              # the captions are its transcript
    assert not videos["_scorm/Daily scrum/Daily scrum - 01 lesson a.mp4"]["transcript_file"]
    assert not any("course.json" in f or "player" in f or "data.js" in f or "intro_en" in f or "lesson_a" in f
                   for f in files if f)                                                # the package's own files: not again


def test_every_text_and_file_is_listed_with_what_happened_to_it(project):
    _input()
    scorm.unpack_zips()
    agile = next(c for c in (scorm.read_course(f) for f in scorm.package_folders()) if c.title == "Agile basics")
    why = {p.text: (p.outcome, p.detail, p.file) for p in agile.pieces}
    assert why[EN[0]] == (scorm.KEPT, "", "data/course.json")
    assert why[DE][:2] == (scorm.LANGUAGE, "de")
    assert why[QUIZ][:2] == (scorm.QUIZ, "")                                       # no known answer: left out
    assert why[f"Question: {QUIZ}\nAnswer: The developers"][0] == scorm.KEPT        # known answer: kept
    assert "The manager" not in why                                                # a wrong answer: never
    assert why["Knowledge check"][0] == scorm.QUIZ
    where = next(p.where for p in agile.pieces if p.text == EN[2])
    assert where == "course.modules[0].components[3].body"                       # where to look in the file
    found, kept = sum(p.words for p in agile.pieces), sum(p.words for p in agile.pieces if p.outcome == scorm.KEPT)
    assert 0 < kept < found
    roles = {f["file"]: (f["role"], f["what happened"]) for f in agile.files}
    assert roles["data/course.json"][0] == "text data" and roles["lib/player.bundle.js"][0] == "player script"
    assert roles["media/intro.mp4"][1].startswith("used: transcript from its captions media/intro_en.vtt")
    assert roles["media/intro_de.srt"] == ("captions", "left out: language de")
    assert roles["media/click.mp3"][1].startswith("left out: under 1 MB")
    assert roles["images/icon.png"][1].startswith("left out: under 15 KB")
    assert roles["fonts/brand.eot"][0] == "style or font" and roles["imsmanifest.xml"][0] == "manifest"
    words = {f["file"]: (f["words found"], f["words kept"]) for f in agile.files}
    assert words["data/course.json"][1] == kept


def test_documents_inside_a_package_are_read_and_scripts_with_sentences_are_flagged(project):
    _input()
    scorm.prepare()
    copied = config.INPUT_DIR / "_scorm" / "Agile basics" / "attachments" / "001 Handout.txt"
    assert copied.read_text(encoding="utf-8") == " ".join(EN)                       # read in the documents step
    agile = next(c for c in (scorm.read_course(f) for f in scorm.package_folders()) if c.title == "Agile basics")
    roles = {f["file"]: f["what happened"] for f in agile.files}
    assert roles["resources/Handout.txt"].startswith("copied to attachments")
    assert roles["lib/content.bundle.js"].endswith("words of sentences: check")   # maybe the course's text
    assert not roles["lib/player.bundle.js"].endswith("check")                     # a player's few words: fine


TTML = """<?xml version="1.0" encoding="utf-8"?><tt xmlns="http://www.w3.org/ns/ttml"><body><div>
<p begin="00:00:01.000" end="00:00:04.500">Welcome to this recorded lesson about planning a sprint with the team.</p>
<p begin="5s" dur="2.5s">The product owner explains the goal and the order of the backlog items.</p></div></body></tt>"""
DFXP_DE = TTML.replace("Welcome to this recorded lesson about planning a sprint with the team.",
                       "Willkommen zu dieser aufgezeichneten Lektion über die Planung eines Sprints mit dem Team.") \
    .replace("The product owner explains the goal and the order of the backlog items.",
             "Der Product Owner erklärt das Ziel und die Reihenfolge der Einträge im Backlog.")


def _locked(files: dict[str, str]) -> bytes:
    """A zip whose files are marked as locked with a password (it cannot be unpacked without it)."""
    b = bytearray(_zip(files))
    for sig, at in ((b"PK\x03\x04", 6), (b"PK\x01\x02", 8)):
        i = b.find(sig)
        while i >= 0:
            b[at + i] |= 1
            i = b.find(sig, i + 4)
    return bytes(b)


def test_captions_in_other_formats_long_names_locked_zips_and_old_copies(project):
    title = "A very long course title about sprint planning, reviews and retrospectives for teams " * 2
    root = config.INPUT_DIR / "Scrum"
    pkg = root / "wbt" / "lesson"
    (pkg / "wbt").mkdir(parents=True)
    (pkg / "imsmanifest.xml").write_text(MANIFEST.format(title=title.strip()), encoding="utf-8")
    (pkg / "wbt" / "lesson.mp4").write_bytes(VIDEO)
    (pkg / "wbt" / "lesson_de.dfxp").write_text(DFXP_DE, encoding="utf-8")
    (pkg / "wbt" / "lesson_en.ttml").write_text(TTML, encoding="utf-8")
    (pkg / "wbt" / "slides.json").write_text(json.dumps({"slides": [
        {"text": EN[0], "alt": "A picture of the planning board with three columns and the sprint goal.",
         "settings": {"intro": "Click the start button to begin the course and to watch the video"}},
        {"text": EN[1]}, {"text": EN[2]}]}), encoding="utf-8")
    (pkg / "videojs-vr.min.js").write_text("var m=[" + ",".join(f'"{s}"' for s in EN * 3) + "];", encoding="utf-8")
    (root / "locked.zip").write_bytes(_locked({"imsmanifest.xml": MANIFEST.format(title="Locked"), "a.json": "{}"}))
    stale = config.INPUT_DIR / "_scorm" / "Old course"
    stale.mkdir(parents=True)
    (stale / "Old course - 01 x.mp4").write_bytes(b"old")

    courses = scorm.prepare()
    assert len(courses) == 1
    c = courses[0]
    assert len(c.name) <= 50 and not stale.exists()                                 # short names; old copies gone
    made = [p for p in c.made if p.suffix == ".mp4"]
    assert len(made) == 1 and len(str(made[0].relative_to(config.INPUT_DIR))) < 160
    vtt = made[0].with_suffix(".vtt").read_text(encoding="utf-8")                   # English TTML, as WebVTT
    assert vtt.startswith("WEBVTT") and "00:00:01.000 --> 00:00:04.500\nWelcome to this recorded lesson" in vtt
    assert "00:00:05.000 --> 00:00:07.500" in vtt and "Willkommen" not in vtt
    roles = {f["file"]: f["what happened"] for f in c.files}
    assert roles["wbt/lesson_de.dfxp"] == "left out: language de"
    assert not roles["videojs-vr.min.js"].endswith("check")                         # a known library
    assert "Extract All" in scorm.problems()["Scrum/locked.zip"]                    # said why, and what to do

    from studio.knowledge import scorm_report
    _, summary = scorm_report.build()
    rows = {s["course"]: s for s in summary}
    assert "settings fields by name: settings" in rows[c.title]["look at"]
    assert "planning board with three columns" in "\n".join(t for _, t in c.blocks)   # a sentence under 'alt' is content
    assert rows["(not read)"]["package"] == "Scrum/locked.zip" and "Extract All" in rows["(not read)"]["look at"]


def test_fonts_are_not_text_and_texts_under_media_or_language_fields_are(project):
    """Seen in real packages: a font as JSON in css/fonts (thousands of glyph 'words'), the lesson's texts under
    'video' and 'lang', and an 'options' list that is not a quiz."""
    pkg = config.INPUT_DIR / "Scrum" / "wbt course"
    (pkg / "css" / "fonts").mkdir(parents=True)
    (pkg / "wbt").mkdir()
    (pkg / "imsmanifest.xml").write_text(MANIFEST.format(title="Snowflake and Power BI"), encoding="utf-8")
    (pkg / "css" / "fonts" / "Bold.json").write_text(json.dumps(
        {"glyphs": {c: {"o": "m 10 20 l 30 40 q 50 60 70 80 z"} for c in "abcdefgh"}, "familyName": "Bold"}),
        encoding="utf-8")
    (pkg / "css" / "fonts" / "Bold.svg").write_bytes(b"<svg><font>" + b"<glyph d='m 1 2'/>" * 2000 + b"</font></svg>")
    (pkg / "wbt" / "wbt.json").write_text(json.dumps({"video": {"chapters": [
        {"title": "Connecting the two tools", "text": EN[0]}, {"title": "Sharing reports", "text": EN[1]}]},
        "lang": {"en": {"intro": EN[2]}, "de": {"intro": DE}},
        "options": {"autoplay": True, "label": "Click here to start the video of this lesson"},
        "menu": {"options": [{"title": "Overview"}, {"title": "Details"}]}}), encoding="utf-8")
    c = scorm.prepare()[0]
    text = "\n".join(t for _, t in c.blocks)
    assert all(p in text for p in EN) and DE not in text and "Connecting the two tools" in text   # media and lang
    assert "Click here to start" not in text and c.quizzes == 0                                   # setup, not a quiz
    roles = {f["file"]: f for f in c.files}
    assert roles["css/fonts/Bold.json"]["role"] == "style or font" and roles["css/fonts/Bold.json"]["words found"] == 0
    assert not c.attachments                                                                      # the SVG font too
    assert not [p for p in c.pieces if p.file.startswith("css/")]


def test_a_course_kept_under_settings_is_read_a_player_setup_is_not(project):
    """Seen in real packages: the whole course under "settings" (thousands of words), beside a player's options."""
    pkg = config.INPUT_DIR / "Scrum" / "settings course"
    (pkg / "wbt").mkdir(parents=True)
    (pkg / "imsmanifest.xml").write_text(MANIFEST.format(title="Settings course"), encoding="utf-8")
    chapters = [{"title": f"Chapter {i}", "text": s} for i, s in enumerate(EN * 3)]
    (pkg / "wbt" / "wbt.json").write_text(json.dumps({
        "settings": {"chapters": chapters, "autoplay": True},
        "player": {"options": {"label": "Click here to start the video of this lesson", "volume": 0.8}}}),
        encoding="utf-8")
    c = scorm.prepare()[0]
    text = "\n".join(t for _, t in c.blocks)
    assert all(s in text for s in EN)                                             # under "settings": read
    assert "Click here to start" not in text                                     # a player's options: not
    why = {p.text: (p.outcome, p.detail) for p in c.pieces}
    assert why["Click here to start the video of this lesson"] == (scorm.SETTING, "options")


def test_slide_bullet_points_are_kept_and_the_same_data_as_a_script_is_read_once(project):
    """Seen in real packages: short phrases as on a slide, buttons beside them, and wbt.json.js = wbt.json."""
    pkg = config.INPUT_DIR / "Scrum" / "bullets"
    (pkg / "wbt").mkdir(parents=True)
    (pkg / "imsmanifest.xml").write_text(MANIFEST.format(title="Bullets"), encoding="utf-8")
    data = {"settings": {"slides": [{"title": "Why join tables", "items": [
        {"text": "Combine sales and customers"}, {"text": "Keep orders"}, {"text": "Missing keys"}],
        "button": "Next page", "image": "img/slide_01.png", "code": "x = 1; y = 2"}, {"text": EN[0]}, {"text": EN[1]},
        {"text": EN[2]}]}}
    (pkg / "wbt" / "wbt.json").write_text(json.dumps(data), encoding="utf-8")
    (pkg / "wbt" / "wbt.json.js").write_text("var wbt = " + json.dumps(data) + ";", encoding="utf-8")
    c = scorm.prepare()[0]
    text = (config.INPUT_DIR / c.text_file).read_text(encoding="utf-8")
    assert "## Why join tables\n\nCombine sales and customers\n\n- Keep orders\n\n- Missing keys" in text   # 2 words too
    assert "Next page" not in text and "slide_01" not in text and "x = 1" not in text   # button, path, code
    assert not [p for p in c.pieces if p.file == "wbt/wbt.json.js"]                    # read once
    roles = {f["file"]: f["what happened"] for f in c.files}
    assert roles["wbt/wbt.json.js"] == "not read: the same data as wbt.json"
    assert not [p for p in c.pieces if p.outcome == scorm.REPEATED]
