"""Documents of every kind in data/input: read, filtered, ingested and used like recordings."""
from __future__ import annotations

import json
import zipfile

from helpers import VTT
from PIL import Image, ImageDraw

from studio.core import config, store
from studio.generation import lesson, storyboard
from studio.knowledge import documents, index, inventory, topics, transcribe
from studio.video import make_video, render

EN = ("The Scrum Master helps the team understand Scrum theory and practice. The Product Owner orders "
      "the Product Backlog so that the most valuable work is done first. The Developers create a usable "
      "increment every Sprint and adapt their plan in the Daily Scrum. ")
DE = ("Der Scrum Master hilft dem Team, die Theorie und die Praxis von Scrum zu verstehen. Der Product Owner "
      "ordnet das Product Backlog, damit die wertvollste Arbeit zuerst erledigt wird und die Entwickler sind "
      "für das Inkrement verantwortlich, das in jedem Sprint entsteht. ")
QUIZ_PAGE = """<html><head><title>Scrum quiz</title>
<script src="quiz_data.js"></script><script src="lib/jquery.min.js"></script>
<script>var quiz = {"questions": [{"question": "Who orders the Product Backlog?",
  "answers": [{"text": "The Scrum Master"}, {"text": "The Product Owner", "correct": true},
              {"text": "The stakeholders"}], "feedback": "The Product Owner is accountable for the order."}]};
</script></head><body>
<div class="q" id="q1"><p>How long is the Daily Scrum timeboxed?</p>
<label><input type="radio" name="a1"> 15 minutes</label><label><input type="radio" name="a1"> one hour</label>
<button>Next</button></div>
<div class="q" id="q2" style="display:none"><p>Which event inspects the increment with stakeholders?</p>
<label><input type="radio" name="a2"> Sprint Review</label><label><input type="radio" name="a2"> Sprint Planning</label>
</div></body></html>"""


def _docx(path, heading, body):
    from docx import Document
    d = Document()
    d.add_heading(heading, 1)
    for _ in range(2):
        d.add_paragraph(body)
    table = d.add_table(rows=2, cols=2)
    table.cell(0, 0).text, table.cell(0, 1).text = "Role", "Accountable for"
    table.cell(1, 0).text, table.cell(1, 1).text = "Product Owner", "maximising the value of the product"
    d.save(path)


def _pptx(path):
    ns = 'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"'
    slide = lambda t: f'<p:sld xmlns:p="x" {ns}><a:p><a:r><a:t>{t}</a:t></a:r></a:p></p:sld>'  # noqa: E731
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("ppt/slides/slide1.xml", slide("Scrum events overview"))
        z.writestr("ppt/slides/slide2.xml", slide("Sprint Planning starts the Sprint. " + EN))
        z.writestr("ppt/notesSlides/notesSlide2.xml", slide("Explain that planning is collaborative."))


def _scrum_folder():
    root = config.INPUT_DIR / "scrum"
    for sub in ("Basics", "Quiz", "Quiz/lib", "Data", "de", "img"):
        (root / sub).mkdir(parents=True, exist_ok=True)
    _docx(root / "Basics" / "Scrum roles.docx", "Scrum roles", EN)
    _pptx(root / "Basics" / "Events.pptx")
    (root / "Quiz" / "quiz.html").write_text(QUIZ_PAGE, encoding="utf-8")
    (root / "Quiz" / "quiz_data.js").write_text(
        'var intro = "This quiz checks what you know about the three Scrum accountabilities and the five events.";'
        'var css = "q-item active";', encoding="utf-8")
    (root / "Quiz" / "lib" / "jquery.min.js").write_text("!function(e){var t='a b c d'}", encoding="utf-8")
    (root / "Quiz" / "artifacts.json").write_text(json.dumps({"items": [
        {"question": "What is the commitment for the Product Backlog?", "options": ["Product Goal", "Sprint Goal",
         "Definition of Done"], "correct": 0, "id": "x1", "color": "#ff0000"},
        {"question": "What is the commitment for the Increment?", "options": ["Product Goal", "Definition of Done"],
         "correct": 1}], "meta": {"version": "1.2", "author_id": "u-123"}}), encoding="utf-8")
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    ws.append(["Event", "Timebox", "Purpose"])
    for row in [["Sprint Planning", "8 hours", "plan the work of the Sprint with the whole team"],
                ["Daily Scrum", "15 minutes", "inspect progress toward the Sprint Goal and adapt the plan"],
                ["Sprint Review", "4 hours", "inspect the outcome with stakeholders and decide next steps"],
                ["Sprint Retrospective", "3 hours", "plan ways to increase quality and effectiveness"]]:
        ws.append(row)
    wb.save(root / "Data" / "Events.xlsx")
    (root / "Data" / "glossary.xml").write_text(
        "<glossary>" + "".join(f"<term><name>{n}</name><definition>{d}</definition></term>" for n, d in [
            ("Increment", "a concrete stepping stone toward the Product Goal that meets the Definition of Done"),
            ("Sprint Goal", "the single objective for the Sprint, created during Sprint Planning by the team"),
            ("Product Goal", "the long-term objective for the Scrum Team that the backlog serves")]) + "</glossary>",
        encoding="utf-8")
    (root / "de" / "Leitfaden.txt").write_text(DE * 2, encoding="utf-8")
    (root / "Basics" / "notes.md").write_text("# Notes\n\n" + EN, encoding="utf-8")
    (root / "Basics" / "notes copy.md").write_text("# Notes\n\n" + EN, encoding="utf-8")
    (root / "readme.txt").write_text("See the folders.", encoding="utf-8")
    (root / "styles.css").write_text("body { color: red }", encoding="utf-8")
    (root / "Thumbs.db").write_bytes(b"\0\0")
    Image.new("RGB", (64, 64), "red").save(root / "img" / "icon.png")
    Image.new("RGB", (900, 600), "white").save(root / "img" / "company_logo.png")
    img = Image.new("RGB", (1400, 500), "white")
    d = ImageDraw.Draw(img)
    f = render.font(40)
    for i, line in enumerate(["The Scrum Team has a Scrum Master, a Product", "Owner and Developers who work",
                              "together in short Sprints and deliver a", "usable Increment every Sprint"]):
        d.text((40, 40 + i * 100), line, font=f, fill="black")
    img.save(root / "img" / "team diagram.png")
    Image.new("RGB", (900, 600), "white").save(root / "img" / "photo.jpg")
    (root / "Basics" / "Daily meeting.vtt").write_text(VTT, encoding="utf-8")   # a recording's transcript
    return root


def test_every_file_is_read_and_filtered(project):
    _scrum_folder()
    assert inventory.main() == 0
    rows = {r.get("source_file") or r.get("transcript_file"): r for r in store.read_manifest()}
    used = {k for k, r in rows.items() if r["include"] == "yes"}
    assert used == {"scrum/Basics/Scrum roles.docx", "scrum/Basics/Events.pptx", "scrum/Quiz/quiz.html",
                    "scrum/Quiz/artifacts.json", "scrum/Data/Events.xlsx", "scrum/Data/glossary.xml",
                    "scrum/Basics/notes copy.md", "scrum/img/team diagram.png", "scrum/Basics/Daily meeting.vtt"}
    why = {k: r["check"] for k, r in rows.items()}
    assert why["scrum/de/Leitfaden.txt"] == "SKIP: language: German"
    assert why["scrum/Basics/notes.md"] == "SKIP: duplicate of scrum/Basics/notes copy.md"
    assert why["scrum/img/icon.png"].startswith("SKIP: icon/logo/decoration")
    assert why["scrum/img/company_logo.png"].startswith("SKIP: icon/logo/decoration")
    assert why["scrum/img/photo.jpg"].startswith("SKIP: image without text")
    assert why["scrum/readme.txt"].startswith("SKIP: too little text")
    assert why["scrum/styles.css"] == "SKIP: not content (.css file)"
    assert why["scrum/Thumbs.db"] == "SKIP: system file"
    assert why["scrum/Quiz/quiz_data.js"] == "SKIP: script of a page (read with that page)"
    assert why["scrum/Quiz/lib/jquery.min.js"] in ("SKIP: code library", "SKIP: script of a page (read with that page)")
    assert rows["scrum/Quiz/quiz.html"]["kind"] == "web" and "quiz: 1 questions" in why["scrum/Quiz/quiz.html"]
    assert rows["scrum/Basics/Scrum roles.docx"]["lang"] == "en"


def test_what_is_read_from_quizzes_slides_sheets_and_data(project):
    root = _scrum_folder()
    page = documents.extract(root / "Quiz" / "quiz.html")
    text = page.text
    assert page.title == "Scrum quiz"
    assert "Which event inspects the increment with stakeholders?" in text          # hidden question too
    assert "( ) Sprint Review" in text or "Sprint Review" in text
    assert "Question: Who orders the Product Backlog?" in text and "Correct: The Product Owner" in text
    assert "This quiz checks what you know" in text and "q-item active" not in text  # local script, no CSS names
    data = documents.extract(root / "Quiz" / "artifacts.json")
    assert "Correct: Product Goal" in data.text and "Correct: Definition of Done" in data.text
    assert "u-123" not in data.text and "#ff0000" not in data.text and data.note == "quiz: 2 questions"
    slides = documents.extract(root / "Basics" / "Events.pptx")
    assert [w for w, _ in slides.parts] == ["slide 1", "slide 2"] and "Notes: Explain" in slides.parts[1][1]
    sheet = documents.extract(root / "Data" / "Events.xlsx")
    assert "Event: Daily Scrum; Timebox: 15 minutes" in sheet.text
    xml = documents.extract(root / "Data" / "glossary.xml")
    assert "definition: the single objective for the Sprint" in xml.text
    doc = documents.extract(root / "Basics" / "Scrum roles.docx")
    assert doc.parts[0][0] == "Scrum roles" and "Role: Product Owner; Accountable for: maximising" in doc.text


def test_documents_become_part_of_the_knowledge_base(gateway):
    _scrum_folder()
    assert inventory.main() == 0
    for row in store.included_rows():
        if row["media_type"] == "document":
            assert documents.ingest_row(row) == "done"
    assert index.build() == 0
    segs = [s for s in store.all_segments().values() if s["kind"] == "document"]
    assert {s["where"] for s in segs} >= {"slide 2", "sheet Sheet", "page", "page data", "data", "image"}
    material, _ = lesson.format_material(segs[:3])
    assert 'Document "' in material and "Recording" not in material.split("\n")[0]
    out_dir, _ = make_video.make("who orders the product backlog", minutes=1, plan_only=True)
    sb = storyboard.load(out_dir)
    assert any("where" in v for v in sb["sources"].values())
    doc_row = next(r for r in store.available_recordings() if r.get("source_file", "").endswith(".pptx"))
    m = topics.analyse_recording(doc_row)
    assert m["kind"] == "document" and topics._where(m, {"start": "00:00", "end": "01:00"}) == "parts 1-2"


def test_other_languages_in_recordings_are_left_out(project, monkeypatch):
    (config.INPUT_DIR / "Daily DE.vtt").write_text(
        "WEBVTT\n\n" + "\n\n".join(f"00:{i:02d}:00.000 --> 00:{i:02d}:50.000\n<v Anna>{DE}</v>" for i in range(3)),
        encoding="utf-8")
    assert inventory.main() == 0
    (row,) = store.read_manifest()
    assert row["lang"] == "de" and "LANGUAGE German" in row["check"] and row["include"] == "no"
    vid = "x-video"
    store.write_json(store.video_dir(vid) / "language.json", {"lang": "de"})
    assert transcribe.needs_transcript({"video_id": vid, "video_file": "a.mp4"}) is False


def test_new_english_recordings_are_used_by_default(project):
    (config.INPUT_DIR / "Daily EN.vtt").write_text(VTT, encoding="utf-8")
    assert inventory.main() == 0
    (row,) = store.read_manifest()
    assert row["lang"] == "en" and row["include"] == "yes"
    row["include"] = "no"                       # your choice is kept on the next run
    store.write_manifest([row])
    assert inventory.main() == 0
    assert store.read_manifest()[0]["include"] == "no"


def test_language_detection():
    assert documents.detect_language(EN) == "en" and documents.detect_language(DE) == "de"
    assert documents.detect_language("Sprint Review") == "unknown"
    assert documents.detect_language("To jest krótki tekst, który nie jest po angielsku i nie ma sensu dla nas.") == "pl"


def test_interactive_quiz_is_clicked_through(project):
    import pytest
    pytest.importorskip("playwright")
    page = config.INPUT_DIR / "click.html"
    page.write_text("""<html><body><div id="box"></div><button id="next">Next</button><script>
    const qs = ["Question one: what does the Product Owner order in Scrum?",
                "Question two: who creates the usable increment in every Sprint?",
                "Question three: which event inspects the outcome with stakeholders?"];
    let i = 0; const box = document.getElementById("box");
    function show() { box.innerHTML = '<p>' + qs[i].split('').join('') + '</p><label><input type="radio"> A</label>'; }
    show(); document.getElementById("next").onclick = () => { i = Math.min(i + 1, qs.length - 1); show(); };
    </script></body></html>""".replace("qs[i].split('').join('')", "qs[i]"), encoding="utf-8")
    try:
        steps = documents.render_clickthrough(page)
    except Exception as e:   # noqa: BLE001 - no browser on this machine
        pytest.skip(f"browser not available: {e}")
    assert any("Question three" in s for s in steps)


def test_the_vision_verdict_on_an_image_is_kept_and_never_asked_again(project, monkeypatch):
    """A decorative picture (an icon, a background) is sent to the vision model once; an unchanged one never again."""
    from PIL import Image
    calls = []
    monkeypatch.setattr(documents, "describe_image", lambda p: calls.append(p) or "")
    img = config.INPUT_DIR / "icon.png"
    img.parent.mkdir(parents=True, exist_ok=True)
    Image.new("RGB", (300, 200), (10, 120, 200)).save(img)
    ex = documents.Extracted("icon", "image", [("image", "")])
    decision = (False, "image without text", "", 0)
    for _ in range(3):
        keep, reason, _, _ = documents._described(img, "icon.png", ex, decision)
        assert not keep and "decorative" in reason
    assert len(calls) == 1
    Image.new("RGB", (300, 201), (10, 120, 200)).save(img)                          # changed: asked again
    documents._described(img, "icon.png", ex, decision)
    assert len(calls) == 2
