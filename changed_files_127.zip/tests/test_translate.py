"""translate.py and its use in scorm.py: German course text, quiz questions and captions in English, translated
once (kept by hash), with the original beside it; nothing breaks when the model cannot be reached."""
from __future__ import annotations

import json

import pytest
from test_scorm import DE, EN, MANIFEST, VIDEO

from studio.core import config, llm
from studio.knowledge import scorm, scorm_report, translate

DE2 = "Die Entwickler entscheiden, wie viel Arbeit in den Sprint passt, weil sie die Arbeit am Ende selbst machen."
QUIZ_DE = "Wer entscheidet in der Planung, wie viel Arbeit in den Sprint passt und wer sie am Ende macht?"
CUES_DE = ("WEBVTT\n\n00:00:01.000 --> 00:00:04.000\nWillkommen zu diesem Kurs über die Planung eines Sprints im Team.\n\n"
           "00:00:05.000 --> 00:00:08.000\nDer Product Owner erklärt das Ziel und die Reihenfolge der Einträge.\n")


@pytest.fixture
def translator(project, monkeypatch):
    """A stand-in for the chat model: 'EN(<text>)' for every item; counts the calls."""
    calls = []

    def fake(prompt, schema, **kw):
        items = json.loads(prompt.split("\n", 1)[1])["items"]
        calls.append(items)
        assert kw["step"] == "translate" and "German" in kw["system"]
        return {"translations": [f"EN({x})" for x in items]}
    monkeypatch.setattr(llm, "chat_json", fake)
    monkeypatch.setattr(config, "TRANSLATE_LANGS", ["de"])
    return calls


def _german_course():
    pkg = config.INPUT_DIR / "Scrum" / "de course"
    (pkg / "wbt").mkdir(parents=True)
    (pkg / "imsmanifest.xml").write_text(MANIFEST.format(title="Thema"), encoding="utf-8")
    (pkg / "wbt" / "wbt.json").write_text(json.dumps({"settings": {"pages": [
        {"title": "Sprintplanung", "text": DE}, {"text": DE2}, {"text": EN[0]},
        {"type": "mcq", "question": QUIZ_DE, "answers": [{"text": "Die Entwickler", "correct": True},
                                                       {"text": "Der Manager"}]}]}}), encoding="utf-8")
    (pkg / "wbt" / "lesson.mp4").write_bytes(VIDEO)
    (pkg / "wbt" / "lesson_de.vtt").write_text(CUES_DE, encoding="utf-8")
    return pkg


def test_german_text_questions_and_captions_come_out_in_english(translator):
    _german_course()
    c = scorm.prepare()[0]
    text = (config.INPUT_DIR / c.text_file).read_text(encoding="utf-8")
    assert "Translated from German into English by AI." in text
    assert f"EN({DE})" in text and f"EN({DE2})" in text and EN[0] in text
    assert f"\n{DE}\n" not in text                                            # no German paragraph left
    assert c.title == "EN(Thema)"                                            # mostly German: the title too
    questions = (config.INPUT_DIR / c.questions_file).read_text(encoding="utf-8")
    assert f"EN(Question: {QUIZ_DE}\nAnswer: Die Entwickler)" in questions and "Manager" not in questions
    vtt = next(p for p in c.made if p.suffix == ".vtt").read_text(encoding="utf-8")
    assert "00:00:01.000 --> 00:00:04.000\nEN(Willkommen zu diesem Kurs" in vtt and "\nWillkommen" not in vtt
    roles = {f["file"]: f["what happened"] for f in c.files}
    assert roles["wbt/lesson_de.vtt"] == "used as the transcript of wbt/lesson.mp4 (translated from de)"
    piece = next(p for p in c.pieces if p.original == DE)
    assert piece.detail == "translated from de" and piece.outcome == scorm.KEPT
    assert translate.store_path().exists()

    paid = len(translator)
    scorm.prepare()                                                           # again: nothing paid twice
    assert len(translator) == paid

    _, summary = scorm_report.build()                                         # the report: from the store
    assert len(translator) == paid and summary[0]["course"] == "EN(Thema)" and summary[0]["translated words"] > 30


def test_no_translation_when_the_model_cannot_be_reached(project, monkeypatch):
    def down(*a, **k):
        raise llm.BudgetExceeded("spending lock")
    monkeypatch.setattr(llm, "chat_json", down)
    monkeypatch.setattr(config, "TRANSLATE_LANGS", ["de"])
    _german_course()
    c = scorm.prepare()[0]                                                    # no crash: German left out, as before
    assert c.title == "Thema" and DE not in "\n".join(t for _, t in c.blocks)
    assert not [p for p in c.made if p.suffix == ".vtt"]                     # the video is transcribed instead
    assert any(p.outcome == scorm.LANGUAGE for p in c.pieces)


def test_switched_off_nothing_is_sent(project, monkeypatch):
    monkeypatch.setattr(llm, "chat_json", lambda *a, **k: pytest.fail("no model call expected"))
    _german_course()                                                          # TRANSLATE_LANGS = [] in the tests
    c = scorm.prepare()[0]
    assert c.translated == 0
