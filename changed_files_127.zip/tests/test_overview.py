"""overview.py and the page's Data tab: what the knowledge base covers - topics in categories, each with its sources
(and where in a recording), the list of sources, and "Ask about this"."""
from __future__ import annotations

import json

import pytest
from helpers import get, serve_app

from studio.core import config, llm, store
from studio.knowledge import overview

TOPICS = {
    "rec-1": [{"title": "Inner and left joins", "covers": "Which rows each join keeps.", "start": "02:10", "end": "05:00",
               "level": "beginner", "depth": "solid", "request": "Explain inner and left joins"},
              {"title": "Checking row counts", "covers": "Count rows before and after a join.", "start": "05:00",
               "end": "07:30", "level": "beginner", "depth": "solid", "request": "How do I check a join?"}],
    "course-1": [{"title": "Inner and left joins", "covers": "Joins in Alteryx.", "start": "", "end": "",
                  "level": "intermediate", "depth": "deep", "request": "Joins in Alteryx"},
                 {"title": "Connecting Snowflake to Power BI", "covers": "The connector and its settings.",
                  "start": "", "end": "", "level": "intermediate", "depth": "deep",
                  "request": "How do I connect Snowflake to Power BI?"}]}


def _sources():
    md = config.INPUT_DIR / "_scorm" / "Snowflake" / "Snowflake.md"
    md.parent.mkdir(parents=True)
    md.write_text("# Snowflake and Power BI\n\nTranslated from German into English by AI.\n\nText.", encoding="utf-8")
    rows = [{"video_id": "rec-1", "include": "yes", "title": "Joining data", "media_type": "video",
             "video_file": "13. Joining data.mp4", "video_min": "42.5", "description": "How to join two tables."},
            {"video_id": "course-1", "include": "yes", "title": "Snowflake and Power BI", "media_type": "document",
             "source_file": "_scorm/Snowflake/Snowflake.md", "words": "3000"},
            {"video_id": "doc-1", "include": "yes", "title": "Style guide", "media_type": "document",
             "source_file": "guide.pdf", "words": "800"},
            {"video_id": "doc-2", "include": "no", "title": "Left out", "media_type": "document", "source_file": "x.pdf"}]
    store.write_manifest(rows)
    for r in rows:
        store.write_json(store.video_dir(r["video_id"]) / "segments.json", [{"text": "x", "start": 0, "end": 1}])
        if r["video_id"] in TOPICS:
            store.write_json(store.video_dir(r["video_id"]) / "topics.json",
                             {"summary": f"About {r['title']}.", "topics": TOPICS[r["video_id"]]})


@pytest.fixture
def grouping(project, monkeypatch):
    calls = []

    def fake(prompt, schema, **kw):
        calls.append(prompt)
        assert kw["step"] == "overview" and "s1t1: Connecting Snowflake to Power BI" in prompt
        return {"categories": [{"name": "Joining tables", "summary": "How joins work and how to check them.",
                                "topic_ids": ["s0t0", "s1t0", "s0t1"]},
                               {"name": "Connecting tools", "summary": "Snowflake and Power BI together.",
                                "topic_ids": ["s1t1"]}]}
    monkeypatch.setattr(llm, "chat_json", fake)
    _sources()
    return calls


def test_topics_in_categories_with_their_sources(grouping):
    data = overview.build()
    assert [c["name"] for c in data["categories"]] == ["Joining tables", "Connecting tools"]
    joins = data["categories"][0]["topics"][0]
    assert joins["title"] == "Inner and left joins"                          # the same topic in two sources: once
    assert [(s["title"], s["start"], s["end"]) for s in joins["sources"]] == [
        ("Joining data", "02:10", "05:00"), ("Snowflake and Power BI", "", "")]
    t = data["totals"]
    assert (t["sources"], t["recordings"], t["hours"], t["courses"], t["documents"], t["topics"], t["not_analysed"]) \
        == (3, 1, 0.7, 1, 1, 3, 1)
    src = {s["title"]: s for s in data["sources"]}
    assert src["Snowflake and Power BI"]["translated"] and src["Snowflake and Power BI"]["kind"] == "e-learning course"
    assert not src["Style guide"]["analysed"] and "Left out" not in src

    assert overview.build()["grouped"] and overview.build(live=False)["grouped"] and len(grouping) == 1   # cached
    store.write_json(store.video_dir("doc-1") / "topics.json", {"summary": "s", "topics": [
        {"title": "Fonts and colours", "covers": "c", "start": "", "end": "", "level": "beginner", "depth": "solid",
         "request": "r"}]})
    stale = overview.build(live=False)                                         # new topics, no call: by source
    assert not stale["grouped"] and [c["name"] for c in stale["categories"]][-1] == "Style guide"


def test_without_a_model_each_source_is_a_category(project, monkeypatch):
    def down(*a, **k):
        raise llm.BudgetExceeded("spending lock")
    monkeypatch.setattr(llm, "chat_json", down)
    _sources()
    data = overview.build()
    assert not data["grouped"] and [c["name"] for c in data["categories"]] == ["Joining data", "Snowflake and Power BI"]


def test_the_data_tab(grouping):
    pytest.importorskip("playwright")
    from playwright.sync_api import sync_playwright
    overview.build()                                                           # as `topics` does
    server, base = serve_app()
    try:
        code, _, body = get(base + "/api/overview")
        assert code == 200 and json.loads(body)["grouped"]
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page(viewport={"width": 1280, "height": 900})
            errors = []
            page.on("pageerror", lambda e: errors.append(str(e)))
            page.goto(base + "/")
            page.click('nav button[data-tab="data"]')
            page.wait_for_selector("#data-categories .category")
            assert "3 sources" in page.inner_text("#data-totals") and "1 source without a topic map" in page.inner_text("#data-totals")
            first = page.inner_text("#data-categories .category >> nth=0")
            assert "Joining tables" in first and "Joining data · 02:10–05:00" in first and "Snowflake and Power BI" in first
            table = page.inner_text("#data-sources").lower()
            assert "translated from german" in table and "43 min" in table and "not analysed yet" in table
            page.fill("#data-filter", "snowflake connect")
            assert page.locator("#data-categories .topic:visible").count() == 1
            page.click("#data-categories .topic:visible .askthis")
            assert page.is_visible("#tab-ask") and page.input_value("#request") == "How do I connect Snowflake to Power BI?"
            assert not errors, errors
            browser.close()
    finally:
        server.shutdown()
