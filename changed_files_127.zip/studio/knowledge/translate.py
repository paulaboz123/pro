"""
translate.py - material in another language (TRANSLATE_LANGS, default de) translated into English once, when it is
read: the app is in English. Used for the e-learning packages: their text, quiz questions and captions (scorm.py).

- the chat model (CHAT_MODEL) translates in batches of about 1,500 words: a JSON list in, a JSON list out
- product and tool names, code, numbers, abbreviations and the glossary's terms (data/glossary.csv) stay as they are
- every translation is kept in data/processed/translations.json by the text and its language: a text is never paid
  for twice, and the extraction report shows translations without a model call
- a batch that fails (the gateway, the spending lock) is left untranslated and tried again on the next run

TRANSLATE_LANGS= (empty) in .env: nothing is translated; material in other languages is left out as before.
"""
from __future__ import annotations

import hashlib
import json
import logging
from pathlib import Path

from studio.core import config, llm, store

log = logging.getLogger("translate")

BATCH_WORDS = 1500
NAMES = {"de": "German", "fr": "French", "es": "Spanish", "it": "Italian", "pl": "Polish", "nl": "Dutch",
         "pt": "Portuguese"}
SYSTEM = """You translate e-learning material from {lang} into English for an English training app.
Translate every item of the list faithfully and completely: keep its meaning, tone and form (line breaks, the
labels 'Question:', 'Answer:' and 'Explanation:'). Do not add, explain, shorten or merge anything. Keep these as they
are: product and tool names, code, file names, numbers, abbreviations{terms}. An item already in English stays as it
is. Answer with JSON {{"translations": [...]}}: exactly one English string per item, in the same order."""
SCHEMA = {"type": "object", "properties": {"translations": {"type": "array", "items": {"type": "string"}}},
          "required": ["translations"]}


def store_path() -> Path:
    """data/processed/translations.json: every translation made, by the text's hash and language."""
    return config.PROCESSED_DIR / "translations.json"


def _key(text: str, lang: str) -> str:
    return hashlib.sha256(f"{lang}\n{text}".encode()).hexdigest()[:20]


def _load() -> dict[str, str]:
    return store.read_json(store_path()) or {}


def known(texts: list[str], lang: str) -> list[str | None]:
    """The translations made before (None for a text not translated yet). No model call."""
    done = _load()
    return [done.get(_key(t, lang)) for t in texts]


def _terms() -> str:
    try:
        from studio.knowledge import glossary
        names = [r["term"] for r in glossary.terms() if r.get("term")][:150]
    except (OSError, KeyError, ValueError):
        names = []
    return f" and these terms: {', '.join(names)}" if names else ""


def _batches(texts: list[str]) -> list[list[str]]:
    out: list[list[str]] = [[]]
    words = 0
    for t in texts:
        n = len(t.split())
        if out[-1] and words + n > BATCH_WORDS:
            out.append([])
            words = 0
        out[-1].append(t)
        words += n
    return [b for b in out if b]


def translate(texts: list[str], lang: str) -> list[str | None]:
    """Each text in English (None where it could not be translated this time). Known ones come from the store;
    the others are sent to the chat model once, in batches, and kept."""
    done = _load()
    todo = list(dict.fromkeys(t for t in texts if _key(t, lang) not in done))
    if todo:
        system = SYSTEM.format(lang=NAMES.get(lang, lang), terms=_terms())
        for batch in _batches(todo):
            try:
                reply = llm.chat_json(_prompt(batch), SCHEMA, system=system, step="translate", temperature=0.0)
            except llm.LLMError as e:   # the gateway or the spending lock: the rest stays untranslated this time
                log.warning("translation stopped (%s); %s texts left for the next run", e, len(todo))
                break
            out = reply.get("translations")
            if not isinstance(out, list) or len(out) != len(batch) or not all(isinstance(x, str) and x for x in out):
                log.warning("a translation batch came back incomplete; it is tried again on the next run")
                continue
            done.update({_key(src, lang): dst.strip() for src, dst in zip(batch, out, strict=True)})
            store.write_json(store_path(), done)   # after each batch: what was paid for is never lost
    return [done.get(_key(t, lang)) for t in texts]


def _prompt(batch: list[str]) -> str:
    return "Translate these items:\n" + json.dumps({"items": batch}, ensure_ascii=False)
