"""
overview.py - what the knowledge base covers, for the page's Data tab: the topics of every source grouped into a
few categories, each topic with the sources (and places in them) that cover it, and the list of sources.

  uv run -m studio overview          # after topics: one model call groups the topics (cached; a re-run is free)

Built from what topics.py already wrote for each source (data/processed/<id>/topics.json); a source that has no
topic map yet is listed as "topics not analysed yet". The grouping is kept in data/processed/overview.json (it
travels to the server with the knowledge base) and made again only when the topics change. Without a model (the
gateway or the spending lock) each source is its own category.
"""
from __future__ import annotations

import hashlib
import json
import logging
import sys
from pathlib import Path
from typing import Any

from studio.core import config, llm, store

log = logging.getLogger("overview")

SCHEMA = {"type": "object", "properties": {"categories": {"type": "array", "items": {
    "type": "object", "properties": {
        "name": {"type": "string", "description": "2-5 words, e.g. 'Data preparation in Alteryx'"},
        "summary": {"type": "string", "description": "One sentence: what a learner finds here"},
        "topic_ids": {"type": "array", "items": {"type": "string"}}},
    "required": ["name", "summary", "topic_ids"]}}}, "required": ["categories"]}
SYSTEM = """You sort the topics of a company's training material into categories for a catalog that learners and
trainers browse to see what the material covers. Make 4-10 categories by subject (not by source or format), each
with a short plain name and one sentence on what it holds. Put every topic id into exactly one category. Use only
the topics given; invent nothing."""


def kind(row: dict) -> str:
    """recording, e-learning course, or document."""
    if row.get("media_type") == "video" or row.get("video_file"):
        return "recording"
    return "e-learning course" if str(row.get("source_file", "")).startswith("_scorm/") else "document"


def _translated(row: dict) -> bool:
    path = config.INPUT_DIR / str(row.get("source_file") or "")
    if not row.get("source_file") or path.suffix != ".md" or not path.exists():
        return False
    return "Translated from " in path.read_text(encoding="utf-8", errors="replace")[:400]


def sources() -> list[dict[str, Any]]:
    """Every source in the knowledge base, with its topic map when it has one."""
    out = []
    for r in store.available_recordings():
        m = store.read_json(store.video_dir(r["video_id"]) / "topics.json", {}) or {}
        minutes = r.get("video_min") or r.get("transcript_min") or ""
        out.append({"id": r["video_id"], "title": r.get("title", ""), "kind": kind(r),
                    "minutes": float(minutes) if str(minutes).replace(".", "", 1).isdigit() else None,
                    "words": int(r.get("words") or 0) or None, "translated": _translated(r),
                    "summary": m.get("summary") or r.get("description", ""), "topics": m.get("topics", []),
                    "analysed": bool(m.get("topics"))})
    return out


def _topics(srcs: list[dict]) -> dict[str, dict]:
    """Every topic by an id (s<source>t<topic>), with its source and place."""
    out = {}
    for i, s in enumerate(srcs):
        for j, t in enumerate(s["topics"]):
            out[f"s{i}t{j}"] = {"title": t.get("title", ""), "covers": t.get("covers", ""), "level": t.get("level", ""),
                                "depth": t.get("depth", ""), "request": t.get("request", ""),
                                "source": {"id": s["id"], "title": s["title"], "kind": s["kind"],
                                           "start": t.get("start", "") if s["kind"] == "recording" else "",
                                           "end": t.get("end", "") if s["kind"] == "recording" else ""}}
    return out


def _key(topics: dict[str, dict]) -> str:
    text = json.dumps([[k, t["title"], t["source"]["id"]] for k, t in sorted(topics.items())])
    return hashlib.sha256(text.encode()).hexdigest()[:16]


def _group(topics: dict[str, dict]) -> list[dict] | None:
    """The model's categories, as lists of topic ids (None when it cannot be asked)."""
    lines = [f"{k}: {t['title']} - {t['covers'][:160]}" for k, t in topics.items()]
    try:
        reply = llm.chat_json("TOPICS\n" + "\n".join(lines), SCHEMA, system=SYSTEM, step="overview", temperature=0.0)
    except llm.LLMError as e:
        log.warning("topics not grouped (%s): each source is its own category", e)
        return None
    cats = [c for c in reply.get("categories", []) if isinstance(c, dict) and c.get("name")]
    return cats or None


def _by_source(topics: dict[str, dict], srcs: list[dict]) -> list[dict]:
    return [{"name": s["title"], "summary": s["summary"],
             "topic_ids": [k for k, t in topics.items() if t["source"]["id"] == s["id"]]} for s in srcs if s["topics"]]


def _categories(groups: list[dict], topics: dict[str, dict]) -> list[dict]:
    """Categories with their topics; the same topic in several sources once, with all its sources."""
    out, placed = [], set()
    for g in groups:
        merged: dict[str, dict] = {}
        for tid in g.get("topic_ids", []):
            t = topics.get(str(tid))
            if not t or tid in placed:
                continue
            placed.add(tid)
            key = " ".join(t["title"].lower().split())
            if key in merged:
                merged[key]["sources"].append(t["source"])
            else:
                merged[key] = {k: v for k, v in t.items() if k != "source"} | {"sources": [t["source"]]}
        if merged:
            out.append({"name": g["name"], "summary": g.get("summary", ""), "topics": list(merged.values())})
    rest = [k for k in topics if k not in placed]
    if rest:   # topics the grouping left out
        out += _categories([{"name": "Other topics", "summary": "", "topic_ids": rest}], topics)
    return out


def path() -> Path:
    """data/processed/overview.json: the grouping, by the topics it was made from."""
    return config.PROCESSED_DIR / "overview.json"


def build(live: bool = True) -> dict[str, Any]:
    """The overview: categories with topics and their sources, every source, and the totals. live=False: no model
    call (the grouping made before if the topics did not change, else each source its own category)."""
    srcs = sources()
    topics = _topics(srcs)
    key = _key(topics)
    saved = store.read_json(path(), {}) or {}
    groups = saved.get("groups") if saved.get("key") == key else None
    if groups is None and topics and live:
        groups = _group(topics)
        if groups:
            store.write_json(path(), {"key": key, "groups": groups})
    grouped = groups is not None
    cats = _categories(groups if groups else _by_source(topics, srcs), topics)
    minutes = sum(s["minutes"] or 0 for s in srcs if s["kind"] == "recording")
    return {"categories": cats, "grouped": grouped,
            "sources": [{k: v for k, v in s.items() if k != "topics"} | {"topics": len(s["topics"])} for s in srcs],
            "totals": {"sources": len(srcs), "recordings": sum(s["kind"] == "recording" for s in srcs),
                       "hours": round(minutes / 60, 1), "courses": sum(s["kind"] == "e-learning course" for s in srcs),
                       "documents": sum(s["kind"] == "document" for s in srcs),
                       "topics": sum(len(c["topics"]) for c in cats),
                       "not_analysed": sum(not s["analysed"] for s in srcs)}}


def main() -> int:
    """Command line: group the topics (once) and print the categories."""
    config.setup_logging()
    data = build(live=True)
    t = data["totals"]
    print(f"{t['sources']} sources ({t['recordings']} recordings, {t['hours']} h; {t['courses']} e-learning courses; "
          f"{t['documents']} documents), {t['topics']} topics" + ("" if data["grouped"] else " (not grouped: no model)"))
    for c in data["categories"]:
        print(f"\n{c['name']} ({len(c['topics'])} topics)\n  {c['summary']}")
    if t["not_analysed"]:
        print(f"\n{t['not_analysed']} sources have no topic map yet: uv run -m studio topics, then this again")
    return 0


if __name__ == "__main__":
    sys.exit(main())
