"""template_look.py - the company's PowerPoint template behind the slides of a presentation ("Slides to present":
slides.pdf and slides.pptx). Only the background comes from it: the background colour, gradient or picture, and the
pictures (logo, icons) and simple shapes (bars, lines, waves) of its master and layouts. Everything on the slide - the
heading, the text, the charts, the diagrams, the fonts, where they are - stays the slides' own. Videos keep their own
background.

Taken from the template's title layout (behind the title slide) and its title-and-content layout (behind the others),
the same two that brand.write_pptx uses. Left out (counted in "skipped"): text that is not a placeholder, EMF/WMF
pictures, tables and charts of the template. slides_editable.pptx, made in the template itself, has everything.

TEMPLATE_SLIDES=off in .env: the presentations keep the slides' own background (with the company's colours and logo).
"""
from __future__ import annotations

import colorsys
import hashlib
import html
import logging
import math
from functools import lru_cache
from pathlib import Path
from typing import Any

from studio.core import config

log = logging.getLogger("template_look")

A = "http://schemas.openxmlformats.org/drawingml/2006/main"
P = "http://schemas.openxmlformats.org/presentationml/2006/main"
R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
NS = {"a": A, "p": P, "r": R}
CANVAS_W, CANVAS_H = 1280, 720          # the slides' design size (slides_html.W, H): a 4:3 template is stretched
WEB_PICTURES = {"image/png": ".png", "image/jpeg": ".jpg", "image/gif": ".gif", "image/svg+xml": ".svg"}
CLR_MAP = {"bg1": "lt1", "tx1": "dk1", "bg2": "lt2", "tx2": "dk2"}   # PowerPoint's usual mapping
TITLE_TYPES = ("title", "ctrTitle")
LEAD_H = 34                              # room for the heading's lead line under the title box
FOOT_H = 22                              # room for the source footnote under the content


def _q(tag: str) -> str:
    prefix, name = tag.split(":")
    return f"{{{NS[prefix]}}}{name}"


def _int(v: Any, default: int = 0) -> int:
    try:
        return int(v)
    except (TypeError, ValueError):
        return default


# --- colours -------------------------------------------------------------------------------------------------
def _hex(rgb: tuple[float, float, float]) -> str:
    return "#" + "".join(f"{max(0, min(255, round(c))):02x}" for c in rgb)


def _modify(h: str, el: Any) -> str:
    """The colour after PowerPoint's changes: lumMod/lumOff (lighter or darker in HSL), tint, shade."""
    r, g, b = (float(int(h[i:i + 2], 16)) for i in (1, 3, 5))
    for m in el:
        name, val = m.tag.split("}")[-1], _int(m.get("val"), 100000) / 100000
        if name in ("lumMod", "lumOff"):
            hh, ll, ss = colorsys.rgb_to_hls(r / 255, g / 255, b / 255)
            ll = ll * val if name == "lumMod" else ll + val
            r, g, b = (c * 255 for c in colorsys.hls_to_rgb(hh, max(0, min(1, ll)), ss))
        elif name == "tint":
            r, g, b = (c + (255 - c) * (1 - val) for c in (r, g, b))
        elif name == "shade":
            r, g, b = (c * val for c in (r, g, b))
    return _hex((r, g, b))


def colour(holder: Any, scheme: dict[str, str]) -> str:
    """'#rrggbb' of the colour in a fill or colour reference (srgbClr, schemeClr, sysClr, prstClr), or ''."""
    if holder is None:
        return ""
    for el in holder:
        name = el.tag.split("}")[-1]
        base = ""
        if name == "srgbClr":
            base = "#" + str(el.get("val", "")).lower()
        elif name == "schemeClr":
            key = str(el.get("val", ""))
            base = scheme.get(key) or scheme.get(CLR_MAP.get(key, ""), "")
        elif name == "sysClr":
            base = "#" + str(el.get("lastClr", "")).lower()
        elif name == "prstClr":
            base = {"white": "#ffffff", "black": "#000000"}.get(str(el.get("val")), "")
        if len(base) == 7:
            try:
                return _modify(base, el)
            except ValueError:
                return ""
    return ""


def scheme_of(master: Any, theme: dict[str, str]) -> dict[str, str]:
    """The theme's colours by every name a shape may use: dk1 ... accent6, and bg1/tx1/bg2/tx2 as the master maps them."""
    out = dict(theme)
    cmap = master.find(_q("p:clrMap"))
    for alias, target in CLR_MAP.items():
        name = cmap.get(alias, target) if cmap is not None else target
        if name in theme:
            out[alias] = theme[name]
    return out


# --- fills, pictures and shapes ------------------------------------------------------------------------------------
class _Reader:
    """Reads one layout and its master: pictures are saved once to data/output/.brand/template_look."""

    def __init__(self, scheme: dict[str, str]) -> None:
        self.scheme = scheme
        self.skipped: list[str] = []
        self.folder = config.OUTPUT_DIR / ".brand" / "template_look"

    def picture(self, part: Any, rid: str) -> str:
        """The file URI of a picture of the template (by its relationship id), or '' when a browser cannot show it."""
        try:
            img = part.related_part(rid)
        except (KeyError, AttributeError):
            return ""
        ext = WEB_PICTURES.get(str(getattr(img, "content_type", "")))
        if not ext:
            self.skipped.append(f"picture {getattr(img, 'partname', '')} ({getattr(img, 'content_type', '?')})")
            return ""
        blob = img.blob
        path = self.folder / (hashlib.sha1(blob).hexdigest()[:16] + ext)   # noqa: S324 - a file name, not security
        if not path.exists():
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(blob)
        return path.resolve().as_uri()

    def fill(self, holder: Any, part: Any, style: Any = None) -> str:
        """A CSS background for a shape's or a slide's fill ('' = none)."""
        if holder is not None:
            if holder.find(_q("a:noFill")) is not None:
                return ""
            solid = holder.find(_q("a:solidFill"))
            if solid is not None:
                return colour(solid, self.scheme)
            grad = holder.find(_q("a:gradFill"))
            if grad is not None:
                stops = sorted(((_int(gs.get("pos")) / 1000, colour(gs, self.scheme)) for gs in grad.iter(_q("a:gs"))),
                               key=lambda s: s[0])
                stops = [(p, c) for p, c in stops if c]
                lin = grad.find(_q("a:lin"))
                angle = _int(lin.get("ang")) / 60000 + 90 if lin is not None else 90
                if len(stops) == 1:
                    return stops[0][1]
                if stops:
                    return f"linear-gradient({angle:.0f}deg,{','.join(f'{c} {p:.0f}%' for p, c in stops)})"
            blip = holder.find(f"{_q('a:blipFill')}/{_q('a:blip')}")
            if blip is not None:
                src = self.picture(part, str(blip.get(_q("r:embed"), "")))
                return f"url('{src}') center/cover no-repeat" if src else ""
            if holder.find(_q("a:pattFill")) is not None or holder.find(_q("a:grpFill")) is not None:
                return ""
        if style is not None:   # no fill of its own: the theme's style (fillRef idx 0 = none)
            ref = style.find(_q("a:fillRef"))
            if ref is not None and _int(ref.get("idx")) > 0:
                return colour(ref, self.scheme)
        return ""

    def outline(self, sp_pr: Any, style: Any = None) -> tuple[str, float]:
        """The line around a shape: (colour, width in EMU); ('', 0) when there is none."""
        ln = sp_pr.find(_q("a:ln")) if sp_pr is not None else None
        if ln is not None and ln.find(_q("a:noFill")) is not None:
            return "", 0
        c = colour(ln.find(_q("a:solidFill")), self.scheme) if ln is not None else ""
        if not c and style is not None:
            ref = style.find(_q("a:lnRef"))
            if ref is not None and _int(ref.get("idx")) > 0:
                c = colour(ref, self.scheme)
        width = _int(ln.get("w"), 12700) if ln is not None else 12700
        return c, (width if c else 0)

    def background(self, el: Any, part: Any) -> str | None:
        """The CSS background of a layout or master (cSld/bg), None when it has none of its own."""
        bg = el.find(f"{_q('p:cSld')}/{_q('p:bg')}")
        if bg is None:
            return None
        pr = bg.find(_q("p:bgPr"))
        if pr is not None:
            return self.fill(pr, part)
        ref = bg.find(_q("p:bgRef"))
        return colour(ref, self.scheme) if ref is not None else None

    def shapes(self, tree: Any, part: Any, place: Any, scale: tuple[float, float]) -> list[dict]:
        """The drawn shapes and pictures of a shape tree (placeholders left out), in canvas pixels."""
        out: list[dict] = []
        for el in tree:
            name = el.tag.split("}")[-1]
            if name == "grpSp":
                out += self.shapes(el, part, _group(place, el.find(f"{_q('p:grpSpPr')}/{_q('a:xfrm')}")), scale)
                continue
            if name == "graphicFrame":
                self.skipped.append("a table or chart")
            if name not in ("sp", "pic", "cxnSp") or el.find(f".//{_q('p:nvPr')}/{_q('p:ph')}") is not None:
                continue   # not drawn, or a placeholder (filled on each slide)
            sp_pr = el.find(_q("p:spPr"))
            xf = sp_pr.find(_q("a:xfrm")) if sp_pr is not None else None
            if xf is None or xf.find(_q("a:off")) is None or xf.find(_q("a:ext")) is None:
                continue
            x, y, w, h = place(xf)
            box = {"x": x * scale[0], "y": y * scale[1], "w": w * scale[0], "h": h * scale[1],
                   "rot": _int(xf.get("rot")) / 60000, "flip": (xf.get("flipH") == "1", xf.get("flipV") == "1")}
            found = self._picture(el, part, box) if name == "pic" else self._drawn(el, sp_pr, part, box, min(scale))
            if found:
                out.append(found)
        return out

    def _picture(self, el: Any, part: Any, box: dict) -> dict | None:
        blip = el.find(f"{_q('p:blipFill')}/{_q('a:blip')}")
        src = self.picture(part, str(blip.get(_q("r:embed"), ""))) if blip is not None else ""
        if not src:
            return None
        crop = el.find(f"{_q('p:blipFill')}/{_q('a:srcRect')}")
        return {**box, "kind": "pic", "src": src,
                "crop": tuple(_int(crop.get(k)) / 100000 for k in ("l", "t", "r", "b")) if crop is not None else (0, 0, 0, 0)}

    def _drawn(self, el: Any, sp_pr: Any, part: Any, box: dict, scale: float) -> dict | None:
        """A line, a rectangle, an ellipse or a shape drawn freely, with its fill and outline."""
        style = el.find(_q("p:style"))
        geom = sp_pr.find(_q("a:prstGeom"))
        prst = geom.get("prst") if geom is not None else "custom"
        c, lw = self.outline(sp_pr, style)
        if el.tag.endswith("cxnSp") or prst in ("line", "straightConnector1"):
            return {**box, "kind": "line", "colour": c, "lw": max(1.0, lw * scale)} if c else None
        bg = self.fill(sp_pr, part, style)
        if "".join(t.text or "" for t in el.iter(_q("a:t"))).strip():
            self.skipped.append("text that is not a placeholder")
        if not (bg or c):
            return None
        if prst == "custom":   # drawn freely (waves, curves): its path, scaled to the shape's box
            d = _path(sp_pr.find(_q("a:custGeom")), box["w"], box["h"])
            if not d:
                self.skipped.append("a shape drawn as a curve")
                return None
            return {**box, "kind": "path", "d": d, "bg": bg, "line": c, "lw": lw * scale}
        if prst not in ("rect", "roundRect", "ellipse", "snip1Rect", "round1Rect", "round2SameRect"):
            self.skipped.append(f"a shape drawn as {prst}")
            return None
        return {**box, "kind": "box", "bg": bg, "line": c, "lw": lw * scale,
                "round": "50%" if prst == "ellipse" else "12px" if prst.startswith("round") else "0"}


def _path(geom: Any, w: float, h: float) -> str:
    """An SVG path (in the box's pixels) from a shape drawn freely in PowerPoint (custGeom), '' when it cannot."""
    if geom is None or w <= 0 or h <= 0:
        return ""
    out = []
    for path in geom.iter(_q("a:path")):
        pw, ph = _int(path.get("w"), 0), _int(path.get("h"), 0)
        if not pw and not ph:
            continue
        sx, sy = w / (pw or ph), h / (ph or pw)
        cur = (0.0, 0.0)
        for cmd in path:
            name = cmd.tag.split("}")[-1]
            pts = [(_int(p.get("x")) * sx, _int(p.get("y")) * sy) for p in cmd.iter(_q("a:pt"))]
            if name == "moveTo" and pts:
                cur = pts[0]
                out.append(f"M{cur[0]:.1f} {cur[1]:.1f}")
            elif name == "lnTo" and pts:
                cur = pts[0]
                out.append(f"L{cur[0]:.1f} {cur[1]:.1f}")
            elif name == "cubicBezTo" and len(pts) == 3:
                cur = pts[2]
                out.append("C" + " ".join(f"{x:.1f} {y:.1f}" for x, y in pts))
            elif name == "quadBezTo" and len(pts) == 2:
                cur = pts[1]
                out.append("Q" + " ".join(f"{x:.1f} {y:.1f}" for x, y in pts))
            elif name == "arcTo":
                rx, ry = _int(cmd.get("wR")) * sx, _int(cmd.get("hR")) * sy
                st, sw = math.radians(_int(cmd.get("stAng")) / 60000), math.radians(_int(cmd.get("swAng")) / 60000)
                cx, cy = cur[0] - rx * math.cos(st), cur[1] - ry * math.sin(st)
                cur = (cx + rx * math.cos(st + sw), cy + ry * math.sin(st + sw))
                out.append(f"A{rx:.1f} {ry:.1f} 0 {int(abs(sw) > math.pi)} {int(sw > 0)} {cur[0]:.1f} {cur[1]:.1f}")
            elif name == "close":
                out.append("Z")
            else:
                return ""
    return " ".join(out)


def _plain(xf: Any) -> tuple[float, float, float, float]:
    off, ext = xf.find(_q("a:off")), xf.find(_q("a:ext"))
    return _int(off.get("x")), _int(off.get("y")), _int(ext.get("cx")), _int(ext.get("cy"))


def _group(outer: Any, xf: Any) -> Any:
    """Where the shapes of a group go: from the group's own coordinates (chOff, chExt) to the slide's."""
    if xf is None or xf.find(_q("a:chOff")) is None or xf.find(_q("a:chExt")) is None:
        return outer
    gx, gy, gw, gh = outer(xf)
    ch_off, ch_ext = xf.find(_q("a:chOff")), xf.find(_q("a:chExt"))
    cx, cy = _int(ch_off.get("x")), _int(ch_off.get("y"))
    sx = gw / max(1, _int(ch_ext.get("cx"), 1))
    sy = gh / max(1, _int(ch_ext.get("cy"), 1))

    def place(child: Any) -> tuple[float, float, float, float]:
        x, y, w, h = _plain(child)
        return gx + (x - cx) * sx, gy + (y - cy) * sy, w * sx, h * sy
    return place


# --- the heading and the text ---------------------------------------------------------------------------------------
def _ph(el: Any, kinds: tuple[str, ...]) -> Any:
    """The placeholder of one of these types in a layout or master (no type = a content placeholder, 'obj')."""
    for sp in el.iter(_q("p:sp")):
        ph = sp.find(f".//{_q('p:nvPr')}/{_q('p:ph')}")
        if ph is not None and ph.get("type", "obj") in kinds:
            return sp
    return None


def _text_style(layers: list[Any], scheme: dict[str, str], fonts: dict[str, str]) -> dict:
    """Size (pt), bold, colour, font, alignment and anchor of a placeholder's first level: the first that says it,
    from the layout's placeholder, the master's and the master's text styles."""
    got: dict[str, Any] = {}
    for layer in layers:
        if layer is None:
            continue
        lvl = layer if layer.tag.endswith("lvl1pPr") else layer.find(f".//{_q('a:lstStyle')}/{_q('a:lvl1pPr')}")
        body = layer.find(f".//{_q('a:bodyPr')}") if not layer.tag.endswith("lvl1pPr") else None
        if body is not None and body.get("anchor"):
            got.setdefault("anchor", body.get("anchor"))
        runs = [lvl.find(_q("a:defRPr"))] if lvl is not None else []
        if not layer.tag.endswith("lvl1pPr"):   # the layout's sample text may carry the format too
            runs += list(layer.iter(_q("a:rPr"))) + list(layer.iter(_q("a:endParaRPr")))
        if lvl is not None and lvl.get("algn"):
            got.setdefault("align", lvl.get("algn"))
        for rpr in (r for r in runs if r is not None):
            if rpr.get("sz"):
                got.setdefault("size", _int(rpr.get("sz")) / 100)
            if rpr.get("b") is not None:
                got.setdefault("bold", rpr.get("b") in ("1", "true"))
            if rpr.get("cap") == "all":
                got.setdefault("caps", True)
            c = colour(rpr.find(_q("a:solidFill")), scheme)
            if c:
                got.setdefault("colour", c)
            latin = rpr.find(_q("a:latin"))
            if latin is not None and latin.get("typeface"):
                face = str(latin.get("typeface"))
                got.setdefault("font", fonts.get("major" if face.startswith("+mj") else "minor", "")
                               if face.startswith("+") else face)
    return got


def _box(sp: Any, fallback: Any, scale: tuple[float, float]) -> tuple[float, float, float, float] | None:
    for el in (sp, fallback):
        xf = el.find(f"{_q('p:spPr')}/{_q('a:xfrm')}") if el is not None else None
        if xf is not None and xf.find(_q("a:off")) is not None and xf.find(_q("a:ext")) is not None:
            x, y, w, h = _plain(xf)
            return x * scale[0], y * scale[1], w * scale[0], h * scale[1]
    return None


def _layout_look(layout: Any, theme: dict, scale: tuple[float, float]) -> dict:
    """One layout as the HTML slides use it."""
    master = layout.slide_master
    lay_el, mas_el = layout._element, master._element   # noqa: SLF001 - python-pptx keeps the XML here
    scheme = scheme_of(mas_el, theme.get("colours", {}))
    reader = _Reader(scheme)
    bg = reader.background(lay_el, layout.part)
    if bg is None:
        bg = reader.background(mas_el, master.part)
    layer: list[dict] = []
    if lay_el.get("showMasterSp") != "0":
        layer += reader.shapes(mas_el.find(f"{_q('p:cSld')}/{_q('p:spTree')}"), master.part, _plain, scale)
    layer += reader.shapes(lay_el.find(f"{_q('p:cSld')}/{_q('p:spTree')}"), layout.part, _plain, scale)
    styles = mas_el.find(_q("p:txStyles"))
    fonts = theme.get("fonts", {})

    def text(kinds: tuple[str, ...], master_kinds: tuple[str, ...], style_tag: str) -> dict | None:
        sp, msp = _ph(lay_el, kinds), _ph(mas_el, master_kinds)
        box = _box(sp, msp, scale) if sp is not None else None
        if box is None:
            return None
        base = styles.find(f"{_q(style_tag)}/{_q('a:lvl1pPr')}") if styles is not None else None
        st = _text_style([sp, msp, base], scheme, fonts)
        return {"box": box, "size": st.get("size", 32 if style_tag == "p:titleStyle" else 18) * 12700 * min(scale),
                "bold": st.get("bold", False), "colour": st.get("colour", scheme.get("tx1", "")),
                "font": st.get("font") or fonts.get("major" if style_tag == "p:titleStyle" else "minor", ""),
                "align": {"ctr": "center", "r": "right", "just": "left"}.get(st.get("align", "l"), "left"),
                "anchor": {"ctr": "center", "b": "flex-end"}.get(st.get("anchor", "t"), "flex-start"),
                "caps": st.get("caps", False)}

    title = text(TITLE_TYPES, TITLE_TYPES, "p:titleStyle")
    body = text(("body", "obj", "subTitle"), ("body", "obj"), "p:bodyStyle")
    return {"name": layout.name, "bg": bg or scheme.get("bg1", "#ffffff"), "layer": layer, "title": title,
            "body": body, "pictures": any(s["kind"] == "pic" for s in layer), "skipped": reader.skipped}


@lru_cache(maxsize=4)
def _read(path: str, stamp: float, output: str) -> dict:   # noqa: ARG001 - read again when the file or folder changes
    from pptx import Presentation

    from studio.video import brand
    prs = Presentation(str(brand._openable(Path(path))))   # noqa: SLF001
    cx, cy = int(prs.slide_width or 12192000), int(prs.slide_height or 6858000)
    scale = (CANVAS_W / cx, CANVAS_H / cy)
    theme = brand.theme_of(Path(path))
    title_l, content_l = brand._layouts(prs)   # noqa: SLF001 - the same layouts as the .pptx
    title, content = _layout_look(title_l, theme, scale), _layout_look(content_l, theme, scale)
    look = {"emu": (cx, cy), "title": title, "content": content}
    skipped = sorted(set(title["skipped"] + content["skipped"]))
    if skipped:
        log.info("template look: left out %s", "; ".join(skipped))
    return look


def look() -> dict:
    """The template's look for presentations, or {} (no template, TEMPLATE_SLIDES=off, or it cannot be read)."""
    if config.TEMPLATE_SLIDES == "off":
        return {}
    from studio.video import brand
    t = brand.template() if brand.on() else None
    if not t:
        return {}
    try:
        return _read(str(t), t.stat().st_mtime, str(config.OUTPUT_DIR))
    except Exception as e:   # noqa: BLE001 - a template we cannot read: the slides keep their own look
        log.warning("template look not used (%s: %s)", type(e).__name__, e)
        return {}


# --- HTML ------------------------------------------------------------------------------------------------------
def _px(v: float) -> str:
    return f"{v:.1f}px"


def layer_html(lay: dict) -> str:
    """The template's background, pictures and shapes behind the slide."""
    parts = []
    for s in lay["layer"]:
        pos = f"left:{_px(s['x'])};top:{_px(s['y'])};width:{_px(s['w'])};height:{_px(s['h'])}"
        turn = (f";transform:rotate({s['rot']:.2f}deg)" + (" scaleX(-1)" if s["flip"][0] else "")
                + (" scaleY(-1)" if s["flip"][1] else "")) if s["rot"] or any(s["flip"]) else ""
        if s["kind"] == "pic":
            cl, ct, cr, cb = s["crop"]
            if any((cl, ct, cr, cb)):
                iw, ih = s["w"] / max(0.01, 1 - cl - cr), s["h"] / max(0.01, 1 - ct - cb)
                parts.append(f'<div style="{pos};overflow:hidden{turn}"><img src="{html.escape(s["src"])}" alt="" '
                             f'style="position:absolute;left:{_px(-cl * iw)};top:{_px(-ct * ih)};width:{_px(iw)};'
                             f'height:{_px(ih)}"></div>')
            else:
                parts.append(f'<img src="{html.escape(s["src"])}" alt="" style="{pos};object-fit:contain{turn}">')
        elif s["kind"] == "line":
            x1, x2 = (s["x"] + s["w"], s["x"]) if s["flip"][0] else (s["x"], s["x"] + s["w"])
            y1, y2 = (s["y"] + s["h"], s["y"]) if s["flip"][1] else (s["y"], s["y"] + s["h"])
            length, angle = math.hypot(x2 - x1, y2 - y1), math.degrees(math.atan2(y2 - y1, x2 - x1))
            parts.append(f'<div style="left:{_px(x1)};top:{_px(y1 - s["lw"] / 2)};width:{_px(length)};height:'
                         f'{_px(s["lw"])};background:{s["colour"]};transform-origin:0 50%;transform:rotate({angle:.2f}deg)"></div>')
        elif s["kind"] == "path":
            if s["bg"]:
                parts.append(f'<div style="{pos};background:{html.escape(s["bg"])};clip-path:path(\'{s["d"]}\'){turn}"></div>')
            else:
                parts.append(f'<svg style="{pos};overflow:visible{turn}" viewBox="0 0 {s["w"]:.1f} {s["h"]:.1f}">'
                             f'<path d="{s["d"]}" fill="none" stroke="{s["line"]}" stroke-width="{max(1.0, s["lw"]):.1f}"/></svg>')
        else:
            border = f";box-shadow:inset 0 0 0 {_px(s['lw'])} {s['line']}" if s["line"] and s["lw"] else ""
            parts.append(f'<div style="{pos};background:{html.escape(s["bg"] or "transparent")};'
                         f'border-radius:{s["round"]}{border}{turn}"></div>')
    return f'<div class="tplbg" aria-hidden="true">{"".join(parts)}</div>'


def _light(c: str) -> bool:
    if len(c) != 7 or not c.startswith("#"):
        return False
    r, g, b = (int(c[i:i + 2], 16) / 255 for i in (1, 3, 5))
    return 0.2126 * r + 0.7152 * g + 0.0722 * b > 0.6


def dark(lay: dict) -> bool:
    """A dark background (the template writes its headings in a light colour, or the background colour is dark):
    the heading, the lead and the footnote then go white. Cards and diagrams keep their own colours."""
    title = lay.get("title") or {}
    if title.get("colour"):
        return _light(title["colour"])
    bg = lay.get("bg", "")
    return len(bg) == 7 and bg.startswith("#") and not _light(bg) and int(bg[1:], 16) < 0x555555


def boxes(lay: dict, lead: bool) -> dict[str, tuple[float, float, float, float]]:
    """For slides_editable.pptx (canvas pixels): the heading in the template's title box, the lead line under it, the
    content picture in the template's text area, the source footnote under the content."""
    title = lay["title"]["box"] if lay.get("title") else (72.0, 40.0, CANVAS_W - 144.0, 90.0)
    tb = title[1] + title[3]
    if lay.get("body"):
        bx, by, bw, bh = lay["body"]["box"]
    else:   # no text area in the layout: below the heading to the bottom
        bx, by, bw, bh = title[0], tb + 16, title[2], CANVAS_H - tb - 60
    top = max(by, tb + LEAD_H) if lead else by
    foot = (bx, min(by + bh, CANVAS_H - FOOT_H) - FOOT_H + 4, bw, FOOT_H - 6)
    return {"title": title, "lead": (title[0], tb + 2, title[2], LEAD_H - 6),
            "main": (bx, top, bw, max(80.0, foot[1] - top - 4)), "foot": foot}


BASE_CSS = (".tpl{background:none}.tpl:before{display:none}.tpl .bg{display:none}"
            ".tplbg{position:absolute;inset:0;z-index:0;overflow:hidden}.tplbg>*{position:absolute}"
            ".tpl .hd,.tpl main,.tpl footer{z-index:1}"
            # the content alone, for slides_editable.pptx (deck.py): no background, heading or footnote
            "html.cut,html.cut body,.cut .slide{background:transparent!important}"
            ".cut .tplbg,.cut .hd,.cut footer,.cut .brandlogo{display:none!important}")
LIGHT_TEXT = (".tpl .heading,.tpl .lead,.tpl .eyebrow,.tpl footer,.tpl footer *,.tpl .ttl,.tpl .tsub,.tpl .kicker,"
              ".tpl .statement-only h1{color:#fff!important}")


def _footer_lift(lay: dict) -> float:
    """How far the footnote line goes up so it does not sit on a bar along the template's bottom edge (0 = none)."""
    tops = [s["y"] for s in lay["layer"] if s["y"] + s["h"] >= CANVAS_H - 6 and s["w"] > CANVAS_W / 3 and s["y"] > CANVAS_H * 0.8]
    return CANVAS_H - min(tops) if tops else 0.0


def slide_css(lay: dict) -> str:
    """The CSS of one slide on the template's background: only the background changes (and the footnote line steps
    up above a bar along the bottom edge)."""
    lift = _footer_lift(lay)
    return (BASE_CSS + f".tplbg{{background:{lay['bg']}}}" + (LIGHT_TEXT if dark(lay) else "")
            + (f".tpl footer{{bottom:{lift + 14:.0f}px}}" if lift else ""))


def summary() -> dict:
    """For the page (Settings > Company look): which layouts are used and what of them could not be taken."""
    lk = look()
    if not lk:
        return {}
    return {"title_layout": lk["title"]["name"], "content_layout": lk["content"]["name"],
            "left_out": sorted(set(lk["title"]["skipped"] + lk["content"]["skipped"]))[:6]}
