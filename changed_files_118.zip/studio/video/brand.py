"""
brand.py - the company's own look in everything made: put its files in data/brand/ and the slides, the
presentations and the videos use them. Nothing to set up beyond copying the files there; in the cluster they are
added on the page (Settings, top right > Company look: one file, or a .zip from the brand site, from which the page
takes the screen logo and the square mark for the browser tab, the master template, the fonts, icons or pictures)
and used at once, without a restart.

  data/brand/logo.png        the logo (PNG with a see-through background is best; SVG, JPG or WebP work too)
  data/brand/template.pptx   the company's PowerPoint template (.pptx or .potx): its colours and font are read
                             from it, and the presentations are made in it (editable text in its layouts)
  data/brand/*.ttf / *.otf   the company font (optional; else the template's font if the computer has it, else Inter)
  data/brand/brand.json      optional, wins over the rest, e.g.
                             {"name": "Company", "accent": "#0b41cd", "accent2": "#ff7d29", "ink": "#1b1b1b",
                              "background": "#ffffff", "font": "Roboto", "logo_corner": "top-right",
                              "footer": "For internal use", "tone": "Plain, friendly, no jargon",
                              "terms": {"e-learning": "learning module", "staff": "colleagues"}}
  data/brand/icons/*.svg     the company icons: a slide that needs an icon takes the company one whose file name
                             matches (money.svg, invoice.svg, team.svg ...), else an open-source one
  data/brand/images/*        the company pictures (PNG, JPG, WebP, SVG): title.* (or the first one) on every
                             video's title slide
Text: "footer" is written on every slide; "tone" and "terms" go to Claude with every script (how to write, which
words to use).

Where it shows:
  - HTML slides (the chosen video tool) and the slide pictures: the company colours and font, the logo in the
    corner of every slide and large on the title slide
  - presentations (deck.py): slides.pptx made in the company template, the text editable
  - every other video tool: the company colours where the tool takes colours (Remotion, documents, pictures),
    and the logo put in the corner of the finished video
  - Lesson Studio: the logo in the page header and the company colours on the page
Colours: brand.json, else the template's theme colours (accent 1 and 2), else the logo's own colours.
THEME_ACCENT / THEME_ACCENT_2 in .env win over all of it; BRAND=off in .env switches the brand off.
After changing the files by hand: restart Lesson Studio (the colours are read when it starts); files added on the
page are used at once.

  uv run -m studio brand              # what was found and which colours are used
  uv run -m studio brand --preview    # a sample slide in the brand: data/output/brand_preview.png
"""
from __future__ import annotations

import argparse
import colorsys
import json
import logging
import re
import subprocess
import sys
import zipfile
from collections import Counter
from functools import lru_cache
from pathlib import Path
from typing import Any
from xml.etree import ElementTree

from studio.core import config

log = logging.getLogger("brand")
IMAGES = (".png", ".svg", ".jpg", ".jpeg", ".webp")
FONTS = (".ttf", ".otf", ".woff", ".woff2")
TEMPLATES = (".pptx", ".potx")
NS = {"a": "http://schemas.openxmlformats.org/drawingml/2006/main"}
CORNERS = ("top-right", "top-left", "bottom-right", "bottom-left")
OFFICE_FONTS = {"calibri", "calibri light", "aptos", "aptos display", "arial", "times new roman", "cambria", "+mn-lt"}


def _files() -> list[Path]:
    d = config.BRAND_DIR
    if config.BRAND == "off" or not d.is_dir():
        return []
    return sorted(p for p in d.iterdir() if p.is_file() and not p.name.startswith(("~$", ".")))


def logo() -> Path | None:
    """The company logo in data/brand (a file with 'logo' in its name first), or None."""
    imgs = [p for p in _files() if p.suffix.lower() in IMAGES and p.stem.lower() != "favicon"]
    return next((p for p in imgs if "logo" in p.stem.lower()), imgs[0] if imgs else None)


def favicon() -> Path | None:
    """The small icon in the browser tab: data/brand/favicon.* (the company's square mark), else the logo."""
    own = next((p for p in _files() if p.stem.lower() == "favicon" and p.suffix.lower() in FAVICONS), None)
    return own or logo()


def template() -> Path | None:
    """The company's PowerPoint template in data/brand, or None."""
    return next((p for p in _files() if p.suffix.lower() in TEMPLATES), None)


def font_files() -> list[Path]:
    """The company's font files in data/brand."""
    return [p for p in _files() if p.suffix.lower() in FONTS]


def settings() -> dict:
    """data/brand/brand.json ({} when there is none, it cannot be read, or BRAND=off)."""
    f = config.BRAND_DIR / "brand.json"
    if config.BRAND == "off" or not f.exists():
        return {}
    try:
        return json.loads(f.read_text(encoding="utf-8-sig")) or {}
    except (OSError, ValueError) as e:
        log.warning("data/brand/brand.json not read (%s): the template and the logo are used", e)
        return {}


# --- icons, pictures, wording ----------------------------------------------------------------------------------
def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")


def icons() -> dict[str, Path]:
    """The company icons in data/brand/icons: {name from the file name: file}."""
    d = config.BRAND_DIR / "icons"
    if config.BRAND == "off" or not d.is_dir():
        return {}
    return {_slug(p.stem): p for p in sorted(d.glob("*.svg"))}


def find_icon(name: str, hint_text: str = "") -> str:
    """The company icon for a slide: its name asked for, else one named like a word of the text; '' if none."""
    have = icons()
    if not have:
        return ""
    name = _slug(name or "")
    if name in have:
        return name
    words = [w for w in re.findall(r"[a-z]+", f"{name.replace('-', ' ')} {hint_text}".lower()) if len(w) >= 3]
    for w in words:
        for k in have:
            if w == k or w.rstrip("s") == k or w in k.split("-"):
                return k
    return ""


def icon_svg(name: str, cls: str = "ic") -> str:
    """The company icon as inline SVG (scripts, external links and event handlers taken out), 24x24 like the others."""
    path = icons().get(name)
    if not path:
        return ""
    try:
        root = ElementTree.fromstring(path.read_text(encoding="utf-8-sig"))
    except (OSError, ElementTree.ParseError) as e:
        log.warning("%s is not a usable SVG (%s)", path.name, e)
        return ""
    for parent in list(root.iter()):
        for child in list(parent):
            if child.tag.split("}")[-1] in ("script", "foreignObject", "image"):
                parent.remove(child)
        for attr in list(parent.attrib):
            if attr.lower().startswith("on") or (attr.split("}")[-1] == "href" and not parent.attrib[attr].startswith("#")):
                del parent.attrib[attr]
    if "viewBox" not in root.attrib:
        w, h = (re.sub(r"[^\d.]", "", root.attrib.get(k, "24")) or "24" for k in ("width", "height"))
        root.set("viewBox", f"0 0 {w} {h}")
    root.set("width", "24")
    root.set("height", "24")
    root.set("class", f"{cls} brandicon")
    ElementTree.register_namespace("", "http://www.w3.org/2000/svg")
    return ElementTree.tostring(root, encoding="unicode")


def images() -> list[Path]:
    """The company's own pictures in data/brand/images."""
    d = config.BRAND_DIR / "images"
    if config.BRAND == "off" or not d.is_dir():
        return []
    return sorted(p for p in d.iterdir() if p.suffix.lower() in IMAGES and not p.name.startswith((".", "~$")))


def title_image() -> Path | None:
    """The picture for the title slide: images/title.* , else the first company picture."""
    pics = images()
    return next((p for p in pics if p.stem.lower() == "title"), pics[0] if pics else None)


def footer_text() -> str:
    """The company's line for every slide's footer (brand.json 'footer')."""
    return str(settings().get("footer") or "").strip()


def writing_rules() -> str:
    """How the company writes (brand.json "tone" and "terms"), for Claude with every script; '' when not set."""
    s = settings()
    tone = str(s.get("tone") or "").strip()
    terms = s.get("terms") if isinstance(s.get("terms"), dict) else {}
    out = []
    if tone:
        out.append(f"The company's way of writing: {tone}.")
    if terms:
        out.append("The company's words (write the second, not the first): "
                   + "; ".join(f'"{a}" -> "{b}"' for a, b in terms.items()) + ".")
    return " ".join(out)


def _hex(v: str | None) -> str:
    v = str(v or "").strip().lstrip("#")
    return f"#{v.lower()}" if re.fullmatch(r"[0-9a-fA-F]{6}", v) else ""


def theme_of(path: Path) -> dict:
    """The theme of a PowerPoint file: its colours (dk1, lt1, dk2, lt2, accent1-6) and fonts (major, minor)."""
    try:
        with zipfile.ZipFile(path) as z:
            names = sorted(n for n in z.namelist() if re.fullmatch(r"ppt/theme/theme\d+\.xml", n))
            if not names:
                return {}
            root = ElementTree.fromstring(z.read(names[0]))
    except (OSError, zipfile.BadZipFile, ElementTree.ParseError) as e:
        log.warning("%s: theme not read (%s)", path.name, e)
        return {}
    colours = {}
    scheme = root.find(".//a:clrScheme", NS)
    for el in list(scheme) if scheme is not None else []:
        name = el.tag.split("}")[-1]
        c, system = el.find("a:srgbClr", NS), el.find("a:sysClr", NS)
        value = c.get("val") if c is not None else (system.get("lastClr") if system is not None else "")
        if _hex(value):
            colours[name] = _hex(value)
    fonts = {}
    for kind in ("major", "minor"):
        f = root.find(f".//a:{kind}Font/a:latin", NS)
        if f is not None and f.get("typeface"):
            fonts[kind] = f.get("typeface")
    return {"colours": colours, "fonts": fonts}


def _rgb(h: str) -> tuple[int, int, int]:
    return int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16)


def _usable(h: str) -> bool:
    """A colour that reads on a light slide: not white-ish, not grey, not black."""
    r, g, b = (x / 255 for x in _rgb(h))
    _hue, light, sat = colorsys.rgb_to_hls(r, g, b)
    return 0.12 < light < 0.82 and sat > 0.18


def _distinct(a: str, b: str) -> bool:
    return sum((x - y) ** 2 for x, y in zip(_rgb(a), _rgb(b), strict=True)) ** 0.5 > 70


def logo_colours(path: Path) -> list[str]:
    """The logo's own colours, most used first (white, black and greys left out)."""
    if path.suffix.lower() == ".svg":
        text = path.read_text(encoding="utf-8", errors="replace")
        found = [_hex(x) for x in re.findall(r"#([0-9a-fA-F]{6})\b", text)]
        return [c for c, _ in Counter(c for c in found if c and _usable(c)).most_common()]
    try:
        from PIL import Image
        im = Image.open(path).convert("RGBA")
    except (ImportError, OSError):
        return []
    im.thumbnail((160, 160))
    counts: Counter = Counter()
    data = im.tobytes()
    for k in range(0, len(data), 4):
        r, g, b, a = data[k:k + 4]
        if a < 128:
            continue
        h = f"#{(r // 16) * 16 + 8:02x}{(g // 16) * 16 + 8:02x}{(b // 16) * 16 + 8:02x}"   # near colours together
        if _usable(h):
            counts[h] += 1
    return [c for c, _ in counts.most_common(12)]


def _font_family(path: Path) -> str:
    """The family name inside a font file (falls back to its file name)."""
    try:
        from PIL import ImageFont
        return ImageFont.truetype(str(path), 12).getname()[0] or re.split(r"[-_ ]", path.stem)[0]
    except (OSError, ImportError, ValueError):   # woff, or no Pillow
        return re.split(r"[-_ ]", path.stem)[0]


def info() -> dict:
    """What the brand is: logo, template, colours, font (and where each came from). BRAND=off (for one job: the
    page's "Look: Default") = no brand."""
    return _info(config.BRAND, str(config.BRAND_DIR))


@lru_cache(maxsize=4)
def _info(mode: str, folder: str) -> dict:   # noqa: ARG001 - the cache's key: read again when they change
    files = _files()
    if not files:
        return {"on": False}
    s, t, lg = settings(), template(), logo()
    theme = theme_of(t) if t else {}
    tc = theme.get("colours", {})
    candidates = [("brand.json", _hex(s.get("accent"))), ("brand.json", _hex(s.get("accent2")))]
    candidates += [("template", tc.get(f"accent{i}", "")) for i in range(1, 7)] + [("template", tc.get("dk2", ""))]
    candidates += [("logo", c) for c in (logo_colours(lg) if lg else [])]
    accent = _hex(s.get("accent")) or next((c for src, c in candidates if c and _usable(c)), "")
    accent2 = _hex(s.get("accent2")) or next((c for src, c in candidates if c and _usable(c) and accent
                                              and _distinct(c, accent)), "")
    source = next((src for src, c in candidates if c and c == accent), "")
    fonts = font_files()
    theme_font = theme.get("fonts", {}).get("minor", "")
    if theme_font.lower() in OFFICE_FONTS:   # PowerPoint's own default, not a company font: keep the slides' Inter
        theme_font = ""
    font = str(s.get("font") or (_font_family(fonts[0]) if fonts else "") or theme_font)
    corner = str(s.get("logo_corner", "top-right")).lower()
    return {"on": True, "name": str(s.get("name") or (t.stem if t else "Company")), "logo": lg, "template": t,
            "fonts": fonts, "font": font, "accent": accent, "accent2": accent2, "colour_source": source,
            "ink": _hex(s.get("ink")), "background": _hex(s.get("background")),
            "corner": corner if corner in CORNERS else "top-right", "theme": tc}


def on() -> bool:
    """Whether a company brand is used."""
    return bool(info().get("on"))


def accents(default1: str, default2: str) -> tuple[str, str]:
    """The brand's two colours (THEME_ACCENT, THEME_ACCENT_2), or the defaults."""
    i = info()
    return (i.get("accent") or default1, i.get("accent2") or default2) if i.get("on") else (default1, default2)


def summary() -> dict:
    """For Lesson Studio and the command line: what was found."""
    i = info()
    if not i.get("on"):
        return {"on": False, "folder": str(config.BRAND_DIR)}
    return {"on": True, "folder": str(config.BRAND_DIR), "name": i["name"],
            "logo": i["logo"].name if i["logo"] else "", "template": i["template"].name if i["template"] else "",
            "font": i["font"], "fonts": [f.name for f in i["fonts"]],
            "accent": config.THEME_ACCENT, "accent2": config.THEME_ACCENT_2, "colour_source": i["colour_source"]
            if (i["accent"] == config.THEME_ACCENT) else ".env (THEME_ACCENT)",
            "icons": len(icons()), "images": [p.name for p in images()], "footer": footer_text(),
            "writing": writing_rules()}


# --- HTML slides -------------------------------------------------------------------------------------------
_WEIGHTS = (("thin", 100), ("extralight", 200), ("light", 300), ("medium", 500), ("semibold", 600),
            ("demibold", 600), ("extrabold", 800), ("black", 900), ("bold", 700))


def css(colours: bool = True) -> str:
    """Extra CSS for the HTML slides: the font, the page colours and the logo (colours=False: the logo only,
    for the second look, which keeps its own colours)."""
    i = info()
    if not i.get("on"):
        return ""
    out = []
    if colours:
        faces = []
        for f in i["fonts"]:
            stem = f.stem.lower().replace("-", "").replace("_", "")
            weight = next((w for k, w in _WEIGHTS if k in stem), 400)
            style = "italic" if "italic" in stem else "normal"
            faces.append(f"@font-face{{font-family:'BrandFont';font-weight:{weight};font-style:{style};"
                         f"src:url('{f.resolve().as_uri()}')}}")
        family = "'BrandFont'," if faces else (f"'{i['font']}'," if i["font"] else "")
        out += faces
        if family:
            out.append(f"body,.heading,.t,.d,.lead{{font-family:{family}'Inter','Segoe UI',system-ui,sans-serif}}")
        root = (f"--ink:{i['ink']};" if i["ink"] else "") + (f"--bg:{i['background']};" if i["background"] else "")
        if root:
            out.append(f":root{{{root}}}")
    if i["logo"]:
        v, h = i["corner"].split("-")
        out.append(f".brandlogo{{position:absolute;z-index:6;{v}:{30 if v == 'top' else 26}px;{h}:40px;height:42px;"
                   f"width:auto;max-width:210px;object-fit:contain}}")
        if v == "top":   # the heading leaves room for the logo
            out.append(f".has-logo .hd{{{h}:{290 if h == 'right' else 72}px}}"
                       + (".has-logo .hd{left:290px}" if h == "left" else ""))
        else:            # the footer leaves room for it
            out.append(f".has-logo footer{{{h}:280px}}")
        out.append(".k-title .brandlogo{top:44px;bottom:auto;left:72px;right:auto;height:64px;max-width:300px}")
    return "".join(out)


def _luminance(h: str) -> float:
    def lin(c: int) -> float:
        v = c / 255
        return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    r, g, b = _rgb(h)
    return 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b)


def page_css() -> str:
    """Lesson Studio itself in the company look: its colours on the buttons, tabs and highlights, its font
    (/brand/page.css; '' without a brand)."""
    i = info()
    if not i.get("on"):
        return ""
    a, a2 = config.THEME_ACCENT, config.THEME_ACCENT_2   # the brand's (THEME_ACCENT in .env wins, as on the slides)
    out = []
    if a:
        on = "#ffffff" if (1.05 / (_luminance(a) + 0.05)) >= 3 else "#111111"   # readable text on the colour
        glow = f"color-mix(in srgb,{a} 28%,transparent)"
        out += [f":root{{--accent:{a};--accent-2:{a2};--accent-soft:color-mix(in srgb,{a} 10%,white)}}",
                f".chatlist .new,.msg.user .bubble,#send,.avform button.main{{background:{a};color:{on};box-shadow:0 6px 16px {glow}}}",
                f".brand i,.kpi::before,section h3::before{{background:linear-gradient(135deg,{a},{a2})}}",
                f".box:focus-within{{border-color:color-mix(in srgb,{a} 45%,white)}}",
                f".how .node.key{{border-color:color-mix(in srgb,{a} 45%,white)}}"]
    fonts = font_files()
    if fonts:
        regular = next((n for n, f in enumerate(fonts) if not re.search(r"bold|italic|light|medium|black|thin", f.stem, re.I)), 0)
        out += [f"@font-face{{font-family:'BrandFont';src:url('/brand/font?n={regular}')}}",
                "body{font-family:'BrandFont','Segoe UI',system-ui,-apple-system,Roboto,Arial,sans-serif}"]
    return "\n".join(out)


def logo_html() -> str:
    """The company logo for a slide's corner ('' without a brand)."""
    i = info()
    return f'<img class="brandlogo" src="{i["logo"].resolve().as_uri()}" alt="">' if i.get("on") and i["logo"] else ""


# --- the logo on a finished video (every tool but the HTML slides, which draw it themselves) ------------------
def _video_height(video: Path) -> int:
    out = subprocess.run([config.FFPROBE, "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=height",
                          "-of", "csv=p=0", str(video)], capture_output=True, text=True, timeout=60)
    try:
        return int(out.stdout.strip().splitlines()[0])
    except (ValueError, IndexError):
        return config.VIDEO_HEIGHT


def logo_png(height: int) -> Path | None:
    """The logo as a PNG this many pixels high (an SVG drawn by the browser), kept in data/output/.brand."""
    lg = logo()
    if not lg:
        return None
    out = config.OUTPUT_DIR / ".brand" / f"logo_{height}.png"
    if out.exists() and out.stat().st_mtime >= lg.stat().st_mtime:
        return out
    out.parent.mkdir(parents=True, exist_ok=True)
    if lg.suffix.lower() == ".svg":
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            b = p.chromium.launch()
            page = b.new_page(viewport={"width": 2400, "height": height})
            page.set_content(f"<html><body style='margin:0;background:transparent'><img id=l src='{lg.resolve().as_uri()}' "
                             f"style='height:{height}px;display:block'></body></html>")
            page.wait_for_load_state("load")
            page.locator("#l").screenshot(path=str(out), omit_background=True)
            b.close()
        return out
    from PIL import Image
    im = Image.open(lg).convert("RGBA")
    im = im.resize((max(1, round(im.width * height / im.height)), height), Image.Resampling.LANCZOS)
    im.save(out)
    return out


def stamp(video: Path) -> bool:
    """Put the logo in the corner of a finished video (in place). True when done."""
    if not on() or not logo() or not video.exists():
        return False
    h = _video_height(video)
    png = logo_png(max(24, round(h * 0.065)))
    if not png:
        return False
    m = round(h * 0.035)
    v, side = info()["corner"].split("-")
    x = f"W-w-{m}" if side == "right" else str(m)
    y = str(m) if v == "top" else f"H-h-{m}"
    tmp = video.with_name(video.stem + ".brand.mp4")
    cmd = [config.FFMPEG, "-hide_banner", "-loglevel", "error", "-y", "-i", str(video), "-i", str(png),
           "-filter_complex", f"[1:v]format=rgba,colorchannelmixer=aa=0.92[l];[0:v][l]overlay={x}:{y}:format=auto[v]",
           "-map", "[v]", "-map", "0:a?", "-map", "0:s?", "-c:v", "libx264", "-crf", "20", "-preset", "veryfast",
           "-pix_fmt", "yuv420p", "-c:a", "copy", "-c:s", "copy", "-movflags", "+faststart", str(tmp)]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=3600)
    if r.returncode != 0:
        log.warning("logo not put on %s: %s", video.name, (r.stderr or "").strip()[-300:])
        tmp.unlink(missing_ok=True)
        return False
    tmp.replace(video)
    return True


# --- presentations in the company template -----------------------------------------------------------------
def scene_text(scene: dict) -> tuple[str, list[tuple[str, int]]]:
    """A scene as a heading and lines of text (text, level) for an editable slide."""
    from studio.video import slides_html
    lines: list[tuple[str, int]] = []
    if scene.get("subheading"):
        lines.append((scene["subheading"], 0))
    kind = scene.get("visual", "")
    if kind == "comparison" and scene.get("columns"):
        for col in scene["columns"]:
            lines.append((col.get("heading", ""), 0))
            lines += [(str(x), 1) for x in col.get("items", [])]
    elif kind == "table" and scene.get("table_rows"):
        head = scene.get("table_header", [])
        for row in scene["table_rows"]:
            lines.append((row[0] if row else "", 0))
            lines += [(f"{h}: {c}" if h else str(c), 1) for h, c in zip(head[1:], row[1:], strict=False)]
    elif kind == "chart" and scene.get("chart"):
        c = scene["chart"]
        for label, value in zip(c.get("labels", []), (c.get("series") or [{}])[0].get("values", c.get("values", [])),
                                strict=False):
            lines.append((f"{label}: {value}{c.get('unit', '')}", 0))
    elif kind in ("question", "answer") and scene.get("items"):
        lines += [(f"{chr(65 + i)}. {x}", 0) for i, x in enumerate(scene["items"])]
        if kind == "answer":
            lines.append((f"Answer: {chr(65 + int(scene.get('correct', 0)))}", 0))
    else:
        for e in slides_html.elements(scene):
            lines.append((e["title"] + (f" {e['value']}" if e.get("value") else ""), 0))
            if e["detail"]:
                lines.append((e["detail"], 1))
    return scene.get("heading", ""), [(t, lvl) for t, lvl in lines if str(t).strip()]


def _layouts(prs: Any) -> tuple:
    """The template's title layout and its title-and-content layout (by their placeholders)."""
    from pptx.enum.shapes import PP_PLACEHOLDER as P
    title_l = content_l = None
    for lay in prs.slide_layouts:
        kinds = {ph.placeholder_format.type for ph in lay.placeholders}
        if title_l is None and (P.CENTER_TITLE in kinds or (P.TITLE in kinds and P.SUBTITLE in kinds)):
            title_l = lay
        if content_l is None and P.TITLE in kinds and (kinds & {P.BODY, P.OBJECT}) and P.SUBTITLE not in kinds:
            content_l = lay
    layouts = list(prs.slide_layouts)
    return title_l or layouts[0], content_l or layouts[min(1, len(layouts) - 1)]


def _drop_slides(prs: Any) -> None:
    """A template may come with example slides: they go (the layouts and the masters stay)."""
    ids = prs.slides._sldIdLst   # noqa: SLF001 - python-pptx has no public way to delete a slide
    for sld in list(ids):
        prs.part.drop_rel(sld.rId)
        ids.remove(sld)


def _openable(t: Path) -> Path:
    """The template as python-pptx opens it: a .potx copied with the content type of a presentation."""
    if t.suffix.lower() != ".potx":
        return t
    src = config.OUTPUT_DIR / ".brand" / "template_from_potx.pptx"
    src.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(t) as zin, zipfile.ZipFile(src, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename == "[Content_Types].xml":
                data = data.replace(b"presentationml.template.main+xml", b"presentationml.presentation.main+xml")
            zout.writestr(item, data)
    return src


def _fill_slide(prs: Any, slide: Any, title_text: str, lines: list[tuple[str, int]], goal: str) -> None:
    """The heading in the title placeholder, the points (or the goal on a title slide) in the text area."""
    from pptx.enum.shapes import PP_PLACEHOLDER as P
    from pptx.util import Inches
    phs = {ph.placeholder_format.type: ph for ph in slide.placeholders}
    title = phs.get(P.CENTER_TITLE) or phs.get(P.TITLE)
    if title is not None:
        title.text = title_text
    body = phs.get(P.SUBTITLE) or phs.get(P.BODY) or phs.get(P.OBJECT)
    if body is None and lines:   # a layout without a text area: a text box where the content goes
        width, height = prs.slide_width or Inches(13.333), prs.slide_height or Inches(7.5)
        body = slide.shapes.add_textbox(Inches(0.8), Inches(1.6), width - Inches(1.6), height - Inches(2.4))
    if body is not None and lines:
        tf = body.text_frame
        tf.text = lines[0][0]
        tf.paragraphs[0].level = lines[0][1]
        for text, level in lines[1:]:
            para = tf.add_paragraph()
            para.text, para.level = text, level
    elif body is not None and goal:
        body.text_frame.text = goal
    for ph in slide.placeholders:   # empty placeholders would show "Click to add text"
        if ph.has_text_frame and not ph.text_frame.text.strip():
            ph._element.getparent().remove(ph._element)   # noqa: SLF001


def _picture_body(prs: Any, slide: Any, sc: dict, body: Path, boxes: dict) -> None:
    """The content as a picture where the template's text area is (the heading stays editable text), with the lead
    line and the source footnote as small text boxes; the empty text area goes."""
    from pptx.enum.shapes import PP_PLACEHOLDER as P
    from pptx.util import Emu, Pt

    from studio.video import template_look
    k = int(prs.slide_width) / template_look.CANVAS_W

    def emu(box: tuple[float, float, float, float]) -> tuple[Any, Any, Any, Any]:
        return tuple(Emu(round(v * k)) for v in box)
    for ph in list(slide.placeholders):
        if ph.placeholder_format.type not in (P.TITLE, P.CENTER_TITLE):
            ph._element.getparent().remove(ph._element)   # noqa: SLF001
    from PIL import Image
    with Image.open(body) as im:
        ratio = im.width / max(1, im.height)
    x, y, w, h = boxes["main"]   # the picture as large as fits, in the middle, not stretched
    fw, fh = (w, w / ratio) if w / ratio <= h else (h * ratio, h)
    slide.shapes.add_picture(str(body), *emu((x + (w - fw) / 2, y + (h - fh) / 2, fw, fh)))
    for text, box, size in ((sc.get("subheading", ""), boxes["lead"], 14), (sc.get("_source", ""), boxes["foot"], 9)):
        if text:
            tb = slide.shapes.add_textbox(*emu(box))
            tb.text_frame.text = text
            tb.text_frame.word_wrap = True
            for run in tb.text_frame.paragraphs[0].runs:
                run.font.size = Pt(size)


def write_pptx(sb: dict, speaker_notes: list[str], out: Path, bodies: list[Path] | None = None) -> Path | None:
    """The presentation made in the company template (slides_editable.pptx): one slide per scene in the template's
    own layouts, the heading as editable text, the content as the picture of it as it is on the slides (bodies:
    scenes/body_NN.png from deck.py) in the template's text area; what to say as speaker notes. Without those
    pictures, the points as editable text. None without a template or python-pptx."""
    t = template() if on() else None
    if not t:
        return None
    try:
        from pptx import Presentation
    except ImportError:
        log.info("presentation in the template skipped: uv add python-pptx")
        return None
    from studio.video import slides_html, template_look
    prs = Presentation(str(_openable(t)))
    _drop_slides(prs)
    title_l, content_l = _layouts(prs)
    look = template_look.look()
    for n, (sc, said) in enumerate(zip(sb["scenes"], speaker_notes, strict=True)):
        heading, lines = scene_text(sc)
        first = n == 0 or sc.get("visual") == "title"
        slide = prs.slides.add_slide(title_l if first else content_l)
        body = bodies[n] if bodies and n < len(bodies) else None
        statement = sc.get("visual", "bullets") in ("bullets", "cards") and not slides_html.elements(sc)
        if look and not first and body and body.exists() and not statement:
            _fill_slide(prs, slide, heading, [], "")
            source = slides_html.source_note(sc, sb.get("sources", {}))
            _picture_body(prs, slide, {**sc, "_source": source}, body,
                          template_look.boxes(look["content"], bool(sc.get("subheading"))))
        else:
            _fill_slide(prs, slide, sb["title"] if n == 0 and not heading else heading, lines,
                        sb.get("goal", "") if first else "")
        if said:
            slide.notes_slide.notes_text_frame.text = said
    prs.save(str(out))
    return out


def preview() -> Path:
    """A sample slide in the brand (HTML slides): data/output/brand_preview.png."""
    from studio.video import slides_html
    scene = {"visual": "steps", "heading": "How a lesson is made", "subheading": "From the recordings to a video",
             "elements": [{"title": "Find", "detail": "the parts of the recordings on the topic"},
                          {"title": "Write", "detail": "the script, every fact with its source"},
                          {"title": "Make", "detail": "slides and voice, in the company look"}]}
    html, n = slides_html.scene_html(scene, lesson_title="Brand preview", goal="", page="2 / 9")
    out = config.OUTPUT_DIR / "brand_preview.png"
    out.parent.mkdir(parents=True, exist_ok=True)
    b = slides_html.Browser()
    try:
        b.still(html, slides_html.timeline({**scene, "animation": "none"}, [], [], n), 30.0, out)
    finally:
        b.close()
    out.with_suffix(".html").unlink(missing_ok=True)
    return out


# --- files added on the page (Lesson Studio: Settings, top right > Company look) -----------------------------------
FAVICONS = (*IMAGES, ".ico")
UPLOAD_KINDS = {"logo": IMAGES, "favicon": FAVICONS, "template": TEMPLATES, "font": FONTS, "icon": (".svg",),
                "image": IMAGES, "settings": (".json",)}
MAX_UPLOAD_BYTES = 100 * 1024 * 1024   # a PowerPoint master with its pictures can be large
_UNSAFE_SVG = re.compile(r"<script|<foreignobject|\son[a-z]+\s*=|javascript:", re.I)
_FONT_MAGIC = (b"\x00\x01\x00\x00", b"true", b"OTTO", b"wOFF", b"wOF2")


def _check_content(ext: str, data: bytes) -> None:
    """Raises ValueError unless the bytes really are a file of this type (and an SVG runs no script)."""
    import io
    if ext == ".svg":
        text = data.decode("utf-8", errors="ignore")
        if "<svg" not in text.lower():
            raise ValueError("not an SVG picture")
        if _UNSAFE_SVG.search(text):
            raise ValueError("the SVG contains a script or event handler")
    elif ext in FAVICONS:
        from PIL import Image
        try:
            Image.open(io.BytesIO(data)).verify()
        except Exception as e:  # noqa: BLE001 - isolation point: Pillow raises many kinds for a broken picture
            raise ValueError("not a picture Pillow can read") from e
    elif ext in TEMPLATES:
        try:
            names = zipfile.ZipFile(io.BytesIO(data)).namelist()
        except zipfile.BadZipFile as e:
            raise ValueError("not a PowerPoint file") from e
        if "ppt/presentation.xml" not in names:
            raise ValueError("not a PowerPoint file")
    elif ext in FONTS:
        if not data.startswith(_FONT_MAGIC):
            raise ValueError("not a font file")
    elif ext == ".json":
        try:
            ok = isinstance(json.loads(data.decode("utf-8-sig")), dict)
        except (UnicodeDecodeError, ValueError) as e:
            raise ValueError(f"brand.json is not valid JSON ({e})") from e
        if not ok:
            raise ValueError('brand.json must be an object, e.g. {"accent": "#0b41cd"}')


def _upload_target(kind: str, name: str, ext: str) -> Path:
    """Where an uploaded file goes; the one logo, template or brand.json there can be is replaced."""
    d = config.BRAND_DIR
    if kind in ("logo", "favicon", "template"):   # one of each: the new one replaces the old
        for old in _files():
            mine = {"logo": "logo" in old.stem.lower() and old.stem.lower() != "favicon",
                    "favicon": old.stem.lower() == "favicon", "template": True}[kind]
            if old.suffix.lower() in UPLOAD_KINDS[kind] and mine:
                old.unlink()
        return d / f"{kind}{ext}"
    if kind == "settings":
        return d / "brand.json"
    if kind == "icon":
        return d / "icons" / f"{_slug(Path(name).stem) or 'icon'}.svg"
    safe = re.sub(r"[^A-Za-z0-9._ -]+", "", Path(name).stem).strip(" .") or kind
    return (d / "images" if kind == "image" else d) / f"{safe}{ext}"


def save_upload(kind: str, name: str, data: bytes) -> Path:
    """Puts a file from the page where the brand is read from, and uses it at once (no restart).

    Raises:
        ValueError: an unknown kind, a wrong file type, an empty, too big or unsafe file.
    """
    if kind not in UPLOAD_KINDS:
        raise ValueError(f"unknown kind '{kind}'")
    ext = Path(name).suffix.lower()
    if ext not in UPLOAD_KINDS[kind]:
        raise ValueError(f"a {kind} must be one of {', '.join(UPLOAD_KINDS[kind])}")
    if not data or len(data) > MAX_UPLOAD_BYTES:
        raise ValueError(f"the file is empty or bigger than {MAX_UPLOAD_BYTES // 2**20} MB")
    _check_content(ext, data)
    target = _upload_target(kind, name, ext)
    target.parent.mkdir(parents=True, exist_ok=True)
    part = target.with_name(f".{target.name}.part")   # hidden while it is written
    part.write_bytes(data)
    part.replace(target)
    if kind not in ("icon", "image"):   # icons and pictures are looked up each time; the rest is read once
        reload()
    log.info("Brand file saved: %s", target.relative_to(config.BRAND_DIR))
    return target


def files() -> list[str]:
    """Every brand file, relative to data/brand (for the page's list)."""
    d = config.BRAND_DIR
    if not d.is_dir():
        return []
    return sorted(p.relative_to(d).as_posix() for p in d.rglob("*")
                  if p.is_file() and not p.name.startswith((".", "~$")))


def delete_file(rel: str) -> bool:
    """Removes one brand file (a path from files()); False when there is no such file."""
    d = config.BRAND_DIR.resolve()
    target = (d / rel).resolve()
    if d not in target.parents or not target.is_file() or rel not in files():
        return False
    target.unlink()
    reload()
    return True


def reload() -> None:
    """After the files changed: the brand, the slide styles and the colours are read again."""
    from studio.video import slides_html
    _info.cache_clear()
    slides_html.css_cache_clear()
    config.apply_brand_colours()


def main() -> int:
    """Command line: show the brand found in data/brand (--preview: a sample slide). Returns the exit code."""
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--preview", action="store_true", help="a sample slide: data/output/brand_preview.png")
    args = ap.parse_args()
    config.setup_logging()
    s = summary()
    if not s["on"]:
        print(f"No brand: put the logo, the PowerPoint template and/or brand.json in {s['folder']}")
        return 1
    print(json.dumps(s, indent=2, ensure_ascii=False))
    if args.preview:
        print(f"Preview: {preview()}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
