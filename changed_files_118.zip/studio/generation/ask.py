"""
ask.py - make a lesson from a request in your own words, the way users will ask for it later.

  uv run -m studio ask "I need a 2-minute video on joining data for beginners, as a presentation with audio"
  uv run -m studio ask "Hej, chcę 3 minuty o typach złączeń, poziom średni, z tabelą porównawczą"
  uv run -m studio ask "Summarise the recording about data cleaning in 5 minutes as a text lesson"
  uv run -m studio ask "An 8-minute course for beginners on preparing data for reports"
  uv run -m studio ask "A 5-minute summary of everything in the recordings"
  uv run -m studio ask "Napisz mi dokument-wykład o rolach w Scrumie, z tabelą i podsumowaniem"
  uv run -m studio ask "A simple 6-slide presentation on sprint planning that I can present myself"
  uv run -m studio ask "A 3-minute video where two people talk about the daily scrum"

How it works:
 1. The chat model reads the request together with the list of available recordings and
    turns it into settings: format (text / slides / video / dialogue / audio), topic, recordings, minutes, level,
    and any wishes about the look ("with a comparison table", "more examples").
 2. The settings are printed, so you see how the request was understood.
 3. The lesson is made from the whole knowledge base (the person does not need to know which
    recording has what):
      text      -> lesson.py: a document like a good written answer (lesson.html + lesson.md):
                   overview, sections with bold key terms, bullets, tables, examples, summary, quiz
      slides    -> deck.py: a simple presentation (slides.pdf, slides.pptx, speaker notes)
      video     -> an animated presentation with a narrator (make_video.py; 4+ min: course.py)
      dialogue  -> the same, but a host and an expert talk about it (two voices, two people)
      audio     -> the narration as mp3 (the video is made next to it)
Requests can be in any language; the lesson itself is written in English.

Every result is checked automatically and gets a verdict: OK / CHECK / FAIL (quality.json).
Requests that try to steer the AI, ask for inappropriate content or for facts from outside the
material are refused before anything is made. Topics the recordings do not cover ("how to make brownies")
are refused before any writing: first a free check (no word of the request is in the recordings and the
search finds nothing close: one embedding, ~$0.00001), then Claude reading the request (~$0.005) says
whether any recording is about it. The message says the topic is not in the training material.

The same request as a result made before (the same words and choices: at once and free; or the same settings as
Claude reads them: ~$0.005), with the same material, code and .env, gets that result back instead of being made
again, unless its verdict was FAIL (library.py, LIBRARY in .env).

Options:  --plan-only  (video: storyboard only, check script.md first)
          --no-review  (skip the model review of the result, ~$0.01; the rule checks always run)
          --fresh      (make a new version even if the library has this one)
"""
from __future__ import annotations

import argparse
import functools
import logging
import re
import sys
from collections.abc import Callable
from pathlib import Path

from studio.core import config, llm, resources, runcard, safety, store
from studio.generation import course, lesson, storyboard
from studio.video import make_video

log = logging.getLogger("ask")

FORMATS = {
    "answer": "a direct answer to a question (what / how / why / who / when ...), a few sentences with sources",
    "text": "a written lesson / document / article / notes / explanation to read (with tables, bullets, summary)",
    "slides": "a simple presentation / slide deck / slides without voice (PDF/PowerPoint with speaker notes)",
    "video": "an animated presentation with a narrator's voice / a video lesson / explainer",
    "dialogue": "a video where two people / characters (a host and an expert) talk about the topic, "
                "a conversation / interview / podcast-style video",
    "audio": "something to listen to only (audio, podcast without picture)",
}
REQUEST_SCHEMA = {
    "type": "object",
    "properties": {
        "format": {"type": "string", "enum": list(FORMATS),
                   "description": "; ".join(f"{k} = {v}" for k, v in FORMATS.items())},
        "topic": {"type": "string", "description": "What to teach, in English, a short phrase"},
        "question": {"type": "string", "description": "For format answer: the question, in English, complete"},
        "recordings": {"type": "array", "items": {"type": "string"},
                       "description": "ids of the recordings the request points to; empty = search all"},
        "minutes": {"type": "number", "description": "Target length in minutes (1-15)"},
        "level": {"type": "string", "enum": ["beginner", "intermediate", "expert"]},
        "wishes": {"type": "string", "description": "Wishes about content or look, in English; empty if none"},
        "characters": {"type": "string", "enum": ["cartoon", "people", "default"],
                       "description": "cartoon: animated cartoon characters / animals / fairy-tale or kids style; "
                                      "people: realistic people; default: not said"},
        "in_material": {"type": "boolean",
                        "description": "false only if no recording is about what the request asks for"},
        "style": {"type": "string", "enum": ["clean", "illustrated", "presenter", "default"],
                  "description": "clean: simple, concrete, no pictures | illustrated: nice slides with pictures of "
                                 "people, offices, screens | presenter: a presenter / teacher / character shows the "
                                 "slides | default: not said"},
    },
    "required": ["format", "topic", "recordings", "minutes", "level", "wishes", "style", "in_material"],
}
SYSTEM = """You turn a learner's request for a lesson into settings. The request can be in any
language; write topic and wishes in English. Rules:
- format: answer if they simply ask a question (what is, how do I, why, who, when ...) and do not
  ask for a lesson, document, slides, video, conversation or audio; text if they want something to read (document, lecture notes, article, explanation,
  summary, handout); slides if they want a presentation or slides without voice or animation
  (to present themselves, to print, a deck); video if they want a video, an animated or narrated
  presentation, an explainer; dialogue if they want two people / characters talking, a
  conversation, an interview or a podcast-style video; audio if they only want to listen.
  Default: video.
- recordings: only if the request clearly points to specific recordings (by number or by their
  subject); use the ids from the list. Otherwise an empty list, and the topic is searched in all.
- topic: what to teach. For "everything", "all recordings", "a summary/overview" write e.g.
  "overview of everything in the recordings".
- minutes: as asked (for text and slides: reading or talk time); default 2 for video, dialogue and
  audio, 5 for text, 4 for slides; between 1 and 15.
- level: beginner unless they say they know the basics (intermediate) or are experienced (expert).
- wishes: anything else they ask for about content or look (e.g. "use a comparison table",
  "include an example"), otherwise empty.
- style: clean if they want it simple, concrete, minimal or without pictures; illustrated if they
  want it nice, colourful, with pictures, images or illustrations; presenter if they want someone
  (a presenter, teacher, trainer, avatar, character) showing or explaining the slides; else default.
- characters: cartoon if they ask for a cartoon, fairy tale (bajka), animated characters or animals
  (a bear, a fox...); people if they want people; else default. A request for a cartoon character
  explaining the topic is format video with style presenter (or dialogue for two characters).
- in_material: false only when the request is clearly about something none of the recordings is
  about (cooking, sport, travel, celebrities, general knowledge, another field); true when any
  recording could cover it, for "everything" / an overview, and whenever you are unsure.
- earlier in this chat: when the request builds on it ("and who owns it?", "more on that", "the same as a
  video", "what about the second one?"), resolve every reference from it, so that topic and question are
  complete on their own; a request that starts something new is read on its own."""


def history_text(history: list[dict] | None) -> str:
    """The last turns of the chat, oldest first, for reading a follow-up request ("and who owns it?")."""
    if config.CHAT_HISTORY_TURNS <= 0:
        return ""
    lines = []
    for h in (history or [])[-config.CHAT_HISTORY_TURNS:]:
        lines.append(f"- asked: {' '.join(str(h.get('request', '')).split())[:300]}")
        if h.get("answer"):
            lines.append(f"  got: {' '.join(str(h['answer']).split())[:400]}")
    return "\n".join(lines)


def understand(request: str, history: list[dict] | None = None) -> dict:
    """Ask the chat model to turn a request in plain words into settings (a follow-up: with the chat so far)."""
    rows = store.available_recordings()
    if not rows:
        raise ValueError("No processed recordings yet: set include=yes in data/manifest.csv and run pipeline.py.")
    listing = "\n".join(f"- id {r['video_id']}: {r['title']}" + (f" ({r['description']})" if r.get("description") else "")
                        for r in rows)
    earlier = history_text(history)
    prompt = (f"Available recordings:\n{listing}\n\n" + (f"Earlier in this chat (oldest first):\n{earlier}\n\n" if earlier
                                                             else "") + f"Request:\n{request}")
    data = llm.chat_json(prompt, REQUEST_SCHEMA, system=SYSTEM, step="understand_request",
                         max_tokens=500, temperature=0.0)
    known = {r["video_id"] for r in rows}
    data["recordings"] = [x for x in data.get("recordings", []) if x in known]
    data["minutes"] = max(1.0, min(15.0, float(data.get("minutes") or 2)))
    if data.get("level") not in lesson.LEVELS:
        data["level"] = "beginner"
    if data.get("format") not in FORMATS:
        data["format"] = "video"
    data["question"] = (data.get("question") or "").strip() or request
    data["topic"] = (data.get("topic") or "").strip() or request[:80]
    if data.get("style") not in ("clean", "illustrated", "presenter"):
        data["style"] = None
    if data.get("characters") not in ("cartoon", "people"):
        data["characters"] = None
    return data


class RequestRefused(ValueError):
    """The request was refused before anything was made (it tries to steer the AI, asks for
    inappropriate content or for facts from outside the material)."""


class NotInMaterial(lesson.NotEnoughMaterial):
    """The request is about something the training material does not cover: refused before any writing."""


# words of a request that say nothing about its topic (the free check looks at the others)
GENERIC = set("""about also want would like need make made create give show tell explain teach please some
something with without that this these those from into what when where which while your mine their there here
have does doing done just more most less very much many really maybe could should video videos minute minutes
lesson lessons course courses presentation slides slide deck document text audio podcast listen watch read
beginner beginners intermediate expert experts level short long quick simple nice cartoon presenter animated
dialogue conversation people characters character style summary overview everything recording recordings
material training learn learning know understand basics hello thanks""".split())
POLISH = re.compile(r"[ąćęłńóśźż]|\b(chcę|chce|zrób|zrob|proszę|prosze|jak|dla|się|sie|czy|jest|minut[ay]?|o\s)\b", re.I)


def _words(text: str) -> set[str]:
    return set(re.findall(r"[^\W\d_]{4,}", text.lower()))


@functools.lru_cache(maxsize=2)
def _vocabulary(built: str) -> tuple[frozenset, frozenset]:   # noqa: ARG001 - the cache key: one per index build
    """Every word of the recordings (and its first 6 letters, so "joining" finds "joins"), per index build."""
    words: set[str] = set()
    for seg in store.all_segments().values():
        words |= _words(f"{seg.get('title', '')} {seg.get('text', '')}")
    return frozenset(words), frozenset(w[:6] for w in words if len(w) >= 6)


def off_topic(request: str) -> str:
    """The free check before any Claude call: '' when the recordings may cover the request, else why not.
    Off topic: no word of the request is in the recordings and the closest excerpt is below MIN_SCORE (the bar
    the search uses: below it nothing would be found anyway). Requests in Polish are left to Claude (the
    recordings are in English, so their words do not match). Any problem: '' (Claude decides)."""
    words = _words(request) - GENERIC
    if not words or POLISH.search(request):
        return ""
    try:
        built = str(store.load_index()[2].get("built_at", ""))
        vocab, stems = _vocabulary(built)
        if any(w in vocab or w[:6] in stems for w in words):
            return ""
        from studio.knowledge import index
        hits = index.search(" ".join(sorted(words)), top_k=3)
    except (OSError, ValueError, KeyError, llm.LLMError) as e:   # no index yet, the embedding failed: Claude decides
        log.info("Free topic check skipped: %s", e)
        return ""
    best = hits[0]["score"] if hits else 0.0
    return "" if best >= config.MIN_SCORE else f"no word of it is in the recordings, closest match {best:.2f}"


def not_in_material(request: str, mark: int) -> str:
    """The message for a topic the recordings do not cover: what is covered instead, and what it cost."""
    spent = sum(c["cost_usd"] for c in llm.calls_since(mark))
    titles = [r["title"] for r in store.available_recordings()]
    covers = "; ".join(titles[:6]) + (f" (and {len(titles) - 6} more)" if len(titles) > 6 else "")
    return (f"This topic is not in the training material, so no lesson can be made about it: \"{request[:100]}\". "
            f"Nothing was made ({'no cost' if spent < 0.0005 else f'${spent:.3f} for the check'}). "
            f"Ask about what the recordings cover: {covers or 'nothing processed yet'}.")


FILES = {"answer": "answer.md", "video": "lesson_video.mp4", "avatar_video": "lesson_video_avatar.mp4", "audio": "lesson_audio.mp3",
         "document": "lesson.html", "markdown": "lesson.md", "pdf": "slides.pdf", "pptx": "slides.pptx",
         "pptx_editable": "slides_editable.pptx", "notes": "notes.md", "script": "script.md", "chapters": "chapters.txt", "run_card": "run_card.md"}


OVERRIDES = ("format", "minutes", "level", "style", "characters")


def run(request: str, *, review: bool = True, model: str | None = None, plan_only: bool = False,
        on_understood: Callable[[dict], None] | None = None, overrides: dict | None = None,
        history: list[dict] | None = None) -> dict:
    """A request in plain words -> the finished, checked result (see _run), with the time of each phase and the
    machine's load written to its run card (resources.py)."""
    with resources.job() as meter:
        result = _run(request, review=review, model=model, plan_only=plan_only, on_understood=on_understood,
                      overrides=overrides, history=history)
    return _with_timeline(result, meter)


def _with_timeline(result: dict, meter: resources.Meter) -> dict:
    """A newly made result gets its time line on the run card (a result from the library keeps the original's)."""
    from studio.core import runcard
    if result.get("reused") or not result.get("folder"):
        return result
    out_dir = Path(result["folder"])
    if (out_dir / "run_card.json").exists():
        runcard.add_timeline(out_dir, meter.summary())
        result["card"] = store.read_json(out_dir / "run_card.json", {}) or {}
    return result


def _run(request: str, *, review: bool = True, model: str | None = None, plan_only: bool = False,
         on_understood: Callable[[dict], None] | None = None, overrides: dict | None = None,
         history: list[dict] | None = None) -> dict:
    """A request in plain words -> the finished, checked result. The one entry point used by
    the command line, the web page (app.py) and the end-to-end check (smoke.py).
    overrides: settings chosen by clicking (format, minutes, level, style, characters); they win
    over what the model reads from the request. {"fresh": True}: a new version, not the one from the library.
    history: the earlier turns of the chat [{request, answer}], so a follow-up is read as a full request.
    Returns {request, understood, format, folder, files, quality, card, cost_usd, seconds}.
    Raises RequestRefused, lesson.NotEnoughMaterial, llm.LLMError / RuntimeError / ValueError."""
    import time

    from studio.core import resources, runcard
    from studio.quality import quality
    t0 = time.perf_counter()
    mark = llm.meter_mark()
    runcard.REQUEST.set(request)   # shown on the result's run card (this job's context only)
    refused = safety.request_problem(request)
    if refused:
        raise RequestRefused(f"Request not accepted: {refused}. Ask for a topic from the training material.")
    # free: before any Claude call (a follow-up is checked with the request before it: "and who owns it?")
    why = off_topic(" ".join([str(history[-1].get("request", "")) if history else "", request]).strip())
    if why:
        log.info("Not in the material (%s): %s", why, request[:100])
        raise NotInMaterial(not_in_material(request, mark))
    fresh = bool((overrides or {}).get("fresh"))
    words = _words_key(request, overrides, model, review, plan_only)
    found = _same_words(words, request, fresh, first_in_chat=not history)   # same words and choices: at once
    if found:
        if on_understood:
            on_understood(found[1])
        return _reused(request, found[1], found[0], mark, t0)
    s = understand(request, history) if history else understand(request)
    if s.get("in_material") is False:   # Claude read the request with the list of recordings (~$0.005)
        raise NotInMaterial(not_in_material(request, mark))
    _with_choices(s, overrides)
    if on_understood:
        on_understood(s)
    recordings = ",".join(s["recordings"]) or None
    if s["format"] == "answer":
        resources.mark("answer")
        return _answer(request, s, model, mark, t0)
    resources.mark("writing")
    shelf, made_before = _library(s, model, review, plan_only, fresh)
    if shelf and not made_before and not fresh:
        log.info("Library: not made before with these settings (%s); making it", _settings_line(s))
    if made_before:
        _keep([words], made_before, {"status": "OK"}, s)   # next time these words find it at once
        return _reused(request, s, made_before, mark, t0)
    if s["format"] == "text":
        record = lesson.make_lesson(s["topic"], int(round(s["minutes"])), s["level"], model=model,
                                    wishes=s.get("wishes", ""))
        out_dir = Path(record["path"])
    elif s["format"] == "slides":
        from studio.generation import deck
        out_dir, _ = deck.make(s["topic"], recordings, s["minutes"], s["level"], model, wishes=s.get("wishes", ""),
                               style=s.get("style") or "clean")
    elif s["minutes"] >= course.COURSE_MIN_MINUTES:
        out_dir, _ = course.make(s["topic"], s["minutes"], s["level"], model, plan_only, wishes=s.get("wishes", ""),
                                 style=s.get("style"), characters=s.get("characters"),
                                 audio_only=s["format"] == "audio")
    else:
        out_dir, _ = make_video.make(s["topic"], recordings, s["minutes"], s["level"], model, plan_only,
                                     wishes=s.get("wishes", ""), style=s.get("style"), characters=s.get("characters"),
                                     audio_only=s["format"] == "audio")
    resources.mark("checks")
    q = quality.check_any(out_dir, review=review and not plan_only)
    _keep([shelf, words], out_dir, q, s)
    card = store.read_json(out_dir / "run_card.json", {}) or {}
    return {"request": request, "understood": s, "format": s["format"], "folder": str(out_dir),
            "files": {k: str(out_dir / f) for k, f in FILES.items() if (out_dir / f).exists()},
            "quality": q, "card": card, "plan_only": plan_only,
            "cost_usd": round(sum(c["cost_usd"] for c in llm.calls_since(mark)), 4),
            "seconds": round(time.perf_counter() - t0, 1)}


def resume(folder: Path, review: bool = True, audio_only: bool = False) -> dict:
    """Finish a video that was stopped (the page's Resume): its storyboard, the paid part, is kept; the voice parts
    already made and the scenes whose pictures are ready are reused (make_video). The same result as run()."""
    with resources.job("writing") as meter:
        result = _resume(folder, review, audio_only)
    return _with_timeline(result, meter)


def _resume(folder: Path, review: bool, audio_only: bool) -> dict:
    """resume() without the time line."""
    import time

    from studio.core import resources
    from studio.quality import quality
    t0, mark = time.perf_counter(), llm.meter_mark()
    sb = storyboard.load(folder)
    req = sb.get("request") or {}
    s = {"format": "audio" if audio_only else "video", "topic": req.get("topic", sb.get("title", "")),
         "minutes": req.get("minutes"), "level": req.get("level"), "style": req.get("style"), "recordings": []}
    out_dir, _ = make_video.make(rerender=folder, audio_only=audio_only)
    resources.mark("checks")
    q = quality.check_any(out_dir, review=review)
    card = store.read_json(out_dir / "run_card.json", {}) or {}
    return {"request": runcard.REQUEST.get() or s["topic"], "understood": s, "format": s["format"],
            "folder": str(out_dir), "files": {k: str(out_dir / f) for k, f in FILES.items() if (out_dir / f).exists()},
            "quality": q, "card": card, "plan_only": False,
            "cost_usd": round(sum(c["cost_usd"] for c in llm.calls_since(mark)), 4),
            "seconds": round(time.perf_counter() - t0, 1)}


def _with_choices(s: dict, overrides: dict | None) -> None:
    """The settings picked on the page win over what Claude read; unsafe wishes are dropped; the style a format or
    a character needs."""
    for key, value in (overrides or {}).items():
        if key in OVERRIDES and value not in (None, "", "auto"):
            s[key] = float(value) if key == "minutes" else value
    if safety.request_problem(s.get("wishes", "")):   # wishes go into the prompts: same screen
        log.warning("Wishes ignored: %s", safety.request_problem(s["wishes"]))
        s["wishes"] = ""
    if s["format"] == "dialogue":
        s["style"] = "dialogue"
    elif s["format"] in ("video", "audio") and s.get("characters") == "cartoon" and s.get("style") in (None, "clean", "illustrated"):
        s["style"] = "presenter"   # a cartoon character presents the lesson


def _words_key(request: str, overrides: dict | None, model: str | None, review: bool, plan_only: bool) -> str:
    """The library key of the request's own words and the page's choices ("" when the library is off, for a plan)."""
    from studio.core import library
    if not config.LIBRARY or plan_only:
        return ""
    return library.request_key(request, overrides, model, review)


def _same_words(words: str, request: str, fresh: bool, first_in_chat: bool = False) -> tuple[Path, dict] | None:
    """(folder, settings) of a result kept for exactly these words and choices; None when there is none or a new
    version is asked for. The first message of a chat stands on its own; later in a chat the words must name the
    result's topic, so a follow-up like "and now as a video" is never taken for it."""
    from studio.core import library
    found = library.find_entry(words) if words and not fresh else None
    if not found or not found[1]:
        return None
    if not first_in_chat and not library.named_in(request, found[1]):
        log.info("Library: the same words were made before, but here they may follow the chat; reading them again")
        return None
    return found[0], found[1]


def _library(s: dict, model: str | None, review: bool, plan_only: bool, fresh: bool) -> tuple[str, Path | None]:
    """(the library key of the settings Claude read, or "" when the library is off or for a plan; the folder of the
    result kept for the same settings, unless a new version is asked for)."""
    from studio.core import library
    if not config.LIBRARY or plan_only:
        return "", None
    shelf = library.key(s, model, review)
    return shelf, None if fresh else library.find(shelf)


def _settings_line(s: dict) -> str:
    """The settings a result is kept under (library.KEYS), for the log."""
    from studio.core import library
    return ", ".join(f"{k}={s.get(k)}" for k in library.KEYS if s.get(k) not in (None, "", []))


def _keep(keys: list[str], out_dir: Path, q: dict, s: dict) -> None:
    """A result with the verdict OK or CHECK: given back for the same words, or the same settings, next time."""
    from studio.core import library
    if library.remember(keys, out_dir, q, {k: s.get(k) for k in library.KEYS}):
        log.info("Kept in the library: the same request gets this result back at once")
    elif config.LIBRARY:
        log.info("Not kept in the library: verdict %s (only OK and CHECK are given again)", q.get("status"))


def _reused(request: str, s: dict, out_dir: Path, mark: int, t0: float) -> dict:
    """The result made before with exactly the same settings (library.py): given back, not made again. Its cost
    now is only reading the request; the run card keeps what it cost when it was made."""
    import time

    from studio.quality import monitoring
    card = store.read_json(out_dir / "run_card.json", {}) or {}
    log.info("From the library: made before on %s (cost then $%.2f), same request and settings, nothing changed "
             "since. For a new version: 'Make a new version' on the page, or --fresh", str(card.get("created", ""))[:16],
             float((card.get("cost") or {}).get("total_usd") or 0))
    monitoring.inc("lesson_studio_library_reused_total", format=s["format"])
    return {"request": request, "understood": s, "format": s["format"], "folder": str(out_dir),
            "files": {k: str(out_dir / f) for k, f in FILES.items() if (out_dir / f).exists()},
            "quality": store.read_json(out_dir / "quality.json", {}) or {"status": "OK", "fail": [], "issues": []},
            "card": card, "plan_only": False, "reused": True,
            "made_cost_usd": round(float((card.get("cost") or {}).get("total_usd") or 0), 4),
            "cost_usd": round(sum(c["cost_usd"] for c in llm.calls_since(mark)), 4),
            "seconds": round(time.perf_counter() - t0, 1)}


def _answer(request: str, s: dict, model: str | None, mark: int, t0: float) -> dict:
    """A question: a short answer from the material with the source of every sentence (answer.py)."""
    import time

    from studio.generation import answer
    record = answer.answer(s.get("question") or request, length="short" if s["minutes"] <= 2 else "medium",
                           level=s["level"], model=model)
    out_dir = Path(record["folder"])
    c = record.get("checks") or {}
    issues = []
    if record.get("not_in_material"):
        issues.append("The training material does not cover this question; nothing was invented.")
    if c.get("unsourced_sentences"):
        issues.append(f"{c['unsourced_sentences']} sentence(s) without a source")
    if c and c.get("evidence_verified", 1) < 0.8:
        issues.append(f"only {c['evidence_verified']:.0%} of the evidence found word for word")
    if c.get("numbers_not_in_sources"):
        issues.append("numbers not in the sources: " + ", ".join(c["numbers_not_in_sources"]))
    if c.get("verified") and not c["verified"].get("checked"):
        issues.append("not checked sentence by sentence this time (checks in code only)")
    q = {"status": "CHECK" if issues and not record.get("not_in_material") else "OK", "fail": [], "issues": issues}
    card = store.read_json(out_dir / "run_card.json", {}) or {}
    return {"request": request, "understood": s, "format": "answer", "folder": str(out_dir),
            "files": {k: str(out_dir / f) for k, f in FILES.items() if (out_dir / f).exists()},
            "quality": q, "card": card, "plan_only": False, "answer": record,
            "cost_usd": round(sum(x["cost_usd"] for x in llm.calls_since(mark)), 4),
            "seconds": round(time.perf_counter() - t0, 1)}


def print_understood(s: dict) -> None:
    """Print what the request was understood as (format, topic, recordings, length, level)."""
    titles = {r["video_id"]: r["title"] for r in store.available_recordings()}
    print("\nUnderstood as:")
    print(f"  format:     {s['format']}")
    print(f"  topic:      {s['topic']}")
    print(f"  recordings: {', '.join(titles.get(v, v) for v in s['recordings']) or 'all (searched by topic)'}")
    print(f"  length:     {s['minutes']:g} min, level {s['level']}")
    if s.get("wishes"):
        print(f"  wishes:     {s['wishes']}")
    if s["format"] in ("video", "slides", "dialogue", "audio"):
        print(f"  style:      {s.get('style') or config.STYLE}" + (f", characters {s['characters']}" if s.get("characters") else ""))
    if s["format"] not in ("text", "slides") and s["minutes"] >= course.COURSE_MIN_MINUTES:
        print(f"  -> a course with chapters from all recordings ({s['minutes']:g} min)")
    print()


LABELS = {"answer": "Answer", "video": "Video", "avatar_video": "Video with presenter", "audio": "Audio", "document": "Document",
          "markdown": "Markdown", "pdf": "Slides", "pptx": "PowerPoint", "notes": "Speaker notes",
          "script": "Script", "chapters": "Chapters", "run_card": "Run card"}


def print_result(r: dict) -> int:
    """The files, the quality verdict and the cost of a result; 1 on FAIL."""
    if r.get("answer"):
        print(r["answer"]["text"] + "\n")
    for key, path in r["files"].items():
        if key in LABELS:
            print(f"{LABELS[key] + ':':<22}{path}")
    if r["plan_only"]:
        print(f"Then: uv run -m studio make_video --rerender \"{r['folder']}\"")
        return 0
    q = r["quality"]
    verdict = {"OK": "OK - ready to use", "CHECK": "CHECK - have a look at the points below",
               "FAIL": "FAIL - do not use this result", "PLAN": "PLAN - not rendered yet"}[q["status"]]
    print(f"\nQuality: {verdict}")
    for line in q["fail"] + q["issues"]:
        print(f"   - {line}")
    if q.get("review"):
        rv = q["review"]
        print(f"   review: true to the sources {rv['faithful']}/5, level {rv['level_fit']}/5, clarity {rv['clarity']}/5")
        for i in rv.get("issues", [])[:5]:
            print(f"     part {i.get('scene')}: {i.get('problem')}")
    card = r["card"]
    if r.get("reused"):
        print(f"\nFrom the library: made before ({str(card.get('created', ''))[:16]}, cost then "
              f"${r['made_cost_usd']:.2f}); this time ${r['cost_usd']:.4f}. A new version: --fresh")
    elif card:
        c = card["cost"]
        print(f"\nCost: ${c['total_usd']:.4f} in model calls ({c['model_calls']} calls), "
              f"{card['input'].get('sources_used', 0)} sources used, {r['seconds']:.0f} s"
              f"   (all results compared: uv run -m studio compare)")
    return 1 if q["status"] == "FAIL" else 0


def main() -> int:
    """Command line: make what a request in plain words asks for. Returns the exit code."""
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("request", help="the request in your own words (in quotes)")
    ap.add_argument("--plan-only", action="store_true", help="video: stop after the storyboard")
    ap.add_argument("--no-review", action="store_true",
                    help="skip the model review of the result (the rule checks always run)")
    ap.add_argument("--model", help="override CHAT_MODEL from .env")
    ap.add_argument("--fresh", action="store_true", help="make a new version even if the library has this one")
    args = ap.parse_args()
    config.setup_logging()
    try:
        r = run(args.request, review=not args.no_review, model=args.model, plan_only=args.plan_only,
                on_understood=print_understood, overrides={"fresh": True} if args.fresh else None)
    except RequestRefused as e:
        log.error("%s", e)
        return 3
    except lesson.NotEnoughMaterial as e:
        log.error("%s", e)
        return 2
    except (RuntimeError, ValueError, OSError) as e:
        log.error("%s", e)
        return 1
    return print_result(r)


if __name__ == "__main__":
    code = main()
    from studio.costs import usage
    usage.report()   # spent today, ElevenLabs characters left, Remotion
    sys.exit(code)
