"""The run card of every result: what it was made from, how, what it cost and how long it took.

Written next to the result as run_card.json (for compare.py and the cost reports) and run_card.md (to read):
request, input (sources and excerpts used), solution (models, voice, slide engine, versions), cost (every model
call by step), time and resources, and the quality verdict (added by quality.py). Costs are list-price estimates.
"""
from __future__ import annotations

import contextvars
from datetime import datetime
from pathlib import Path
from typing import Any

from studio.core import config, store

# the request in the person's own words, shown on the card (set by ask.py for the current job's context)
REQUEST: contextvars.ContextVar[str] = contextvars.ContextVar("request_text", default="")

FILES = ["answer.md", "lesson.html", "lesson.md", "slides.pdf", "slides.pptx", "slides_editable.pptx", "notes.md", "lesson_video.mp4",
         "lesson_audio.mp3", "lesson_video.srt", "lesson_audio.srt", "chapters.txt", "script.md", "quiz.md"]


def cost_summary(calls: list[dict[str, Any]]) -> dict[str, Any]:
    """Model calls added up per step and model, and in total."""
    rows: dict[tuple[Any, ...], dict[str, Any]] = {}
    for c in calls:
        r = rows.setdefault((c["step"], c["model"], c["backend"]),
                            {"step": c["step"], "model": c["model"], "backend": c["backend"], "calls": 0,
                             "in_tokens": 0, "out_tokens": 0, "cache_read_tokens": 0, "cache_write_tokens": 0,
                             "characters": 0,
                             "seconds": 0.0, "cost_usd": 0.0})
        r["calls"] += 1
        r["in_tokens"] += int(c.get("in_tokens") or 0)
        r["out_tokens"] += int(c.get("out_tokens") or 0)
        r["characters"] += int(c.get("characters") or 0)
        r["cache_read_tokens"] += int(c.get("cache_read_tokens") or 0)
        r["cache_write_tokens"] += int(c.get("cache_write_tokens") or 0)
        r["seconds"] = round(r["seconds"] + float(c.get("seconds") or 0), 1)
        r["cost_usd"] = round(r["cost_usd"] + float(c.get("cost_usd") or 0), 6)
    by_step = sorted(rows.values(), key=lambda r: -r["cost_usd"])
    return {"total_usd": round(sum(r["cost_usd"] for r in by_step), 4),
            "model_calls": sum(r["calls"] for r in by_step),
            "in_tokens": sum(r["in_tokens"] for r in by_step), "out_tokens": sum(r["out_tokens"] for r in by_step),
            "cache_read_tokens": sum(r["cache_read_tokens"] for r in by_step),
            "model_seconds": round(sum(r["seconds"] for r in by_step), 1), "by_step": by_step,
            "note": "estimate from list prices; local models and local steps are free"}


def input_summary(sources: dict[str, Any]) -> dict[str, Any]:
    """The sources a result was made from: per source title, how many excerpts and where."""
    used: dict[str, dict[str, Any]] = {}
    for _label, s in sorted(sources.items(), key=lambda kv: (kv[1].get("title", ""), kv[1].get("start", 0))):
        u = used.setdefault(s.get("title", s.get("video_id", "?")),
                            {"source": s.get("title", ""), "id": s.get("video_id", ""), "excerpts": 0, "where": []})
        u["excerpts"] += 1
        where = s.get("where") or f"{store.fmt_ts(s.get('start', 0))}-{store.fmt_ts(s.get('end', 0))}"
        if where not in u["where"]:
            u["where"].append(where)
    try:
        base = {"sources_in_knowledge_base": len(store.available_recordings()),
                "excerpts_in_knowledge_base": len(store.all_segments())}
    except (OSError, ValueError, KeyError):
        base = {}
    return {**base, "sources_used": len(used), "excerpts_used": sum(u["excerpts"] for u in used.values()),
            "used": list(used.values())}


def _where(backend: str) -> str:
    return "local" if backend == "ollama" else "Amazon Bedrock via gateway"


def _voice(style: str) -> str:
    """The voice engine and the voices that spoke (host and expert in a dialogue)."""
    from studio.video import tts

    def name(voice: str) -> str:
        return tts.eleven_voice_name(voice) if config.TTS_ENGINE == "elevenlabs" else voice

    try:
        who = (f"host {name(tts.role_voice('host') or 'default')}, expert {name(tts.role_voice('expert') or 'default')}"
               if style == "dialogue" else f"voice {name(tts.role_voice('narrator') or 'default')}")
    except tts.TTSError:
        who = "voice: default"
    return f"{tts.engine_label()}: {who}"


SLIDE_ENGINES = {"remotion": "Remotion (React templates)", "remotion-ai": "Remotion, scene code written by Claude",
                 "remotion-pro": "Remotion Pro (motion-design scenes, presenters)"}


def _pictures(style: str, characters: str, renderer: str) -> dict[str, str]:
    """How the slides, pictures and presenters were drawn, and which model read the original slides."""
    html = "designer slides (html" + (", GSAP motion)" if config.GSAP else ")")
    out = {"slides": html if renderer == "html" else SLIDE_ENGINES.get(renderer, f"simple slides ({renderer or 'pillow'})"),
           "style": style, "pictures": config.IMAGE_MODEL or "built-in drawings and icons (no image model)"}
    if style in ("presenter", "dialogue"):
        out["characters"] = characters or config.CHARACTERS
        if renderer == "remotion-pro":   # Pro draws its own presenters
            out["characters"] = config.PRO_PRESENTER + (f" ({config.PRO_AVATAR})" if config.PRO_PRESENTER == "person-2d" else "")
    out["slide_reader"] = f"{config.VISION_MODEL} ({_where(config.VISION_BACKEND)})"
    return out


def solution(kind: str, style: str = "", characters: str = "", renderer: str = "", models: list[str] | None = None,
             settings: dict[str, Any] | None = None) -> dict[str, Any]:
    """What made the result. `models`: the models actually called (from the cost log)."""
    out: dict[str, Any] = {
        "writing_model": f"{(settings or {}).get('model') or config.CHAT_MODEL} ({_where(config.CHAT_BACKEND)})",
        "review_model": config.REVIEW_MODEL or config.CHAT_MODEL,
        "search_model": f"{config.EMBED_MODEL} ({_where(config.EMBED_BACKEND)})",
        "models_called": sorted(set(models or []))}
    if kind not in ("document", "slides", "answer"):
        out["voice"] = _voice(style)
    if kind not in ("document", "audio", "answer"):
        out.update(_pictures(style, characters, renderer))
    if settings:
        out.update({k: settings[k] for k in ("skill", "prompt_version", "code_version", "self_review") if k in settings})
    return out


def write(out_dir: Path, *, kind: str, title: str, request: dict[str, Any], sources: dict[str, Any], calls: list[dict[str, Any]],
          timings: dict[str, Any] | None = None, style: str = "", characters: str = "", renderer: str = "",
          settings: dict[str, Any] | None = None, extra: dict[str, Any] | None = None) -> dict[str, Any]:
    """Write run_card.json and run_card.md into the result's folder. Returns the card."""
    previous = store.read_json(out_dir / "run_card.json", {}) or {}
    card = {
        "kind": kind, "title": title, "folder": out_dir.name, "created": datetime.now().isoformat(timespec="seconds"),
        "request": {**({"text": REQUEST.get()} if REQUEST.get() else {}), **request},
        "files": [f for f in FILES if (out_dir / f).exists()],
        "input": input_summary(sources),
        "solution": solution(kind, style, characters, renderer, [c["model"] for c in calls], settings),
        "cost": cost_summary(calls),
        "calls": calls,   # every model call, so later additions (the review) are added up exactly
        "time": timings or {},
        **(extra or {}),
    }
    if previous.get("quality"):
        card["quality"] = previous["quality"]
    save(out_dir, card)
    return card


def add_quality(out_dir: Path, result: dict[str, Any], review_calls: list[dict[str, Any]]) -> None:
    """Add the verdict (and the cost of the model review) to an existing run card."""
    card = store.read_json(out_dir / "run_card.json", {}) or {}
    if not card:
        return
    q = {"verdict": result.get("status"), "fail": result.get("fail", [])[:5], "issues": len(result.get("issues", []))}
    if result.get("review"):
        q.update({k: result["review"].get(k) for k in ("faithful", "level_fit", "clarity")})
    card["quality"] = q
    if review_calls:   # the review is part of what the result cost
        card["calls"] = card.get("calls", []) + review_calls
        card["cost"] = cost_summary(card["calls"])
    save(out_dir, card)


def add_timeline(out_dir: Path, timeline: dict[str, Any]) -> None:
    """Add how long each phase took and the machine's load (resources.py) to an existing run card."""
    card = store.read_json(out_dir / "run_card.json", {}) or {}
    if card:
        card["timeline"] = timeline
        save(out_dir, card)


def save(out_dir: Path, card: dict[str, Any]) -> None:
    """Save the run card as run_card.json and run_card.md."""
    store.write_json(out_dir / "run_card.json", card)
    (out_dir / "run_card.md").write_text(markdown(card), encoding="utf-8")


def _md_request_and_input(card: dict[str, Any]) -> list[str]:
    r, i = card["request"], card["input"]
    out = [f"# Run card: {card['title']}", "",
           f"**Output:** {card['kind']} · {', '.join(card['files']) or 'plan only'} · created {card['created']}", ""]
    if r.get("text"):
        out += [f"**Request:** \"{r['text']}\"", ""]
    hide = {"text"} | ({"characters"} if r.get("style") not in ("presenter", "dialogue") else set())
    asked = ", ".join(f"{k} {v}" for k, v in r.items() if k not in hide and v not in ("", None, [], {}))
    out += [f"**Settings:** {asked}", "", "## Input", ""]
    if "sources_in_knowledge_base" in i:
        out += [f"Knowledge base: {i['sources_in_knowledge_base']} sources, {i['excerpts_in_knowledge_base']} excerpts. "
                f"Used: {i['sources_used']} sources, {i['excerpts_used']} excerpts.", ""]
    out += ["| Source | Excerpts | Where |", "|---|---|---|"]
    out += [f"| {u['source']} | {u['excerpts']} | {', '.join(u['where'][:6])}{' ...' if len(u['where']) > 6 else ''} |"
            for u in i["used"]]
    out += ["", "## Solution", "", "| Part | Used |", "|---|---|"]
    out += [f"| {k.replace('_', ' ')} | {', '.join(v) if isinstance(v, list) else v} |" for k, v in card["solution"].items()]
    return out


def _md_cost(card: dict[str, Any]) -> list[str]:
    c = card["cost"]
    out = ["", "## Cost and time", "",
           f"**Model cost: ${c['total_usd']:.4f}** ({c['model_calls']} calls, {c['in_tokens']:,} tokens in, "
           f"{c['out_tokens']:,} out; {c['note']})", "",
           "| Step | Model | Calls | Tokens in / out | Seconds | Cost $ |", "|---|---|---|---|---|---|"]
    out += [f"| {x['step']} | {x['model']} | {x['calls']} | "
            + (f"{x['characters']:,} characters" if x.get("characters") else f"{x['in_tokens']:,} / {x['out_tokens']:,}")
            + f" | {x['seconds']} | {x['cost_usd']:.4f} |" for x in c["by_step"]]
    if card.get("time"):
        out += ["", "Time: " + ", ".join(f"{k.replace('_s', '')} {v} s" for k, v in card["time"].items()
                                       if isinstance(v, int | float))]
    return out


def _md_timeline(t: dict[str, Any]) -> list[str]:
    m = t.get("machine") or {}
    out = ["", "## Time and resources", "",
           f"**Total: {t['total_s']} s** · machine: {m.get('where', '')}, {m.get('cpu', '')}, {m.get('cores', '?')} cores"
           + (f", {m['ram_gb']} GB RAM" if m.get("ram_gb") else "") + f" · GPU {m.get('gpu', '')}"
           + (f" · peak memory {t['peak_ram_mb']} MB" if t.get("peak_ram_mb") else ""), "",
           "| Phase | Seconds | CPU % |", "|---|---|---|"]
    return out + [f"| {p['label']} | {p['seconds']} | {p['cpu_pct'] if p.get('cpu_pct') is not None else '-'} |"
                  for p in t.get("phases", [])]


def _md_quality(q: dict[str, Any]) -> list[str]:
    out = ["", "## Quality", "", f"**Verdict: {q['verdict']}**"
           + (f" · review: true to sources {q['faithful']}/5, level {q['level_fit']}/5, clarity {q['clarity']}/5"
              if q.get("faithful") else "")]
    return out + [f"- {x}" for x in q.get("fail", [])]


def markdown(card: dict[str, Any]) -> str:
    """The run card to read: request and input, solution, cost and time, resources, quality."""
    out = _md_request_and_input(card) + _md_cost(card)
    if card.get("timeline"):
        out += _md_timeline(card["timeline"])
    if card.get("quality"):
        out += _md_quality(card["quality"])
    return "\n".join(out) + "\n"
