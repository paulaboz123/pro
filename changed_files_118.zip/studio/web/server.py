"""The HTTP server: routes, sign-in check, files, health probes and a clean stop."""
from __future__ import annotations

import hashlib
import hmac
import json
import logging
import mimetypes
import os
import re
import socket
import sys
import threading
import time
import uuid
import webbrowser
from collections.abc import Callable
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import ParseResult, parse_qs, unquote, urlparse

from studio.core import config
from studio.costs import results_report
from studio.quality import monitoring
from studio.web import chats, jobs
from studio.web.auth import LOGIN, SIGN_IN_DAYS, _token, _token_ok
from studio.web.catalog import avatar_post, avatars, brand_post, brand_raw, brand_state, choices, defaults
from studio.web.jobs import ahead_of, chat_action, new_job, options, resume_job, state, stop_job
from studio.web.pricing import estimate, prices
from studio.web.views import comparisons, decks, report, results

log = logging.getLogger("app")
MAX_BODY = 64 * 1024              # a request, a rename, feedback
MAX_UPLOAD = 12 * 1024 * 1024     # a company avatar picture (base64 in JSON)
MAX_BRAND_UPLOAD = 42 * 1024 * 1024   # a company file, e.g. a PowerPoint template (base64 in JSON)
MAX_BRAND_RAW = 100 * 1024 * 1024     # the same sent as it is (the page's way): a large PowerPoint master
# every answer: no MIME sniffing, no referrer leaks, only this site may frame the page (results open in iframes)
SECURITY_HEADERS = {"X-Content-Type-Options": "nosniff", "Referrer-Policy": "no-referrer",
                    "X-Frame-Options": "SAMEORIGIN"}
# the page itself: its own inline script and styles, nothing from other sites
# The app's own pages: scripts and styles only as files from this server (static/), nothing inline.
RESTARTING = "Lesson Studio is restarting. Ask again in a minute."
PAGE_CSP = ("default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; font-src 'self' data:; "
            "style-src 'self'; script-src 'self'; frame-src 'self'; "
            "frame-ancestors 'self'; object-src 'none'; base-uri 'none'; form-action 'self'")
# Result documents shown in the page's frames (lesson.html): their styles are inline; no scripts.
DOCUMENT_CSP = ("default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; font-src 'self' data:; "
                "style-src 'self' 'unsafe-inline'; script-src 'none'; frame-ancestors 'self'; object-src 'none'; "
                "base-uri 'none'; form-action 'none'")
STATIC = Path(__file__).with_name("static")
STATIC_TYPES = {".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8"}


class Handler(BaseHTTPRequestHandler):
    """Lesson Studio's HTTP handler: the page, the JSON API and the files, behind the sign-in."""
    server_version = "LessonStudio/1.0"

    def _owner(self) -> str:
        """Whose chats these are: behind the company login, the signed-in person (from their e-mail, so the same
        chats on every device); otherwise this browser's id (a cookie set with the page)."""
        if config.AUTH_PROXY_HEADER:
            user = (self.headers.get(config.AUTH_PROXY_HEADER) or "").strip().lower()
            return hashlib.sha256(user.encode("utf-8")).hexdigest()[:24] if user else ""
        morsel = SimpleCookie(self.headers.get("Cookie") or "").get("ls_user")
        return morsel.value if morsel and chats.ID.fullmatch(morsel.value) else ""

    def _shared(self) -> bool:
        """The request came through a shared link (VS Code port forwarding, a tunnel), not from this
        computer's own browser: the tunnel adds X-Forwarded-* headers or keeps its own host name."""
        host = (self.headers.get("Host") or "").rsplit(":", 1)[0].strip("[]").lower()
        forwarded = any(self.headers.get(h) for h in ("X-Forwarded-For", "X-Forwarded-Host", "Forwarded"))
        return forwarded or host not in ("localhost", "127.0.0.1", "::1", "")

    def _allowed(self) -> bool:
        """No APP_PASSWORD: open only to this computer's own browser; a shared link is refused. With
        one: the cookie from /login."""
        if config.AUTH_PROXY_HEADER:   # signed in by the company login in front (oauth2-proxy)
            return bool((self.headers.get(config.AUTH_PROXY_HEADER) or "").strip())
        if not config.APP_PASSWORD:
            return not self._shared()
        morsel = SimpleCookie(self.headers.get("Cookie") or "").get("ls_auth")
        return morsel is not None and _token_ok(morsel.value)

    def _https(self) -> bool:
        """Behind https (a load balancer or an ingress says so): cookies are then sent over https only."""
        return (self.headers.get("X-Forwarded-Proto") or "").lower() == "https"

    def _body(self, limit: int = MAX_BODY) -> bytes | None:
        """The request body, or None after answering 400/413 (a missing, wrong or too large Content-Length)."""
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            n = -1
        if n < 0:
            self._json({"error": "Bad request."}, 400)
            return None
        if n > limit:
            self._json({"error": f"Too large (at most {limit // 1024} KB)."}, 413)
            return None
        return self.rfile.read(n)

    def _login(self, error: str = "", code: int = 200) -> None:
        err = f'<p class="err">{error}</p>' if error else ""
        self._send(LOGIN.replace("__ERR__", err).encode(), "text/html; charset=utf-8", code, csp=PAGE_CSP)

    def _static(self, name: str) -> None:
        """A script or style sheet of the page (static/ only, by its plain file name)."""
        target = STATIC / name
        if "/" in name or "\\" in name or target.suffix not in STATIC_TYPES or not target.is_file():
            return self._send(b"not found", "text/plain", 404)
        return self._send(target.read_bytes(), STATIC_TYPES[target.suffix])

    def log_message(self, fmt: str, *args: object) -> None:   # quiet: the page shows the progress
        """Nothing to the terminal: the page shows the progress."""
        pass

    def log_request(self, code: int | str = "-", size: int | str = "-") -> None:   # noqa: ARG002 - base signature
        """Requests through a shared link are written to data/output/app_access.log (time, what, answer), so a
        page that does not open for someone else can be traced. Not to the terminal: on Windows a click in the
        terminal window pauses every program writing to it, and the page would hang for the other person.
        In a container (LOG_FORMAT=json) they go to the log with the other lines; the health checks are left out."""
        path = urlparse(self.path).path
        if path in ("/healthz", "/readyz") or not self._shared():   # the cluster checks every few seconds: no line
            return
        if config.LOG_FORMAT == "json":   # in a container: to the log collector, with the other lines
            logging.getLogger("access").info("%s %s -> %s", self.command, path, code)
            return
        try:
            line = f"{time.strftime('%Y-%m-%d %H:%M:%S')}  {self.command} {path} -> {code}\n"
            config.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
            with ACCESS_LOCK, open(config.OUTPUT_DIR / "app_access.log", "a", encoding="utf-8") as f:
                f.write(line)
        except Exception:   # noqa: BLE001 - isolation point: a log line must never stop an answer
            pass

    def _send(self, body: bytes, ctype: str, code: int = 200, extra: dict[str, Any] | None = None,
              csp: str = DOCUMENT_CSP) -> None:
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for k, v in {**SECURITY_HEADERS, **({"Content-Security-Policy": csp} if ctype.startswith("text/html")
                                            else {}), **(extra or {})}.items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, data: object, code: int = 200) -> None:
        self._send(json.dumps(data).encode(), "application/json", code)

    def do_GET(self) -> None:   # noqa: N802 - http.server API
        """The page, the JSON API and the files. Everything but /status needs the sign-in when a password is set."""
        url = urlparse(self.path)
        if url.path in PROBES:   # no sign-in, no data: for the link test and the cluster's health checks
            return PROBES[url.path](self)
        if url.path.startswith("/static/"):   # the page's script and styles: no data, also for the sign-in page
            return self._static(url.path[len("/static/"):])
        if not self._allowed():
            return self._refuse(url.path)
        route = self._get_route(url.path)
        if route is None:
            return self._send(b"not found", "text/plain", 404)
        return route(url)

    def _get_route(self, path: str) -> Callable[[ParseResult], None] | None:
        """The method that answers a GET of `path`, or None (404)."""
        exact = {
            "/": self._home,
            "/api/chats": lambda _u: self._json({"chats": chats.listing(self._owner())}),
            "/api/state": lambda _u: self._json(state(self._owner())),
            "/api/choices": lambda _u: self._json(choices()),
            "/api/comparisons": lambda _u: self._json(comparisons()),
            "/api/prices": lambda _u: self._json(prices()),
            "/api/decks": lambda _u: self._json(decks()),
            "/api/options": lambda _u: self._json(options(self._owner())),
            "/api/estimate": self._estimate,
            "/api/results": lambda _u: self._json(results()),
            "/api/report": lambda _u: self._json(report()),
            "/api/export": self._export,
            "/api/monitor": lambda u: self._json(monitoring.report(_days(u))),
            "/api/avatars": lambda _u: self._json(avatars()),
            "/api/brand": self._brand,
            "/brand/logo": self._brand_logo,
            "/brand/favicon": self._brand_favicon,
            "/brand/page.css": self._brand_css,
            "/brand/font": self._brand_font,
        }
        if path in exact:
            return exact[path]
        prefixed = (("/api/chats/", self._chat), ("/api/jobs/", self._job), ("/avatars/", self._avatar_picture),
                    ("/files/", lambda u: self._file(unquote(u.path[len("/files/"):]))))
        return next((fn for prefix, fn in prefixed if path.startswith(prefix)), None)

    def _status(self) -> None:
        """A quick test of a shared link: is the app reached at all (no sign-in, no data)."""
        came = "through a shared link" if self._shared() else "from this computer"
        text = (f"Lesson Studio is running.\nThis request came {came}."
                f"\nPassword: {'on' if config.APP_PASSWORD else 'OFF (a shared link is refused)'}.\n")
        self._send(text.encode(), "text/plain; charset=utf-8")

    def _healthz(self) -> None:
        """Liveness: the process answers. Nothing outside it is checked, so a slow gateway never restarts it."""
        self._json({"status": "ok", "version": config.APP_VERSION})

    def _readyz(self) -> None:
        """Readiness: 200 when the app can take requests (not stopping, the data folder writable), else 503."""
        ready, checks = readiness()
        self._json({"ready": ready, "checks": checks, "version": config.APP_VERSION}, 200 if ready else 503)

    def _refuse(self, path: str) -> None:
        """Not signed in: the sign-in page for the page itself, 401/403 for the API. Shared without a password:
        closed, and the page says how to set one."""
        if config.AUTH_PROXY_HEADER:
            return self._json({"error": "Sign in through the company login first."}, 401)
        if not config.APP_PASSWORD:
            if path == "/":
                return self._login("Shared without a password, so it stays closed. On the laptop: stop app.py (Ctrl+C) "
                                   "and start it with: uv run -m studio app --password <a long password>", 200)
            return self._json({"error": "No password set."}, 403)
        return self._login() if path == "/" else self._json({"error": "Sign in first."}, 401)

    def _home(self, _url: ParseResult) -> None:
        """The page; a new browser gets its own id (its chats and requests are only its own)."""
        extra = {} if self._owner() else {
            "Set-Cookie": f"ls_user={uuid.uuid4().hex[:16]}; Path=/; HttpOnly; SameSite=Lax; Max-Age={400 * 86400}"
                          + ("; Secure" if self._https() else "")}
        self._send(page().encode(), "text/html; charset=utf-8", extra=extra, csp=PAGE_CSP)

    def _chat(self, url: ParseResult) -> None:
        """One chat of this browser, with which of its requests are still being made."""
        chat = chats.load(url.path.rsplit("/", 1)[-1], self._owner())
        busy = {j["id"] for j in jobs.JOBS.values() if j["status"] in ("queued", "running")}
        self._json(chats.for_page(chat, busy) if chat else {"error": "No such chat."}, 200 if chat else 404)

    def _job(self, url: ParseResult) -> None:
        """A request's progress and result: only for the browser that asked."""
        job = jobs.JOBS.get(url.path.rsplit("/", 1)[-1])
        if not job or job.get("owner", "") not in ("", self._owner()):
            return self._json({"status": "unknown"}, 404)
        return self._json({**{k: v for k, v in job.items() if k != "owner"}, "ahead": ahead_of(job)})

    def _estimate(self, url: ParseResult) -> None:
        """What a request will cost and take, before it is sent (?format=&minutes=&model=&voice=)."""
        q = {k: v[0] for k, v in parse_qs(url.query).items()}
        try:
            minutes = float(q.get("minutes") or 0)
        except ValueError:
            minutes = 0
        self._json(estimate(q.get("format", "auto"), minutes, q.get("model") or defaults()["CHAT_MODEL"],
                            q.get("voice") or defaults()["TTS_ENGINE"]))

    def _export(self, url: ParseResult) -> None:
        """The Excel report of one result (?folder=<name>) or of every result, as a download."""
        folder = (parse_qs(url.query).get("folder") or [""])[0]
        if folder and (Path(folder).name != folder or not (config.OUTPUT_DIR / folder / "run_card.json").exists()):
            return self._json({"error": "No such result."}, 404)
        path = results_report.export_file(folder)
        return self._send(path.read_bytes(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                          extra={"Content-Disposition": f'attachment; filename="{path.name}"'})

    def _avatar_picture(self, url: ParseResult) -> None:
        """A company avatar's picture (from data/avatars only)."""
        from studio.video import company_avatar
        name = unquote(url.path[len("/avatars/"):])
        pic = company_avatar.pictures().get(company_avatar.slug(Path(name).stem))
        if not pic or pic.name != name:
            return self._send(b"not found", "text/plain", 404)
        return self._stream(pic, 0, pic.stat().st_size - 1, pic.stat().st_size,
                            mimetypes.guess_type(pic.name)[0] or "image/png", 200)

    def _brand(self, _url: ParseResult) -> None:
        """The company brand found in data/brand (brand.py)."""
        self._json(brand_state())

    def _brand_logo(self, _url: ParseResult) -> None:
        """The company logo file."""
        from studio.video import brand
        lg = brand.logo()
        if not lg:
            return self._send(b"not found", "text/plain", 404)
        return self._stream(lg, 0, lg.stat().st_size - 1, lg.stat().st_size,
                            mimetypes.guess_type(lg.name)[0] or "image/png", 200)

    def _brand_favicon(self, _url: ParseResult) -> None:
        """The icon in the browser tab: the company's mark, else its logo (404: the browser's own)."""
        from studio.video import brand
        icon = brand.favicon()
        if not icon:
            return self._send(b"not found", "text/plain", 404)
        ctype = "image/x-icon" if icon.suffix.lower() == ".ico" else mimetypes.guess_type(icon.name)[0] or "image/png"
        return self._stream(icon, 0, icon.stat().st_size - 1, icon.stat().st_size, ctype, 200)

    def _brand_css(self, _url: ParseResult) -> None:
        """The page in the company's colours and font (empty without a brand)."""
        from studio.video import brand
        self._send(brand.page_css().encode(), "text/css; charset=utf-8")

    def _brand_font(self, url: ParseResult) -> None:
        """One of the company's font files (?n=0), for the page."""
        from studio.video import brand
        fonts = brand.font_files()
        n = (parse_qs(url.query).get("n") or ["0"])[0]
        if not n.isdigit() or int(n) >= len(fonts):
            return self._send(b"not found", "text/plain", 404)
        f = fonts[int(n)]
        types = {".ttf": "font/ttf", ".otf": "font/otf", ".woff": "font/woff", ".woff2": "font/woff2"}
        return self._send(f.read_bytes(), types.get(f.suffix.lower(), "application/octet-stream"))

    do_HEAD = do_GET

    def _sign_in(self) -> None:
        """The sign-in form: the signed cookie for the right password, else the page again (a second later)."""
        raw = self._body(4096)
        if raw is None:
            return None
        given = (parse_qs(raw.decode("utf-8", "replace")).get("password") or [""])[0]
        if config.APP_PASSWORD and hmac.compare_digest(given.encode(), config.APP_PASSWORD.encode()):
            cookie = (f"ls_auth={_token()}; Path=/; HttpOnly; SameSite=Lax; Max-Age={SIGN_IN_DAYS * 86400}"
                      + ("; Secure" if self._https() else ""))
            return self._send(b"", "text/plain", 303, {"Location": "/", "Set-Cookie": cookie})
        time.sleep(1)   # slows down guessing
        return self._login("Wrong password." if config.APP_PASSWORD else "No password is set.", 401)

    def _job_button(self, job_id: str, action: str) -> None:
        """The Stop and Resume buttons of a request."""
        if action == "stop":
            ok = stop_job(job_id, self._owner())
            return self._json({"ok": ok}, 200 if ok else 404)
        if jobs.STOPPING.is_set():
            return self._json({"error": RESTARTING}, 503)
        job, error, code = resume_job(job_id, self._owner())
        return self._json({"id": job["id"], "chat": job.get("chat", "")} if job else {"error": error}, code)

    def _json_body(self, limit: int) -> dict[str, Any] | None:
        """The request's JSON object, or None after answering 400 (or 413 for a body over the limit)."""
        raw = self._body(limit)
        if raw is None:
            return None
        try:
            body = json.loads(raw or b"{}")
        except (json.JSONDecodeError, UnicodeDecodeError):
            body = None
        if not isinstance(body, dict):
            self._json({"error": "Bad request."}, 400)
            return None
        return body

    def do_POST(self) -> None:   # noqa: N802 - http.server API
        """Sign-in, new requests, the Stop and Resume buttons, chat actions, avatar pictures and brand files."""
        path = urlparse(self.path).path
        if path == "/login":
            return self._sign_in()
        if not self._allowed():
            return self._json({"error": "Sign in first."}, 401)
        if jobs.STOPPING.is_set() and path == "/api/jobs":
            return self._json({"error": RESTARTING}, 503)
        button = re.fullmatch(r"/api/jobs/([^/]+)/(stop|resume)", path)
        if button:
            return self._job_button(button.group(1), button.group(2))
        if path != "/api/jobs" and not path.startswith(("/api/chats/", "/api/avatars", "/api/brand")):
            return self._send(b"not found", "text/plain", 404)
        if path == "/api/brand/raw":          # ?kind=&name=, the file's bytes as the body
            raw = self._body(MAX_BRAND_RAW)
            if raw is None:
                return None
            q = {k: v[0] for k, v in parse_qs(urlparse(self.path).query).items()}
            return self._json(*brand_raw(q.get("kind", ""), q.get("name", ""), raw))
        limit = MAX_BRAND_UPLOAD if path.startswith("/api/brand") else MAX_UPLOAD if path.startswith("/api/avatars") else MAX_BODY
        body = self._json_body(limit)
        if body is None:
            return None
        if path.startswith("/api/brand"):     # /api/brand {kind, name, data}: a company file; /api/brand/delete {name}
            return self._json(*brand_post(path, body))
        if path.startswith("/api/avatars"):   # /api/avatars {name, data}: a new picture; /api/avatars/<name> {marks}; .../delete
            return self._json(*avatar_post(path, body))
        if path.startswith("/api/chats/"):
            ok = chat_action(path, body, self._owner())
            return self._json({"ok": ok}, 200 if ok else 404)
        job, error, code = new_job(body, self._owner())
        return self._json({"id": job["id"], "chat": job.get("chat", "")} if job else {"error": error}, code)

    def _file(self, rel: str) -> None:
        """A file from data/output only (no other folder), with byte ranges so videos can seek."""
        root = config.OUTPUT_DIR.resolve()
        target = (root / rel).resolve()
        if (root not in target.parents or not target.is_file() or chats.folder().resolve() in target.parents
                or target.suffix.lower() == ".log"):   # chats only through /api/chats; logs hold others' addresses
            return self._send(b"not found", "text/plain", 404)
        ctype = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        if target.suffix in (".md", ".txt", ".srt"):
            ctype = "text/plain; charset=utf-8"
        size = target.stat().st_size
        rng = self.headers.get("Range")
        start, end, code = 0, size - 1, 200
        if rng and rng.startswith("bytes="):
            a, _, b = rng[6:].partition("-")
            try:
                start = int(a) if a else max(0, size - int(b))
                end = min(size - 1, int(b)) if a and b else size - 1
            except ValueError:
                start, end = 0, size - 1
            if not b:   # "from here on": a piece at a time, so a video starts at once and many can load together
                end = min(end, start + CHUNK_ON_REQUEST - 1)
            code = 206
        return self._stream(target, start, end, size, ctype, code)

    def _stream(self, target: Path, start: int, end: int, size: int, ctype: str, code: int) -> None:
        """Send part of a file in small blocks (never the whole video in memory at once)."""
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(max(0, end - start + 1)))
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Cache-Control", "no-store")
        for k, v in SECURITY_HEADERS.items():
            self.send_header(k, v)
        if code == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.end_headers()
        if self.command == "HEAD":
            return
        with open(target, "rb") as f:
            f.seek(start)
            left = end - start + 1
            while left > 0:
                block = f.read(min(256 * 1024, left))
                if not block:
                    break
                self.wfile.write(block)
                left -= len(block)


CHUNK_ON_REQUEST = 1024 * 1024   # an open range ("bytes=0-") is answered with this much; the player asks for more


class Server(ThreadingHTTPServer):
    """The HTTP server: one thread per connection, so a long video download does not block the page."""
    daemon_threads = True
    ipv6: Server | None = None   # the same page on [::1], when localhost is IPv6 first

    def handle_error(self, request: Any, client_address: Any) -> None:
        """The browser stopping a video it no longer needs (seeking, another video, closing the tab) is
        normal: no error printed for it ("an established connection was aborted")."""
        if isinstance(sys.exc_info()[1], (ConnectionError, TimeoutError)):
            return
        super().handle_error(request, client_address)


class Server6(Server):
    """The same server on IPv6 (when localhost resolves to ::1)."""
    address_family = socket.AF_INET6


def also_on_ipv6(port: int) -> Server | None:
    """The same page on ::1 too (still only this computer). "localhost" can mean ::1 first: VS Code's
    port forwarding then reached nothing ("localhost refused to connect") with only 127.0.0.1."""
    try:
        extra = Server6(("::1", port), Handler)
    except OSError as e:   # no IPv6 on this computer, or the port taken there: 127.0.0.1 is enough
        log.info("Not on ::1: %s", e)
        return None
    threading.Thread(target=extra.serve_forever, daemon=True).start()
    return extra


LOCAL_HOSTS = ("127.0.0.1", "localhost", "::1")


def serve(port: int, open_browser: bool = True, host: str = "127.0.0.1") -> ThreadingHTTPServer:
    """host 127.0.0.1: only this computer (the default); 0.0.0.0: every address (a container, a server)."""
    if host not in LOCAL_HOSTS and not config.APP_PASSWORD and not config.AUTH_PROXY_HEADER:
        raise SystemExit(f"Listening on {host} (not only this computer) needs a password: set APP_PASSWORD "
                         "(in .env or the container's environment) or give --password.")
    for problem in config.validate():
        log.error("Setting that cannot work: %s", problem)
    server = Server((host, port), Handler)
    server.daemon_threads = True
    server.ipv6 = also_on_ipv6(server.server_address[1]) if host in LOCAL_HOSTS else None
    url = f"http://localhost:{server.server_address[1]}"
    if host not in LOCAL_HOSTS:
        print(f"Listening on {host}:{server.server_address[1]} (all addresses of this machine or container)")
    print(f"Lesson Studio: {url}   (Ctrl+C to stop)"
          + ("   password on" if config.APP_PASSWORD else
             "   NO PASSWORD: a shared link stays closed (uv run -m studio app --password <a long password>)"))
    if open_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    return server


ACCESS_LOCK = threading.Lock()
PROBES = {"/status": Handler._status, "/healthz": Handler._healthz, "/readyz": Handler._readyz}


def _days(url: ParseResult) -> int:
    """?days=N of the monitoring report (1-90, default 7)."""
    try:
        return min(90, max(1, int(parse_qs(url.query).get("days", ["7"])[0])))
    except ValueError:
        return 7


def readiness() -> tuple[bool, dict[str, bool]]:
    """Can the app take requests? (ready, each check): not stopping, and the data folder can be written."""
    checks = {"not_stopping": not jobs.STOPPING.is_set(), "data_writable": _writable(config.DATA_DIR)}
    return all(checks.values()), checks


def _writable(folder: Path) -> bool:
    """A file can be created and removed in `folder` (a full or read-only volume cannot)."""
    try:
        folder.mkdir(parents=True, exist_ok=True)
        probe = folder / f".ready-{os.getpid()}"
        probe.write_bytes(b"")
        probe.unlink()
        return True
    except OSError:
        return False


def stop_when_idle(server: ThreadingHTTPServer, wait_s: float | None = None) -> None:
    """A clean stop (SIGTERM from Kubernetes or `docker stop`): refuse new requests and report not ready, let the
    request being made finish (at most `wait_s`, SHUTDOWN_WAIT_S), then stop the server. Requests still waiting
    are shown as stopped in their chats after the restart (chats.STOPPED)."""
    wait_s = config.SHUTDOWN_WAIT_S if wait_s is None else wait_s
    jobs.STOPPING.set()
    log.info("Stopping: no new requests; waiting up to %ss for the one being made", wait_s)
    deadline = time.monotonic() + wait_s
    while time.monotonic() < deadline and any(j["status"] == "running" for j in jobs.JOBS.values()):
        time.sleep(0.5)
    busy = [j["id"] for j in jobs.JOBS.values() if j["status"] in ("queued", "running")]
    if busy:
        log.warning("Stopped with %s request(s) not finished: %s", len(busy), ", ".join(busy))
    server.shutdown()


def on_sigterm(server: ThreadingHTTPServer) -> None:
    """Make SIGTERM a clean stop (stop_when_idle in its own thread: the server's loop must keep running)."""
    import signal

    def handler(_signum: int, _frame: object) -> None:
        if not jobs.STOPPING.is_set():
            threading.Thread(target=stop_when_idle, args=(server,), name="stop", daemon=True).start()
    signal.signal(signal.SIGTERM, handler)


def no_pause_on_click() -> None:
    """Windows: a click in the terminal window starts selecting text ("QuickEdit"), and while it is selecting
    every program writing to that window stops, the page with it (for someone on the shared link it loads
    for ever). Turned off for this window while app.py runs (no admin rights needed)."""
    if sys.platform == "win32":
        import ctypes
        k32 = ctypes.windll.kernel32
        handle = k32.GetStdHandle(-10)   # the window's input
        mode = ctypes.c_uint32()
        if not (k32.GetConsoleMode(handle, ctypes.byref(mode))
                and k32.SetConsoleMode(handle, (mode.value & ~0x0040) | 0x0080)):   # QuickEdit off, extended flags on
            log.info("QuickEdit not turned off (no console window)")


def page() -> str:
    """The page (app_page.html next to this file; read on every visit, so edits show after a reload)."""
    path = Path(__file__).with_name("app_page.html")
    return path.read_text(encoding="utf-8") if path.exists() else "<h1>app_page.html is missing next to app.py</h1>"
