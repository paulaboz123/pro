"""What the page offers: formats, looks, levels, models, voices, tools and company avatars."""
from __future__ import annotations

import importlib.util
import logging
import time
from typing import Any
from urllib.parse import quote

from studio.core import addons, config, llm, store
from studio.video import tools

log = logging.getLogger("app")
SWITCHED = ("CHAT_MODEL", "CHAT_BACKEND", "TTS_ENGINE", "REVIEW_MODEL", "RENDERER", "TTS_VOICE", "ELEVENLABS_VOICE",
            "PRO_PRESENTER", "PRO_PERSON", "CARTOON_PRESENTER", "BRAND", "TEMPLATE_SLIDES", "THEME_ACCENT",
            "THEME_ACCENT_2")   # what a job may change for itself

# The formats as the person sees them: settings for ask.run, and how to ask for them in words
# What can be asked for, grouped by what the person does with it (read, present, watch); the picker shows these names
FORMATS: list[dict[str, Any]] = [
    {"id": "auto", "label": "Auto (from my words)", "settings": {},
     "how": "", "example": ""},
    {"id": "answer", "label": "Answer", "group": "Read", "settings": {"format": "answer"}, "kind": "answer",
     "how": "Ask a question: a short answer with the source of every sentence.", "example": "What is a left join?"},
    {"id": "document", "label": "Written lesson", "group": "Read", "settings": {"format": "text"}, "kind": "document",
     "how": "Ask for something to read: a document, lecture notes, an explanation, a summary.",
     "example": "Write a document on the three Scrum roles, with a comparison table and a summary"},
    {"id": "slides", "label": "Slides to present (PDF + PowerPoint)", "group": "Present", "settings": {"format": "slides"},
     "kind": "slides",
     "how": "Ask for a presentation or slides you will present yourself (PDF + PowerPoint with speaker notes).",
     "example": "A simple 6-slide presentation on sprint planning that I can present myself"},
    {"id": "video", "label": "Video with narrator", "group": "Watch", "settings": {"format": "video"}, "kind": "video",
     "how": "Ask for a video or an animated presentation with a voice. Add 'clean slides' or 'with illustrations' for the look.",
     "example": "A 2-minute video lesson on the daily scrum for beginners, with illustrations"},
    {"id": "presenter", "label": "Video with a cartoon presenter", "group": "Watch",
     "settings": {"format": "video", "style": "presenter", "characters": "cartoon"}, "kind": "video",
     "how": "Ask for a cartoon, an animated character or an animal presenting the topic.",
     "example": "A 2-minute cartoon where a bear explains the definition of done"},
    {"id": "silent", "label": "Video without voice", "group": "Watch", "settings": {"format": "video"}, "kind": "video",
     "config": {"TTS_ENGINE": "silent"},
     "how": "Ask for animated slides without a voice (a video to watch at your own pace).",
     "example": "Animated slides on the sprint review, no voice, about 2 minutes"},
    {"id": "dialogue", "label": "Two characters talking", "picker": False, "settings": {"format": "dialogue", "style": "dialogue"},
     "kind": "dialogue", "how": "Ask for two people or characters talking about the topic, a conversation or an interview.",
     "example": "A 3-minute video where two characters talk about the sprint review"},
    {"id": "audio", "label": "Audio", "picker": False, "settings": {"format": "audio"}, "kind": "audio",
     "how": "Ask for something to listen to: audio, a podcast, for the way to work.",
     "example": "Something to listen to on the way to work: 3 minutes on the product backlog"},
]
LOOKS = [("auto", "Auto"), ("clean", "Clean slides"), ("illustrated", "With illustrations"),
         ("presenter", "Cartoon presenter")]
LEVELS = [("auto", "Auto"), ("beginner", "Beginner"), ("intermediate", "Intermediate"), ("expert", "Expert")]
LENGTHS = [0, 1, 2, 3, 5, 8]   # 0 = auto; 4+ minute videos become courses with chapters


# --- what the page offers -------------------------------------------------------------------
def voices() -> list[dict[str, Any]]:
    """The voice engines that work here (Kokoro, plus cloud voices when they are set up)."""
    from studio.video import tts
    out = []
    for engine, label in (("kokoro", "Kokoro (free, local)"), ("elevenlabs", "ElevenLabs (most natural, paid)"),
                          ("system", "Windows voice (free, robotic)")):
        ok, why = tts.check(engine)
        if ok or engine == defaults()["TTS_ENGINE"]:
            out.append({"id": engine, "label": label, "ok": ok, "detail": why,
                        "usd_per_1k": {"elevenlabs": config.ELEVENLABS_USD_PER_1K_CHARS}.get(engine, 0)})
    return out


def suggestions() -> dict[str, Any]:
    """Topic suggestions: the topic maps of the sources (topics.py), else the source titles."""
    out, analysed = [], False
    rows = store.available_recordings()
    for r in rows:
        m = store.read_json(store.video_dir(r["video_id"]) / "topics.json", {}) or {}
        for t in m.get("topics", []):
            analysed = True
            if t.get("depth") == "brief":   # only mentioned in the source: too thin for a lesson
                continue
            out.append({"title": t["title"], "covers": t.get("covers", ""), "source": r["title"],
                        "level": t.get("level", ""), "minutes": t.get("minutes", 2)})
    across = (store.read_json(config.OUTPUT_DIR / "topics" / "topics.json", {}) or {}).get("across") or {}
    for t in reversed(across.get("shared_topics", [])):
        out.insert(0, {"title": t["title"], "covers": t.get("covers", ""), "source": "several sources",
                       "level": t.get("level", ""), "minutes": t.get("minutes", 3)})
    if not out:
        out = [{"title": r["title"], "covers": r.get("description", ""), "source": "", "level": "", "minutes": 2}
               for r in rows]
    return {"analysed": analysed, "topics": out[:60], "sources": len(rows)}


def models() -> list[dict[str, Any]]:
    """The models to pick from, with their list price (the configured ones, not the one a running job uses)."""
    out = config.model_choices(defaults()["CHAT_MODEL"], defaults()["CHAT_BACKEND"])
    for m in out:
        m["price_in"], m["price_out"] = (round(x, 4) for x in llm.price(m["id"], m["backend"]))
    return out


def elevenlabs_left() -> dict[str, Any] | None:
    """ElevenLabs characters used and left (usage.py), or None when it is not set up."""
    from studio.costs import usage
    try:
        return usage.elevenlabs()
    except (OSError, ValueError, KeyError):   # information only
        return None


def course_min() -> float:
    """From how many minutes a video becomes a course with chapters."""
    from studio.generation import course
    return course.COURSE_MIN_MINUTES


def defaults() -> dict[str, Any]:
    """The configured model and voice, never a running job's own choice."""
    return {k: config.configured(k) for k in SWITCHED}


# --- tools and narrators to pick in the chat (the same as in the comparison) -----------------------
LEVEL_CHOICES = [("auto", "Auto"), ("beginner", "Beginner"), ("intermediate", "Intermediate"), ("expert", "Expert")]
ELEVEN_PICK = ("lily", "brian", "alice", "daniel", "charlotte", "will")
_choices: dict[str, Any] = {}


def tool_settings(tool: str) -> tuple[dict[str, Any], dict[str, Any]]:
    """(config values, request overrides) for a tool this installation offers (tools.offered); ({}, {}) else."""
    sol = next((x for x in tools.offered() if x["id"] == tool), None)
    if not sol:
        return {}, {}
    over = {"style": sol["style"]}
    if sol.get("characters"):
        over["characters"] = sol["characters"]
    return {"RENDERER": sol["renderer"], **sol.get("set", {})}, over


def brand_settings(choice: str) -> dict[str, Any]:
    """The page's Look picker -> the config values for one job. default: the slides' and videos' own look, as before
    the company files (no company colours, logo or template); domain: the company's colours, logo, font, icons and,
    for presentations, the template's background."""
    if choice == "domain":
        return {"BRAND": "auto", "TEMPLATE_SLIDES": "on"}
    return {"BRAND": "off", "TEMPLATE_SLIDES": "off", "THEME_ACCENT": config.THEME_ACCENT_DEFAULTS[0],
            "THEME_ACCENT_2": config.THEME_ACCENT_DEFAULTS[1]}


def voice_settings(voice: str) -> dict[str, Any]:
    """kokoro:af_heart / elevenlabs:brian -> the config values for that narrator."""
    engine, _, name = (voice or "").partition(":")
    if engine == "kokoro" and name:
        return {"TTS_ENGINE": "kokoro", "TTS_VOICE": name}
    if engine == "elevenlabs" and name:
        return {"TTS_ENGINE": "elevenlabs", "ELEVENLABS_VOICE": name}
    return {}


def _quick_ok(sol: dict[str, Any]) -> tuple[bool, str]:
    """Can this tool run here? Quick checks only (nothing is installed by asking)."""
    r = sol.get("renderer", "")
    if r == "html":
        return importlib.util.find_spec("playwright") is not None, "needs playwright"
    if r.startswith("remotion"):
        return (config.EXPERIMENTS_DIR / "remotion" / "node_modules").exists(), "Remotion not installed (experiments/remotion, npm.cmd install)"
    if r in ("manim", "hyperframes"):
        ok, why = addons.experiment(f"{r}_render").available()
    else:
        ok, why = addons.experiment("deck_js").available(r)
    return bool(ok), str(why)


def choices() -> dict[str, Any]:
    """What can be picked under the chat box (checked at most once a minute)."""
    if _choices.get("at", 0) > time.time() - 60:
        cached: dict[str, Any] = _choices["data"]
        return cached
    from studio.video import tts
    offered = []
    every = "all" in config.PAGE_TOOLS
    for sol in tools.offered():
        if not every and sol["id"] not in config.PAGE_TOOLS:
            continue
        ok, why = _quick_ok(sol)
        if not ok and not every:   # a tool that is not set up here is not offered at all
            continue
        offered.append({"id": sol["id"], "label": sol["group"] + (f" \u2013 {sol['variant']}" if sol.get("variant") else ""),
                      "ok": bool(ok), "why": "" if ok else why})
    voices = []
    if tts.check("kokoro")[0]:
        voices += [{"id": f"kokoro:{v}", "label": f"Kokoro \u2013 {name} ({who}, {accent})"}
                   for _, v, name, who, accent in tools.KOKORO]
    if config.ELEVENLABS_API_KEY:
        voices += [{"id": f"elevenlabs:{n}", "label": f"ElevenLabs \u2013 {n.capitalize()} "
                    f"({tools.ELEVEN_WHO.get(n, '')}, paid)"} for n in ELEVEN_PICK]
    renderer = next((t["label"] for t in offered if t["id"] == defaults()["RENDERER"]), defaults()["RENDERER"])
    voice = defaults()["TTS_ENGINE"] + (f" \u2013 {config.TTS_VOICE}" if defaults()["TTS_ENGINE"] == "kokoro" else "")
    named = next((v["label"] for v in voices if v["id"] == f"{defaults()['TTS_ENGINE']}:{config.TTS_VOICE}"), "")
    voice = named or voice   # "Kokoro \u2013 Heart (woman, US)", not the voice's file name
    from studio.video import brand
    data = {"formats": [{"id": f["id"], "label": f["label"].replace(" (from my words)", ""), "group": f.get("group", "")}
                        for f in FORMATS if f.get("picker", True)],
            "tools": offered, "voices": voices, "levels": [{"id": k, "label": v} for k, v in LEVEL_CHOICES],
            # Look: Default (as before) or Domain (the company files of Settings > Company look), once there are some
            "brand": [{"id": "domain", "label": "Look: Domain"}] if brand.on() else [],
            "defaults": {"tool": renderer, "voice": voice}}
    _choices.update(at=time.time(), data=data)
    return data


# --- the company's avatars (company_avatar.py): pictures in data/avatars, marked on the Avatars tab ---------
def avatars() -> dict[str, Any]:
    """The company avatars in data/avatars, with the address of each picture."""
    from studio.video import company_avatar
    rows = company_avatar.listing()
    for a in rows:
        a["url"] = "/avatars/" + quote(a["file"])
    return {"folder": str(company_avatar.folder()), "avatars": rows}


def brand_state() -> dict[str, Any]:
    """The company brand for the page: what was found (brand.py), the logo's address and every file."""
    from studio.video import brand
    s: dict[str, Any] = brand.summary()
    s["logo_url"] = "/brand/logo" if s.get("logo") else ""
    s["favicon_url"] = "/brand/favicon" if brand.favicon() else ""
    s["folder"] = "data/brand"
    s["files"] = brand.files()
    from studio.video import template_look
    s["template_look"] = template_look.summary()   # which layouts the presentations use
    return s


def brand_post(path: str, body: dict[str, Any]) -> tuple[dict[str, Any], int]:
    """A company file from the page ({kind, name, data: a data URL}) or a deletion (/api/brand/delete {name}).
    Used at once: the next slide, presentation or video is made with it."""
    import base64

    from studio.video import brand
    route = path.rstrip("/")
    try:
        if route == "/api/brand/delete":
            if not brand.delete_file(str(body.get("name", ""))):
                return {"error": "No such file."}, 404
        elif route == "/api/brand":
            raw = str(body.get("data", ""))
            raw = raw.split(",", 1)[1] if raw.startswith("data:") else raw
            brand.save_upload(str(body.get("kind", "")), str(body.get("name", "")),
                              base64.b64decode(raw, validate=True))
        else:
            return {"error": "Not found."}, 404
    except ValueError as e:   # also a broken data URL (binascii.Error is a ValueError)
        return {"error": f"Not saved: {e}"}, 400
    _choices.clear()   # the Look picker comes and goes with the company files
    return {"ok": True, **brand_state()}, 200


def brand_raw(kind: str, name: str, data: bytes) -> tuple[dict[str, Any], int]:
    """A company file sent as it is (/api/brand/raw?kind=&name=): the page sends big templates this way."""
    from studio.video import brand
    try:
        brand.save_upload(kind, name, data)
    except ValueError as e:
        return {"error": f"Not saved: {e}"}, 400
    _choices.clear()   # the Look picker appears with the first company file
    return {"ok": True, **brand_state()}, 200


def avatar_post(path: str, body: dict[str, Any]) -> tuple[dict[str, Any], int]:
    """A new picture ({name, data: a data URL}: marked by AI at once), every unmarked picture marked by AI
    (/api/avatars/auto), one marked again by AI (/api/avatars/<name>/ai), marks moved by hand ({mouth, eyes,
    label, who}) or a deletion (/api/avatars/<name>/delete)."""
    import base64
    import binascii

    from studio.video import company_avatar
    parts = [p for p in path.split("/") if p][2:]   # after /api/avatars
    try:
        if not parts:
            raw = str(body.get("data", ""))
            raw = raw.split(",", 1)[1] if raw.startswith("data:") else raw
            if len(raw) > 14_000_000:
                return {"error": "The picture is too big (at most about 10 MB)."}, 413
            name = company_avatar.add_picture(str(body.get("name") or "avatar"), base64.b64decode(raw, validate=True))
            company_avatar.mark(name, label=" ".join(str(body.get("name") or "").split())[:40])
            return {"ok": True, "name": name, **avatars()}, 200
        if parts == ["auto"]:
            return {"ok": True, "marked": company_avatar.mark_all(), **avatars()}, 200
        name = parts[0].lower()
        if len(parts) > 1 and parts[1] == "ai":
            if name not in company_avatar.pictures():
                return {"error": "No such avatar."}, 404
            company_avatar.mark(name)
            return {"ok": True, **avatars()}, 200
        if len(parts) > 1 and parts[1] == "delete":
            ok = company_avatar.delete(name)
            return ({"ok": True, **avatars()} if ok else {"error": "No such avatar."}), 200 if ok else 404
        company_avatar.save(name, {**body, "by": "hand"})
        return {"ok": True, **avatars()}, 200
    except FileNotFoundError as e:
        return {"error": str(e)}, 404
    except (ValueError, KeyError, TypeError, binascii.Error) as e:
        return {"error": f"Not saved: {e}"}, 400
