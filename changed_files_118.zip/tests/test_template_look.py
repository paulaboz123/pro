"""template_look.py: presentations (slides.pdf, slides.pptx) on the background of the company's PowerPoint template -
its background picture, the logo and the shapes of its master and layouts - with the slides' own content unchanged
(headings, text, charts, diagrams, fonts); slides_editable.pptx made in the template; the page in the company colours."""
from __future__ import annotations

import re

import pytest
from helpers import get, serve_app
from test_brand import _reset, _template

from studio.core import config, store
from studio.video import brand, template_look

P = "http://schemas.openxmlformats.org/presentationml/2006/main"
A = "http://schemas.openxmlformats.org/drawingml/2006/main"
R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
NS = f'xmlns:p="{P}" xmlns:a="{A}" xmlns:r="{R}"'
BG_PICTURE, LOGO, BAR, WAVE, TITLE = (200, 30, 90), (11, 65, 205), "#0b41cd", "#ff7d29", "#0b41cd"


def _png(path, colour, size=(320, 180)):
    from PIL import Image
    Image.new("RGB", size, colour).save(path)
    return path


def _company_template(tmp_path):
    """A 4:3 template as companies make them: a picture as the title slide's background (without the master's logo),
    the logo and a bar in the theme colour on the master, a freely drawn wave on the content layout, and the
    heading's own colour, size and boldness."""
    pytest.importorskip("pptx")
    from lxml import etree
    from pptx.oxml.ns import qn
    base = _template(tmp_path / "base.pptx")                       # theme accent1 0B41CD, accent2 FF7D29
    from pptx import Presentation
    prs = Presentation(str(base))
    master, title_l, content_l = prs.slide_master, prs.slide_layouts[0], prs.slide_layouts[1]
    tree = master._element.find(qn("p:cSld")).find(qn("p:spTree"))
    _, rid = master.part.get_or_add_image_part(str(_png(tmp_path / "logo.png", LOGO, (300, 100))))
    tree.append(etree.fromstring(
        f'<p:pic {NS}><p:nvPicPr><p:cNvPr id="90" name="Logo"/><p:cNvPicPr/><p:nvPr/></p:nvPicPr>'
        f'<p:blipFill><a:blip r:embed="{rid}"/><a:stretch><a:fillRect/></a:stretch></p:blipFill><p:spPr><a:xfrm>'
        '<a:off x="7315200" y="228600"/><a:ext cx="1371600" cy="457200"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/>'
        '</a:prstGeom></p:spPr></p:pic>'))
    tree.append(etree.fromstring(
        f'<p:sp {NS}><p:nvSpPr><p:cNvPr id="91" name="Bar"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm>'
        '<a:off x="0" y="6629400"/><a:ext cx="9144000" cy="228600"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/>'
        '</a:prstGeom><a:solidFill><a:schemeClr val="accent1"/></a:solidFill><a:ln><a:noFill/></a:ln></p:spPr></p:sp>'))
    _, rid = title_l.part.get_or_add_image_part(str(_png(tmp_path / "bg.png", BG_PICTURE, (400, 300))))
    title_l._element.find(qn("p:cSld")).insert(0, etree.fromstring(
        f'<p:bg {NS}><p:bgPr><a:blipFill><a:blip r:embed="{rid}"/><a:stretch><a:fillRect/></a:stretch></a:blipFill>'
        '<a:effectLst/></p:bgPr></p:bg>'))
    title_l._element.set("showMasterSp", "0")
    content_l._element.find(qn("p:cSld")).find(qn("p:spTree")).append(etree.fromstring(
        f'<p:sp {NS}><p:nvSpPr><p:cNvPr id="92" name="Wave"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm>'
        '<a:off x="7772400" y="1600200"/><a:ext cx="1371600" cy="914400"/></a:xfrm><a:custGeom><a:avLst/><a:gdLst/>'
        '<a:ahLst/><a:cxnLst/><a:rect l="0" t="0" r="r" b="b"/><a:pathLst><a:path w="100" h="100"><a:moveTo>'
        '<a:pt x="0" y="0"/></a:moveTo><a:lnTo><a:pt x="100" y="0"/></a:lnTo><a:lnTo><a:pt x="100" y="100"/></a:lnTo>'
        '<a:cubicBezTo><a:pt x="60" y="70"/><a:pt x="30" y="40"/><a:pt x="0" y="0"/></a:cubicBezTo><a:close/>'
        '</a:path></a:pathLst></a:custGeom><a:solidFill><a:srgbClr val="FF7D29"/></a:solidFill></p:spPr></p:sp>'))
    title = next(sp for sp in content_l.placeholders if sp.placeholder_format.type == 1)   # TITLE
    lst = title._element.find(qn("p:txBody")).find(qn("a:lstStyle"))
    lst.append(etree.fromstring(f'<a:lvl1pPr {NS} algn="l"><a:defRPr sz="3200" b="1"><a:solidFill>'
                                '<a:srgbClr val="0B41CD"/></a:solidFill></a:defRPr></a:lvl1pPr>'))
    out = tmp_path / "Company master.pptx"
    prs.save(str(out))
    return out


def _upload(path) -> None:
    config.BRAND_DIR.mkdir(parents=True, exist_ok=True)
    brand.save_upload("template", path.name, path.read_bytes())
    _reset()


def test_the_template_is_read_as_the_slides_use_it(project, tmp_path):
    _upload(_company_template(tmp_path))
    look = template_look.look()
    assert look["emu"] == (9144000, 6858000)                                             # 4:3: stretched to 16:9
    title, content = look["title"], look["content"]
    assert (title["name"], content["name"]) == ("Title Slide", "Title and Content")    # the .pptx's layouts too
    assert title["bg"].startswith("url('file:") and not title["layer"]                 # its picture, no master logo
    kinds = {s["kind"]: s for s in content["layer"]}
    assert kinds["pic"]["src"].startswith("file:") and round(kinds["pic"]["x"]) == 1024   # the logo, top right
    assert kinds["box"]["bg"] == BAR and round(kinds["box"]["y"]) == 696                 # the bar in accent1
    assert kinds["path"]["bg"] == WAVE and kinds["path"]["d"].startswith("M0.0 0.0")     # the wave, drawn freely
    assert content["title"]["colour"] == TITLE and not template_look.dark(content)      # dark headings: a light background
    assert content["body"]["box"][1] > content["title"]["box"][1]
    assert content["pictures"] and not title["pictures"]

    config.TEMPLATE_SLIDES = "off"                                                       # off: the slides' own look
    try:
        assert template_look.look() == {}
    finally:
        config.TEMPLATE_SLIDES = "on"


def _storyboard(out_dir):
    sb = {"title": "Joining data", "goal": "Join two tables without losing rows", "style": "clean", "sources": {},
          "scenes": [
              {"visual": "title", "heading": "Joining data", "narration": "Hello."},
              {"visual": "cards", "heading": "Three kinds of join", "subheading": "Which rows stay",
               "elements": [{"title": "Inner", "detail": "only rows in both"}, {"title": "Left", "detail": "every row of the first"},
                            {"title": "Full", "detail": "every row of both"}], "narration": "Three joins."},
              {"visual": "bullets", "heading": "Before you join", "items": ["Trim the keys", "Check the types"],
               "narration": "Check first."}]}
    out_dir.mkdir(parents=True)
    store.write_json(out_dir / "storyboard.json", sb)
    return sb


def _pixel(png, x, y):
    from PIL import Image
    with Image.open(png) as im:
        return im.convert("RGB").getpixel((x, y))


def _near(c, target, tol=24):
    t = tuple(int(target[i:i + 2], 16) for i in (1, 3, 5)) if isinstance(target, str) else target
    return all(abs(a - b) <= tol for a, b in zip(c, t, strict=True))


def test_slides_to_present_in_the_template_pdf_and_powerpoint(project, tmp_path, monkeypatch):
    pytest.importorskip("playwright")
    monkeypatch.setattr(config, "RENDERER", "html")
    from pptx import Presentation
    from pptx.enum.shapes import MSO_SHAPE_TYPE

    from studio.generation import deck
    _upload(_company_template(tmp_path))
    out_dir = config.OUTPUT_DIR / "deck"
    _storyboard(out_dir)
    info = deck.produce(out_dir)
    assert info["renderer"] == "html" and info["template"] == "template.pptx"
    scenes = out_dir / "scenes"
    from PIL import Image
    with Image.open(scenes / "scene_01.png") as im:
        w, h = im.size
    assert abs(w / h - 16 / 9) < 0.01                                                    # the slides' own size
    k = w / 1280
    assert _near(_pixel(scenes / "scene_01.png", 6, 6), BG_PICTURE)                     # title: its background picture
    second = scenes / "scene_02.png"
    assert _near(_pixel(second, int(640 * k), int(710 * k)), BAR)                       # the master's bar
    assert _near(_pixel(second, int(1100 * k), int(40 * k)), LOGO)                       # the master's logo
    assert _near(_pixel(second, int(1270 * k), int(180 * k)), WAVE)                      # the layout's wave
    assert not (scenes / "body_01.png").exists()
    with Image.open(scenes / "body_02.png") as body:                                     # the content alone
        assert body.mode == "RGBA" and body.getpixel((2, 2))[3] == 0

    prs = Presentation(str(out_dir / "slides.pptx"))                                     # the slides as they look
    assert len(prs.slides) == 3 and (prs.slide_width, prs.slide_height) == (12192000, 6858000)
    assert all(len(s.shapes) == 1 and s.shapes[0].shape_type == MSO_SHAPE_TYPE.PICTURE for s in prs.slides)
    assert prs.slides[1].notes_slide.notes_text_frame.text == "Three joins."
    assert info["pptx"].endswith("slides.pptx") and info["pptx_editable"].endswith("slides_editable.pptx")

    editable = Presentation(str(out_dir / "slides_editable.pptx"))                       # made in the template itself
    assert len(editable.slides) == 3 and (editable.slide_width, editable.slide_height) == (9144000, 6858000)
    cards, points = editable.slides[1], editable.slides[2]
    assert cards.shapes.title.text == "Three kinds of join"                             # editable heading
    for s in (cards, points):                                                             # the content as on the slides
        assert [x for x in s.shapes if x.shape_type == MSO_SHAPE_TYPE.PICTURE]
    assert "Which rows stay" in " ".join(s.text_frame.text for s in cards.shapes if s.has_text_frame)
    assert (out_dir / "slides.pdf").read_bytes()[:5] == b"%PDF-"


def test_the_content_stays_the_same_only_the_background_changes(project, tmp_path):
    from studio.video import slides_html
    _upload(_company_template(tmp_path))
    look = template_look.look()
    for scene in ({"visual": "cards", "heading": "Kinds", "subheading": "Which rows stay",
                   "elements": [{"title": "A", "detail": "a"}, {"title": "B", "detail": "b"}]},
                  {"visual": "chart", "heading": "Rows kept", "chart": {"type": "bar", "labels": ["Inner", "Left"],
                                                                      "values": [40, 100]}},
                  {"visual": "title", "heading": "Joining data", "items": ["Pick a join"]}):
        own, n1 = slides_html.scene_html(scene, lesson_title="L", goal="G", page="2 / 3")
        on_template, n2 = slides_html.scene_html(scene, lesson_title="L", goal="G", page="2 / 3", template=look)
        assert n1 == n2
        part = lambda page: re.search(r"(<header class=\"hd\">.*?)?<main>.*?</main>(<footer>.*?</footer>)?", page, re.S).group(0)   # noqa: E731
        assert part(own) == part(on_template)                                    # heading, content, footnote: the same
        extra = on_template.split("</style>")[0].replace(own.split("</style>")[0], "")
        assert "font" not in extra and "main{" not in extra and ".hd{" not in extra   # no font, place or size changed


def test_videos_keep_their_own_look(project, tmp_path):
    from studio.video import slides_html
    _upload(_company_template(tmp_path))
    scene = {"visual": "cards", "heading": "Kinds", "elements": [{"title": "A", "detail": "a"}]}
    video, _ = slides_html.scene_html(scene, lesson_title="L", goal="", page="2 / 3")
    deck_page, _ = slides_html.scene_html(scene, lesson_title="L", goal="", page="2 / 3", template=template_look.look())
    assert 'class="tplbg"' not in video and " tpl" not in video.split("<body>")[1][:200]
    assert 'class="tplbg"' in deck_page and "brandlogo" not in deck_page.split("<body>")[1]   # the template's logo
    presenter, _ = slides_html.scene_html(scene, lesson_title="L", goal="", page="2 / 3", style="presenter",
                                          template=template_look.look())
    assert 'class="tplbg"' not in presenter


def test_the_page_in_the_company_colours_and_the_layouts_in_settings(project, tmp_path):
    server, base = serve_app()
    try:
        code, headers, body = get(base + "/brand/page.css")
        assert code == 200 and headers["Content-Type"].startswith("text/css") and body == b""   # no brand: as it is
        _upload(_company_template(tmp_path))
        config.apply_brand_colours()
        _, _, body = get(base + "/brand/page.css")
        css = body.decode()
        assert "--accent:#0b41cd" in css and "#send" in css and "color:#ffffff" in css
        assert get(base + "/brand/font?n=0")[0] == 404
        from studio.web import catalog
        state = catalog.brand_state()
        assert state["template_look"]["title_layout"] == "Title Slide"
        assert state["template_look"]["content_layout"] == "Title and Content"
    finally:
        server.shutdown()


def test_look_default_or_domain_for_one_request(project, tmp_path):
    """The page's Look picker: Default = as before the company files (no brand, no template); Domain = the company's
    colours, logo and the template's background. Only for that request: the rest keeps the configured setting."""
    from studio.video import slides_html
    from studio.web import catalog, jobs
    _upload(_company_template(tmp_path))
    config.apply_brand_colours()
    assert brand.on() and template_look.look()
    cfg, _ = jobs._tool_and_voice({"brand": "domain"}, catalog.FORMATS[0], {})
    assert cfg["BRAND"] == "auto" and cfg["TEMPLATE_SLIDES"] == "on"
    default, _ = jobs._tool_and_voice({}, catalog.FORMATS[0], {})                   # nothing picked: Default
    assert default["BRAND"] == "off" and default["THEME_ACCENT"] == config.THEME_ACCENT_DEFAULTS[0]
    with jobs.chosen(None, None, default):
        assert not brand.on() and template_look.look() == {}
        assert "BrandFont" not in slides_html.css() and config.THEME_ACCENT_DEFAULTS[0] in slides_html.css()
        assert "brandlogo" not in slides_html.scene_html({"visual": "bullets", "heading": "H", "items": ["a"]},
                                                         lesson_title="L", goal="", page="1 / 2")[0].split("<body>")[1]
    with jobs.chosen(None, None, cfg):
        assert brand.on() and template_look.look()
        assert config.THEME_ACCENT in slides_html.css()
    assert brand.on()                                                                   # the others: unchanged
    catalog._choices.clear()                                                            # as an upload on the page does
    assert catalog.choices()["brand"] == [{"id": "domain", "label": "Look: Domain"}]


def test_the_look_picker_beside_the_narrator(project, tmp_path):
    pytest.importorskip("playwright")
    from playwright.sync_api import sync_playwright

    from studio.web import catalog
    catalog._choices.clear()
    server, base = serve_app()
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page(viewport={"width": 1280, "height": 900})
            page.goto(base + "/")
            page.wait_for_selector("#pick-format option", state="attached")
            assert page.locator("#pick-brand").is_hidden()                               # no company files: nothing to pick
            _upload(_company_template(tmp_path))
            catalog._choices.clear()
            page.goto(base + "/")
            page.wait_for_selector("#pick-brand:not([hidden])")
            assert page.locator("#pick-brand option").all_inner_texts() == ["Look: Default", "Look: Domain"]
            page.select_option("#pick-brand", "domain")
            assert page.evaluate("picked()")["brand"] == "domain"
            page.select_option("#pick-brand", "default")
            assert "brand" not in page.evaluate("picked()")
            browser.close()
    finally:
        server.shutdown()
