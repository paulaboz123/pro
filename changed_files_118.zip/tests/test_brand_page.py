"""The page's Company look (the settings behind the gear at the top right): single files, the .zip packages of the
company's brand site (zips inside zips, ZIP64, Mac copies) and whole folders go to data/brand (only what is needed is
taken) and the next result uses them."""
from __future__ import annotations

import io
import json
import urllib.request
import zipfile

import pytest
from helpers import serve_app
from test_brand import _template

from studio.core import config
from studio.video import brand


def _png(colour: tuple[int, int, int], size: tuple[int, int] = (300, 100)) -> bytes:
    from PIL import Image
    buf = io.BytesIO()
    Image.new("RGBA", size, colour + (255,)).save(buf, "PNG")
    return buf.getvalue()


SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/></svg>'


def _packages(tmp_path):
    logos = tmp_path / "Logo package.zip"
    with zipfile.ZipFile(logos, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("Logo/CMYK/Logo_CMYK_colour_horizontal.png", _png((200, 0, 0)))     # print
        z.writestr("Logo/RGB/Logo_RGB_colour_horizontal.png", _png((11, 65, 205)))     # the one for screens
        z.writestr("Logo/RGB/Logo_RGB_white_negative.png", _png((255, 255, 255)))       # for dark backgrounds
        z.writestr("Logo/RGB/Logo_motto_RGB_colour.png", _png((0, 120, 0)))             # a variant
        z.writestr("Logo/Symbol/Symbol_RGB_colour.png", _png((11, 65, 205), (64, 64)))  # the square mark: browser tab
        z.writestr("Logo/Symbol/Symbol_CMYK_colour.png", _png((200, 0, 0), (64, 64)))
        z.writestr("Logo/Logo.eps", b"%!PS-Adobe")
        z.writestr("Logo/Logo guide.pdf", b"%PDF-1.4")
        z.writestr("__MACOSX/Logo/RGB/._Logo_RGB_colour_horizontal.png", b"junk")
    masters = tmp_path / "PowerPoint master.zip"
    with zipfile.ZipFile(masters, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("PowerPoint/Presentation checklist.pptx", _template(tmp_path / "c.pptx", "111111", "222222").read_bytes())
        z.writestr("PowerPoint/Corporate Master.potx", _template(tmp_path / "m.pptx").read_bytes())
        z.writestr("PowerPoint/preview.png", _png((0, 0, 0)))                          # not a logo: left out
    icons = tmp_path / "PowerPoint Icons.zip"
    with zipfile.ZipFile(icons, "w", zipfile.ZIP_STORED) as z:
        z.writestr("Icons/Money.svg", SVG)
        z.writestr("Icons/Team.svg", SVG)
        z.writestr("Icons/Unsafe.svg", '<svg xmlns="http://www.w3.org/2000/svg" onload="alert(1)"></svg>')
        z.writestr("Icons/Money.png", _png((0, 0, 0), (32, 32)))                        # icons only as SVG
    plans = tmp_path / "Wall layout.zip"
    with zipfile.ZipFile(plans, "w") as z:
        z.writestr("Wall/plan.dwg", b"AC1027")
        z.writestr("Wall/plan.dxf", b"0\nSECTION")
    return logos, masters, icons, plans


def test_one_button_takes_every_package_and_puts_each_file_where_it_belongs(project, tmp_path):
    pytest.importorskip("playwright")
    from playwright.sync_api import sync_playwright
    logos, masters, icons, plans = _packages(tmp_path)
    server, base = serve_app()
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page(viewport={"width": 1280, "height": 900})
            errors = []
            page.on("pageerror", lambda e: errors.append(str(e)))
            page.goto(base + "/")
            page.click("#settings-open")                                     # the gear at the top right
            page.wait_for_selector("#settings[open] #brand-now:has-text('No company files yet')")

            page.set_input_files("#brand-files", [str(logos), str(masters), str(icons), str(plans)])   # all at once
            page.wait_for_selector("#brand-msg:has-text('The next result uses them')", timeout=30_000)
            msg = page.inner_text("#brand-msg")
            assert "Logo: Logo_RGB_colour_horizontal.png" in msg and "Browser tab icon: Symbol_RGB_colour.png" in msg
            assert "from Logo package.zip › Logo › RGB" in msg                                # where it was found
            assert "PowerPoint template: Corporate Master.potx" in msg and "2 icons" in msg
            assert "Could not use 1 file" in msg and "Unsafe.svg" in msg and "Left out" in msg   # the unsafe icon; PDF, DWG ...
            with zipfile.ZipFile(logos) as z:
                assert (config.BRAND_DIR / "logo.png").read_bytes() == z.read("Logo/RGB/Logo_RGB_colour_horizontal.png")
                assert (config.BRAND_DIR / "favicon.png").read_bytes() == z.read("Logo/Symbol/Symbol_RGB_colour.png")
            assert brand.template().name == "template.potx" and config.THEME_ACCENT == "#0b41cd"
            assert set(brand.icons()) == {"money", "team"} and not brand.images()
            assert sorted(brand.files()) == ["favicon.png", "icons/money.svg", "icons/team.svg", "logo.png", "template.potx"]
            page.wait_for_selector("header .brand img")                       # the logo in the page header too
            assert "/brand/favicon?v=" in page.get_attribute("link[rel=icon]", "href")   # and in the browser tab
            assert page.locator(".brandfiles li").count() == 5

            page.click(".brandfiles button[data-del='icons/team.svg']")              # a wrong file: removed
            page.wait_for_selector("#brand-msg:has-text('Removed icons/team.svg')")
            assert set(brand.icons()) == {"money"} and page.locator(".brandfiles li").count() == 4
            single = tmp_path / "Our logo 2027.png"                                   # one file: by its name
            single.write_bytes(_png((0, 90, 160)))
            page.set_input_files("#brand-files", str(single))
            page.wait_for_selector("#brand-msg:has-text('Logo: Our logo 2027.png')")
            assert (config.BRAND_DIR / "logo.png").read_bytes() == single.read_bytes()
            page.keyboard.press("Escape")                                       # closes like any window
            page.wait_for_selector("#settings", state="hidden")
            assert not errors, errors
            browser.close()
    finally:
        server.shutdown()


def _zip(files: dict[str, bytes], method: int = zipfile.ZIP_DEFLATED) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", method) as z:
        for name, data in files.items():
            z.writestr(name, data)
    return buf.getvalue()


def _packed_with(data: bytes, method: int) -> bytes:
    """The same .zip with its files marked as packed another way (9 = Deflate64, as Windows does for big files)."""
    b = bytearray(data)
    for sig, at in ((b"PK\x03\x04", 8), (b"PK\x01\x02", 10)):
        i = b.find(sig)
        while i >= 0:
            b[i + at:i + at + 2] = method.to_bytes(2, "little")
            i = b.find(sig, i + 4)
    return bytes(b)


BLUE, GREEN = (11, 65, 205), (0, 120, 0)


def _brand_site(tmp_path, monkeypatch) -> tuple[dict[str, bytes], bytes]:
    """What the brand site gives: packages inside one download, folders inside folders, print and Mac copies."""
    with monkeypatch.context() as m:              # the logo package as ZIP64, the way packages over 4 GB are written
        m.setattr(zipfile, "ZIP64_LIMIT", 64)
        m.setattr(zipfile, "ZIP_FILECOUNT_LIMIT", 2)
        logo_package = _zip({
            "Logo package/Logo plus motto/Digital/PNG/Logo plus motto RGB.png": _png(GREEN),
            "Logo package/Logo plus motto/Digital/SVG/Logo plus motto RGB.svg": SVG.encode(),
            "Logo package/Logo plus motto/Print/EPS/Logo plus motto CMYK.eps": b"%!PS-Adobe",
            "Logo package/Logo plus motto/Print/PDF/Logo plus motto CMYK.pdf": b"%PDF-1.4",
            "Logo package/Logo/Digital/PNG/RGB/Brand.png": _png(BLUE),                     # the one for screens
            "Logo package/Logo/Digital/PNG/RGB/Brand white.png": _png((255, 255, 255)),
            "Logo package/Logo/Print/PNG/Brand CMYK.png": _png((200, 0, 0)),
            "Logo package/Logo/Print/EPS/Brand CMYK.eps": b"%!PS-Adobe",
            "Logo package/Symbol/Digital/PNG/RGB/Brand.png": _png(BLUE, (64, 64)),         # the square mark: browser tab
            "__MACOSX/Logo package/Logo/Digital/PNG/RGB/._Brand.png": b"junk",
        })
    with zipfile.ZipFile(io.BytesIO(logo_package)) as z:
        assert z.read("Logo package/Logo/Digital/PNG/RGB/Brand.png") == _png(BLUE)   # a real ZIP64 package
    assert b"PK\x06\x06" in logo_package and b"PK\x06\x07" in logo_package
    master = _template(tmp_path / "w.pptx").read_bytes()
    mac_master = _template(tmp_path / "m.pptx", "111111", "222222").read_bytes()
    icons = _zip({"Icon Set UI/SVG/Arrow.svg": SVG.encode(), "Icon Set UI/SVG/Check.svg": SVG.encode(),
                  "Icon Set UI/PNG/Arrow.png": _png((0, 0, 0), (32, 32)),
                  "Icon Set UI/More icons.zip": _zip({"Calendar.svg": SVG.encode()})})       # a third level
    inside = {
        "Brand/Logo package.zip": logo_package,
        "Brand/PowerPoint Master.zip": _zip({"Windows/PowerPoint Master V1.8.potx": master,
                                             "Mac OS X/PowerPoint Master V1.8.potx": mac_master}),
        "Brand/Digital Background 11.jpg": _png((9, 9, 9)), "Brand/Digital Background 12.jpg": _png((8, 8, 8)),
        "Brand/Icon Set UI.zip": icons,
        "Brand/Mac OS X/Icon Set UI/SVG/Arrow.svg": SVG.encode(),                          # the same icon for Mac
        "Brand/Name Badge Template.potx": master,
        "Brand/Wall Layout.zip": _zip({"Wall/plan.dwg": b"AC1027", "Wall/plan.dxf": b"0\nSECTION"}),
        "Brand/Sound Package.zip": _zip({"Sound/Logo sound.wav": b"RIFF"}),
        "Brand/Old logos.zip": _packed_with(_zip({"Old/Logo old.png": _png((1, 2, 3))}, zipfile.ZIP_STORED), 9),
    }
    return inside, _zip(inside, zipfile.ZIP_STORED)


def _check_brand_site_result(msg: str) -> None:
    assert "Logo: Brand.png from" in msg and "Logo package › Logo › Digital › PNG › RGB" in msg
    assert "Browser tab icon: Brand.png from" in msg and "Symbol › Digital" in msg
    assert "PowerPoint template: PowerPoint Master V1.8.potx from" in msg and "Windows" in msg
    assert "3 icons" in msg                                                   # Arrow once (not the Mac copy), Check, Calendar
    assert "Could not use 1 file" in msg and "Logo old.png" in msg and "Deflate64" in msg and "Extract All" in msg
    assert "Left out" in msg
    assert (config.BRAND_DIR / "logo.png").read_bytes() == _png(BLUE)
    assert (config.BRAND_DIR / "favicon.png").read_bytes() == _png(BLUE, (64, 64))
    assert brand.template().name == "template.potx" and config.THEME_ACCENT == "#0b41cd"      # the Windows master
    assert set(brand.icons()) == {"arrow", "check", "calendar"} and not brand.images()


def _open_settings(page, base):
    page.goto(base + "/")
    page.click("#settings-open")
    page.wait_for_selector("#settings[open] #brand-now")


def test_the_whole_brand_download_as_one_zip_with_zips_inside(project, tmp_path, monkeypatch):
    pytest.importorskip("playwright")
    from playwright.sync_api import sync_playwright
    _, download = _brand_site(tmp_path, monkeypatch)
    whole = tmp_path / "Brand site download.zip"
    whole.write_bytes(download)
    server, base = serve_app()
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page(viewport={"width": 1280, "height": 900})
            errors = []
            page.on("pageerror", lambda e: errors.append(str(e)))
            _open_settings(page, base)
            page.set_input_files("#brand-files", str(whole))
            page.wait_for_selector("#brand-msg:has-text('The next result uses them')", timeout=30_000)
            msg = page.inner_text("#brand-msg")
            _check_brand_site_result(msg)
            assert "from Brand site download.zip › Brand › Logo package.zip ›" in msg
            page.click(".brandleft summary")                                  # why the rest was left out
            left = page.inner_text(".brandleft")
            for why in ("PDF, EPS and print versions", "drawings (DWG, DXF)", "backgrounds and photos", "videos and sounds",
                        "Mac and Windows system files", "icons as pictures", "other PowerPoint files",
                        "other copies of the PowerPoint master (e.g. for Mac)", "the same icons again"):
                assert why in left, why
            assert not errors, errors
            browser.close()
    finally:
        server.shutdown()


def test_the_unpacked_folder_with_the_zips_still_inside(project, tmp_path, monkeypatch):
    pytest.importorskip("playwright")
    from playwright.sync_api import sync_playwright
    inside, _ = _brand_site(tmp_path, monkeypatch)
    folder = tmp_path / "unpacked"
    for name, data in inside.items():                                         # as Windows' Extract All leaves it
        (folder / name).parent.mkdir(parents=True, exist_ok=True)
        (folder / name).write_bytes(data)
    server, base = serve_app()
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page(viewport={"width": 1280, "height": 900})
            errors = []
            page.on("pageerror", lambda e: errors.append(str(e)))
            _open_settings(page, base)
            assert page.is_visible("text=Choose a folder") and page.is_visible("text=Choose files or .zip")
            page.set_input_files("#brand-folder", str(folder / "Brand"))
            page.wait_for_selector("#brand-msg:has-text('The next result uses them')", timeout=30_000)
            _check_brand_site_result(page.inner_text("#brand-msg"))
            assert not errors, errors
            browser.close()
    finally:
        server.shutdown()


def test_a_dropped_folder_is_read_with_all_its_folders(project):
    pytest.importorskip("playwright")
    from playwright.sync_api import sync_playwright
    server, base = serve_app()
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page()
            page.goto(base + "/")
            paths = page.evaluate("""() => {
              const file = (path, text) => ({isFile: true, fullPath: path,
                                             file: ok => ok(new File([text], path.split("/").pop()))});
              const dir = (path, children) => ({isFile: false, fullPath: path, createReader: () => {
                const rest = [...children];
                return {readEntries: ok => ok(rest.splice(0, 2))};     // the browser gives a folder in batches
              }});
              const tree = dir("/Brand", [file("/Brand/a.svg", "x"), dir("/Brand/Logo", [dir("/Brand/Logo/Digital", [
                file("/Brand/Logo/Digital/Logo RGB.png", "y")]), file("/Brand/Logo/b.png", "z")]), file("/Brand/c.txt", "w")]);
              return droppedFiles({items: [{webkitGetAsEntry: () => tree}], files: []})
                .then(list => list.map(i => i.path + ":" + i.file.size).sort());
            }""")
            assert paths == ["Brand/Logo/Digital/Logo RGB.png:1", "Brand/Logo/b.png:1", "Brand/a.svg:1", "Brand/c.txt:1"]
            browser.close()
    finally:
        server.shutdown()


def test_big_company_files_are_sent_as_they_are(project):
    server, base = serve_app()
    try:
        def post(query: str, data: bytes) -> tuple[int, dict]:
            req = urllib.request.Request(f"{base}/api/brand/raw?{query}", data=data, method="POST",
                                         headers={"Content-Type": "application/octet-stream"})
            try:
                with urllib.request.urlopen(req, timeout=10) as r:
                    return r.status, json.loads(r.read())
            except urllib.error.HTTPError as e:
                return e.code, json.loads(e.read() or b"{}")

        code, out = post("kind=logo&name=Logo%20RGB.png", _png(BLUE))
        assert code == 200 and out["logo_url"] and (config.BRAND_DIR / "logo.png").read_bytes() == _png(BLUE)
        assert post("kind=nonsense&name=a.png", _png(BLUE))[0] == 400
        assert post("kind=icon&name=bad.svg", b'<svg xmlns="http://www.w3.org/2000/svg" onload="x()"/>')[0] == 400
        assert post("kind=logo&name=a.png", b"")[0] == 400
    finally:
        server.shutdown()
