"""brand.py: the company's logo, colours and PowerPoint template in the slides, presentations and videos."""
from __future__ import annotations

import re
import subprocess
import zipfile

import pytest
from helpers import needs_ffmpeg

from studio.core import config
from studio.video import brand, slides_html


def _logo(path, colour=(11, 65, 205)):
    from PIL import Image, ImageDraw
    im = Image.new("RGBA", (300, 100), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle((0, 10, 290, 90), 20, fill=colour + (255,))
    d.ellipse((20, 25, 70, 75), fill=(255, 125, 41, 255))
    im.save(path)
    return path


def _template(path, accent1="0B41CD", accent2="FF7D29"):
    """A PowerPoint template with its own theme colours and one example slide (which must not end up in ours)."""
    pptx = pytest.importorskip("pptx")
    prs = pptx.Presentation()
    s = prs.slides.add_slide(prs.slide_layouts[1])
    s.shapes.title.text = "EXAMPLE SLIDE OF THE TEMPLATE"
    tmp = path.with_suffix(".tmp.pptx")
    prs.save(tmp)
    with zipfile.ZipFile(tmp) as zin, zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if re.fullmatch(r"ppt/theme/theme\d+\.xml", item.filename):
                text = data.decode("utf-8")
                text = re.sub(r'(<a:accent1>\s*<a:srgbClr val=")[0-9A-Fa-f]{6}', rf"\g<1>{accent1}", text)
                text = re.sub(r'(<a:accent2>\s*<a:srgbClr val=")[0-9A-Fa-f]{6}', rf"\g<1>{accent2}", text)
                data = text.encode("utf-8")
            zout.writestr(item, data)
    tmp.unlink()
    return path


def _reset():
    brand._info.cache_clear()
    slides_html.css_cache_clear()


def test_no_brand_changes_nothing(project):
    assert not brand.on() and brand.css() == "" and brand.logo_html() == ""
    assert brand.accents("#111111", "#222222") == ("#111111", "#222222")


def test_colours_from_the_template_and_the_logo_on_every_slide(project):
    d = config.BRAND_DIR
    d.mkdir(parents=True)
    _logo(d / "logo.png")
    _template(d / "Company template.pptx")
    _reset()
    i = brand.info()
    assert i["on"] and i["logo"].name == "logo.png" and i["accent"] == "#0b41cd" and i["accent2"] == "#ff7d29"
    assert i["colour_source"] == "template"
    html, _ = slides_html.scene_html({"visual": "bullets", "heading": "Hello", "items": ["one", "two"]},
                                     lesson_title="T", goal="", page="1 / 2")
    assert 'class="brandlogo"' in html and "has-logo" in html and ".brandlogo{" in html


def test_brand_json_wins_and_logo_colours_without_template(project):
    d = config.BRAND_DIR
    d.mkdir(parents=True)
    _logo(d / "logo.png")
    _reset()
    assert brand.info()["accent"] and brand.info()["colour_source"] == "logo"   # the logo's blue
    (d / "brand.json").write_text('{"accent": "#123456", "accent2": "#abcdef", "logo_corner": "bottom-left"}')
    _reset()
    i = brand.info()
    assert (i["accent"], i["accent2"], i["corner"]) == ("#123456", "#abcdef", "bottom-left")


def test_presentation_made_in_the_template(project):
    pptx = pytest.importorskip("pptx")
    d = config.BRAND_DIR
    d.mkdir(parents=True)
    _template(d / "template.pptx")
    _reset()
    sb = {"title": "Joining data", "goal": "Join two tables", "scenes": [
        {"visual": "title", "heading": "Joining data"},
        {"visual": "bullets", "heading": "Before you join", "elements": [{"title": "Trim the keys", "detail": "no spaces"}]},
        {"visual": "comparison", "heading": "Inner vs left", "columns": [{"heading": "Inner", "items": ["matches only"]},
                                                                         {"heading": "Left", "items": ["every row"]}]}]}
    out = brand.write_pptx(sb, ["hello", "trim", "compare"], project / "slides.pptx")
    prs = pptx.Presentation(str(out))
    texts = [" ".join(sh.text_frame.text for sh in s.shapes if sh.has_text_frame) for s in prs.slides]
    assert len(prs.slides) == 3 and "EXAMPLE SLIDE" not in " ".join(texts)
    assert "Trim the keys" in texts[1] and "no spaces" in texts[1] and "every row" in texts[2]
    assert prs.slides[1].notes_slide.notes_text_frame.text == "trim"


@needs_ffmpeg
def test_logo_put_on_a_finished_video(project):
    d = config.BRAND_DIR
    d.mkdir(parents=True)
    _logo(d / "logo.png", colour=(255, 0, 0))
    _reset()
    config.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    video = config.OUTPUT_DIR / "v.mp4"
    subprocess.run([config.FFMPEG, "-loglevel", "error", "-y", "-f", "lavfi", "-i", "color=c=white:s=640x360:d=1",
                    "-f", "lavfi", "-i", "sine=d=1", "-shortest", "-c:v", "libx264", "-pix_fmt", "yuv420p", str(video)],
                   check=True)
    assert brand.stamp(video)
    frame = config.OUTPUT_DIR / "f.png"
    subprocess.run([config.FFMPEG, "-loglevel", "error", "-y", "-i", str(video), "-frames:v", "1", str(frame)], check=True)
    from PIL import Image
    im = Image.open(frame).convert("RGB")
    r, g, b = im.getpixel((640 - 13 - 10, 13 + 6))   # inside the logo, top right
    assert r > 180 and g < 90 and b < 90
    assert im.getpixel((20, 300)) == (255, 255, 255) or sum(im.getpixel((20, 300))) > 740   # the rest untouched


def test_company_icons_pictures_and_wording_in_the_slides_and_the_script(project):
    """data/brand/icons, images and brand.json footer/tone/terms: used in the slides and given to Claude."""
    import json

    from studio.generation import storyboard
    d = config.BRAND_DIR
    (d / "icons").mkdir(parents=True)
    (d / "images").mkdir()
    _logo(d / "logo.png")
    _logo(d / "images" / "title.png", (200, 30, 30))
    (d / "icons" / "Money.svg").write_text(
        '<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" onload="alert(1)"><script>alert(2)</script>'
        '<circle cx="24" cy="24" r="20" fill="#0b41cd"/><image href="https://x.example/a.png"/></svg>')
    (d / "brand.json").write_text(json.dumps({"footer": "For internal use", "tone": "Plain and friendly",
                                              "terms": {"staff": "colleagues"}}))
    _reset()
    assert slides_html.find_icon("money") == "brand:money"
    assert slides_html.find_icon("chart", "Money in the budget") == "brand:money"      # a word of the text
    assert slides_html.find_icon("calendar") == "calendar"                            # else the open-source one
    svg = slides_html.svg_icon("brand:money")
    assert 'viewBox="0 0 48 48"' in svg and "script" not in svg and "onload" not in svg and "x.example" not in svg
    html, _ = slides_html.scene_html({"visual": "bullets", "heading": "Costs", "items": ["one", "two"]},
                                     lesson_title="T", goal="", page="2 / 5")
    assert "For internal use" in html
    title, _ = slides_html.scene_html({"visual": "title", "heading": "Budgets"}, lesson_title="T", goal="g", page="1 / 5")
    assert "brandhero" in title and "title.png" in title
    prompt = storyboard.build_prompt("budgets", 1, "beginner", "material", "", "", "", "clean")
    assert "Plain and friendly" in prompt and '"staff" -> "colleagues"' in prompt
    s = brand.summary()
    assert s["icons"] == 1 and s["images"] == ["title.png"] and s["footer"] == "For internal use"


def _data_url(path):
    import base64
    return "data:application/octet-stream;base64," + base64.b64encode(path.read_bytes()).decode()


def test_files_added_on_the_page_are_used_at_once(project, tmp_path):
    from studio.web import catalog
    _reset()
    assert config.THEME_ACCENT == config.THEME_ACCENT_DEFAULTS[0] and catalog.brand_state()["files"] == []
    out, code = catalog.brand_post("/api/brand", {"kind": "logo", "name": "Our Logo.png",
                                                  "data": _data_url(_logo(tmp_path / "x.png"))})
    assert code == 200 and out["on"] and out["logo"] == "logo.png" and out["logo_url"] == "/brand/logo"
    assert config.THEME_ACCENT == brand.info()["accent"] != config.THEME_ACCENT_DEFAULTS[0]   # no restart needed
    out, code = catalog.brand_post("/api/brand", {"kind": "template", "name": "corp.potx",
                                                  "data": _data_url(_template(tmp_path / "t.pptx"))})
    assert code == 200 and out["template"] == "template.potx" and config.THEME_ACCENT == "#0b41cd"
    icon = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/></svg>'
    (tmp_path / "Money Bag.svg").write_text(icon)
    catalog.brand_post("/api/brand", {"kind": "icon", "name": "Money Bag.svg", "data": _data_url(tmp_path / "Money Bag.svg")})
    assert "money-bag" in brand.icons() and "icons/money-bag.svg" in catalog.brand_state()["files"]
    # a second logo replaces the first one (one logo), whatever its name
    out, code = catalog.brand_post("/api/brand", {"kind": "logo", "name": "new.png", "data": _data_url(_logo(tmp_path / "y.png"))})
    assert code == 200 and [f for f in out["files"] if f.startswith("logo")] == ["logo.png"]
    out, code = catalog.brand_post("/api/brand/delete", {"name": "template.potx"})
    assert code == 200 and not out["template"] and config.THEME_ACCENT == brand.info()["accent"]
    assert catalog.brand_post("/api/brand/delete", {"name": "../../secret.txt"})[1] == 404
    for name in list(catalog.brand_state()["files"]):
        catalog.brand_post("/api/brand/delete", {"name": name})
    assert not brand.on() and config.THEME_ACCENT == config.THEME_ACCENT_DEFAULTS[0]   # the default look again


def test_wrong_or_unsafe_brand_files_are_refused(project, tmp_path):
    from studio.web import catalog

    def post(kind, name, raw):
        import base64
        return catalog.brand_post("/api/brand", {"kind": kind, "name": name, "data": base64.b64encode(raw).decode()})
    bad_svg = b'<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>'
    assert post("logo", "logo.svg", bad_svg)[1] == 400
    assert post("icon", "x.svg", b'<svg onload="alert(1)"></svg>')[1] == 400
    assert post("logo", "logo.png", b"not a picture")[1] == 400
    assert post("template", "t.pptx", b"PK not really")[1] == 400
    assert post("font", "f.ttf", b"<html>")[1] == 400
    assert post("settings", "brand.json", b"[1, 2]")[1] == 400
    assert post("logo", "logo.exe", b"MZ")[1] == 400 and post("virus", "a.png", b"x")[1] == 400
    assert catalog.brand_post("/api/brand", {"kind": "logo", "name": "a.png", "data": "%%%"})[1] == 400
    out, code = post("settings", "anything.json", b'{"accent": "#123456", "footer": "Internal"}')
    assert code == 200 and out["files"] == ["brand.json"] and out["footer"] == "Internal"
    out, code = post("image", "../../title.png", _logo(tmp_path / "p.png").read_bytes())
    assert code == 200 and "images/title.png" in out["files"] and brand.title_image().name == "title.png"


def test_the_browser_tab_icon_is_the_square_mark_else_the_logo(project, tmp_path):
    from helpers import get, serve_app

    from studio.web import catalog
    assert brand.favicon() is None
    config.BRAND_DIR.mkdir(parents=True)
    _logo(config.BRAND_DIR / "logo.png")
    assert brand.favicon().name == "logo.png" and catalog.brand_state()["favicon_url"] == "/brand/favicon"
    out, code = catalog.brand_post("/api/brand", {"kind": "favicon", "name": "Symbol RGB.png",
                                                  "data": _data_url(_logo(tmp_path / "s.png"))})
    assert code == 200 and brand.favicon().name == "favicon.png" and brand.logo().name == "logo.png"
    server, base = serve_app()
    try:
        code, headers, body = get(base + "/brand/favicon")
        assert code == 200 and headers["Content-Type"] == "image/png" and body == (config.BRAND_DIR / "favicon.png").read_bytes()
        catalog.brand_post("/api/brand/delete", {"name": "favicon.png"})
        assert get(base + "/brand/favicon")[2] == (config.BRAND_DIR / "logo.png").read_bytes()   # the logo again
    finally:
        server.shutdown()
