"""
scorm_report.py - what was taken from each e-learning package (SCORM) in data/input and what was not, and why: to
check the extraction by hand, file by file.

  uv run -m studio scorm_report        -> data/scorm_report.xlsx, and a summary here

Sheets:
  Courses    one row per package: words of text found and kept, coverage, the words left out by reason, videos,
             pictures and documents, and what to look at
  Files      one row per file of every package: what it is, what happened to it, words found and kept, coverage,
             what the later steps made of it (OCR of a picture, a document's reading, a video's transcript), and
             "check" where something may have been missed
  Left out   every text left out: its file, its place in the file and why. Quizzes, other languages and repeats
             are left out on purpose; settings fields, labels and headings without text are the ones to check
  Kept       every text kept, with its file and place (to compare with the package)

Coverage = the words kept / the words of the course's own text (all text found, without quizzes, other languages and
repeats). Under 100 %: some of its text was taken for a label or a setting - see "Left out".
The packages are read again (nothing is changed); the later steps' results come from data/manifest.csv, so run it
after inventory or pipeline.
"""
from __future__ import annotations

import sys
from collections import Counter
from pathlib import Path
from typing import Any

from studio.core import config, store
from studio.knowledge import scorm

ON_PURPOSE = (scorm.QUIZ, scorm.LANGUAGE, scorm.REPEATED)          # left out by design
TO_CHECK = (scorm.SETTING, scorm.LABEL, scorm.LONE_HEADING)        # maybe content: look at these
REPORT = "scorm_report.xlsx"


def _pct(part: int, whole: int) -> float | None:
    return round(100 * part / whole, 1) if whole else None


def _later(made: str, rows: dict[str, dict]) -> str:
    """What the later steps (inventory, documents, pipeline) did with a made file, from the manifest."""
    r = rows.get(made)
    if not made:
        return ""
    if r is None:
        return "not in the manifest yet: run inventory"
    out = ("used" if r.get("include") == "yes" else "not used") + (f": {r['check']}" if r.get("check") else "")
    if r.get("media_type") == "video":
        out += "; transcript: " + (r.get("transcript_file") or "none yet")
    if r.get("words"):
        out += f"; {r['words']} words"
    return out


def _words(c: scorm.Course) -> dict[str, Counter]:
    by: dict[str, Counter] = {}
    for p in c.pieces:
        by.setdefault(p.file, Counter())[p.outcome] += p.words
    return by


def course_row(c: scorm.Course, rows: dict[str, dict]) -> dict[str, Any]:
    """One package in numbers, and what to look at."""
    by: Counter[str] = Counter()
    for p in c.pieces:
        by[p.outcome] += p.words
    found, kept = sum(by.values()), by[scorm.KEPT]
    questions = sum(1 for p in c.pieces if p.kind == "q" and p.outcome == scorm.KEPT)
    own = found - sum(by[o] for o in ON_PURPOSE)
    pairs = scorm.pair_captions(c.videos, c.captions)
    pictures = [rows.get(c.made_from.get(p.relative_to(c.folder).as_posix(), "")) for p in c.pictures]
    look = [f"{by[o]} words as '{o}'" for o in TO_CHECK if by[o]]
    keys: Counter[str] = Counter()
    labels: Counter[str] = Counter()
    for p in c.pieces:
        if p.outcome == scorm.SETTING:
            keys[p.detail] += p.words
        elif p.outcome == scorm.LABEL:
            labels[p.file] += p.words
    if keys:   # the field names say whether it is content (subtitles, notes) or settings (colours, paths)
        look.append("settings fields by name: " + ", ".join(f"{k} {n}" for k, n in keys.most_common(6)))
    if labels:
        look.append("labels by file: " + ", ".join(f"{k} {n}" for k, n in labels.most_common(3)))
    look += [f"{f['file']}: {f['what happened']}" for f in c.files if f["what happened"].endswith("check")]
    if not c.blocks:
        look.append("no text kept: is the course's text in a file the reader does not know?")
    if len(c.videos) > len(pairs):
        look.append(f"{len(c.videos) - len(pairs)} videos without English captions: transcribe (pipeline --mode all)")
    return {"package": c.folder.relative_to(config.INPUT_DIR).as_posix(), "course": c.title,
            "made in": f"{scorm.OUT}/{c.name}", "words found": found, "words kept": kept,
            "coverage %": _pct(kept, own), "kept % of all text": _pct(kept, found),
            "questions with answers": questions, "quiz": by[scorm.QUIZ],
            "other language": by[scorm.LANGUAGE], "repeated": by[scorm.REPEATED],
            "settings fields": by[scorm.SETTING], "labels": by[scorm.LABEL],
            "headings without text": by[scorm.LONE_HEADING], "files": len(c.files),
            "files read for text": sum(f["role"] in ("text data", "page") for f in c.files),
            "videos": len(c.videos), "videos with captions": len(pairs), "pictures": len(c.pictures),
            "pictures with text": sum(1 for r in pictures if r and r.get("include") == "yes") if any(pictures) else None,
            "documents inside": len(c.attachments), "look at": "; ".join(look)}


def file_rows(c: scorm.Course, rows: dict[str, dict]) -> list[dict]:
    """Every file of a package, with its coverage and what the later steps made of it."""
    by = _words(c)
    out = []
    for f in c.files:
        w = by.get(f["file"], Counter())
        own = sum(w.values()) - sum(w[o] for o in ON_PURPOSE)
        made = c.made_from.get(f["file"], "")
        later = _later(made, rows)
        check = f["what happened"].endswith("check") or f["what happened"] == "read: no text in it" or \
            any(w[o] for o in TO_CHECK) or f["role"] == "other" or later.startswith("not used")
        out.append({"course": c.title, "file": f["file"], "role": f["role"], "what happened": f["what happened"],
                    "size_kb": f["size_kb"], "words found": f["words found"] or None,
                    "words kept": f["words kept"] or None, "coverage %": _pct(w[scorm.KEPT], own),
                    "left out on purpose": sum(w[o] for o in ON_PURPOSE) or None,
                    "left out to check": sum(w[o] for o in TO_CHECK) or None,
                    "made": made, "later steps": later, "check": "yes" if check else ""})
    if c.text_file:
        out.append({"course": c.title, "file": "(the course text)", "role": "made", "what happened":
                    f"{sum(len(t.split()) for _, t in c.blocks)} words in {sum(k == 'h' for k, _ in c.blocks)} sections",
                    "made": c.text_file, "later steps": _later(c.text_file, rows), "check": ""})
    return out


def piece_rows(c: scorm.Course, kept: bool) -> list[dict]:
    """The texts kept, or left out with why (the ones to check marked)."""
    out = []
    for p in c.pieces:
        if (p.outcome == scorm.KEPT) != kept:
            continue
        kind = {"h": "heading", "p": "paragraph", "b": "bullet point", "q": "question and answer"}[p.kind]
        row = {"course": c.title, "file": p.file, "where": p.where, "kind": kind,
               "words": p.words, "text": p.text[:1000]}
        if not kept:
            row = {"why": p.outcome + (f" ({p.detail})" if p.detail else ""),
                   "to check": "yes" if p.outcome in TO_CHECK else "", **row}
        out.append(row)
    return out


def _sheet(wb: Any, title: str, rows: list[dict], widths: dict[str, int]) -> None:
    from openpyxl.styles import Alignment, Font
    ws = wb.create_sheet(title)
    if not rows:
        ws.append(["nothing here"])
        return
    head: list[str] = []
    for r in rows:
        head += [k for k in r if k not in head]
    ws.append(head)
    for r in rows:
        ws.append([r.get(k) for k in head])
    for cell in ws[1]:
        cell.font = Font(bold=True)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    for i, name in enumerate(head, 1):
        letter = ws.cell(row=1, column=i).column_letter
        ws.column_dimensions[letter].width = widths.get(name, max(10, min(30, len(name) + 3)))
        if name in ("text", "what happened", "look at", "later steps"):
            for cell in ws[letter][1:]:
                cell.alignment = Alignment(wrap_text=True, vertical="top")


def build(out: Path | None = None) -> tuple[Path, list[dict]]:
    """data/scorm_report.xlsx and its Courses rows."""
    from openpyxl import Workbook
    folders = scorm.package_folders() if config.INPUT_DIR.exists() else []
    courses = [scorm.read_course(f) for f in folders]
    used: set[str] = set()
    for c in courses:   # the same names as prepare() gave
        scorm.plan(c, used)
    rows = {r.get("source_file") or r.get("video_file") or "": r for r in store.read_manifest()}
    summary = [course_row(c, rows) for c in courses]
    summary += [{"package": where, "course": "(not read)", "look at": why} for where, why in scorm.problems().items()]
    wb = Workbook()
    wb.remove(wb.active)
    _sheet(wb, "Courses", summary, {"package": 40, "course": 35, "made in": 30, "look at": 80})
    _sheet(wb, "Files", [r for c in courses for r in file_rows(c, rows)],
           {"course": 25, "file": 50, "what happened": 60, "made": 45, "later steps": 60})
    _sheet(wb, "Left out", [r for c in courses for r in piece_rows(c, kept=False)],
           {"why": 28, "course": 25, "file": 30, "where": 45, "text": 90})
    _sheet(wb, "Kept", [r for c in courses for r in piece_rows(c, kept=True)],
           {"course": 25, "file": 30, "where": 45, "text": 90})
    path = out or config.DATA_DIR / REPORT
    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)
    return path, summary


def main() -> int:
    """Command line: write the report and print each course's numbers."""
    config.setup_logging()
    path, summary = build()
    if not summary:
        print(f"No e-learning package (a folder or .zip with imsmanifest.xml) in {config.INPUT_DIR}")
        return 0
    for s in summary:
        if s["course"] == "(not read)":
            print(f"\nNOT READ: {s['package']}\n  {s['look at']}")
            continue
        print(f"\n{s['course']}  ({s['package']})\n"
              f"  coverage: {s['coverage %']} % of its own text kept ({s['words kept']} of {s['words found']} words found)\n"
              f"  quiz questions kept with their right answer: {s['questions with answers']}\n"
              f"  left out on purpose: quiz {s['quiz']}, other language {s['other language']}, repeated {s['repeated']}\n"
              f"  to check: settings fields {s['settings fields']}, labels {s['labels']}, "
              f"headings without text {s['headings without text']}\n"
              f"  files: {s['files']} ({s['files read for text']} read for text), videos: {s['videos']} "
              f"({s['videos with captions']} with English captions), pictures: {s['pictures']}, "
              f"documents inside: {s['documents inside']}"
              + "".join(f"\n  look at: {x}" for x in s["look at"].split("; ") if x))   # one per line: none cut off
    print(f"\nReport: {path}  (sheets Courses, Files, Left out, Kept; filter 'check' / 'to check' = yes)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
