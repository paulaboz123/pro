"""Every slide of a video or presentation says where its content comes from (a footnote: the training and the
time), and the page lists the sources under the result, as under an answer."""
from __future__ import annotations

from studio.video import slides_html

SOURCES = {"S1": {"title": "Joining data", "video_id": "v1", "start": 750, "end": 790},
           "S2": {"title": "Joining data", "video_id": "v1", "start": 845, "end": 870},
           "S3": {"title": "A very long training title about month-end closing in the finance team", "video_id": "v2",
                  "start": 3725, "end": 3760},
           "D1": {"title": "Close checklist", "video_id": "d1", "where": "page 3"},
           "D2": {"title": "Close guide", "video_id": "d2", "where": "start (2)", "start": 60},
           "S4": {"title": "Short one", "video_id": "v3", "start": 4, "end": 1}}


def test_the_footnote_names_the_training_and_the_time():
    assert slides_html.source_note({"sources": ["S1", "S2"]}, SOURCES) == "Source: Joining data, 12:30 · 14:05"
    two = slides_html.source_note({"sources": ["S1", "S3"]}, SOURCES)
    assert two.startswith("Sources: Joining data, 12:30; A very long training title about month-end") and "1:02:05" in two
    assert "…" in two and len(two) < 110                                            # a long title is shortened
    assert slides_html.source_note({"sources": ["D1"]}, SOURCES) == "Source: Close checklist, page 3"
    assert slides_html.source_note({"sources": ["D2"]}, SOURCES) == "Source: Close guide, beginning, part 2"   # words
    assert slides_html.source_note({"sources": ["S4"]}, SOURCES) == "Source: Short one, 0:04"
    assert slides_html.source_note({"sources": []}, SOURCES) == "" and slides_html.source_note({"sources": ["X"]}, SOURCES) == ""


def test_the_footnote_is_on_the_slide_but_not_on_the_title():
    scene = {"visual": "bullets", "heading": "Joins", "items": ["One", "Two"], "sources": ["S1"]}
    html, _ = slides_html.scene_html(scene, lesson_title="T", goal="", page="2 / 5",
                                     source=slides_html.source_note(scene, SOURCES))
    assert '<span class="srcnote">Source: Joining data, 12:30</span>' in html and ".srcnote{" in html
    title, _ = slides_html.scene_html({"visual": "title", "heading": "Joins"}, lesson_title="T", goal="", page="1 / 5",
                                      source="Source: x")
    assert "srcnote\">" not in title


def test_the_page_lists_each_training_once_with_its_places_in_words(gateway):
    import pytest
    pytest.importorskip("playwright")
    from helpers import serve_app
    from playwright.sync_api import sync_playwright
    server, base = serve_app()
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page()
            page.goto(base + "/")
            places = page.evaluate("placesIn(['00:04-00:01', '01:27-02:00', '02:00-02:27', 'start', 'start (2)', "
                                   "'slide 4', 'start'])")
            assert places == ["at 0:04", "1:27–2:27", "Beginning", "Beginning, part 2", "Slide 4"]
            html = page.evaluate("usedSources({sources: [{source: 'Data connections', where: ['01:27-02:00', 'start']},"
                                 " {source: 'Joins', where: ['00:10-00:40']}]})")
            assert "<details" in html and "2 parts" in html and '<div class="src"><b>2</b> Joins' in html and "0:10–0:40" in html
            browser.close()
    finally:
        server.shutdown()
