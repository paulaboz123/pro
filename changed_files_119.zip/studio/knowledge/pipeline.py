"""
pipeline.py - runs the whole preparation in the right order, for the mode you choose.

Modes (pick with --mode, or PIPELINE_MODE in .env; --mode wins):
  easy   videos that already have a transcript                     <- start here
  audio  + audio files and standalone transcripts with a transcript
  all    + every recording without a transcript (transcribed locally with Whisper)
Add --vision to also describe what each slide shows (diagrams, processes). Recommended
with the gateway (cheap, fast); slow with a local model.

E-learning packages (SCORM .zip or folders) become a course text, videos with captions and pictures first
(scorm.py); videos without English captions need --mode all.
Everything else in data/input (Word, PowerPoint, PDF, Excel, HTML quizzes, JSON, XML, images) is
read by documents.py and filtered (icons, logos, code, too little text, other languages and
duplicates are left out); see the 'check' column of the manifest. Options for documents:
--ai-triage (the model judges usefulness), --render-html (click through interactive quizzes),
--vision (also describes diagrams without text).

Order of steps, each skipping what is already done:
  1. inventory        find recordings, pair them with transcripts, read and filter documents
                      -> data/manifest.csv
  2. transcribe       only in mode "all": make missing transcripts
  3. ingest           transcripts -> ~1-minute segments; documents -> ~180-word pieces
  4. slides           videos only: detect slides, read their text
  5. describe slides  only with --vision
  6. chunk            cut each transcript where the subject, screen or speaker changes (chunking.py)
  7. sections         group the pieces into topic sections (one model call per recording, kept)
  8. index            glossary of terms (glossary.py, free) and the search index

Only manifest rows with include=yes are processed, in every mode. A row the current mode
does not cover is listed at the end, so nothing is skipped silently.

Usage:
  uv run -m studio pipeline                        # mode from .env (default: easy)
  uv run -m studio pipeline --mode audio
  uv run -m studio pipeline --mode all --vision
  uv run -m studio pipeline --force                # redo ingest + slides for the selected rows
  uv run -m studio pipeline --mode all --rechunk   # cut the transcripts again (new CHUNKING settings)
"""
from __future__ import annotations

import argparse
import logging
import sys
from collections.abc import Callable

from studio.core import config, llm, store
from studio.knowledge import chunking, documents, index, ingest, inventory, slides

log = logging.getLogger("pipeline")


def in_mode(row: dict, mode: str) -> tuple[bool, str]:
    """Is this row handled in this mode? Returns (yes/no, reason if no)."""
    kind = row.get("media_type") or ("video" if row.get("video_file") else "none")
    if kind == "document":   # documents are read in every mode
        return True, ""
    has_transcript = store.transcript_path(row) is not None
    if mode == "all":
        return True, ""
    if not has_transcript:
        return False, "no transcript (needs mode 'all')"
    if kind == "video":
        return True, ""
    if mode == "audio":
        return True, ""
    label = "transcript without a recording" if kind == "none" else f"{kind} file"
    return False, f"{label} (needs mode 'audio')"


def _name(row: dict) -> str:
    """How a row is named in the log: its file, else its id."""
    return row.get("video_file") or row.get("transcript_file") or row.get("source_file") or row.get("video_id", "")


def run_step(rows: list[dict], label: str, fn: Callable[[dict], object], *, stops_on_budget: bool = False) -> int:
    """Run one step for every row; a row that fails is logged and the others go on.

    Args:
        rows: the manifest rows to process.
        label: the step's name in the log.
        fn: the step for one row.
        stops_on_budget: stop at the spending lock (a step with model calls), instead of trying the next row.

    Returns:
        How many rows failed.
    """
    failed = 0
    for row in rows:
        try:
            fn(row)
        except llm.BudgetExceeded as e:
            failed += 1
            if stops_on_budget:   # no point trying the other recordings
                log.error("%s stopped: %s", label, e)
                break
            log.error("%s: %s FAILED - %s", _name(row), label, e)
        except Exception as e:   # noqa: BLE001 - isolation point: one recording must not stop the others
            log.error("%s: %s FAILED - %s", _name(row), label, e)
            failed += 1
    return failed


def select_rows(mode: str) -> tuple[list[dict], list[tuple[dict, str]]] | None:
    """The included rows this mode processes, and the ones it leaves out with why. None when none is included."""
    included = store.included_rows()
    if not included:
        log.error("No rows with include=yes in %s. Mark your dev set and run again.", config.MANIFEST)
        return None
    rows, left_out = [], []
    for row in included:
        ok, reason = in_mode(row, mode)
        if ok:
            rows.append(row)
        else:
            left_out.append((row, reason))
    log.info("%s of %s included rows are covered by mode '%s'", len(rows), len(included), mode)
    return rows, left_out


def ingest_one(row: dict, force: bool) -> None:
    """Read one row's transcript (a talk) or text (a document) into segments."""
    if row.get("media_type") == "document":
        documents.ingest_row(row, force)
    else:
        ingest.ingest_row(row, force)


def glossary_and_index() -> int:
    """The glossary (terms, acronyms, spellings; no model calls) and the search index. Returns failures."""
    try:
        from studio.knowledge import glossary
        glossary.build()
    except Exception as e:   # noqa: BLE001 - isolation point: search works without the glossary
        log.error("Glossary FAILED - %s (search works without it)", e)
    try:
        return 1 if index.build() != 0 else 0
    except Exception as e:   # noqa: BLE001 - isolation point: report it with the other failures
        log.error("Index build FAILED - %s", e)
        return 1


def main() -> int:
    """Prepare every included recording and document, step by step. Returns 0 when nothing failed."""
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--mode", choices=config.MODES, default=config.PIPELINE_MODE)
    ap.add_argument("--vision", action="store_true", help="also describe slides with the vision model")
    ap.add_argument("--force", action="store_true", help="redo ingest and slides for the selected rows")
    ap.add_argument("--rechunk", action="store_true", help="cut the transcripts again (after changing CHUNKING or limits)")
    ap.add_argument("--no-sections", action="store_true", help="no topic sections (saves one model call per recording)")
    ap.add_argument("--ai-triage", action="store_true", help="documents: let the chat model judge them too")
    ap.add_argument("--render-html", action="store_true", help="documents: click through interactive HTML")
    args = ap.parse_args()
    config.setup_logging()
    log.info("=== Mode: %s%s", args.mode, " + vision" if args.vision else "")

    log.info("=== 1/8 Inventory")
    if inventory.main(ai_triage=args.ai_triage, render_html=args.render_html, vision=args.vision) != 0:
        return 1
    chosen = select_rows(args.mode)
    if chosen is None:
        return 1
    rows, left_out = chosen

    failed = 0
    if args.mode == "all":
        log.info("=== 2/8 Transcribe missing transcripts")
        from studio.knowledge import transcribe  # imported only here: needs faster-whisper
        failed += transcribe.run(rows).get("failed", 0)
    else:
        log.info("=== 2/8 Transcribe: skipped in mode '%s'", args.mode)

    log.info("=== 3/8 Ingest transcripts and documents")
    failed += run_step(rows, "ingest", lambda r: ingest_one(r, args.force))

    log.info("=== 4/8 Slides (videos only)")
    videos = [r for r in rows if r.get("media_type", "video") == "video" and store.has_segments(r["video_id"])]
    failed += run_step(videos, "slides", lambda r: slides.process_video(r["video_id"], args.force))

    if args.vision:
        log.info("=== 5/8 Describe slides with %s", config.VISION_MODEL)
        from studio.knowledge import describe_slides
        with_slides = [r for r in rows if store.has_slides(r["video_id"])]
        failed += run_step(with_slides, "describe slides",
                           lambda r: describe_slides.describe_video(r["video_id"], args.force, None),
                           stops_on_budget=True)
    else:
        log.info("=== 5/8 Describe slides: skipped (add --vision)")

    log.info("=== 6/8 Cut transcripts (CHUNKING=%s; on a failure the ~1-minute pieces are kept)", config.CHUNKING)
    talks = [r for r in rows if r.get("media_type") != "document" and store.has_segments(r["video_id"])]
    failed += run_step(talks, "chunking", lambda r: chunking.rechunk(r["video_id"], force=args.force or args.rechunk))

    if config.CHUNKING == "content" and not args.no_sections:
        log.info("=== 7/8 Topic sections (one model call per recording, kept)")
        failed += run_step(talks, "topic sections", chunking.build_sections, stops_on_budget=True)
    else:
        log.info("=== 7/8 Topic sections: skipped")

    log.info("=== 8/8 Glossary and search index")
    failed += glossary_and_index()

    for row, reason in left_out:
        log.info("Not processed in this mode: %s - %s", row.get("title"), reason)
    log.info("=== Done: %s rows processed, %s failures", len(rows), failed)
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
