"""
inventory.py - builds data/manifest.csv: one row per recording, paired with its transcript
and its row in description.xlsx, with a sanity check for each row.

Recordings = video (.mp4 ...) and audio (.m4a ...) files; media_type says which. Files can
sit in any sub-folder of data/input (video/, audio/, transcript/ ...): pairing is by name.

Recording <-> transcript: same file name first, then the same name without Teams additions
(dates, "Meeting Recording"), then a close fuzzy match. pair_method says which rule matched.

Recording <-> description.xlsx (optional; columns id | name | description):
- "13. Introduction to joining data.mp4" is matched to the row with id 13 (the number at the
  start of the file name). Files without a number are matched by name.
- That row's name becomes the title; its description is kept and later used for search and
  as context for lessons. Edit names and descriptions in the Excel, not in the manifest:
  they are refreshed on every run.
- If the number matches but the names look different, the row is flagged in "check".
  A video missing from the Excel is flagged too; audio and transcripts are not.

E-learning packages (SCORM) are turned into a course text, videos with captions and pictures first
(scorm.py, into data/input/_scorm); their own files are not listed.

Re-running is safe: your edits (include, crop, a corrected transcript_file) are kept, new
files are added. To redo a row from scratch, delete it from the manifest and run again.

Usage:  uv run -m studio inventory
"""
from __future__ import annotations

import difflib
import logging
import re
import sys
from dataclasses import dataclass
from pathlib import Path

from studio.core import config, store
from studio.knowledge import documents, ingest, scorm
from studio.video import media

log = logging.getLogger("inventory")

TEAMS_NOISE = re.compile(r"meeting recording|meeting transcript|transcript|recording", re.I)
TEAMS_STAMP = re.compile(r"\d{8}_\d{6}")                          # 20241015_100302
NOT_BY_DEFAULT = ("LANGUAGE", "AUDIO OF A VIDEO", "UNREADABLE")   # such new rows stay include=no
LEADING_NUMBER = re.compile(r"^\s*(\d+)\s*[.)_:\-]?\s*(.*)$")       # "13. Name" -> "13", "Name"


@dataclass
class Entry:
    """One row of description.xlsx."""
    id: str
    name: str
    description: str


# --- Recording <-> transcript -------------------------------------------------------
def _norm(name: str, keep_dates: bool) -> str:
    """File name as plain lowercase words, without Teams additions (and without the date
    stamp unless keep_dates)."""
    s = TEAMS_NOISE.sub(" ", Path(name).stem)
    if not keep_dates:
        s = TEAMS_STAMP.sub(" ", s)
    return " ".join(re.sub(r"[^a-z0-9]+", " ", s.lower()).split())


def clean_title(video_name: str) -> str:
    """'Weekly sync-20241015_100302-Meeting Recording' -> 'Weekly sync (2024-10-15)'."""
    stem = Path(video_name).stem
    m = TEAMS_STAMP.search(stem)
    date = f" ({m.group()[:4]}-{m.group()[4:6]}-{m.group()[6:8]})" if m else ""
    title = TEAMS_STAMP.sub(" ", TEAMS_NOISE.sub(" ", stem))
    title = " ".join(re.sub(r"[_\-]+", " ", title).split())
    return (title or stem) + date


def pair(videos: list[Path], transcripts: list[Path]) -> dict[Path, tuple[Path | None, str]]:
    """Match each recording to at most one transcript: exact name -> normalized name -> fuzzy."""
    free = list(transcripts)
    result: dict[Path, tuple[Path | None, str]] = {}
    same_name: dict[str, int] = {}   # recurring meetings share a name; then dates matter
    for v in videos:
        same_name[_norm(v.name, False)] = same_name.get(_norm(v.name, False), 0) + 1

    def take(video: Path, match: Path, how: str) -> None:
        """Record a match and remove that transcript from the free ones."""
        free.remove(match)
        result[video] = (match, how)

    for v in videos:  # 1) same file name (any folder)
        m = next((t for t in free if t.stem.lower() == v.stem.lower()), None)
        if m:
            take(v, m, "exact")
    for v in videos:  # 2) same name once Teams noise is removed, dates kept
        if v in result:
            continue
        m = next((t for t in free if _norm(t.name, True) == _norm(v.name, True)), None)
        if m:
            take(v, m, "name")
    for v in videos:  # 3) fuzzy, dates ignored; only if clearly the best candidate
        if v in result:
            continue
        scored = sorted(((difflib.SequenceMatcher(None, _norm(v.name, False), _norm(t.name, False)).ratio(), t)
                         for t in free), key=lambda x: x[0], reverse=True)
        if scored and scored[0][0] >= 0.8 and (len(scored) == 1 or scored[0][0] - scored[1][0] > 0.05):
            exact = scored[0][0] == 1.0 and same_name[_norm(v.name, False)] == 1
            take(v, scored[0][1], "name, date ignored" if exact else f"fuzzy {scored[0][0]:.2f}")
        else:
            result[v] = (None, "none")
    return result


def checks(video_min: float | None, transcript_min: float | None, how: str) -> str:
    """Sanity checks for one recording/transcript pair, as text for the 'check' column
    ('' = nothing suspicious)."""
    issues = []
    if video_min is None:
        issues.append("UNREADABLE VIDEO")
    if how == "none":
        issues.append("NO TRANSCRIPT")
    elif transcript_min is None:
        issues.append("UNREADABLE TRANSCRIPT")
    elif video_min and transcript_min > video_min + 2:
        issues.append(f"TRANSCRIPT LONGER THAN VIDEO ({transcript_min:.0f} vs {video_min:.0f} min) - wrong pair?")
    elif video_min and transcript_min < video_min * 0.5:
        issues.append(f"TRANSCRIPT COVERS ONLY {transcript_min:.0f} of {video_min:.0f} min")
    if how.startswith("fuzzy"):
        issues.append("CHECK PAIR")
    return "; ".join(issues)


# --- Recording <-> description.xlsx -----------------------------------------------------
def _simple(text: str) -> str:
    """'Intro_to Joining-Data' -> 'intro to joining data' (letters and digits only)."""
    return " ".join(re.sub(r"[\W_]+", " ", text.lower()).split())


def _norm_id(value: object) -> str:
    """13, 13.0, '13', '013', '13.' -> '13'. Ids that are not numbers are kept as text."""
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        value = int(value)
    text = str(value).strip().rstrip(".")
    return str(int(text)) if text.isdigit() else text.lower()


def _cell(row: tuple, i: int | None) -> str:
    """Text of one Excel cell ('' for empty or missing cells), spaces tidied."""
    value = row[i] if i is not None and i < len(row) else None
    return "" if value is None else " ".join(str(value).split())


def find_descriptions_file() -> Path | None:
    """DESCRIPTIONS_FILE from .env, else the first description*.xlsx anywhere in data/input."""
    if config.DESCRIPTIONS_FILE:
        path = Path(config.DESCRIPTIONS_FILE)
        return path if path.is_absolute() else config.ROOT / path
    found = sorted(p for p in config.INPUT_DIR.rglob("*.xlsx")
                   if p.stem.lower().startswith("description") and not p.name.startswith("~$"))
    if len(found) > 1:
        log.warning("Several description files, using %s (ignoring %s)",
                    found[0].name, ", ".join(p.name for p in found[1:]))
    return found[0] if found else None


def load_descriptions(path: Path) -> dict[str, Entry]:
    """Rows of the first sheet that has a header row with 'id' and 'name' (any row, any order)."""
    try:
        from openpyxl import load_workbook
    except ImportError as e:
        raise RuntimeError("openpyxl is not installed. Run: uv add openpyxl") from e
    wb = load_workbook(path, read_only=True, data_only=True)
    try:
        for ws in wb.worksheets:
            rows = ws.iter_rows(values_only=True)
            cols: dict[str, int] | None = None
            for row in rows:   # find the header row
                cells = [_cell(row, i).lower() for i in range(len(row))]
                if "id" in cells and "name" in cells:
                    cols = {k: cells.index(k) for k in ("id", "name", "description") if k in cells}
                    break
            if cols is None:
                continue
            if "description" not in cols:
                log.warning("%s has no 'description' column; only names are used", path.name)
            entries: dict[str, Entry] = {}
            for row in rows:   # iteration continues after the header row
                eid = _norm_id(row[cols["id"]] if cols["id"] < len(row) else None)
                if not eid:
                    continue
                if eid in entries:
                    log.warning("%s: id %s appears twice, using the first row", path.name, eid)
                    continue
                entries[eid] = Entry(eid, _cell(row, cols["name"]), _cell(row, cols.get("description")))
            return entries
    finally:
        wb.close()
    raise ValueError(f"{path.name}: no sheet has a header row with the columns 'id' and 'name'")


def _names_agree(file_part: str, excel_name: str) -> bool:
    """True if the name in the file and the name in the Excel look like the same recording."""
    a, b = _simple(file_part), _simple(excel_name)
    return not a or not b or a in b or b in a or difflib.SequenceMatcher(None, a, b).ratio() >= 0.6


def match_entry(file_name: str, entries: dict[str, Entry]) -> tuple[Entry | None, str]:
    """The description.xlsx row for one file. Returns (row or None, problem for 'check')."""
    stem = TEAMS_STAMP.sub(" ", Path(file_name).stem)
    m = LEADING_NUMBER.match(stem)
    if m and _norm_id(m.group(1)) in entries:
        entry = entries[_norm_id(m.group(1))]
        if _names_agree(m.group(2), entry.name):
            return entry, ""
        return entry, f"EXCEL ID {entry.id} HAS ANOTHER NAME ('{entry.name}') - check"

    # no number, or a number the Excel does not have: try the name
    target = _simple(m.group(2) if m else stem)
    scored = sorted(((difflib.SequenceMatcher(None, target, _simple(e.name)).ratio(), e)
                     for e in entries.values() if e.name), key=lambda x: x[0], reverse=True)
    if scored and scored[0][0] >= 0.85 and (len(scored) == 1 or scored[0][0] - scored[1][0] > 0.05):
        entry = scored[0][1]
        if m:
            return entry, f"FILE NUMBER {m.group(1)} BUT EXCEL ID {entry.id} HAS THIS NAME - check"
        return entry, "" if scored[0][0] == 1.0 else f"MATCHED TO EXCEL ID {entry.id} BY NAME - check"
    return None, "NOT IN description.xlsx"


def _apply_entry(row: dict, entries: dict[str, Entry], used: set[str]) -> None:
    """Fill catalog_id, title and description from the Excel; add any problem to 'check'."""
    entry, problem = None, "NOT IN description.xlsx"
    for name in (row.get("video_file"), row.get("transcript_file")):
        if name:
            entry, problem = match_entry(Path(name).name, entries)
            if entry:
                break
    if entry:
        row["catalog_id"], row["description"] = entry.id, entry.description
        if entry.name:
            row["title"] = entry.name
        used.add(entry.id)
    else:   # keep anything typed into the manifest by hand
        row.setdefault("catalog_id", "")
        row.setdefault("description", "")
    if problem and (entry or row.get("media_type") == "video"):   # the Excel may list only videos
        row["check"] = "; ".join(x for x in (row.get("check"), problem) if x)


# --- Main ------------------------------------------------------------------------------
def _rel(p: Path) -> str:
    """Path relative to data/input, with forward slashes (as stored in the manifest)."""
    return p.relative_to(config.INPUT_DIR).as_posix()


def _row_key(r: dict) -> str:
    """Identity of a manifest row: its source file, its recording, or its transcript if it has neither."""
    if r.get("source_file"):
        return "s:" + r["source_file"]
    return r.get("video_file") or "t:" + r.get("transcript_file", "")


def _read_entries(desc_path: Path | None) -> dict[str, Entry] | None:
    """The rows of description.xlsx ({} when there is none). None when it is set but cannot be read."""
    if desc_path is None:
        log.info("No description*.xlsx in %s: titles come from file names", config.INPUT_DIR)
        return {}
    if not desc_path.exists():
        log.error("DESCRIPTIONS_FILE %s does not exist", desc_path)
        return None
    try:
        entries = load_descriptions(desc_path)
    except Exception as e:   # noqa: BLE001 - isolation point: any unreadable Excel file: say which and stop
        log.error("Could not read %s: %s", desc_path.name, e)
        return None
    log.info("Read %s rows from %s", len(entries), desc_path.name)
    return entries


def _input_files() -> tuple[list[Path], list[Path]]:
    """The recordings (videos before audio copies, so a transcript pairs with the video) and the transcripts
    (.vtt before .docx, as their times are exact; a .docx only with timed cues, else it is a document)."""
    files = [p for p in config.INPUT_DIR.rglob("*") if p.is_file() and not scorm.inside_package(p)]
    videos = sorted((p for p in files if p.suffix.lower() in config.MEDIA_EXT),
                    key=lambda p: (p.suffix.lower() in config.AUDIO_EXT, p.as_posix().lower()))
    transcripts = sorted(p for p in files if p.suffix.lower() in config.TRANSCRIPT_EXT
                         and (p.suffix.lower() != ".docx" or documents.is_transcript_docx(p)))
    transcripts.sort(key=lambda p: p.suffix.lower() != ".vtt")
    log.info("Found %s recordings (video/audio) and %s transcripts in %s",
             len(videos), len(transcripts), config.INPUT_DIR)
    return videos, transcripts


def _new_row(file: Path, entries: dict[str, Entry], **fields: str) -> dict:
    """A fresh row; video_id = Excel id + name when known, so it is easy to recognise."""
    entry, _ = match_entry(file.name, entries) if entries else (None, "")
    title = entry.name if entry and entry.name else clean_title(file.name)
    label = f"{entry.id} {title}" if entry else title
    return {"video_id": store.stable_id(_rel(file), label), "include": "no", "title": title, "crop": "", **fields}


def _recording_rows(videos: list[Path], transcripts: list[Path], existing: dict[str, dict],
                    entries: dict[str, Entry]) -> list[dict]:
    """One row per recording, paired with its transcript; your edits to existing rows are kept and only the
    measured columns refreshed. An audio copy of a listed video is flagged."""
    taken = {r.get("transcript_file") for r in existing.values()}
    pairs = pair([v for v in videos if _rel(v) not in existing], [t for t in transcripts if _rel(t) not in taken])
    video_names = {_norm(v.name, True) for v in videos if v.suffix.lower() in config.VIDEO_EXT}
    rows: list[dict] = []
    for v in videos:
        try:
            video_min: float | None = round(media.duration_s(v) / 60, 1)
        except media.MediaError as e:
            log.warning("%s: %s", v.name, e)
            video_min = None
        if _rel(v) in existing:
            row = existing[_rel(v)]
            t_rel, how = row.get("transcript_file", ""), row.get("pair_method") or "manual"
        else:
            t_path, how = pairs[v]
            t_rel = _rel(t_path) if t_path else ""
            row = _new_row(v, entries, video_file=_rel(v))
        row["media_type"] = "audio" if v.suffix.lower() in config.AUDIO_EXT else "video"
        rows.append(_refresh(row, t_rel, how, video_min))
        if row["media_type"] == "audio" and _norm(v.name, True) in video_names:
            row["check"] = "; ".join(x for x in [row["check"], "AUDIO OF A VIDEO ALREADY LISTED - keep include=no"] if x)
    return rows


def _transcript_only_rows(transcripts: list[Path], rows: list[dict], existing: dict[str, dict],
                          entries: dict[str, Entry]) -> list[dict]:
    """Transcripts without a recording; the second format of one already used (.docx next to its .vtt) is skipped."""
    used = {r["transcript_file"] for r in rows if r["transcript_file"]}
    used_names = {_norm(Path(u).name, True) for u in used}
    out = []
    for t in transcripts:
        if _rel(t) in used or _norm(t.name, True) in used_names:
            continue
        row = existing.get("t:" + _rel(t)) or _new_row(t, entries, media_type="none", video_file="")
        out.append(_refresh(row, _rel(t), "transcript only", None))
        used_names.add(_norm(t.name, True))
    return out


def _apply_descriptions(rows: list[dict], entries: dict[str, Entry], desc_name: str) -> None:
    """Titles and descriptions from description.xlsx; its rows without a file are listed."""
    used_ids: set[str] = set()
    for row in rows:
        _apply_entry(row, entries, used_ids)
    missing = [e for e in entries.values() if e.id not in used_ids]
    if missing:
        log.info("%s rows of %s have no file in data/input (fine if you left them out on purpose): %s",
                 len(missing), desc_name, ", ".join(f"{e.id} {e.name}"[:50] for e in missing[:15]))


def main(ai_triage: bool = False, render_html: bool = False, vision: bool = False) -> int:
    """List every recording, transcript and document of data/input in data/manifest.csv.

    New recordings are included at once unless the check column speaks against it; your edits (include=no, a
    pairing, a crop) are kept. ai_triage / render_html / vision: see documents.py.

    Returns:
        0, or 1 when the input folder or description.xlsx cannot be read.
    """
    config.setup_logging()
    if not config.INPUT_DIR.exists():
        log.error("Folder %s does not exist", config.INPUT_DIR)
        return 1
    scorm.prepare()   # e-learning packages -> a course text, videos with captions, pictures (data/input/_scorm)
    desc_path = find_descriptions_file()
    entries = _read_entries(desc_path)
    if entries is None:
        return 1
    videos, transcripts = _input_files()
    existing = {_row_key(r): r for r in store.read_manifest()}
    rows = _recording_rows(videos, transcripts, existing, entries)
    rows += _transcript_only_rows(transcripts, rows, existing, entries)
    if entries and desc_path:
        _apply_descriptions(rows, entries, desc_path.name)
    for row in rows:   # new recordings are used right away, unless something speaks against it
        if _row_key(row) not in existing and not any(flag in row["check"] for flag in NOT_BY_DEFAULT):
            row["include"] = "yes"
    skip = set(videos) | set(transcripts) | ({desc_path} if desc_path else set())
    doc_rows = documents.inventory_rows(existing, {p.resolve() for p in skip} | skip,
                                        ai=ai_triage, render_html=render_html, vision=vision)
    store.write_manifest(rows + doc_rows)
    _print_summary(rows)
    _print_documents(doc_rows)
    rows = rows + doc_rows
    flagged = sum(bool(r["check"]) for r in rows)
    log.info("Wrote %s rows to %s (%s flagged in the 'check' column)", len(rows), config.MANIFEST, flagged)
    log.info("Next: open the manifest, fix flagged rows, set include=yes for the recordings to use "
             "(documents are already decided by the filter; override with include=yes/no)")
    return 0


def _refresh(row: dict, t_rel: str, how: str, video_min: float | None) -> dict:
    """Fill the measured columns: transcript length and the sanity check."""
    transcript_min = None
    if t_rel and (config.INPUT_DIR / t_rel).exists():
        try:
            cues = ingest.parse_transcript(config.INPUT_DIR / t_rel)
            transcript_min = round(cues[-1].end / 60, 1) if cues else None
        except Exception as e:   # noqa: BLE001 - isolation point: an unreadable transcript is reported in the list
            log.warning("%s: %s", t_rel, e)
    if how == "transcript only":
        check = "" if transcript_min else "UNREADABLE TRANSCRIPT"
    else:
        check = checks(video_min, transcript_min, how if t_rel else "none")
    lang = _transcript_language(row, t_rel)
    row["lang"] = lang
    if lang and lang not in config.KNOWLEDGE_LANGS and lang != "unknown":
        name = documents.LANG_NAMES.get(lang, lang)
        check = "; ".join(x for x in [check, f"LANGUAGE {name} - not used (KNOWLEDGE_LANGS)"] if x)
    row.update({"transcript_file": t_rel, "pair_method": how,
                "video_min": "" if video_min is None else video_min,
                "transcript_min": "" if transcript_min is None else transcript_min,
                "check": check})
    return row


def _transcript_language(row: dict, t_rel: str) -> str:
    """Language of the transcript (downloaded or made by Whisper); '' if there is none yet."""
    path = config.INPUT_DIR / t_rel if t_rel else store.transcript_path(row) if row.get("video_id") else None
    marker = store.read_json(store.video_dir(row.get("video_id", "")) / "language.json") if row.get("video_id") else None
    if marker:   # Whisper found another language and stopped (transcribe.py)
        return marker.get("lang", "")
    if not path or not Path(path).exists():
        return ""
    try:
        cues = ingest.parse_transcript(Path(path))
    except Exception:   # noqa: BLE001 - isolation point: reported by the transcript check already
        return ""
    return documents.detect_language(" ".join(c.text for c in cues[:400]))


def _print_documents(rows: list[dict]) -> None:
    """Documents: what is used, and how many were left out for which reason."""
    if not rows:
        return
    used = [r for r in rows if r["include"] == "yes"]
    print(f"Documents used ({len(used)} of {len(rows)}):")
    for r in used[:80]:
        print(f"  {r['kind']:9} {r['lang'] or '-':7} {str(r['words']):>6} words  {r['source_file'][:70]}"
              + (f"  ({r['check']})" if r["check"] else ""))
    if len(used) > 80:
        print(f"  ... and {len(used) - 80} more (see manifest.csv)")
    reasons: dict[str, int] = {}
    for r in rows:
        if r["include"] != "yes":
            reason = r["check"].replace("SKIP: ", "")
            reason = "duplicate" if reason.startswith("duplicate") else re.sub(r"\s*\(.*?\)", "", reason).strip(" ;")
            reason = reason or "excluded by you"
            reasons[reason] = reasons.get(reason, 0) + 1
    if reasons:
        print("Left out:")
        for reason, n in sorted(reasons.items(), key=lambda x: -x[1]):
            print(f"  {n:4}  {reason}")
    print()


def _print_summary(rows: list[dict]) -> None:
    """One line per row, so you can see the result without opening the CSV."""
    print(f"\n{'include':7}  {'type':5}  {'id':>4}  {'title':40}  {'min':>5}  {'transcript':10}  check")
    for r in sorted(rows, key=lambda r: (r.get("media_type") != "video", r.get("media_type", ""), r["title"].lower())):
        transcript = Path(r["transcript_file"]).suffix if r["transcript_file"] else "-"
        print(f"{r['include']:7}  {r.get('media_type', ''):5}  {r.get('catalog_id', ''):>4}  "
              f"{r['title'][:40]:40}  {str(r['video_min'] or '-'):>5}  {transcript:10}  {r['check'] or 'OK'}")
    print()


if __name__ == "__main__":
    sys.exit(main())
