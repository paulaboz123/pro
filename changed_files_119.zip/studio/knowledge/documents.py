"""
documents.py - everything in data/input that is not a recording or a transcript: Word,
PowerPoint, PDF, Excel, HTML (also interactive quizzes), JSON, XML, text, images. Each file is
read, its language detected, and kept only if it carries information for learning. Kept files
become part of the knowledge base like the recordings: every request (ask.py, course.py ...)
searches them too.

Called by inventory.py (scan + filter, one manifest row per file) and pipeline.py (ingest).
  uv run -m studio documents                 # what was found and why each file is kept or left out
  uv run -m studio documents --ai-triage     # also let the chat model judge the files that passed the
                                      # rules (useful? one-line summary); ~0.2 cents per file
  uv run -m studio documents --render-html   # also click through interactive HTML quizzes in a
                                      # hidden browser (needs: uv add playwright, then
                                      # uv run playwright install chromium)

What is read from each type:
  .docx .pptx .pdf     paragraphs and tables / slide texts and speaker notes / page texts
  .xlsx .xlsm .csv     every sheet, row by row as "column: value" (the description file is skipped)
  .html .htm           all text, also hidden parts (interactive quizzes keep the next questions
                       hidden in the page), answer options, and question data inside scripts
  .json .xml .js       natural-language texts with their field names; quiz structures
                       (question / options / correct answer) are recognised and kept together
  .txt .md .rtf        the text
  .png .jpg .gif ...   text on the image (OCR); logos, icons and pictures without text are left out
                       (with --vision in pipeline.py, diagrams are also described by the model)

Filter rules (the reason is written to the 'check' column of manifest.csv):
  system and helper files, code libraries, fonts, styles     -> left out
  icons, logos, small images, images without text            -> left out
  less than MIN_WORDS words of text, or mostly code/numbers  -> left out
  language not in KNOWLEDGE_LANGS (default: en)              -> left out (e.g. German)
  the same content as another file                           -> left out
You can override any decision: set include=yes/no in manifest.csv; your choice is kept.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import html
import io
import json
import logging
import re
import sys
import zipfile
from dataclasses import dataclass, field
from html.parser import HTMLParser
from pathlib import Path
from typing import Any
from xml.etree import ElementTree

from studio.core import config, llm, store

log = logging.getLogger("documents")

DOC_EXT = {".docx", ".pptx", ".pdf", ".xlsx", ".xlsm", ".csv", ".txt", ".md", ".rtf",
           ".html", ".htm", ".xhtml", ".json", ".xml", ".js", ".svg"}
IMAGE_EXT = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".tif", ".tiff"}
SKIP_EXT = {".css", ".scss", ".less", ".map", ".woff", ".woff2", ".ttf", ".otf", ".eot", ".ico",
            ".exe", ".dll", ".bin", ".lnk", ".url", ".ini", ".db", ".tmp", ".bak", ".log", ".swf",
            ".pyc", ".lock", ".zip", ".7z", ".rar"}
JUNK_NAMES = re.compile(r"^(\.ds_store|thumbs\.db|desktop\.ini|~\$.*|\._.*)$", re.I)
JUNK_DIRS = {"__macosx", "node_modules", ".git", ".svn", "__pycache__", ".idea", ".vscode"}
LIBRARY = re.compile(r"(jquery|bootstrap|angular|react|vue|lodash|polyfill|vendor|modernizr|\.min\.|"
                     r"fontawesome|font-awesome|swiper|slick|popper|d3\.|chart\.js|three\.)", re.I)
DECORATIVE = re.compile(r"(icon|logo|favicon|sprite|arrow|button|btn|bullet|bg|background|spacer|"
                        r"banner|avatar|thumb|placeholder|loader|spinner|check(mark)?|close|cross)", re.I)
MIN_WORDS = 40            # less text than this is not worth a lesson
MIN_IMAGE_SIDE = 300      # px; smaller images are icons, bullets, buttons
MIN_IMAGE_WORDS = 15      # an image needs at least this much text (OCR) to count as content
CHUNK_WORDS = 180         # words per knowledge-base segment
QUESTION_KEYS = re.compile(r"^(question|questiontext|frage|prompt|stem|title|text|q)$", re.I)
OPTION_KEYS = re.compile(r"^(answers?|options?|choices?|antworten|alternatives|distractors|items)$", re.I)
CORRECT_KEYS = re.compile(r"^(correct|correctanswer|correct_answer|iscorrect|is_correct|right|richtig|"
                          r"solution|answer_key|key)$", re.I)

STOPWORDS = {
    "en": "the and to of a in is that for it you with on as are this be or by not your can if will "
          "from have at an they we which when what how there their more about should do so".split(),
    "de": "der die das und ist nicht ein eine zu den von mit sich des auf für im dem auch es an "
          "werden aus er hat dass sie nach wird bei einer um am sind noch wie einem über so zum "
          "kann oder wir ihr sie".split(),
    "pl": "i w nie na z się to że do jest o jak co ale po tak za od jego czy by przez może są "
          "dla tego jako już oraz który które".split(),
    "fr": "le la les et des est un une du en que qui dans pour pas sur au avec ce il sont vous".split(),
    "es": "el la los las y de que en un una es por con para no se del al lo como más".split(),
    "it": "il la di che e un una per non sono con del della gli le si come anche".split(),
    "nl": "de het een en van is dat op te in voor niet met zijn er aan ook als bij".split(),
}
LANG_NAMES = {"en": "English", "de": "German", "pl": "Polish", "fr": "French", "es": "Spanish",
              "it": "Italian", "nl": "Dutch"}


@dataclass
class Extracted:
    """What was read from one file."""
    title: str
    kind: str                                   # document | slides | pdf | sheet | web | data | text | image
    parts: list[tuple[str, str]] = field(default_factory=list)   # (where, text)
    note: str = ""                              # e.g. "quiz: 12 questions", "scanned PDF"

    @property
    def text(self) -> str:
        """All of the document's text."""
        return "\n".join(t for _, t in self.parts)

    @property
    def words(self) -> int:
        """How many words the document has."""
        return len(self.text.split())


# --- Language and content checks ------------------------------------------------------------
def detect_language(text: str) -> str:
    """'en', 'de', 'pl' ... from common words; 'unknown' when there is too little text."""
    words = re.findall(r"[a-zäöüßąćęłńóśźżàâçéèêëîïôûùüÿñ]+", text.lower())[:3000]
    if len(words) < 8:
        return "unknown"
    scores = {lang: sum(w in sw for w in words) for lang, sw in ((k, set(v)) for k, v in STOPWORDS.items())}
    best = max(scores, key=lambda lang: scores[lang])
    if scores[best] < max(3, len(words) * 0.04):
        return "unknown"
    return best


def natural_ratio(text: str) -> float:
    """Share of tokens that are ordinary words: low for code, ids, numbers and data dumps."""
    tokens = text.split()
    if not tokens:
        return 0.0
    words = sum(bool(re.fullmatch(r"[^\W\d_]{2,}[.,:;!?)]?", t)) for t in tokens)
    return words / len(tokens)


def is_natural_text(s: str, min_words: int = 3) -> bool:
    """A string that reads like language (not an id, a URL, a colour, a CSS class or code)."""
    s = s.strip()
    if len(s.split()) < min_words or len(s) > 5000:
        return False
    if re.search(r"https?://|www\.|[{};=<>]|\\u[0-9a-f]{4}|^[\w-]+\.(png|jpg|js|css|html?)$", s, re.I):
        return natural_ratio(s) > 0.7
    return natural_ratio(s) >= 0.5


def _clean(s: str) -> str:
    return " ".join(html.unescape(str(s)).split())


# --- Structured data (JSON, XML, script data): quizzes and texts ------------------------------
TRUE = (True, 1, "true", "True", "yes")


def _options(opts: list) -> tuple[list[str], list[str]]:
    """(the options' labels, the ones marked correct) of a quiz question."""
    options, correct = [], []
    for o in opts:
        if isinstance(o, dict):
            label = next((_clean(v) for v in o.values() if isinstance(v, str) and is_natural_text(v, 1)), "")
            right = any(CORRECT_KEYS.match(str(k)) and v in TRUE for k, v in o.items())
        else:
            label, right = _clean(o), False
        if label:
            options.append(label)
            if right:
                correct.append(label)
    return options, correct


def _correct_beside(keys: dict, options: list[str]) -> list[str]:
    """The correct answer given next to the options: an index, a text or a list of either."""
    correct: list[str] = []
    for k, v in keys.items():
        if not CORRECT_KEYS.match(k) or correct:
            continue
        if isinstance(v, int) and not isinstance(v, bool) and 0 <= v < len(options):
            correct.append(options[v])
        elif isinstance(v, str) and v.strip():
            correct.append(_clean(v))
        elif isinstance(v, list):
            correct += [options[i] if isinstance(i, int) and 0 <= i < len(options) else _clean(i) for i in v]
    return correct


def _quiz_text(obj: dict) -> str | None:
    """'Question: ... / Options: ... / Correct: ...' when a dict looks like a quiz question."""
    keys = {k: v for k, v in obj.items() if isinstance(k, str)}
    q = next((v for k, v in keys.items() if QUESTION_KEYS.match(k) and isinstance(v, str) and is_natural_text(v, 2)), None)
    opts = next((v for k, v in keys.items() if OPTION_KEYS.match(k) and isinstance(v, list) and len(v) >= 2), None)
    if not q or not opts:
        return None
    options, correct = _options(opts)
    correct = correct or _correct_beside(keys, options)
    lines = [f"Question: {_clean(q)}", "Options: " + " | ".join(options)]
    if correct:
        lines.append("Correct: " + " | ".join(correct))
    feedback = [_clean(v) for k, v in keys.items() if re.search(r"feedback|explanation|erkl", k, re.I)
                and isinstance(v, str) and is_natural_text(v)]
    if feedback:
        lines.append("Explanation: " + " ".join(feedback))
    return "\n".join(lines)


def walk_data(obj: object, path: str = "", out: list | None = None, quiz: list | None = None) -> tuple[list[str], int]:
    """Natural-language strings of a JSON-like structure, with their field names; quiz questions
    as whole blocks. Returns (lines, number of quiz questions)."""
    out = [] if out is None else out
    quiz = [] if quiz is None else quiz
    if isinstance(obj, dict):
        q = _quiz_text(obj)
        if q:
            out.append(q)
            quiz.append(1)
            return out, len(quiz)
        for k, v in obj.items():
            walk_data(v, f"{path}.{k}" if path else str(k), out, quiz)
    elif isinstance(obj, list):
        for v in obj:
            walk_data(v, path, out, quiz)
    elif isinstance(obj, str):
        s = _clean(re.sub(r"<[^>]+>", " ", obj))   # texts in data often carry HTML
        if is_natural_text(s):
            name = path.rsplit(".", 1)[-1]
            out.append(f"{name}: {s}" if name and not name.isdigit() and len(name) < 30 else s)
    return out, len(quiz)


def _xml_to_data(el: ElementTree.Element) -> object:
    """An XML element as nested dicts/lists, tag names without namespaces (so quiz detection
    and field names work the same as for JSON)."""
    tag = el.tag.split("}")[-1] if isinstance(el.tag, str) else ""
    children = list(el)
    text = _clean(el.text or "")
    if not children:
        return text
    groups: dict[str, list] = {}
    for c in children:
        groups.setdefault(c.tag.split("}")[-1] if isinstance(c.tag, str) else "", []).append(_xml_to_data(c))
    data = {k: (v if len(v) > 1 or OPTION_KEYS.match(k) else v[0]) for k, v in groups.items()}
    for k, v in el.attrib.items():
        data[k.split("}")[-1]] = v
    if text:
        data[tag or "text"] = text
    return data


def script_data(script: str) -> tuple[list[str], int]:
    """Texts and quizzes inside JavaScript: JSON objects/arrays first, then plain string literals."""
    lines, n_quiz = [], 0
    decoder = json.JSONDecoder()
    covered = -1   # end of the last object read: don't read its inner parts again
    for m in re.finditer(r"[=(:,]\s*([\[{])", script):
        if m.start(1) < covered:
            continue
        try:
            obj, length = decoder.raw_decode(script[m.start(1):])
        except ValueError:
            continue
        covered = m.start(1) + length
        found, q = walk_data(obj)
        lines += found
        n_quiz += q
    if not lines:   # not JSON: take the string literals that read like language
        for m in re.finditer(r"([\"'`])((?:\\.|(?!\1).){12,}?)\1", script):
            s = _clean(m.group(2).encode().decode("unicode_escape", errors="ignore")
                       if "\\u" in m.group(2) else m.group(2))
            s = _clean(re.sub(r"<[^>]+>", " ", s))
            if is_natural_text(s, 4):
                lines.append(s)
    return list(dict.fromkeys(lines)), n_quiz


# --- HTML -------------------------------------------------------------------------------------
class _HTMLText(HTMLParser):
    """All text of a page, hidden parts included, with line breaks at blocks and answer options
    marked; scripts and inline JSON collected separately."""
    BLOCK = {"p", "div", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6", "section", "article", "br",
             "label", "legend", "fieldset", "td", "th", "option", "dt", "dd", "blockquote", "button"}

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.lines: list[str] = [""]
        self.scripts: list[str] = []
        self.script_src: list[str] = []
        self.title = ""
        self._skip = 0
        self._in = ""

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        a = {k: v or "" for k, v in attrs}   # an attribute without a value: ""
        if tag in ("script", "style", "noscript", "svg"):
            self._skip += 1
            self._in = tag
            if tag == "script" and a.get("src"):
                self.script_src.append(a["src"])
            return
        if tag in self.BLOCK:
            self.lines.append("")
        if tag == "input" and a.get("type") in ("radio", "checkbox"):
            self.lines.append("( ) " + _clean(a.get("value", "")) if a.get("value") and
                              not a.get("value", "").isdigit() else "( ) ")
        if tag in ("title", "h1"):
            self._in = tag
        for key in ("alt", "title", "aria-label", "placeholder"):   # text in attributes
            if a.get(key) and is_natural_text(a[key], 3):
                self.lines.append(_clean(a[key]))

    def handle_endtag(self, tag: str) -> None:
        if tag in ("script", "style", "noscript", "svg"):
            self._skip = max(0, self._skip - 1)
            return
        if tag in self.BLOCK:
            self.lines.append("")

    def handle_data(self, data: str) -> None:
        if self._skip:
            if self._in == "script" and data.strip():
                self.scripts.append(data)
            return
        text = _clean(data)
        if not text:
            return
        if self._in in ("title", "h1") and not self.title:
            self.title = text
        self.lines[-1] = (self.lines[-1] + " " + text).strip()


def read_html(path: Path, render: bool = False) -> Extracted:
    """The text of an HTML file (scripts' quiz data included; `render`: click through it in a browser)."""
    raw = _read_text_file(path)
    p = _HTMLText()
    p.feed(raw)
    lines = [x for x in (" ".join(line.split()) for line in p.lines) if x and x != "( )"]
    data_lines, n_quiz = [], 0
    for s in p.scripts:
        found, q = script_data(s)
        data_lines += found
        n_quiz += q
    for src in p.script_src:   # local scripts next to the page (quiz content often lives there)
        f = (path.parent / src.split("?")[0]).resolve()
        if f.is_file() and f.suffix.lower() == ".js" and not LIBRARY.search(f.name) and f.stat().st_size < 3_000_000:
            found, q = script_data(_read_text_file(f))
            data_lines += found
            n_quiz += q
    parts = [("page", "\n".join(_dedupe(lines)))] if lines else []
    if data_lines:
        parts.append(("page data", "\n".join(_dedupe(data_lines))))
    note = []
    if n_quiz:
        note.append(f"quiz: {n_quiz} questions")
    if render:
        steps = render_clickthrough(path)
        if steps:
            parts.append(("clicked through", "\n".join(_dedupe(steps))))
            note.append(f"clicked through: {len(steps)} new texts")
    radios = raw.lower().count('type="radio"') + raw.lower().count("type='radio'")
    if radios and not n_quiz:
        note.append("interactive form/quiz")
    return Extracted(p.title or _title_from_name(path), "web", parts, "; ".join(note))


NEXT_WORDS = re.compile(r"^\s*(next|continue|weiter|submit|check|start|begin|ok|go|nächste|prüfen|"
                        r"absenden|dalej|→|>|»|›)\s*[>»›→]?\s*$", re.I)


def render_clickthrough(path: Path, max_steps: int = 80) -> list[str]:
    """Open the page in a hidden browser and click 'Next'-like buttons (picking the first option
    when a question needs an answer), collecting every new text. For quizzes that build their
    questions only while you click. Needs playwright; returns [] if it is not installed."""
    try:
        from playwright.sync_api import Error as PlaywrightError
        from playwright.sync_api import sync_playwright
    except ImportError:
        log.warning("--render-html needs playwright: uv add playwright; uv run playwright install chromium")
        return []
    seen: set[str] = set()
    new: list[str] = []

    def collect(page: Any) -> int:
        added = 0
        for line in page.inner_text("body").splitlines():
            line = " ".join(line.split())
            if line and line not in seen:
                seen.add(line)
                new.append(line)
                added += 1
        return added

    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        page = browser.new_page()
        page.goto(path.resolve().as_uri())
        page.wait_for_timeout(800)
        collect(page)
        idle = 0
        for _ in range(max_steps):
            for opt in page.query_selector_all("input[type=radio], input[type=checkbox]")[:1]:
                try:
                    if opt.is_visible():
                        opt.click(timeout=500)
                except PlaywrightError:   # the element may be detached meanwhile
                    pass
            button = next((b for b in page.query_selector_all("button, a, input[type=button], input[type=submit], "
                                                              "[role=button]")
                           if b.is_visible() and NEXT_WORDS.match((b.inner_text() or b.get_attribute("value") or ""))),
                          None)
            if button is None:
                break
            try:
                button.click(timeout=1000)
            except PlaywrightError:
                break
            page.wait_for_timeout(400)
            idle = 0 if collect(page) else idle + 1
            if idle >= 2:
                break
        browser.close()
    return new


# --- Office, PDF, sheets, text, images ---------------------------------------------------------
def _read_text_file(path: Path) -> str:
    raw = path.read_bytes()
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="ignore")


def _title_from_name(path: Path) -> str:
    return re.sub(r"[_\-]+", " ", path.stem).strip() or path.name


def _dedupe(lines: list[str]) -> list[str]:
    return list(dict.fromkeys(line for line in lines if line.strip()))


def read_docx(path: Path) -> Extracted:
    """The text of a Word file, section by section (its headings)."""
    from docx import Document
    doc = Document(str(path))
    parts: list[tuple[str, str]] = []
    cur_head = "start"
    cur: list[str] = []
    for para in doc.paragraphs:
        text = _clean(para.text)
        if not text:
            continue
        if para.style is not None and para.style.name.lower().startswith(("heading", "title")):
            if cur:
                parts.append((cur_head, "\n".join(cur)))
            cur_head, cur = text[:60], [text]
        else:
            cur.append(text)
    if cur:
        parts.append((cur_head, "\n".join(cur)))
    for n, table in enumerate(doc.tables, 1):
        rows = [[_clean(c.text) for c in r.cells] for r in table.rows]
        if len(rows) >= 2:
            head = rows[0]
            lines = ["; ".join(f"{h}: {v}" if h else v for h, v in zip(head, r, strict=False) if v) for r in rows[1:]]
            parts.append((f"table {n}", "\n".join(x for x in lines if x)))
    title = _clean(doc.core_properties.title or "") or _title_from_name(path)
    return Extracted(title, "document", parts)


def _zip_texts(z: zipfile.ZipFile, name: str) -> list[str]:
    """Paragraphs of an Office XML part (text runs joined per paragraph)."""
    root = ElementTree.fromstring(z.read(name))
    out = []
    for para in root.iter():
        if para.tag.endswith("}p"):
            text = "".join(t.text or "" for t in para.iter() if t.tag.endswith("}t"))
            if text.strip():
                out.append(_clean(text))
    return out


def read_pptx(path: Path) -> Extracted:
    """Slide texts and speaker notes (read from the file's XML, no extra package needed)."""
    parts = []
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        slides = sorted((n for n in names if re.fullmatch(r"ppt/slides/slide\d+\.xml", n)),
                        key=lambda n: int(re.sub(r"\D", "", n.rsplit("/", 1)[-1])))
        for n, name in enumerate(slides, 1):
            text = _zip_texts(z, name)
            notes_name = f"ppt/notesSlides/notesSlide{name.rsplit('slide', 1)[-1]}"
            notes = [t for t in _zip_texts(z, notes_name) if not t.isdigit()] if notes_name in names else []
            body = "\n".join(text + (["Notes: " + " ".join(notes)] if notes else []))
            if body.strip():
                parts.append((f"slide {n}", body))
    first = parts[0][1].splitlines()[0] if parts else ""
    return Extracted(first[:80] or _title_from_name(path), "slides", parts)


def read_pdf(path: Path) -> Extracted:
    """The text of a PDF, page by page (a note when pypdf is missing)."""
    try:
        from pypdf import PdfReader
    except ImportError:
        return Extracted(_title_from_name(path), "pdf", [], "needs: uv add pypdf")
    reader = PdfReader(str(path))
    parts = []
    for n, page in enumerate(reader.pages, 1):
        text = "\n".join(_clean(x) for x in (page.extract_text() or "").splitlines() if x.strip())
        if text:
            parts.append((f"page {n}", text))
    note = "" if parts else f"scanned PDF ({len(reader.pages)} pages without text)"
    title = _clean(str(reader.metadata.title or "")) if reader.metadata else ""
    return Extracted(title or _title_from_name(path), "pdf", parts, note)


def read_sheet(path: Path) -> Extracted:
    """Every sheet, each row as 'column: value; ...' (headers from the first non-empty row)."""
    parts = []
    if path.suffix.lower() == ".csv":
        text = _read_text_file(path)
        delim = ";" if text[:2000].count(";") > text[:2000].count(",") else ","
        sheets = [("csv", list(csv.reader(io.StringIO(text), delimiter=delim)))]
    else:
        from openpyxl import load_workbook
        wb = load_workbook(path, read_only=True, data_only=True)
        sheets = [(ws.title, [list(r) for r in ws.iter_rows(values_only=True)]) for ws in wb.worksheets]
        wb.close()
    for name, rows in sheets:
        rows = [["" if c is None else _clean(c) for c in r] for r in rows]
        rows = [r for r in rows if any(r)]
        if not rows:
            continue
        head, lines = rows[0], []
        for r in rows[1:2001]:
            cells = [f"{h}: {v}" if h and h != v else v for h, v in zip(head + [""] * len(r), r, strict=False) if v]
            if cells:
                lines.append("; ".join(cells))
        if not lines and len(head) > 1:
            lines = ["; ".join(head)]
        parts.append((f"sheet {name}", "\n".join(lines)))
    return Extracted(_title_from_name(path), "sheet", parts)


def read_data(path: Path) -> Extracted:
    """JSON, XML, JavaScript and SVG: natural-language texts and quiz questions."""
    ext = path.suffix.lower()
    raw = _read_text_file(path)
    n_quiz = 0
    if ext == ".json":
        try:
            lines, n_quiz = walk_data(json.loads(raw))
        except ValueError:
            lines, n_quiz = script_data(raw)
    elif ext in (".xml", ".svg"):
        try:
            lines, n_quiz = walk_data(_xml_to_data(ElementTree.fromstring(raw.encode("utf-8"))))
        except ElementTree.ParseError:
            lines = [x for x in (_clean(t) for t in re.split(r"<[^>]+>", raw)) if is_natural_text(x)]
    else:   # .js
        lines, n_quiz = script_data(raw)
    lines = _dedupe(lines)
    note = f"quiz: {n_quiz} questions" if n_quiz else ""
    return Extracted(_title_from_name(path), "data", [("data", "\n".join(lines))] if lines else [], note)


def read_text(path: Path) -> Extracted:
    """The text of a plain text, Markdown or RTF file."""
    raw = _read_text_file(path)
    if path.suffix.lower() == ".rtf":   # rough: drop control words and groups
        raw = re.sub(r"\\[a-z]+-?\d* ?|[{}]", " ", raw)
    paras = [_clean(p) for p in re.split(r"\n\s*\n", raw) if p.strip()]
    title = next((p.lstrip("# ") for p in paras if p.startswith("#")), "") or _title_from_name(path)
    return Extracted(title[:80], "text", [("text", "\n".join(paras))] if paras else [])


def image_info(path: Path) -> tuple[int, int]:
    """An image's width and height."""
    from PIL import Image
    with Image.open(path) as im:
        return im.size


def read_image(path: Path) -> Extracted:
    """Text on the image (OCR). Decorative images (icons, logos, small) are not read at all."""
    from PIL import Image

    from studio.video import media
    try:
        w, h = image_info(path)
    except (OSError, ValueError, Image.DecompressionBombError) as e:   # broken or unsupported image
        return Extracted(_title_from_name(path), "image", [], f"unreadable image: {e}")
    note = f"{w}x{h}px"
    if max(w, h) < MIN_IMAGE_SIDE or w * h < 120_000 or DECORATIVE.search(path.stem):
        return Extracted(_title_from_name(path), "image", [], note + ", decorative")
    try:
        text = media.ocr(path)
    except (media.MediaError, OSError) as e:   # OCR missing or failed: keep the file for --vision
        return Extracted(_title_from_name(path), "image", [], f"{note}, OCR failed: {e}")
    return Extracted(_title_from_name(path), "image", [("image", text)] if text else [], note)


READERS = {".docx": read_docx, ".pptx": read_pptx, ".pdf": read_pdf, ".xlsx": read_sheet, ".xlsm": read_sheet,
           ".csv": read_sheet, ".txt": read_text, ".md": read_text, ".rtf": read_text, ".json": read_data,
           ".xml": read_data, ".js": read_data, ".svg": read_data}


def extract(path: Path, render_html: bool = False) -> Extracted:
    """The text of any supported file, by its type."""
    ext = path.suffix.lower()
    if ext in (".html", ".htm", ".xhtml"):
        return read_html(path, render_html)
    if ext in IMAGE_EXT:
        return read_image(path)
    return READERS[ext](path)


# --- Which files, and the filter -------------------------------------------------------------
def is_transcript_docx(path: Path) -> bool:
    """A .docx is a Teams transcript only if it has timed cues; otherwise it is a document."""
    from studio.knowledge import ingest
    try:
        return len(ingest.parse_docx(path)) >= 3
    except Exception:   # noqa: BLE001 - isolation point: unreadable: let the document reader report it
        return False


def candidate_files(skip: set[Path]) -> list[Path]:
    """Every file under data/input that is not a recording, transcript or the description file (nor a file of an
    e-learning package: scorm.py reads those as one course)."""
    from studio.knowledge import scorm
    out = []
    for p in sorted(config.INPUT_DIR.rglob("*")):
        if not p.is_file() or p in skip or scorm.inside_package(p):
            continue
        rel_parts = {x.lower() for x in p.relative_to(config.INPUT_DIR).parts[:-1]}
        if rel_parts & JUNK_DIRS:
            continue
        if p.suffix.lower() in config.MEDIA_EXT or p.suffix.lower() == ".vtt":
            continue
        out.append(p)
    return out


def rule_check(path: Path, ex: Extracted | None, seen_hashes: dict[str, str]) -> tuple[bool, str, str, int]:
    """(keep?, reason, language, words) by the filter rules."""
    ext = path.suffix.lower()
    if JUNK_NAMES.match(path.name):
        return False, "system file", "", 0
    if ext in SKIP_EXT:
        return False, f"not content ({ext} file)", "", 0
    if ext not in DOC_EXT and ext not in IMAGE_EXT:
        return False, f"unknown file type {ext or '(none)'}", "", 0
    if ext == ".js" and LIBRARY.search(path.name):
        return False, "code library", "", 0
    if ex is None:
        return False, "could not be read", "", 0
    text, words = ex.text, ex.words
    lang = detect_language(text)
    if ex.kind == "image":
        if "decorative" in ex.note:
            return False, f"icon/logo/decoration ({ex.note.split(',')[0]})", lang, words
        if words < MIN_IMAGE_WORDS:
            return False, "image without text (use pipeline.py --vision to describe diagrams)", lang, words
    if words < (MIN_IMAGE_WORDS if ex.kind == "image" else MIN_WORDS):
        return False, f"too little text ({words} words)" + (f"; {ex.note}" if ex.note else ""), lang, words
    if natural_ratio(text) < 0.45 and "quiz" not in ex.note:
        return False, "mostly code, numbers or ids", lang, words
    from studio.core import safety
    hidden = safety.injection(text)
    if hidden:
        return False, f"contains instructions aimed at an AI ('{hidden[:40]}') - check the file", lang, words
    if lang not in config.KNOWLEDGE_LANGS and lang != "unknown":
        return False, f"language: {LANG_NAMES.get(lang, lang)}", lang, words
    digest = hashlib.sha1(" ".join(text.lower().split()).encode(), usedforsecurity=False).hexdigest()
    if digest in seen_hashes:
        return False, f"duplicate of {seen_hashes[digest]}", lang, words
    seen_hashes[digest] = path.relative_to(config.INPUT_DIR).as_posix()
    return True, ex.note, lang, words


TRIAGE_SCHEMA = {
    "type": "object",
    "properties": {
        "useful": {"type": "boolean", "description": "true if it carries knowledge an employee could learn from"},
        "category": {"type": "string", "enum": ["course content", "quiz or exercise", "reference", "template",
                                                "admin or organisational", "marketing", "other"]},
        "summary": {"type": "string", "description": "one sentence: what it is about"},
    },
    "required": ["useful", "category", "summary"],
}


def ai_triage(title: str, path: str, text: str) -> dict:
    """The chat model's judgement of one file that passed the rules."""
    from studio.core import llm
    words = text.split()
    prompt = (f"File: {path}\nTitle: {title}\nLength: {len(words)} words\n\nBeginning:\n" + " ".join(words[:450]))
    return llm.chat_json(prompt, TRIAGE_SCHEMA, step="triage", max_tokens=300, temperature=0.0,
                         system="You sort files of an internal training folder for a learning assistant. Is this "
                                "file worth learning from (course content, quizzes, reference material), or is it "
                                "noise (templates, admin, navigation, marketing, empty)? Answer in English.")


# --- Cache of the extraction (inventory reads once, ingest reuses it) --------------------------
def _doc_id(rel: str, title: str) -> str:
    return store.stable_id(rel, title)


def _cache_path(doc_id: str) -> Path:
    return store.video_dir(doc_id) / "extracted.json"


def _fingerprint(path: Path, render: bool) -> str:
    st = path.stat()
    return f"{st.st_size}-{int(st.st_mtime)}-{int(render)}-{MIN_WORDS}"


def read_cached(path: Path, doc_id: str, render: bool) -> Extracted | None:
    """A document read before, if it did not change since (fingerprint), else None."""
    cached = store.read_json(_cache_path(doc_id))
    if cached and cached.get("fingerprint") == _fingerprint(path, render):
        return Extracted(cached["title"], cached["kind"], [tuple(p) for p in cached["parts"]], cached["note"])
    return None


def write_cache(path: Path, doc_id: str, ex: Extracted, render: bool) -> None:
    """Keep what was read from a document, with its fingerprint."""
    store.write_json(_cache_path(doc_id), {"fingerprint": _fingerprint(path, render), "title": ex.title,
                                           "kind": ex.kind, "parts": ex.parts, "note": ex.note})


# --- Manifest rows (called by inventory.py) ------------------------------------------------------
VISION_PROMPT = """Is this image informative for learning (a diagram, chart, process, table, or a
screenshot with content) or decorative (logo, icon, photo, background)? Answer on the first line
INFORMATIVE or DECORATIVE. If informative, then describe what it shows and every label, step
and relation in it, in English, as plain text (at most 200 words)."""


def describe_image(path: Path) -> str:
    """The vision model's description of an informative image ('' for decorative ones)."""
    from studio.core import llm
    answer = llm.describe_image(path, VISION_PROMPT, step="document_image")
    first, _, rest = answer.strip().partition("\n")
    return rest.strip() if "INFORMATIVE" in first.upper() else ""


def _read(path: Path, rel: str, doc_id: str, render_html: bool) -> Extracted | None:
    """The file's text (from the cache when it is current), or None for a file that is not a document or breaks."""
    if path.suffix.lower() not in DOC_EXT | IMAGE_EXT or JUNK_NAMES.match(path.name):
        return None
    try:
        return read_cached(path, doc_id, render_html) or extract(path, render_html)
    except Exception as e:   # noqa: BLE001 - isolation point: one broken file must not stop the scan
        log.warning("%s: %s", rel, e)
        return None


def _described(path: Path, rel: str, ex: Extracted, decision: tuple[bool, str, str, int]) -> tuple[bool, str, str, int]:
    """An image without text described by the vision model; decorative when it says nothing."""
    try:
        described = describe_image(path)
    except (llm.LLMError, OSError) as e:   # spending lock or gateway: keep the rule decision
        log.warning("Describing %s skipped: %s", rel, e)
        described = ""
    if not described:
        return decision[0], "image without information (vision model: decorative)", decision[2], decision[3]
    ex.parts = [("image", "\n".join(t for _, t in ex.parts) + "\n" + described)]
    ex.note += ", described by the vision model"
    return True, ex.note, "en", ex.words


def _triaged(ex: Extracted, rel: str, keep: bool, reason: str, summary: str) -> tuple[bool, str, str]:
    """Claude's verdict on a kept document: (useful, reason with its category, a summary)."""
    try:
        verdict = ai_triage(ex.title, rel, ex.text)
    except (llm.LLMError, OSError, ValueError) as e:   # the spending lock or the gateway: keep the rule decision
        log.warning("AI triage skipped for %s: %s", rel, e)
        return keep, reason, summary
    keep = bool(verdict.get("useful"))
    reason = "; ".join(x for x in [reason, f"AI: {verdict.get('category', '')}" + ("" if keep else " - not useful")] if x)
    return keep, reason, verdict.get("summary", "")


def _decide(path: Path, rel: str, doc_id: str, seen: dict[str, str], vision: bool,
            render_html: bool) -> tuple[Extracted | None, tuple[bool, str, str, int]]:
    """The file's text and the rules' decision: (keep, reason, language, words)."""
    ex = _read(path, rel, doc_id, render_html)
    decision = rule_check(path, ex, seen)
    if vision and ex is not None and ex.kind == "image" and decision[1].startswith("image without text"):
        decision = _described(path, rel, ex, decision)
    return ex, decision


def _row(path: Path, rel: str, doc_id: str, old: dict, ex: Extracted | None, decision: tuple[bool, str, str, int],
         summary: str, ai: bool) -> dict:
    """A document's manifest row; what the person set before (include, catalog id, title) is kept."""
    keep, reason, lang, words = decision
    check = f"you included it, but: {reason}" if old.get("include") == "yes" and not keep else \
        ("" if keep else "SKIP: ") + reason
    return {"video_id": doc_id, "include": old["include"] if old else ("yes" if keep else "no"),
            "catalog_id": old.get("catalog_id", ""),
            "title": old.get("title") or (ex.title if ex else _title_from_name(path)),
            "description": summary, "media_type": "document", "video_file": "", "transcript_file": "",
            "source_file": rel, "kind": ex.kind if ex else path.suffix.lower().lstrip("."),
            "lang": lang, "words": words, "pair_method": "", "video_min": "", "transcript_min": "",
            "crop": "", "check": check, "ai": old.get("ai", "") or ("yes" if ai and keep else "")}


def inventory_rows(existing: dict[str, dict], skip: set[Path], *, ai: bool = False,
                   render_html: bool = False, vision: bool = False) -> list[dict]:
    """One manifest row per file. Your include=yes/no from an earlier run is kept; the check
    column always shows the current reason."""
    rows: list[dict] = []
    seen: dict[str, str] = {}
    files = candidate_files(skip)
    referenced_js = _scripts_used_by_pages(files)
    for path in files:
        rel = path.relative_to(config.INPUT_DIR).as_posix()
        old = existing.get("s:" + rel) or {}
        doc_id = old["video_id"] if old else _doc_id(rel, _title_from_name(path))
        if path in referenced_js:
            ex, (keep, reason, lang, words) = None, (False, "script of a page (read with that page)", "", 0)
        else:
            ex, (keep, reason, lang, words) = _decide(path, rel, doc_id, seen, vision, render_html)
        summary = old.get("description", "")
        if keep and ai and ex is not None and not old.get("ai"):
            keep, reason, summary = _triaged(ex, rel, keep, reason, summary)
        if ex is not None and keep:
            write_cache(path, doc_id, ex, render_html)
        rows.append(_row(path, rel, doc_id, old, ex, (keep, reason, lang, words), summary, ai))
    kept = sum(r["include"] == "yes" for r in rows)
    log.info("Documents: %s files, %s used, %s left out", len(rows), kept, len(rows) - kept)
    return rows


def _scripts_used_by_pages(files: list[Path]) -> set[Path]:
    """.js files that an HTML page in the folder loads (their content is read with the page)."""
    used = set()
    for p in files:
        if p.suffix.lower() in (".html", ".htm", ".xhtml"):
            for src in re.findall(r"<script[^>]+src=[\"']([^\"'?#]+)", _read_text_file(p), re.I):
                used.add((p.parent / src).resolve())
    return {f for f in files if f.resolve() in used}


# --- Ingest (called by pipeline.py) ------------------------------------------------------------
def chunk(parts: list[tuple[str, str]], size: int = CHUNK_WORDS) -> list[tuple[str, str]]:
    """Parts split into pieces of about `size` words, at line ends; quiz questions stay whole."""
    out = []
    for where, text in parts:
        cur: list[str] = []
        n, k = 0, 1
        blocks = re.split(r"\n(?=Question: )", text) if "Question: " in text else text.splitlines()
        for block in blocks:
            w = len(block.split())
            if cur and n + w > size:
                out.append((where if k == 1 else f"{where} ({k})", "\n".join(cur)))
                cur, n, k = [], 0, k + 1
            cur.append(block)
            n += w
        if cur:
            out.append((where if k == 1 else f"{where} ({k})", "\n".join(cur)))
    return out


def ingest_row(row: dict, force: bool = False) -> str:
    """Segments + meta.json for one document row (the same files recordings get, so search,
    lessons, videos and courses use documents without any change)."""
    vid = row["video_id"]
    if store.has_segments(vid) and not force:
        return "skipped"
    path = config.INPUT_DIR / row["source_file"]
    if not path.exists():
        raise FileNotFoundError(f"Document not found: {path}")
    ex = read_cached(path, vid, False) or read_cached(path, vid, True) or extract(path)
    pieces = chunk(ex.parts)
    if not pieces:
        raise ValueError(f"No text in {path.name}")
    segments = [{"id": f"{vid}#{i:04d}", "video_id": vid, "idx": i,
                 # position as pseudo-time (1 minute per piece): course outlines use time ranges
                 "start": float(i * 60), "end": float(i * 60 + 60), "where": where,
                 "speakers": [], "text": text, "words": len(text.split()), "slide_ids": []}
                for i, (where, text) in enumerate(pieces)]
    store.save_segments(vid, segments)
    store.save_meta(vid, {"video_id": vid, "title": row.get("title") or ex.title, "kind": "document",
                          "doc_kind": ex.kind, "media_type": "document", "source_file": row["source_file"],
                          "description": row.get("description", ""), "lang": row.get("lang", ""),
                          "n_segments": len(segments), "speakers": [], "note": ex.note})
    log.info("%s: %s pieces (%s words)%s", row["source_file"], len(segments), sum(s["words"] for s in segments),
             f", {ex.note}" if ex.note else "")
    return "done"


def main() -> int:
    """Command line: list and read the documents in data/input. Returns the exit code."""
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--ai-triage", action="store_true", help="also let the chat model judge the kept files")
    ap.add_argument("--render-html", action="store_true", help="click through interactive HTML (playwright)")
    args = ap.parse_args()
    config.setup_logging()
    from studio.knowledge import inventory
    return inventory.main(ai_triage=args.ai_triage, render_html=args.render_html)


if __name__ == "__main__":
    sys.exit(main())
