"""scorm.py: e-learning packages (as .zip, zips inside zips, or unpacked folders) become one course text (page order,
quizzes and German left out), videos with their English captions as transcripts, and pictures - and the package's
own files are not read again as separate documents."""
from __future__ import annotations

import base64
import io
import json
import zipfile

from studio.core import config, store
from studio.knowledge import inventory, scorm

MANIFEST = """<?xml version="1.0" encoding="UTF-8"?>
<manifest identifier="m1" version="1.2" xmlns="http://www.imsproject.org/xsd/imscp_rootv1p1p2"
          xmlns:adlcp="http://www.adlnet.org/xsd/adlcp_rootv1p2">
  <metadata><schema>ADL SCORM</schema><schemaversion>1.2</schemaversion></metadata>
  <organizations default="o1"><organization identifier="o1"><title>{title}</title>
    <item identifier="i1" identifierref="r1"><title>{title}</title></item></organization></organizations>
  <resources><resource identifier="r1" type="webcontent" adlcp:scormtype="sco" href="index.html"/></resources>
</manifest>"""
EN = ["Sprint planning is the meeting where the whole team agrees on what to deliver in the coming sprint.",
      "The product owner brings the ordered backlog and explains why each item matters to the customers.",
      "The developers decide how much work fits, because they are the people who will actually do it."]
DE = "Die Sprintplanung ist das Meeting, in dem das ganze Team festlegt, was im nächsten Sprint geliefert wird und wie."
QUIZ = "Who decides how much work fits into the sprint during the planning meeting?"
VIDEO = b"\x00\x00\x00\x18ftypmp42" + b"\x00" * (1024 * 1024 + 10)   # over 1 MB: a real video, not a click
CLICK = b"ID3" + b"\x00" * 200_000
VTT_EN = "WEBVTT\n\n00:00:01.000 --> 00:00:04.000\nWelcome to the sprint planning video of this course.\n"
SRT_DE = "1\n00:00:01,000 --> 00:00:04,000\nWillkommen zum Video über die Sprintplanung in diesem Kurs.\n"


def _zip(files: dict[str, bytes | str]) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for name, data in files.items():
            z.writestr(name, data)
    return buf.getvalue()


def _picture() -> bytes:
    from PIL import Image
    buf = io.BytesIO()
    Image.effect_noise((400, 300), 60).convert("RGB").save(buf, "PNG")
    return buf.getvalue()


def _course_json() -> dict:
    return {"course": {"id": "c1", "title": "Agile basics", "modules": [
        {"id": "m1", "title": "Sprint planning", "theme": {"color": "#ff0000"}, "components": [
            {"type": "text", "body": f"<p>{EN[0]}</p><p>{EN[1]}</p>"},
            {"type": "text", "body": f"<p>{DE}</p>"},
            {"type": "mcq", "question": QUIZ, "answers": [{"text": "The developers", "correct": True},
                                                         {"text": "The manager"}]},
            {"type": "text", "body": EN[2], "src": "media/intro.mp4"}]},
        {"id": "m2", "title": "Knowledge check", "type": "assessment", "questions": [{"text": QUIZ}]}]}}


def _input():
    root = config.INPUT_DIR / "Scrum"
    # 1: a zip as the tool exports it: data in JSON, a player, fonts, a video with English and German captions
    (root / "1").mkdir(parents=True)
    (root / "1" / "Agile basics.zip").write_bytes(_zip({
        "imsmanifest.xml": MANIFEST.format(title="Agile basics"), "adlcp_rootv1p2.xsd": "<xs/>",
        "index.html": "<html><head><title>Course</title><script src='lib/player.bundle.js'></script></head>"
                      "<body><div id='app'></div></body></html>",
        "data/course.json": json.dumps(_course_json()),
        "lib/player.bundle.js": 'var ui={next:"Click here to go to the next page of the course"};' * 50,
        "fonts/brand.eot": b"\x00" * 100,
        "media/intro.mp4": VIDEO, "media/intro_en.vtt": VTT_EN, "media/intro_de.srt": SRT_DE,
        "media/click.mp3": CLICK, "images/diagram.png": _picture(), "images/icon.png": b"\x89PNG" + b"\x00" * 50}))
    # 2: unpacked, the whole course as base64 JSON inside a script, two videos without captions
    data = base64.b64encode(json.dumps({"lessons": [{"title": "Daily scrum", "items": [
        {"text": "The daily scrum is a short meeting where developers inspect progress toward the sprint goal."},
        {"text": "It is held at the same time and place every working day to keep things simple for everyone."},
        {"text": "The developers plan the next day together and raise anything that blocks them from the goal."}]}]})
        .encode()).decode()
    pkg = root / "2" / "Daily scrum"
    (pkg / "scormcontent").mkdir(parents=True)
    (pkg / "imsmanifest.xml").write_text(MANIFEST.format(title="Daily scrum"), encoding="utf-8")
    (pkg / "scormcontent" / "data.js").write_text(f'window.courseData = "{data}";', encoding="utf-8")
    for n in ("a", "b"):
        (pkg / "scormcontent" / f"lesson_{n}.mp4").write_bytes(VIDEO)
    # 3: a zip inside a zip
    (root / "3").mkdir()
    inner = _zip({"imsmanifest.xml": MANIFEST.format(title="Retrospective"),
                  "content.json": json.dumps({"pages": [{"heading": "Retrospective", "paragraphs": [
                      "In the retrospective the team looks back at the sprint and agrees on improvements to try next.",
                      "Everyone speaks openly about what went well and what should change in the next sprint.",
                      "The team picks one or two changes and checks at the next retrospective whether they helped."]}]})})
    (root / "3" / "Export.zip").write_bytes(_zip({"Retrospective SCORM.zip": inner, "readme.txt": "export"}))
    return root


def test_packages_become_a_course_text_videos_with_captions_and_pictures(project):
    _input()
    courses = {c.title: c for c in scorm.prepare()}
    assert set(courses) == {"Agile basics", "Daily scrum", "Retrospective"}
    out = config.INPUT_DIR / "_scorm"

    text = (out / "Agile basics" / "Agile basics.md").read_text(encoding="utf-8")
    assert text.startswith("# Agile basics") and "## Sprint planning" in text
    assert all(p in text for p in EN) and text.index(EN[0]) < text.index(EN[2])       # every part, in page order
    assert DE not in text and courses["Agile basics"].other_language == 1             # German left out
    assert QUIZ not in text and courses["Agile basics"].quizzes >= 2                 # quizzes left out
    assert "Click here" not in text and "#ff0000" not in text                          # the player and settings
    video = out / "Agile basics" / "Agile basics - 01 intro.mp4"
    assert video.read_bytes() == VIDEO
    assert (out / "Agile basics" / "Agile basics - 01 intro.vtt").read_text(encoding="utf-8") == VTT_EN   # English
    assert not list((out / "Agile basics").glob("*click*"))                           # a click sound is not a recording
    assert [p.name for p in (out / "Agile basics" / "screens").iterdir()] == ["001 diagram.png"]   # no icon

    daily = (out / "Daily scrum" / "Daily scrum.md").read_text(encoding="utf-8")
    assert "## Daily scrum" in daily and "same time and place" in daily               # base64 data in a script
    assert sorted(p.name for p in (out / "Daily scrum").glob("*.mp4")) == [
        "Daily scrum - 01 lesson a.mp4", "Daily scrum - 02 lesson b.mp4"]
    assert not list((out / "Daily scrum").glob("*.vtt"))                              # to be transcribed
    assert "looks back at the sprint" in (out / "Retrospective" / "Retrospective.md").read_text(encoding="utf-8")

    again = {c.title: c for c in scorm.prepare()}                                       # run again: the same, no doubles
    assert set(again) == set(courses) and len(list((out / "Agile basics").glob("*.mp4"))) == 1


def test_the_pipeline_reads_the_course_not_the_package_files(project):
    _input()
    assert inventory.main() == 0
    rows = store.read_manifest()
    files = {r.get("source_file") or r.get("video_file") or r.get("transcript_file") for r in rows}
    assert "_scorm/Agile basics/Agile basics.md" in files
    docs = {r["source_file"]: r for r in rows if r["media_type"] == "document"}
    assert docs["_scorm/Agile basics/Agile basics.md"]["include"] == "yes"
    assert docs["_scorm/Agile basics/Agile basics.md"]["lang"] == "en"
    videos = {r["video_file"]: r for r in rows if r["media_type"] == "video"}
    assert set(videos) == {"_scorm/Agile basics/Agile basics - 01 intro.mp4", "_scorm/Daily scrum/Daily scrum - 01 lesson a.mp4",
                           "_scorm/Daily scrum/Daily scrum - 02 lesson b.mp4"}
    assert videos["_scorm/Agile basics/Agile basics - 01 intro.mp4"]["transcript_file"] == \
        "_scorm/Agile basics/Agile basics - 01 intro.vtt"                              # the captions are its transcript
    assert not videos["_scorm/Daily scrum/Daily scrum - 01 lesson a.mp4"]["transcript_file"]
    assert not any("course.json" in f or "player" in f or "data.js" in f or "intro_en" in f or "lesson_a" in f
                   for f in files if f)                                                # the package's own files: not again
