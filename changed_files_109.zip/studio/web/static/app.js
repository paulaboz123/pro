const $ = (s, el = document) => el.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"}[c]));
const usd0 = v => "$" + Math.round(Number(v) || 0).toLocaleString("en-US");
const usd = v => v == null || v === "" ? "–" : "$" + (Number(v) < 0.1 ? Number(v).toFixed(3) : Number(v).toFixed(2));
const mmss = s => { s = Math.max(0, Math.round(s)); return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"); };
const KIND = {answer: "Answer", text: "Written lesson", document: "Written lesson", slides: "Slides to present",
              video: "Video", dialogue: "Conversation", audio: "Audio", course: "Course", "avatar video": "Video"};
// the verdict of the automatic checks as the page says it: notes for the author, not a red mark under every result
const QUALITY = {OK: "OK", CHECK: "Check", FAIL: "Needs review", PLAN: "Plan"};
const verdictTag = v => v ? `<span class="tag ${esc(v)}">${esc(QUALITY[v] || v)}</span>` : "";
const FILE_LABEL = {answer: "Answer", video: "Video", avatar_video: "Video with presenter", audio: "Audio", document: "Written lesson",
                    markdown: "Markdown", pdf: "Slides (PDF)", pptx: "PowerPoint", notes: "Speaker notes", script: "Script",
                    chapters: "Chapters"};

async function api(path, opts) {
  const r = await fetch(path, opts);
  if (r.status === 401) { location.reload(); throw new Error("Sign in first."); }
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error(data.error || ("HTTP " + r.status)), {status: r.status});
  return data;
}

// --- tabs ----------------------------------------------------------------------------------------
document.querySelectorAll("nav button").forEach(b => b.addEventListener("click", () => {
  document.querySelectorAll("nav button").forEach(x => x.setAttribute("aria-selected", String(x === b)));
  $("#tab-ask").hidden = b.dataset.tab !== "ask";
  $("#tab-prices").hidden = b.dataset.tab !== "prices";
  if (b.dataset.tab === "prices") loadPrices();
}));

async function loadSpend() {
  try {
    const s = await api("/api/state");
    $("#spend").textContent = `Today ${usd(s.today)} of ${usd(s.daily)}`;
    return s;
  } catch (e) { return {}; }
}

// --- chat ------------------------------------------------------------------------------------------
const box = $("#request");
box.addEventListener("input", grow);
box.addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); $("#form").requestSubmit(); } });
function grow() { box.style.height = "auto"; box.style.height = Math.min(200, box.scrollHeight) + "px"; }

function add(html, cls) {
  $("#empty").hidden = true;
  const el = document.createElement("div");
  el.className = "msg " + cls;
  el.innerHTML = html;
  $("#messages").appendChild(el);
  $("#thread").scrollTop = $("#thread").scrollHeight;
  return el;
}

function busy(on) { $("#send").disabled = on; box.disabled = on; if (!on) box.focus(); }

$("#form").addEventListener("submit", e => {
  e.preventDefault();
  const request = box.value.trim();
  if (!request || $("#send").disabled) return;
  box.value = ""; grow();
  send(request, picked());
});

// one request: from the box, or "Make a new version" of a result from the library (the same picks + fresh)
async function send(request, picks, fresh) {
  add(`<div class="bubble">${esc(request)}</div>`, "user");
  const bot = add(`<div class="card"><div class="working"><span class="dots"><span></span><span></span><span></span></span>
                   <span class="step">Reading your request…</span><span class="timer">0:00</span></div></div>`, "bot");
  busy(true);
  try {
    const job = await api("/api/jobs", {method: "POST", headers: {"Content-Type": "application/json"},
                                        body: JSON.stringify({request, chat: chatId, ...picks, ...(fresh ? {fresh: true} : {})})});
    if (job.chat && job.chat !== chatId) { chatId = job.chat; remember(chatId); }
    loadChats();
    await follow(job.id, bot, picks);
  } catch (err) {
    $(".card", bot).innerHTML = `<div class="problem">${esc(err.message)}</div>`;
  } finally {
    busy(false);
    loadSpend();
    loadChats();
  }
}

// --- the chats: kept on the server, the list on the left reopens one -----------------------------------
let chatId = "";
const EMPTY = $("#messages").innerHTML;
const remember = id => { try { localStorage.setItem("ls_chat", id); } catch (e) {} };
const remembered = () => { try { return localStorage.getItem("ls_chat") || ""; } catch (e) { return ""; } };
const when = t => { const d = new Date(t); if (isNaN(d)) return ""; const today = new Date().toDateString() === d.toDateString();
  return today ? d.toTimeString().slice(0, 5) : d.toLocaleDateString(undefined, {day: "numeric", month: "short"}); };
const working = step => `<div class="card"><div class="working"><span class="dots"><span></span><span></span><span></span></span>
                   <span class="step">${esc(step)}</span><span class="timer">0:00</span></div></div>`;

async function loadChats() {
  let list = [];
  try { list = (await api("/api/chats")).chats || []; } catch (e) { return []; }
  $("#chats").innerHTML = list.length ? list.map(c => `<div class="chatitem${c.id === chatId ? " on" : ""}" data-id="${esc(c.id)}">` +
    `<button class="open" type="button" title="${esc(c.title)}"><span>${esc(c.title || "Chat")}</span>` +
    `<small>${esc(when(c.updated))} · ${c.count} ${c.count === 1 ? "request" : "requests"}</small></button>` +
    `<button class="del" type="button" title="Delete this chat (its results stay in Prices & results)">✕</button></div>`).join("")
    : `<p class="small pad48">No chats yet.</p>`;
  $("#chats").querySelectorAll(".chatitem").forEach(el => {
    $(".open", el).onclick = () => openChat(el.dataset.id);
    const del = $(".del", el);
    del.onclick = async () => {   // two clicks: ✕, then "Delete?"
      if (!del.classList.contains("sure")) { del.classList.add("sure"); del.textContent = "Delete?"; return; }
      await api(`/api/chats/${el.dataset.id}/delete`, {method: "POST", headers: {"Content-Type": "application/json"}, body: "{}"}).catch(() => {});
      if (el.dataset.id === chatId) newChat();
      loadChats();
    };
    del.onblur = () => { del.classList.remove("sure"); del.textContent = "✕"; };
  });
  return list;
}

function newChat() {
  chatId = ""; remember("");
  $("#messages").innerHTML = EMPTY;
  document.querySelectorAll(".chatitem").forEach(x => x.classList.remove("on"));
  $("#chatlist").classList.remove("show");
  if (!box.disabled) box.focus();
}

async function openChat(id) {
  let chat;
  try { chat = await api("/api/chats/" + encodeURIComponent(id)); } catch (e) { newChat(); return; }
  chatId = chat.id; remember(chatId);
  $("#messages").innerHTML = EMPTY;
  for (const m of chat.messages || []) {
    add(`<div class="bubble">${esc(m.request)}</div>`, "user");
    if (m.status === "running") {
      const bot = add(working("Working…"), "bot");
      follow(m.job, bot).then(() => loadChats());
    } else {
      add(`<div class="card">${m.status === "done" && m.result ? render(m.result, m.seconds || 0, m.picks) + feedbackBar(m.job, m.feedback)
        : `<div class="${m.status === "error" || m.status === "stopped" ? "problem" : "none"}">${esc(m.error || "Something went wrong.")}</div>`}</div>`, "bot");
    }
  }
  fitFrames($("#messages"));
  document.querySelectorAll(".chatitem").forEach(x => x.classList.toggle("on", x.dataset.id === chatId));
  $("#chatlist").classList.remove("show");
  $("#thread").scrollTop = $("#thread").scrollHeight;
}

// --- feedback on a result: 👍 at once, 👎 with what was wrong (kept with the chat and in feedback.csv) ----
function feedbackBar(job, given) {
  const g = given || {};
  return `<div class="fb" data-job="${esc(job)}"><span>Was this useful?</span>` +
    `<button type="button" data-r="up" class="${g.rating === "up" ? "on" : ""}" aria-label="Useful">👍</button>` +
    `<button type="button" data-r="down" class="${g.rating === "down" ? "on" : ""}" aria-label="Not useful">👎</button>` +
    `<input type="text" maxlength="1000" placeholder="What was wrong or missing? (optional)" value="${esc(g.comment || "")}" ${g.rating === "down" ? "" : "hidden"}>` +
    `<button type="button" data-r="send" hidden>Send</button><span class="fbs">${g.rating ? "Thanks, saved." : ""}</span></div>`;
}
async function sendFeedback(bar, rating) {
  const comment = $("input", bar).value;
  try {
    await api(`/api/chats/${encodeURIComponent(chatId)}/feedback`, {method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({job: bar.dataset.job, rating, comment})});
    bar.querySelectorAll("button[data-r=up], button[data-r=down]").forEach(b => b.classList.toggle("on", b.dataset.r === rating));
    const askMore = rating === "down" && !comment.trim();   // 👎 is saved at once; the comment can follow
    $(".fbs", bar).textContent = askMore ? "Saved. What was wrong? (optional)" : "Thanks, saved.";
    $("button[data-r=send]", bar).hidden = !askMore;
    $("input", bar).hidden = rating !== "down";
  } catch (e) { $(".fbs", bar).textContent = "Not saved: " + e.message; }
}
// Resume a stopped video: a new request in the chat that finishes it from its folder (no new writing)
async function resumeJob(oldId, button) {
  button.disabled = true;
  add(`<div class="bubble">Resume</div>`, "user");
  const bot = add(working("Resuming…"), "bot");
  busy(true);
  try {
    const job = await api(`/api/jobs/${encodeURIComponent(oldId)}/resume`, {method: "POST",
      headers: {"Content-Type": "application/json"}, body: "{}"});
    await follow(job.id, bot);
  } catch (err) {
    $(".card", bot).innerHTML = `<div class="problem">${esc(err.message)}</div>`;
    button.disabled = false;
  } finally {
    busy(false);
    loadSpend();
    loadChats();
  }
}

$("#messages").addEventListener("click", e => {
  const resume = e.target.closest("button.resume");
  if (resume && !$("#send").disabled) { resumeJob(resume.dataset.job, resume); return; }
  const stop = e.target.closest(".working .stop");
  if (stop) {
    stop.disabled = true;
    stop.textContent = "Stopping…";
    api(`/api/jobs/${encodeURIComponent(stop.dataset.job)}/stop`, {method: "POST", headers: {"Content-Type": "application/json"},
        body: "{}"}).catch(err => { stop.textContent = "Not stopped: " + err.message; });
    return;
  }
  const again = e.target.closest(".reused button:not(.resume)");
  if (again && !$("#send").disabled) {
    let picks = {};
    try { picks = JSON.parse(again.dataset.picks || "{}"); } catch (err) {}
    again.disabled = true;
    send(again.dataset.request, picks, true);
    return;
  }
  const b = e.target.closest(".fb button");
  if (!b) return;
  const bar = b.closest(".fb");
  if (b.dataset.r === "up") sendFeedback(bar, "up");
  else if (b.dataset.r === "down") { $("input", bar).hidden = false; $("button[data-r=send]", bar).hidden = false; $("input", bar).focus(); sendFeedback(bar, "down"); }
  else sendFeedback(bar, "down");
});

$("#newchat").addEventListener("click", newChat);
$("#chats-toggle").addEventListener("click", () => $("#chatlist").classList.toggle("show"));

function stepText(line) {
  return String(line || "").replace(/^\d\d:\d\d:\d\d\s+/, "").replace(/\s+->\s+.*$/, "").slice(0, 140);
}

function understoodLine(u, expected) {
  if (!u) return "";
  const parts = [KIND[u.format] || u.format];
  if (u.format !== "answer") parts.push(`${u.minutes} min`, u.level);
  if (expected) parts.push(`usually ready in about ${expected < 90 ? "1 minute" : Math.round(expected / 60) + " minutes"}`);
  return parts.filter(Boolean).join(" · ");
}

// how long the current part still takes, from the pace of its steps so far ("pictures 6/17" ...)
function timeLeft(log, pace) {
  const m = /\b(voice|pictures) (\d+)\/(\d+)/.exec((log || []).slice(-6).reverse().join(" | "));
  if (!m) return "";
  const phase = m[1], n = Number(m[2]), total = Number(m[3]);
  if (pace.phase !== phase) { Object.assign(pace, {phase, n0: n, t0: Date.now()}); return ""; }
  if (n <= pace.n0) return "";
  const left = (total - n) * (Date.now() - pace.t0) / (n - pace.n0) / 60000;
  return ` · about ${left < 1 ? "1" : Math.round(left)} min left for the ${phase === "voice" ? "voice" : "pictures"}`;
}

async function follow(id, bot, picks) {
  const t0 = Date.now();
  const pace = {};
  const card = $(".card", bot);
  const tick = setInterval(() => { const t = $(".timer", card); if (t) t.textContent = mmss((Date.now() - t0) / 1000); }, 500);
  try {
    for (;;) {
      const j = await api("/api/jobs/" + id);
      if (j.status === "queued" || j.status === "running") {
        const w = $(".working", card);   // the Stop button: before the next paid call or the next scene
        if (w && !$(".stop", w)) w.insertAdjacentHTML("beforeend", `<button class="stop" type="button" data-job="${esc(id)}">Stop</button>`);
        const step = $(".step", card);
        if (step && j.status === "queued" && j.ahead > 0) {   // waiting in line: requests are made one after another
          step.textContent = `Waiting in line: ${j.ahead} request${j.ahead > 1 ? "s" : ""} ahead`;
        } else if (step) {
          const u = understoodLine(j.understood, j.expected_s);
          step.textContent = (u ? u + " — " : "") + (stepText(j.log[j.log.length - 1]) || "Working…") + timeLeft(j.log, pace);
        }
        await new Promise(r => setTimeout(r, 1500));
        continue;
      }
      card.innerHTML = j.status === "done" ? render(j.result, (Date.now() - t0) / 1000, picks) + feedbackBar(id)
        : `<div class="${j.status === "error" ? "problem" : "none"}">${esc(j.error || "Something went wrong.")}</div>` +
          (j.resume_folder ? `<div class="reused"><span>The script (the paid part) and every finished part are kept: ` +
            `resuming costs nothing more for the writing.</span><button type="button" class="resume" data-job="${esc(id)}">Resume</button></div>` : "");
      fitFrames(card);
      $("#thread").scrollTop = $("#thread").scrollHeight;
      return;
    }
  } finally { clearInterval(tick); }
}

function links(files, skip) {
  const out = Object.entries(files || {}).filter(([k]) => FILE_LABEL[k] && !skip.includes(k))
    .map(([k, u]) => `<a href="${esc(u)}" target="_blank" rel="noopener">${FILE_LABEL[k]}</a>`);
  return out.length ? `<div class="links">${out.join("")}</div>` : "";
}

function render(r, seconds, picks) {
  const f = r.files || {};
  let body = "", shown = [];
  if (r.answer) {
    const a = r.answer;
    if (a.not_in_material) {
      body = `<div class="none">The training material does not cover this question, so nothing was made up.</div>`;
    } else {
      body = `<p class="answer">${esc(a.text).replace(/\[(\d+)\]/g, "<sup>$1</sup>")}</p>`;
      if (a.not_covered) body += `<p class="muted">Not covered by the material: ${esc(a.not_covered)}</p>`;
      body += `<div class="sources"><h4>Sources</h4>` + a.sources.map(s =>
        `<div class="src"><b>${s.n}</b> ${esc(s.title)} <span class="muted">· ${esc(s.where)}${s.at && s.at.length ? " · at " + esc(s.at.join(", ")) : ""}</span>` +
        (s.evidence[0] ? `<q>${esc(s.evidence[0])}</q>` : "") + `</div>`).join("") + `</div>`;
    }
    shown = ["answer"];
  } else if (f.avatar_video || f.video) {
    const v = f.avatar_video || f.video;
    body = `<video controls preload="metadata" src="${esc(v)}"></video>`;
    shown = [f.avatar_video ? "avatar_video" : "video"];
  } else if (f.audio) {
    body = `<audio controls preload="metadata" src="${esc(f.audio)}"></audio>`;
    shown = ["audio"];
  } else if (f.pdf) {
    body = `<iframe src="${esc(f.pdf)}" class="h62" title="Slides"></iframe>`;
    shown = [];
  } else if (f.document) {
    body = `<iframe src="${esc(f.document)}" data-fit class="h60" title="Document"></iframe>`;
    shown = [];
  }
  const title = r.title && !r.answer ? `<div class="understood">${esc(r.title)}</div>` : "";
  const meta = `<div class="meta">${verdictTag(r.verdict)}<span>${usd(r.cost_usd)}</span>` +
               `<span>${r.reused ? "Found" : "Made"} in ${mmss(r.seconds || seconds)} min</span><span>${esc(KIND[r.format] || r.format)}</span></div>`;
  const again = r.reused ? `<div class="reused"><span>From the library: made before with exactly the same request and settings` +
    `${r.made_cost_usd ? ` (it cost ${usd(r.made_cost_usd)} then)` : ""} and nothing changed since, so you get it again at no cost.</span>` +
    `<button type="button" data-request="${esc(r.request || "")}" data-picks="${esc(JSON.stringify(picks || {}))}">Make a new version</button></div>` : "";
  return title + body + links(f, shown) + again + meta + qualityNotes(r) + reportPanels(r);
}

// --- the automatic checks (quality.py) as a closed panel: for whoever made the result, not in the way of the video --
function qualityNotes(r) {
  const notes = (r.fail || []).concat(r.verdict !== "OK" ? (r.issues || []) : []);
  if (!notes.length) return "";
  return `<details class="report qnotes"><summary>Quality notes <span class="sub">${notes.length} for the author</span></summary>` +
    `<div class="body"><ul>${notes.map(i => `<li>${esc(i)}</li>`).join("")}</ul>` +
    `<p class="note">Automatic checks of the finished result: sentences the judge could not find in the cited excerpts, ` +
    `length, how voice and screen fit, words to listen to. The result is made; these are points to look at before sharing it.</p></div></details>`;
}

// --- the cost under each result (results_report.py): tokens and cost by step; the time is in the line above -------
const num = v => v == null || v === "" ? "–" : Number(v).toLocaleString("en-US");
function reportPanels(r) {
  const R = r.report;
  if (!R) return "";
  const when = r.reused ? `<p class="note">From the library: these are the figures from when it was made (${esc(String(R.created).slice(0, 16).replace("T", " "))}). Getting it again cost ${usd(r.cost_usd)}.</p>` : "";
  const perMin = R.cost_per_minute_usd != null ? ` · ${usd(R.cost_per_minute_usd)} per video minute` : "";
  const steps = (R.by_step || []).map(s => `<tr><td>${esc(s.step)}</td><td class="num">${num(s.calls)}</td>` +
    `<td class="num">${num(s.tokens_in)}</td><td class="num">${num(s.tokens_cached)}</td><td class="num">${num(s.tokens_out)}</td>` +
    `<td class="num">${usd(s.cost_usd)}</td><td class="num">${s.share_pct}%</td></tr>`).join("");
  const costs = `<details class="report"><summary>Costs <span class="sub">${usd(R.cost_usd)} · ${num(R.tokens_in + R.tokens_cached)} tokens in (${num(R.tokens_cached)} cached), ` +
    `${num(R.tokens_out)} out${perMin}</span></summary><div class="body">${when}<div class="tablewrap"><table>` +
    `<tr><th>Step</th><th class="num">Calls</th><th class="num">Tokens in</th><th class="num">Cached in</th><th class="num">Tokens out</th>` +
    `<th class="num">Cost</th><th class="num">Share</th></tr>${steps}` +
    `<tr><td><b>Total</b></td><td class="num">${num(R.model_calls)}</td><td class="num">${num(R.tokens_in)}</td><td class="num">${num(R.tokens_cached)}</td>` +
    `<td class="num">${num(R.tokens_out)}</td><td class="num"><b>${usd(R.cost_usd)}</b></td><td></td></tr></table></div>` +
    `<p class="note">Only the model (Claude) is paid; voice, slides and video are made locally at no cost. Cached input costs 10% of the input price.</p>` +
    `<div class="exports"><a href="/api/export?folder=${encodeURIComponent(r.folder)}" download>Download report (Excel)</a></div></div></details>`;
  return costs;
}

function fitFrames(root) {
  root.querySelectorAll("iframe[data-fit]").forEach(fr => fr.addEventListener("load", () => {
    try { fr.style.height = Math.min(1400, fr.contentDocument.documentElement.scrollHeight + 4) + "px"; } catch (e) {}
  }));
}

// --- prices & results ------------------------------------------------------------------------------
async function loadPrices() {
  try {
    const [p, rows, decks] = await Promise.all([api("/api/prices"), api("/api/results"), api("/api/decks")]);
    $("#kpis").innerHTML = [["Spent today", `${usd(p.today)} <span class="muted kpi-sub">of ${usd(p.daily)} limit</span>`],
                            ["Spent in total", usd(p.total)], ["Results made", rows.length],
                            ["Feedback", `👍 ${rows.filter(r => (r.feedback || {}).rating === "up").length} · 👎 ${rows.filter(r => (r.feedback || {}).rating === "down").length}`]]
      .map(([k, v]) => `<div class="kpi"><small>${k}</small><div>${v}</div></div>`).join("");
    renderLengths(p.lengths);
    renderAws(p.aws || {});
    api("/api/monitor?days=7").then(renderMonitor).catch(e => { $("#monitor-note").textContent = "Could not load: " + e.message; });
    let last = "";
    $("#subs-note").textContent = `What each service costs a month and what that allows (checked ${p.checked}). Free tools have no limit.`;
    $("#subs-table").innerHTML = `<tr><th>Service</th><th>Plan</th><th class="num">A month</th><th>Limit</th><th>For</th></tr>` +
      p.subscriptions.map(r => { const first = r.service !== last; last = r.service;
        return `<tr${first ? ' class="grp"' : ""}><td>${first ? `<b>${esc(r.service)}</b>` : ""}</td><td>${esc(r.plan)}</td>` +
          `<td class="num">${esc(r.price)}</td><td class="sub">${esc(r.limit)}</td><td class="sub">${first ? esc(r.for) : ""}</td></tr>`; }).join("");
    $("#results-table").innerHTML = rows.length ? `<tr><th>Date</th><th>Request</th><th>Type</th><th class="num">Cost</th><th>Quality</th><th>Feedback</th><th>Open</th></tr>` +
      rows.map(r => `<tr><td class="sub">${esc(String(r.created).slice(0, 16).replace("T", " "))}</td><td>${esc(r.topic)}</td>` +
        `<td>${esc(KIND[r.kind] || r.kind)}</td><td class="num">${usd(r.cost_usd)}</td>` +
        `<td>${verdictTag(r.verdict)}</td>` +
        `<td title="${esc((r.feedback || {}).comment || "")}">${{up: "👍", down: "👎"}[(r.feedback || {}).rating] || ""}${(r.feedback || {}).comment ? ` <span class="sub">${esc(r.feedback.comment.slice(0, 60))}</span>` : ""}</td>` +
        `<td>${links(r.files, ["markdown", "notes", "chapters"])}</td></tr>`).join("")
      : `<tr><td class="muted">Nothing made yet.</td></tr>`;
    $("#decks-section").hidden = !decks.length;
    $("#decks-table").innerHTML = `<tr><th>Deck</th><th>Videos</th></tr>` + decks.map(d => `<tr><td>${esc(d.title)}</td><td><div class="links">` +
      Object.entries(d.videos).map(([e, u]) => `<a href="${esc(u)}" target="_blank" rel="noopener">${esc(e)}</a>`).join("") + `</div></td></tr>`).join("");
  } catch (e) {
    $("#aws-note").textContent = "Could not load: " + e.message;
  }
}

// --- quality and health: monitoring.py (every answer's checks, the judge's sample, votes, time, failures) ----------
function renderMonitor(M) {
  const pct = v => v == null ? "–" : Math.round(v * 100) + "%";
  $("#monitor-note").textContent = M.requests ? `${M.requests} requests, ${M.errors} failed. Every answer is checked ` +
    `sentence by sentence; ${pct(M.sample)} of them are also graded by the judge model (EVAL_SAMPLE).` : "Nothing asked in the last 7 days.";
  $("#monitor-attention").innerHTML = (M.attention || []).map(a => `<li class="problem">${esc(a)}</li>`).join("");
  $("#monitor-answers").innerHTML = M.answers ? `<tr><th>Answers</th><th class="num">${M.answers}</th></tr>` + [
      ["Answered", M.answered], ["Not in the material", M.not_in_material], ["Refused (unsafe)", M.refused],
      ["From the cache (free)", M.from_cache], ["Sentences removed by the check", pct(M.removed_share)],
      ["Sentences corrected by the check", pct(M.corrected_share)], ["Searched again", M.searched_again],
      ["Graded by the judge", M.judged ? `${M.judged}, faithfulness ${M.faithfulness}` + (M.self_judged ? " (judge = writer)" : "") : "–"],
      ["Votes", `👍 ${M.votes_up} · 👎 ${M.votes_down}`]]
    .map(([k, v]) => `<tr><td>${k}</td><td class="num">${esc(String(v))}</td></tr>`).join("") : "";
  $("#monitor-formats").innerHTML = (M.by_format || []).length ? `<tr><th>Format</th><th class="num">Requests</th><th class="num">Failed</th>` +
    `<th class="num">Median time</th><th class="num">95% within</th><th class="num">Cost</th></tr>` +
    M.by_format.map(f => `<tr><td>${esc(KIND[f.format] || f.format)}</td><td class="num">${f.count}</td><td class="num">${f.errors}</td>` +
      `<td class="num">${f.median_s == null ? "–" : f.median_s + " s"}</td><td class="num">${f.p95_s == null ? "–" : f.p95_s + " s"}</td>` +
      `<td class="num">${usd(f.cost_usd)}</td></tr>`).join("") : "";
}

// --- AWS a month: only what the AWS Pricing Calculator says (its export in data/aws, aws_estimate.py) -----
function renderAws(A) {
  if (!A.file) {
    $("#aws-note").innerHTML = "Not priced yet. Make the estimate in the AWS Pricing Calculator (calculator.aws), " +
      "groups Prod and Dev, then Export &gt; CSV into <code>data/aws</code>.";
    $("#aws-groups").innerHTML = "";
    return;
  }
  $("#aws-note").innerHTML = `From the AWS Pricing Calculator (${esc(A.file)})` +
    (A.link ? ` · <a href="${esc(A.link)}" target="_blank" rel="noopener">Open the estimate</a>` : "") +
    (A.error ? ` · <span class="problem">${esc(A.error)}</span>` : "");
  $("#aws-groups").innerHTML = (A.groups || []).map(g => `<h4 class="h4-gap">${esc(g.name)}: ${usd(g.monthly)} a month</h4>` +
    `<div class="tablewrap"><table><tr><th>Service</th><th>What</th><th class="num">A month</th></tr>` +
    g.services.map(r => `<tr><td><b>${esc(r.service)}</b></td><td class="sub">${esc(r.description)}</td><td class="num">${usd(r.monthly)}</td></tr>`).join("") +
    `</table></div>`).join("") +
    ((A.groups || []).length > 1 ? `<p class="mt12"><b>Total: ${usd(A.monthly)} a month</b></p>` : "");
}

// --- a video opens in the middle of the page, with sound; × or Esc or a click beside it closes it ------
function openVideo(url) {
  const v = $("#vplayer");
  v.muted = false; v.volume = 1; v.src = url; $("#vmodal").hidden = false;
  v.play().catch(() => {});
}
function closeVideo() { const v = $("#vplayer"); v.pause(); v.removeAttribute("src"); v.load(); $("#vmodal").hidden = true; }
$("#vclose").onclick = closeVideo;
$("#vmodal").addEventListener("click", e => { if (e.target.id === "vmodal") closeVideo(); });
document.addEventListener("keydown", e => { if (e.key === "Escape" && !$("#vmodal").hidden) closeVideo(); });
document.addEventListener("click", e => {   // every link to a video on the page plays it here, not in a new page
  const a = e.target.closest && e.target.closest("a[href]");
  if (!a || !/\.(mp4|webm|mov)(\?|#|$)/i.test(a.getAttribute("href"))) return;
  e.preventDefault();
  openVideo(a.getAttribute("href"));
});

// --- costs by length (length_costs.py) ------------------------------------------------------------
// how long making the video took on this machine (Claude writing it, the voice, the slides, the video)
// Claude's tokens for the video, measured (with the shorter videos it is built on): for the calculator's Bedrock entry
// Claude's tokens the way the AWS calculator asks for them: input (not cached) + read from the prompt cache / output
function tokens(r) {
  const k = v => (v / 1000).toFixed(v < 10000 ? 1 : 0) + "k", t = name => r[name + "_total"] ?? r[name] ?? 0;
  if (!r.in_tokens) return "–";
  const fresh = t("fresh_in_tokens") || t("in_tokens"), cached = t("cache_read_tokens") + t("cache_write_tokens");
  return `${k(fresh)}${cached ? ` + ${k(cached)} cached` : ""} / ${k(t("out_tokens"))}`;
}
function madeIn(r) { const s = r.made_in_s || r.make_s; return s ? `${mmss(s)} min` : ""; }
function renderLengths(L) {
  L = L || {rows: []};
  const rows = L.rows || [], fresh = L.scratch || [];
  $("#len-scratch").innerHTML = fresh.length ? `<h4 class="h4-gap2">Made from scratch</h4>` +
    `<div class="tablewrap"><table><tr><th>Video</th><th>Theme</th><th class="num">Cost</th><th class="num">Made in</th><th></th></tr>` +
    fresh.map(r => `<tr><td><b>${r.minutes} min</b>${r.version ? ` <span class="ver">v${r.version}</span>` : ""}</td><td>${esc(r.theme)}<div class="sub">${esc((r.topics || []).join(" · "))}</div></td>` +
      `<td class="num"><b>${usd(r.claude_usd)}</b></td><td class="num">${madeIn(r)}</td><td>${r.url ? `<a href="${esc(r.url)}" class="watch">Watch</a>` : ""}</td></tr>`).join("") +
    `</table></div>` : "";
  $("#len-grid").hidden = $("#len-table").hidden = !rows.length;
  if (!rows.length) {
    $("#len-note").textContent = fresh.length ? "" : "Not measured yet.";
    return;
  }
  $("#len-note").innerHTML = `<span class="sub">Cost: ${esc(L.price_source || "")}.</span>` + (L.xlsx ? ` <a href="${esc(L.xlsx)}">Excel</a>` : "");
  // what is paid today: Claude writing the video (the voice and the slides are free, they run on this computer)
  $("#len-table").innerHTML = `<tr><th>Video</th><th class="num">Cost</th><th class="num">Claude tokens (in + cached / out)</th><th class="num">Made in</th><th></th></tr>` +
    rows.map(r => `<tr><td><b>${r.minutes} min</b>${r.version ? ` <span class="ver">v${r.version}</span>` : ""}</td><td class="num"><b>${usd(r.claude_usd)}</b></td>` +
      `<td class="num">${tokens(r)}</td><td class="num">${madeIn(r)}</td><td>${r.url ? `<a href="${esc(r.url)}" class="watch">Watch</a>` : ""}</td></tr>` +
      ((r.new_topics || []).length ? `<tr><td colspan="5" class="sub pt0">The topic ran out; new topics added: ` +
        `${esc(r.new_topics.join(", "))}</td></tr>` : "")).join("");
  const W = 520, H = 190, pad = 26, bw = (W - pad) / rows.length, top = Math.max(...rows.map(r => r.claude_usd), 0.01);
  $("#len-chart").innerHTML = `<svg class="lenchart" viewBox="0 0 ${W} ${H + 20}" width="100%" role="img" aria-label="Cost of one video by length">` +
    rows.map((r, k) => { const h = Math.max(2, (H - 30) * r.claude_usd / top), x = pad + k * bw + 8, y = H - h, bwi = Math.min(bw - 16, 70);
      return `<rect x="${x}" y="${y}" width="${bwi}" height="${h}" rx="4" fill="#4f46e5"/>` +
        `<text class="v" x="${x + bwi / 2}" y="${y - 5}" text-anchor="middle">${usd(r.claude_usd)}</text>` +
        `<text x="${x + bwi / 2}" y="${H + 15}" text-anchor="middle">${r.minutes} min</text>`; }).join("") +
    `<line x1="${pad}" y1="${H}" x2="${W}" y2="${H}" stroke="#e3e7ec"/></svg>`;
  $("#len-limits").innerHTML = (L.limits || []).filter(x => !/server/i.test(x.limit)).map(x => `<li><b>${esc(x.limit)}: ${esc(x.value)}.</b> <small>${esc(x.why)}</small></li>`).join("");
}

async function loadBrandMark() {
  try {
    const b = await api("/api/brand");
    $(".brand").innerHTML = b.logo_url ? `<img src="${esc(b.logo_url)}?v=${Date.now()}" alt="">Lesson Studio`   // a new logo at once
                                       : `<i aria-hidden="true"></i>Lesson Studio`;
    const tab = document.querySelector("link[rel=icon]");
    if (tab) tab.href = b.favicon_url ? `${b.favicon_url}?v=${Date.now()}` : "/brand/favicon";   // the browser tab too
    if (b.on && /^#[0-9a-f]{6}$/i.test(b.accent || "")) {   // the company colours on the page too
      const r = document.documentElement.style;
      r.setProperty("--accent", b.accent);
      r.setProperty("--accent-soft", `color-mix(in srgb, ${b.accent} 12%, white)`);
    }
  } catch (e) { /* the default mark stays */ }
}
loadBrandMark();

// --- the company look: files added on the page go to data/brand and are used at once (brand.py) --------------------
const readFile = file => new Promise((ok, fail) => {
  const r = new FileReader();
  r.onload = () => ok(r.result);
  r.onerror = () => fail(r.error);
  r.readAsDataURL(file);
});

function showBrand(b) {
  const box = $("#brand-now");
  if (!box) return;
  if (!b.on && !(b.files || []).length) {
    box.innerHTML = `<p class="muted">No company files yet: the default look is used.</p>`;
    return;
  }
  const facts = [b.logo ? `Logo: ${esc(b.logo)}` : "No logo", b.template ? `Template: ${esc(b.template)}` : "No template",
                 b.font ? `Font: ${esc(b.font)}` : "", b.icons ? `${b.icons} icon${b.icons === 1 ? "" : "s"}` : "",
                 (b.images || []).length ? `${b.images.length} picture${b.images.length === 1 ? "" : "s"}` : "",
                 b.footer ? `Footer: ${esc(b.footer)}` : ""].filter(Boolean);
  box.innerHTML = `<div class="brandfacts">${b.logo_url ? `<img src="${esc(b.logo_url)}?v=${Date.now()}" alt="Logo">` : ""}` +
    `<span class="sw" data-c="${esc(b.accent || "")}"></span><span class="sw" data-c="${esc(b.accent2 || "")}"></span>` +
    `<span>${facts.join(" · ")}</span></div>` +
    `<ul class="brandfiles">${(b.files || []).map(f => `<li><span>${esc(f)}</span>` +
      `<button type="button" data-del="${esc(f)}">Remove</button></li>`).join("")}</ul>`;
  box.querySelectorAll(".sw").forEach(s => { if (/^#[0-9a-f]{6}$/i.test(s.dataset.c)) s.style.background = s.dataset.c; else s.remove(); });
  box.querySelectorAll("[data-del]").forEach(btn => btn.addEventListener("click", async () => {
    try {
      showBrand(await api("/api/brand/delete", {method: "POST", headers: {"Content-Type": "application/json"},
                                                 body: JSON.stringify({name: btn.dataset.del})}));
      $("#brand-msg").textContent = `Removed ${btn.dataset.del}.`;
      loadBrandMark();
    } catch (e) { $("#brand-msg").textContent = e.message; }
  }));
}

async function loadBrandPanel() {
  try { showBrand(await api("/api/brand")); } catch (e) { /* the section stays empty */ }
}

const sendBrandFile = async (kind, name, blob) => api("/api/brand", {method: "POST",
  headers: {"Content-Type": "application/json"}, body: JSON.stringify({kind, name, data: await readFile(blob)})});

// A .zip as it comes from the company's brand site is opened here, in the browser: only the files that are needed
// go to the app (one logo, one template; every font, icon or picture), not the whole package.
const fileName = n => n.split("/").pop();
const fileExt = n => (fileName(n).match(/\.[^.]+$/) || [""])[0].toLowerCase();
const BRAND_TYPES = {logo: [".png", ".svg", ".jpg", ".jpeg", ".webp"], favicon: [".png", ".svg", ".ico", ".jpg", ".jpeg", ".webp"],
                     template: [".potx", ".pptx"],
                     font: [".ttf", ".otf", ".woff", ".woff2"], icon: [".svg"], image: [".png", ".jpg", ".jpeg", ".webp", ".svg"]};
const ZIP_LIMIT = {logo: 1, favicon: 1, template: 1, font: 20, icon: 400, image: 20};

function logoScore(name) {          // the colour logo for screens: RGB, colour, horizontal; not print, white or a variant
  const n = name.toLowerCase();
  let s = 0;
  if (/rgb/.test(n)) s += 3;
  if (/colou?r|full/.test(n)) s += 3;
  if (/horizontal|landscape|primary|main|standard/.test(n)) s += 2;
  if (n.endsWith(".png")) s += 2;
  else if (n.endsWith(".svg")) s += 1;
  if (/cmyk|pantone|print/.test(n)) s -= 10;
  if (/negative|inverse|reverse|white|mono|black|grey|gray|outline/.test(n)) s -= 8;
  if (/favicon|icon|small|social|avatar|motto|claim|tagline|patch|stamp/.test(n)) s -= 4;
  return s;
}

function faviconScore(name) {       // the square mark for the browser tab; -99: not one (then the logo is used)
  const n = fileName(name).toLowerCase();
  if (!/favicon|symbol|signet|emblem|monogram|app.?icon|\bicon\b|\bmark\b/.test(n) ||
      /social|linkedin|twitter|facebook|instagram|youtube|xing|cmyk|pantone|print/.test(n)) return -99;
  return (/favicon/.test(n) ? 4 : 0) + (/rgb/.test(n) ? 2 : 0) + (/colou?r/.test(n) ? 2 : 0) + (/\.(png|svg|ico)$/.test(n) ? 1 : 0)
         - (/negative|inverse|reverse|white|mono|black|grey|gray|outline/.test(n) ? 8 : 0);
}

function templateScore(name) {      // the master, not an example deck or a checklist
  const n = name.toLowerCase();
  return (n.endsWith(".potx") ? 2 : 0) + (/master|template/.test(n) ? 2 : 0) - (/checklist|example|sample|guide|demo/.test(n) ? 5 : 0);
}

async function zipEntries(file) {   // the central directory of a .zip (ZIP64 entries are left out)
  const buf = await file.arrayBuffer();
  const v = new DataView(buf);
  let end = -1;
  for (let i = buf.byteLength - 22; i >= Math.max(0, buf.byteLength - 65557); i--) {
    if (v.getUint32(i, true) === 0x06054b50) { end = i; break; }
  }
  if (end < 0) throw new Error("this is not a .zip file");
  const decoder = new TextDecoder(), entries = [];
  let p = v.getUint32(end + 16, true);
  for (let n = v.getUint16(end + 10, true); n > 0 && v.getUint32(p, true) === 0x02014b50; n--) {
    const nameLen = v.getUint16(p + 28, true);
    entries.push({name: decoder.decode(new Uint8Array(buf, p + 46, nameLen)), method: v.getUint16(p + 10, true),
                  size: v.getUint32(p + 20, true), usize: v.getUint32(p + 24, true), local: v.getUint32(p + 42, true)});
    p += 46 + nameLen + v.getUint16(p + 30, true) + v.getUint16(p + 32, true);
  }
  return {buf, v, entries: entries.filter(e => e.size !== 0xffffffff && e.usize > 0 && !e.name.endsWith("/") &&
                                           !/(^|\/)(__MACOSX\/|\.)/.test(e.name))};
}

async function zipRead(zip, e) {    // one file of the .zip, stored or deflated
  const start = e.local + 30 + zip.v.getUint16(e.local + 26, true) + zip.v.getUint16(e.local + 28, true);
  const raw = new Blob([new Uint8Array(zip.buf, start, e.size)]);
  if (e.method === 0) return raw;
  if (e.method !== 8) throw new Error(`${fileName(e.name)}: compression not supported`);
  return new Response(raw.stream().pipeThrough(new DecompressionStream("deflate-raw"))).blob();
}

async function brandFromZip(kind, file, msg) {
  const zip = await zipEntries(file);
  let picked = zip.entries.filter(e => BRAND_TYPES[kind].includes(fileExt(e.name)));
  if (kind === "logo") picked = picked.filter(e => e.usize <= 8e6 && faviconScore(e.name) === -99)
                                       .sort((a, b) => logoScore(b.name) - logoScore(a.name) || b.usize - a.usize);
  if (kind === "favicon") picked = picked.filter(e => e.usize <= 8e6 && faviconScore(e.name) > -99)
                                         .sort((a, b) => faviconScore(b.name) - faviconScore(a.name));
  if (kind === "template") picked = picked.filter(e => e.usize <= 30e6).sort((a, b) => templateScore(b.name) - templateScore(a.name));
  picked = picked.slice(0, ZIP_LIMIT[kind]);
  if (!picked.length) throw new Error(`no ${BRAND_TYPES[kind].join(" / ")} file in it`);
  let state = null, saved = [], failed = 0;
  for (const e of picked) {
    msg.textContent = `${file.name}: saving ${fileName(e.name)} (${saved.length + failed + 1} of ${picked.length})…`;
    try { state = await sendBrandFile(kind, fileName(e.name), await zipRead(zip, e)); saved.push(fileName(e.name)); }
    catch (err) { failed++; }
  }
  if (!state) throw new Error("none of its files could be used");
  showBrand(state);
  const what = saved.length === 1 ? `used ${saved[0]}` : `saved ${saved.length} files`;
  let tab = "";
  if (kind === "logo") {   // a logo package usually has the square mark too: for the browser tab
    try { await brandFromZip("favicon", file, {}); tab = " and its square mark for the browser tab"; } catch (e) { /* the logo is used */ }
  }
  msg.textContent = `From ${file.name}: ${what}${tab}${failed ? ` (${failed} left out: not usable)` : ""}. The next result uses it.`;
}

document.querySelectorAll("#brand-section input[type=file]").forEach(input => input.addEventListener("change", async () => {
  const msg = $("#brand-msg"), kind = input.dataset.kind;
  for (const file of input.files) {
    msg.textContent = `Saving ${file.name}…`;
    try {
      if (/\.zip$/i.test(file.name)) await brandFromZip(kind, file, msg);
      else {
        showBrand(await sendBrandFile(kind, file.name, file));
        msg.textContent = `Saved ${file.name}. The next result uses it.`;
      }
    } catch (e) { msg.textContent = `${file.name}: ${e.message}`; }
  }
  input.value = "";
  loadBrandMark();
}));
loadBrandPanel();

// --- what can be picked under the box (default = from the words / from .env) ------------------------
const PICKS = {format: "#pick-format", tool: "#pick-tool", voice: "#pick-voice", level: "#pick-level"};
function picked() {
  const out = {};
  for (const [k, sel] of Object.entries(PICKS)) { const v = $(sel).value; if (v && v !== "default" && v !== "auto") out[k] = v; }
  return out;
}
function fill(sel, first, items) {
  const el = $(sel);
  const option = i => `<option value="${esc(i.id)}"${i.ok === false ? " disabled" : ""}>${esc(i.label)}` +
                      `${i.ok === false ? " (not set up here)" : ""}</option>`;
  const groups = [...new Set(items.map(i => i.group || ""))];
  el.innerHTML = `<option value="${first[0]}">${esc(first[1])}</option>` + (groups.some(Boolean)
    ? groups.map(g => `<optgroup label="${esc(g || "Other")}">${items.filter(i => (i.group || "") === g).map(option).join("")}</optgroup>`).join("")
    : items.map(option).join(""));
  el.hidden = items.filter(i => i.ok !== false).length < 2 && sel !== PICKS.format;   // one choice: nothing to pick
  el.addEventListener("change", () => el.classList.toggle("set", el.selectedIndex > 0));
}
async function loadChoices() {
  try {
    const c = await api("/api/choices");
    fill(PICKS.format, ["auto", "Output: Auto (from my words)"], c.formats.filter(f => f.id !== "auto"));
    fill(PICKS.tool, ["default", `Tool: Default (${c.defaults.tool})`], c.tools);
    fill(PICKS.voice, ["default", `Narrator: Default (${c.defaults.voice})`], c.voices);
    fill(PICKS.level, ["auto", "Level: Auto"], c.levels.filter(l => l.id !== "auto"));
  } catch (e) { document.querySelector(".picks").hidden = true; }
}
loadChoices();

// --- start: if a request is already being made (e.g. after a reload), follow it -----------------------
(async () => {
  const s = await loadSpend();
  const list = await loadChats();
  if (s.running) busy(true);
  const want = s.running_chat || remembered();
  if (want && list.some(c => c.id === want)) await openChat(want);
  else if (s.running) {   // a request without a chat (made from the command line or an older page)
    add(`<div class="bubble">${esc(s.running_request || "…")}</div>`, "user");
    const bot = add(working("Working…"), "bot");
    try { await follow(s.running, bot); } finally { busy(false); }
  }
  if (s.running) {   // the composer opens again when that request is finished
    for (;;) { const t = await loadSpend(); if (!t.running) break; await new Promise(r => setTimeout(r, 3000)); }
    busy(false); loadChats();
  } else { box.focus(); }
})();
