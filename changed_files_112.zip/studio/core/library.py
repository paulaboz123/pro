"""Finished results given back when the same request comes again, instead of being made again (docs/COSTS.md).

A result depends only on the request, the indexed material, the code, the prompts and the settings, so all of
these are in the key, and a match is exact, never "similar":
    request_key: the same words and choices on the page, found before any model call. The first message of a
        chat always; later ones only when the words name the result's topic (named_in).
    key: the same request as the model understood it (~$0.005), for other words with the same meaning.

Results with the verdict OK or CHECK are kept, FAIL never; one marked 👎 is forgotten. "Make a new version" (the
`fresh` override) and LIBRARY=no skip it. Stored in data/output/library.json.
"""
from __future__ import annotations

import hashlib
import json
import logging
import re
from pathlib import Path
from typing import Any

from studio.core import config, store

log = logging.getLogger("library")

# The settings a result is made from (ask.run passes only these to the makers).
KEYS = ("format", "topic", "recordings", "minutes", "level", "wishes", "style", "characters")
KEPT = ("OK", "CHECK")   # verdicts a result is kept with (FAIL: never)
CHOICES = ("format", "tool", "voice", "level", "minutes", "style", "characters", "look")   # picked on the page
# Settings in .env that do not change what is made (running, monitoring, prices and limits, secrets).
NOT_OUTPUT = ("LIBRARY", "APP_", "LOG_", "METRICS_PORT", "SHUTDOWN_WAIT_S", "DAILY_BUDGET_USD", "EVAL_SAMPLE",
              "RUN_BUDGET_USD", "HARD_DAILY_LIMIT_USD", "PRICE", "COST_", "REGIONAL_PREMIUM", "IMAGE_PRICE_USD",
              "ELEVENLABS_PLAN_", "ELEVENLABS_USD_", "ELEVENLABS_MONTHLY_", "LLM_TIMEOUT_S", "PARALLEL_CALLS",
              "CA_BUNDLE", "ANSWER_CACHE", "CHAT_HISTORY_TURNS", "_")
SECRET_WORDS = ("KEY", "PASSWORD", "TOKEN", "SECRET")


def library_file() -> Path:
    """{key: the result's folder name}, next to the results."""
    return config.OUTPUT_DIR / "library.json"


def _text(value: Any) -> Any:
    """Case and spacing ignored in free text; a list in any order."""
    if isinstance(value, str):
        return " ".join(value.lower().split()).rstrip(" ?.!")
    if isinstance(value, (list, tuple)):
        return sorted(str(v) for v in value)
    return value


def config_fingerprint() -> str:
    """Every setting from .env that can change a result (model, voice, style, pictures, review ...)."""
    out = {}
    for name in sorted(dir(config)):
        if not name.isupper() or name.startswith(NOT_OUTPUT) or any(w in name for w in SECRET_WORDS):
            continue
        value = getattr(config, name)
        if isinstance(value, (str, int, float, bool, Path, list, tuple)) or value is None:
            out[name] = str(value)
    return hashlib.sha256(json.dumps(out, sort_keys=True).encode("utf-8")).hexdigest()[:16]


def material_fingerprint() -> str:
    """What the search index holds (every excerpt's text and context), not when it was built."""
    try:
        info = store.load_index()[2]
        return json.dumps([info.get("embed_model", ""), info.get("hashes") or info.get("built_at", "")], default=str)
    except (FileNotFoundError, ValueError, OSError):
        return ""


def code_fingerprint() -> str:
    """The code, the prompts (skills) and the design files (assets: by name, size and time)."""
    h = hashlib.sha256()
    code = sorted((config.ROOT / "studio").rglob("*.py")) + sorted((config.ROOT / "studio").rglob("*.html"))
    for f in code + sorted(config.SKILLS_DIR.glob("**/*.md")):
        h.update(f.name.encode() + f.read_bytes())
    assets = config.ROOT / "assets"
    for f in sorted(assets.rglob("*")) if assets.is_dir() else []:
        if f.is_file():
            st = f.stat()
            h.update(f"{f.relative_to(assets)}|{st.st_size}|{st.st_mtime_ns}".encode())
    return h.hexdigest()[:16]


def brand_fingerprint() -> str:
    """The company files (data/brand: by name, size and time): a new logo or template makes a new result."""
    d = config.BRAND_DIR
    h = hashlib.sha256()
    for f in sorted(d.rglob("*")) if d.is_dir() else []:
        if f.is_file() and not f.name.startswith("."):
            st = f.stat()
            h.update(f"{f.relative_to(d)}|{st.st_size}|{st.st_mtime_ns}".encode())
    return h.hexdigest()[:16]


def _hash(parts: list[Any]) -> str:
    parts += [material_fingerprint(), code_fingerprint(), config_fingerprint(), brand_fingerprint()]
    return hashlib.sha256(json.dumps(parts, default=str).encode("utf-8")).hexdigest()[:32]


def key(settings: dict[str, Any], model: str | None, review: bool) -> str:
    """The request as Claude read it, and everything else a result depends on. Any change = a new result."""
    return _hash([{k: _text(settings.get(k)) for k in KEYS}, model or config.CHAT_MODEL, review])


def request_key(request: str, choices: dict[str, Any] | None, model: str | None, review: bool) -> str:
    """The request's own words (case, spacing and the last . ? ! ignored) and what was picked on the page."""
    picked = {k: str(v) for k, v in (choices or {}).items() if k in CHOICES and v not in (None, "", "auto")}
    return _hash(["words", _text(request), dict(sorted(picked.items())), model or config.CHAT_MODEL, review])


def _entry(value: object) -> dict[str, Any]:
    """An entry of library.json (an older one is just the folder name)."""
    return value if isinstance(value, dict) else {"folder": str(value or ""), "understood": None}


def find_entry(k: str) -> tuple[Path, dict[str, Any] | None] | None:
    """(the folder, the settings it was made with) of the result kept with this key, if it is still there and
    its verdict is still OK or CHECK."""
    if not k:
        return None
    raw = (store.read_json(library_file(), {}) or {}).get(k)
    if not raw:
        return None
    entry = _entry(raw)
    folder = config.OUTPUT_DIR / entry["folder"]
    q = store.read_json(folder / "quality.json", {}) or {}
    if not entry["folder"] or not (folder / "run_card.json").exists() or q.get("status") not in KEPT:
        return None
    return folder, entry.get("understood")


def find(k: str) -> Path | None:
    """The folder of the result kept with this key (find_entry)."""
    found = find_entry(k)
    return found[0] if found else None


def named_in(request: str, understood: dict[str, Any] | None) -> bool:
    """The request's words name the topic of the result found (at least one of the topic's words of 4+ letters):
    then the same words mean the same result whatever came before in the chat."""
    topic = [w for w in re.findall(r"[a-z0-9]+", str((understood or {}).get("topic", "")).lower()) if len(w) >= 4]
    said = [w for w in re.findall(r"[a-z0-9]+", request.lower()) if len(w) >= 4]
    hits = sum(any(s.startswith(w) or w.startswith(s) for s in said) for w in topic)   # join ~ joins, joining
    return bool(topic) and hits >= 1


def remember(keys: list[str], folder: Path, quality: dict[str, Any], understood: dict[str, Any] | None = None) -> bool:
    """Keep the result under these keys for the next same request; verdict OK or CHECK (FAIL: never)."""
    keys = [k for k in keys if k]
    if quality.get("status") not in KEPT or not keys:
        return False
    data = store.read_json(library_file(), {}) or {}
    for k in keys:
        data[k] = {"folder": folder.name, "understood": understood}
    store.write_json(library_file(), data)
    return True


def forget(folder_name: str) -> int:
    """A result someone marked 👎: never given again. Returns how many entries were removed."""
    data = store.read_json(library_file(), {}) or {}
    keep = {k: v for k, v in data.items() if _entry(v)["folder"] != folder_name}
    if len(keep) != len(data):
        store.write_json(library_file(), keep)
    return len(data) - len(keep)
