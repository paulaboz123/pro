"""
quality.py - automatic checks of a finished video lesson, so you only need to look closely at
the ones that need it.

Checks without a model call (free):
  length      narration words vs target (within 25% is fine)
  sync        video and audio tracks of the mp4 have the same length
  privacy     no e-mail addresses or phone numbers (fail), no names of people from the recordings
  safety      no inappropriate words (fail); sensitive words are flagged for a look
  truth       every number on screen is in the sources (fail); calculations were recomputed
  match       the voice talks about what the screen shows (at least half of the elements)
  layout      nothing cut off, overflowing or overlapping (checked while rendering)
  audio       no silence, distortion or odd speaking pace; loudness normalised
  visual      with --visual: the vision model reviews each finished slide like an editor
  repetition  course chapters don't repeat each other
  sources     invented source labels removed, scenes without sources
  read-aloud  a slide scene whose narration repeats the slide text word for word
  mayer       multimedia principles (Mayer): the voice reads a designed slide aloud (redundancy), the narration
              never speaks to the learner (personalization); before the review also a process shown all at once
              (signaling). Given to the self-review as facts to fix (storyboard.draft_problems)
  on-screen   key points / steps longer than 8 words, headings longer than 10 words
  slides      the same slide shown twice
  voice       unusual words (acronyms, CamelCase, words with digits) and the glossary's terms
              that are not in pronunciation.csv: listen to them, add a row if the voice says them wrongly
  listen      with --listen: Whisper transcribes the finished voice and it is compared with the
              script, word by word: the share of words that don't come out as written, and which
              terms were heard as something else (a mispronounced or skipped term), so you don't
              have to listen to every video (needs faster-whisper; ~1 min per 2-min video on CPU)
Optional review by the chat model (--review, about $0.01 per video): every scene is compared
with the transcript excerpts it cites; scores 1-5 for faithful / level fit / clarity, plus a
list of problems. Plus the claim check, the same judge as the answers to questions (qa_eval.py):
every sentence of the narration and every on-screen point is split into claims and each claim is
checked against the excerpts its scene cites (their words and their slides). A claim they don't
support, or that they contradict, makes the video FAIL and is listed; that is the hallucination
check of a video, claim by claim, not a score for the whole scene. Judge: JUDGE_MODEL, else
REVIEW_MODEL (best a different model than the writer, CHAT_MODEL).

Result: quality.json in the video folder, with status OK, CHECK (look at it), FAIL, or PLAN
(storyboard only, not rendered yet). A review is kept until the storyboard changes.

Usage:
  uv run -m studio quality data/output/<folder>             # one video
  uv run -m studio quality data/output/<folder> --review    # plus the model review
  uv run -m studio quality --all [--review]                 # every video folder
"""
from __future__ import annotations

import argparse
import logging
import re
import sys
from pathlib import Path
from typing import Any

from studio.core import config, llm, safety, store
from studio.generation import lesson, storyboard
from studio.video import media, tts

log = logging.getLogger("quality")

READ_ALOUD_LIMIT = 0.5     # share of the slide's 4-word phrases repeated in the narration
LENGTH_TOLERANCE = 0.25
MAX_ITEM_WORDS = 8
MAX_HEADING_WORDS = 10
SYNC_TOLERANCE_S = 0.5
COMMON_ACRONYMS = {"OK", "AI", "IT", "HR", "US", "UK", "EU", "PDF", "FAQ", "ID", "TV", "PC", "I"}

REVIEW_SCHEMA = {
    "type": "object",
    "properties": {
        "faithful": {"type": "integer", "description": "1-5: every statement is supported by the excerpts"},
        "level_fit": {"type": "integer", "description": "1-5: suits the learner level"},
        "clarity": {"type": "integer", "description": "1-5: easy to follow when heard once"},
        "issues": {"type": "array", "items": {"type": "object", "properties": {
            "scene": {"type": "integer"}, "problem": {"type": "string"}},
            "required": ["scene", "problem"]}},
    },
    "required": ["faithful", "level_fit", "clarity", "issues"],
}
REVIEW_PROMPT = """You review a narrated video lesson made from internal training recordings.
For each scene you get the narration, what the screen shows, and the transcript excerpts it
was based on. Score from 1 (bad) to 5 (very good):
- faithful: every statement is supported by the excerpts (no invented facts, numbers or names)
- level_fit: suits a {level} learner
- clarity: easy to follow when heard once
List concrete problems with the scene number (empty list if none). Be strict but fair."""


def _words(text: str) -> list[str]:
    """Lowercase words (letters and digits) of a text."""
    return re.findall(r"[a-z0-9]+", text.lower())


def read_aloud_ratio(narration: str, slide_text: str, n: int = 4) -> float:
    """Share of the slide's n-word phrases that appear unchanged in the narration (0 to 1).
    High values mean the voice reads the slide out instead of explaining it."""
    slide, spoken = _words(slide_text), _words(narration)
    if len(slide) < 2 * n:
        return 0.0
    slide_grams = {tuple(slide[i:i + n]) for i in range(len(slide) - n + 1)}
    spoken_grams = {tuple(spoken[i:i + n]) for i in range(len(spoken) - n + 1)}
    return len(slide_grams & spoken_grams) / len(slide_grams)


EMAIL, PHONE = safety.EMAIL, safety.PHONE   # personal data (also stopped before cloud voices)

PROCESS_LAYOUTS = ("steps", "cycle", "timeline", "calculation")
NOT_DESIGNED = ("title", "question", "answer", "slide")   # no designed screen text to read aloud (or own check)
YOU = re.compile(r"\byou(?:r|rs|rself)?\b", re.I)


def mayer_problems(scenes: list[dict], signaling: bool = False) -> list[str]:
    """Free checks of Mayer's multimedia principles (Mayer, Multimedia Learning; Clark & Mayer, e-Learning and the
    Science of Instruction), as short facts to fix:
      redundancy       the voice reads a designed slide aloud: the screen shows the structure, the voice explains
      personalization  the narration never speaks to the learner ("you"): conversational style
      signaling        (signaling=True, before the review) a process of 3+ parts shown all at once: build or
                       highlight shows which part the voice is on
    """
    out = []
    for i, sc in enumerate(scenes, 1):
        visual = sc.get("visual", "")
        if visual in NOT_DESIGNED:
            continue
        ratio = read_aloud_ratio(sc.get("narration", ""), screen_and_voice_text({**sc, "narration": ""}))
        if ratio >= READ_ALOUD_LIMIT:
            out.append(f"scene {i}: the voice reads the screen aloud ({ratio:.0%} of its phrases): explain and connect "
                       "instead, the screen already shows the words (redundancy)")
        parts = len(sc.get("elements") or sc.get("items") or [])
        if signaling and visual in PROCESS_LAYOUTS and parts >= 3 and (sc.get("animation") or "none") == "none":
            out.append(f"scene {i}: a {visual} of {parts} parts shown all at once: use build (or highlight) with cues, "
                       "so the learner sees which part the voice is on (signaling)")
    spoken = [sc.get("narration", "") for sc in scenes if sc.get("visual") not in ("question", "answer")]
    if len(spoken) >= 3 and not any(YOU.search(x) for x in spoken):
        out.append("the narration never speaks to the learner: say \"you\", as a trainer would (personalization)")
    return out


def screen_and_voice_text(scene: dict) -> str:
    """Everything the learner hears or sees in one scene."""
    parts = [scene.get("narration", ""), scene.get("heading", ""), scene.get("subheading", ""), *scene.get("items", [])]
    parts += [x for e in scene.get("elements", []) for x in (e.get("title", ""), e.get("detail", ""), e.get("value", ""))]
    parts += [x for col in scene.get("columns", []) for x in [col.get("heading", ""), *col.get("items", [])]]
    parts += [*scene.get("table_header", []), *(c for r in scene.get("table_rows", []) for c in r)]
    return "\n".join(p for p in parts if p)


def personal_data(sb: dict) -> tuple[list[str], list[str]]:
    """Compliance check: personal data must not leave the recordings. Returns (fail, issues):
    e-mail addresses and phone numbers fail the video; names of people who spoke in the source
    recordings (full name or surname) are flagged for a look."""
    fail, issues = [], []
    names: set[str] = set()
    for vid in {v.get("video_id") for v in sb.get("sources", {}).values() if v.get("video_id")}:
        try:
            meta = store.load_meta(vid)
        except FileNotFoundError:
            continue
        for sp in meta.get("speakers", []):
            words = [w for w in re.findall(r"[A-Za-zÀ-ž'-]+", sp) if len(w) > 2]
            if len(words) >= 2:
                names |= {" ".join(words), words[-1]}
    for i, sc in enumerate(sb["scenes"], 1):
        text = screen_and_voice_text(sc)
        if EMAIL.search(text):
            fail.append(f"scene {i}: contains an e-mail address")
        if PHONE.search(text):
            fail.append(f"scene {i}: contains a phone number")
        said = sorted(n for n in names if re.search(rf"\b{re.escape(n)}\b", text))
        if said:
            issues.append(f"scene {i}: names a person from the recording ({', '.join(said)})")
    return fail, issues


STOP = set("the and for with your that this from into what when then they them each more most over".split())


def screen_terms(scene: dict) -> list[str]:
    """The labels the screen shows as separate elements (titles, columns, rows, chart labels)."""
    out = [e.get("title", "") for e in scene.get("elements", [])] or list(scene.get("items", []))
    out += [c.get("heading", "") for c in scene.get("columns", [])]
    out += [r[0] for r in scene.get("table_rows", []) if r]
    out += scene.get("chart", {}).get("labels", []) if isinstance(scene.get("chart"), dict) else []
    return [x for x in out if x]


def screen_voice_match(scene: dict) -> float | None:
    """Share of the on-screen elements the voice talks about (by their key words, also as word
    stems: 'planning' matches 'plan'). None when the scene has fewer than 2 elements."""
    if scene.get("visual") in ("title", "question", "answer", "formula", "calculation"):
        return None
    terms = screen_terms(scene)
    if len(terms) < 2:
        return None
    spoken = {w[:5] for w in _words(scene.get("narration", "")) if len(w) > 2}
    hit = 0
    for t in terms:
        keys = [w[:5] for w in _words(t) if len(w) > 2 and w not in STOP] or [w[:5] for w in _words(t)]
        if keys and any(k in spoken for k in keys):
            hit += 1
    return hit / len(terms)


VISUAL_PROMPT = """You review one slide of a narrated corporate training video like a careful human editor.
While this slide is shown, the voice says:
"{narration}"
Answer in exactly this format, one line each:
READABLE: yes/no (all text is fully visible and readable, nothing cut off)
LAYOUT: yes/no (nothing overlaps, nothing is misaligned or squeezed, it looks professionally designed)
PICTURE: yes/no/none (any picture fits what the slide is about and looks natural; none = no picture)
APPROPRIATE: yes/no (professional and safe for work)
MATCHES_VOICE: yes/no (what is shown fits what the voice says)
PROBLEM: one short sentence, or none"""


def visual_review(out_dir: Path, sb: dict) -> list[str]:
    """The vision model looks at every finished slide (scenes/scene_NN.png) with its narration."""
    issues = []
    for i, sc in enumerate(sb["scenes"], 1):
        png = out_dir / "scenes" / f"scene_{i:02d}.png"
        if not png.exists():
            continue
        try:
            answer = llm.describe_image(png, VISUAL_PROMPT.format(narration=sc["narration"][:700]), step="visual_review")
        except llm.LLMError as e:
            issues.append(f"scene {i}: visual review failed ({str(e)[:80]})")
            continue
        f = {k.strip().upper(): v.strip() for k, v in (ln.split(":", 1) for ln in answer.splitlines() if ":" in ln)}
        bad = [k.lower() for k in ("READABLE", "LAYOUT", "PICTURE", "APPROPRIATE", "MATCHES_VOICE")
               if (f.get(k, "yes").lower().split() or ["yes"])[0].strip(".,;") == "no"]
        if bad:
            issues.append(f"scene {i}: visual review - {', '.join(bad)}: {f.get('PROBLEM', '')}"[:220])
    return issues


def repeated_chapters(sb: dict, n: int = 6, limit: float = 0.15) -> list[str]:
    """Course check: chapters that repeat earlier chapters (share of their n-word phrases already
    said before). A course should build up, not say the same thing twice."""
    chapters: dict[str, list[str]] = {}
    for sc in sb["scenes"]:
        if str(sc.get("section", "")).startswith("Chapter"):
            chapters.setdefault(sc["section"], []).append(sc["narration"])
    seen: set[tuple] = set()
    found = []
    for name, texts in chapters.items():
        words = _words(" ".join(texts))
        grams = {tuple(words[i:i + n]) for i in range(len(words) - n + 1)}
        if grams and len(grams & seen) / len(grams) > limit:
            found.append(f"{name} repeats earlier chapters ({len(grams & seen) / len(grams):.0%} of its phrases)")
        seen |= grams
    return found


NUMBER_WORDS = set("zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen "
                   "sixteen seventeen eighteen nineteen twenty thirty forty fifty sixty seventy eighty ninety "
                   "hundred thousand million billion percent point".split())
MAX_VOICE_WER = 0.1


def _spoken_words(text: str) -> list[str]:
    """Words for comparing a script with what Whisper heard: lower case, no punctuation, numbers
    left out (the voice says 'two', Whisper may write '2'), spelled-out letters joined ('k p i' = kpi)."""
    words = [w for w in re.findall(r"[a-z0-9']+", text.lower().replace("-", " ")) if w.strip("'")]
    words = [w.strip("'") for w in words if not w.isdigit() and w not in NUMBER_WORDS]
    out: list[str] = []
    run = False
    for w in words:
        if len(w) == 1 and run:          # k p i -> kpi
            out[-1] += w
            continue
        out.append(w)
        run = len(w) == 1 and w not in ("a", "i")
    return out


def heard_vs_script(script: str, heard: str, terms: set[str] | None = None) -> dict:
    """Word error rate of what was heard against the script, and the terms heard as something else."""
    import difflib
    a, b = _spoken_words(script), _spoken_words(heard)
    sm = difflib.SequenceMatcher(a=a, b=b, autojunk=False)
    errors, misheard = 0, []
    terms = {t.lower() for t in (terms or set())}
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            continue
        errors += max(i2 - i1, j2 - j1)
        if tag in ("replace", "delete"):
            for w in a[i1:i2]:
                if w in terms:
                    misheard.append(f"{w} (heard: {' '.join(b[j1:j2]) or 'nothing'})")
    return {"wer": round(errors / max(1, len(a)), 3), "misheard_terms": list(dict.fromkeys(misheard))}


def listen(out_dir: Path, sb: dict) -> tuple[dict, list[str]]:
    """Whisper on the finished voice vs the script. Returns (metrics, issues)."""
    from studio.knowledge import transcribe
    audio = out_dir / "lesson_audio.mp3"
    if not audio.exists():
        return {}, ["listen: no lesson_audio.mp3 (render the video first)"]
    try:
        heard = transcribe.transcribe_audio(audio)
    except (RuntimeError, media.MediaError, OSError) as e:
        return {}, [f"listen skipped: {e}"]
    written = " ".join(s["narration"] for s in sb["scenes"])
    known = tts.load_pronunciations()
    # compare with what the voice was given (pronunciation.csv applied: 'Nginx' -> 'engine x'), and look
    # for the terms that have no pronunciation yet
    script = tts.clean_for_speech(written)
    terms = {t for t in set(unusual_words(written, set())) | set(glossary_terms_in(written)) if t not in known}
    r = heard_vs_script(script, heard, terms)
    issues = []
    if r["wer"] > MAX_VOICE_WER:
        issues.append(f"listen: {r['wer']:.0%} of the words did not come out as written (check the voice)")
    if r["misheard_terms"]:
        issues.append("listen: terms heard as something else (add to pronunciation.csv): "
                      + ", ".join(r["misheard_terms"][:8]))
    (out_dir / "heard.txt").write_text(heard, encoding="utf-8")
    return {"voice_wer": r["wer"], "misheard_terms": r["misheard_terms"]}, issues


def glossary_terms_in(text: str) -> list[str]:
    """The glossary's terms (tools, names, acronyms of this material) that the text contains."""
    from studio.knowledge import glossary
    found = []
    for row in glossary.terms():
        t = row.get("term", "")
        if t and re.search(rf"(?<![\w-]){re.escape(t)}(?![\w-])", text):
            found.append(t)
    return found


def unusual_words(text: str, known: set[str]) -> list[str]:
    """Words a voice may say wrongly: acronyms (KPI), CamelCase (PowerBI), words with digits (Q3)."""
    found = re.findall(r"\b(?:[A-Z]{2,}s?|[A-Z][a-z]+[A-Z][A-Za-z]*|[A-Za-z]*\d[A-Za-z\d]*)\b", text)
    return sorted({w for w in found if w not in known and w not in COMMON_ACRONYMS and not w.isdigit()})


ITEM_WORD_LIMITS = {"concept": 20, "example": 14, "question": 10, "answer": 10, "title": 10, "cycle": 6, "hub": 7,
                    "timeline": 7}   # words per on-screen item by layout (else MAX_ITEM_WORDS)


def _length(sb: dict) -> tuple[list[str], dict]:
    """The narration's length against the length asked for. Returns (issues, metrics)."""
    words = sum(len(s["narration"].split()) for s in sb["scenes"])
    target = sb.get("stats", {}).get("target_words") or int(sb["minutes"] * storyboard.SPOKEN_WPM)
    metrics = {"words": words, "target_words": target, "length_ratio": round(words / max(target, 1), 2)}
    off = abs(words / max(target, 1) - 1) > LENGTH_TOLERANCE
    issues = [f"narration is {words} words, target {target}"] if off else []
    return issues, metrics


def _screen_texts(scenes: list[dict]) -> list[str]:
    """Scene by scene: original slides read aloud, shown twice or missing; on-screen texts and headings too long."""
    issues: list[str] = []
    seen_slides: set[str] = set()
    for i, sc in enumerate(scenes, 1):
        if sc["visual"] == "slide":
            ratio = read_aloud_ratio(sc["narration"], sc.get("slide_text", ""))
            if ratio >= READ_ALOUD_LIMIT:
                issues.append(f"scene {i}: narration reads the slide aloud ({ratio:.0%} of its phrases)")
            if sc.get("slide") in seen_slides:
                issues.append(f"scene {i}: slide {sc['slide']} shown twice")
            seen_slides.add(sc.get("slide", ""))
            if sc.get("slide_image") and not Path(sc["slide_image"]).exists():
                issues.append(f"scene {i}: slide image missing ({sc['slide_image']})")
        limit = ITEM_WORD_LIMITS.get(sc["visual"], MAX_ITEM_WORDS)
        long_items = [x for x in sc.get("items", []) if len(x.split()) > limit and not sc.get("elements")]
        long_items += [e["detail"] for e in sc.get("elements", []) if len(e.get("detail", "").split()) > 18]
        if long_items:
            issues.append(f"scene {i}: on-screen text too long: {long_items[0][:60]}")
        if sc["visual"] not in ("question", "answer") and len(sc.get("heading", "").split()) > MAX_HEADING_WORDS:
            issues.append(f"scene {i}: heading too long")
    return issues


def _safety_and_truth(scenes: list[dict]) -> tuple[list[str], list[str], dict]:
    """Inappropriate or sensitive words, numbers not in the sources, and how much of the screen the voice
    talks about. Returns (fail, issues, metrics)."""
    fail: list[str] = []
    issues: list[str] = []
    for i, sc in enumerate(scenes, 1):
        text = screen_and_voice_text(sc)
        if safety.blocked_terms(text):
            fail.append(f"scene {i}: inappropriate words: {', '.join(safety.blocked_terms(text))}")
        if safety.sensitive_terms(text):
            issues.append(f"scene {i}: sensitive words, have a look: {', '.join(safety.sensitive_terms(text))}")
        if sc.get("unverified"):
            fail.append(f"scene {i}: numbers on screen not found in the sources: {', '.join(sc['unverified'])}")
        match = screen_voice_match(sc)
        if match is not None and match < 0.5:
            issues.append(f"scene {i}: the voice talks about only {match:.0%} of what the screen shows")
    matches = [m for m in (screen_voice_match(s) for s in scenes) if m is not None]
    return fail, issues, {"screen_voice_match": round(sum(matches) / max(1, len(matches)), 2)}


def _render_findings(out_dir: Path, sb: dict, visual: bool) -> tuple[list[str], list[str]]:
    """What rendering found (layout the shrinking could not fix, silent or clipped voice) and, with `visual`,
    what a model sees on the frames. Returns (fail, issues)."""
    fail: list[str] = []
    issues: list[str] = []
    for scene_no, problems in (store.read_json(out_dir / "layout.json", {}) or {}).items():
        issues += [f"scene {scene_no}: {p}" for p in problems[:3]]
    for p in (store.read_json(out_dir / "info.json", {}) or {}).get("audio_issues", []):
        (fail if "silent" in p else issues).append(p)
    if visual and (out_dir / "scenes").exists():
        issues += visual_review(out_dir, sb)
    return fail, issues


def _words_to_listen_to(scenes: list[dict]) -> tuple[list[str], dict]:
    """Unusual words and glossary terms without a pronunciation entry. Returns (issues, metrics)."""
    known = set(tts.load_pronunciations())
    narration = " ".join(s["narration"] for s in scenes)
    odd = sorted(set(unusual_words(narration, known)) | {t for t in glossary_terms_in(narration) if t not in known})
    issues = ([f"listen to how these are spoken (add to pronunciation.csv if wrong): {', '.join(odd[:12])}"]
              if odd else [])
    return issues, {"words_to_listen_to": odd}


def _files_and_sync(out_dir: Path) -> tuple[list[str], list[str], dict, bool]:
    """Is it rendered, and do the mp4's video and audio tracks have the same length?
    Returns (fail, issues, metrics, planned_only)."""
    fail: list[str] = []
    issues: list[str] = []
    metrics: dict = {}
    video = out_dir / "lesson_video.mp4"
    planned_only = not any((out_dir / f).exists() for f in ("lesson_video.mp4", "slides.pdf", "lesson_audio.mp3"))
    if planned_only:
        issues.append("not rendered yet (storyboard only): uv run -m studio make_video --rerender <folder>")
        return fail, issues, metrics, planned_only
    if not video.exists():
        return fail, issues, metrics, planned_only
    try:
        d = media.stream_durations(video)
    except media.MediaError as e:
        return [f"mp4 unreadable: {e}"], issues, metrics, planned_only
    metrics["video_s"], metrics["audio_s"] = round(d.get("video", 0), 1), round(d.get("audio", 0), 1)
    gap = abs(d.get("video", 0) - d.get("audio", 0))
    if not d.get("video") or not d.get("audio"):
        fail.append("video or audio track missing in the mp4")
    elif gap > 2:
        fail.append(f"video and audio differ by {gap:.1f}s")
    elif gap > SYNC_TOLERANCE_S:
        issues.append(f"video and audio differ by {gap:.1f}s")
    return fail, issues, metrics, planned_only


def _model_review(result: dict, sb: dict, previous: dict, review: bool) -> None:
    """With `review`: a model grades the lesson and checks its claims against the sources. Without: the review
    of the same storyboard made before is kept (it costs money)."""
    if review:
        try:
            result["review"] = model_review(sb)
            result["claims"] = video_claims(sb)
        except llm.LLMError as e:
            result["review_error"] = str(e)[:300]
            log.warning("Review failed: %s", e)
    elif previous.get("review") and previous.get("storyboard_created") == sb.get("created"):
        result["review"] = previous["review"]
        if previous.get("claims"):
            result["claims"] = previous["claims"]


def check(out_dir: Path, review: bool = False, visual: bool = False, hear: bool = False) -> dict:
    """Run every check on one made video (or plan) and save the verdict in quality.json.

    Args:
        out_dir: the video's folder (storyboard.json, the mp4, layout.json, info.json).
        review: also let a model grade the lesson and check every claim (costs money).
        visual: also let a model look at the rendered frames.
        hear: also let Whisper listen to the voice (is every word spoken as written).

    Returns:
        {"status": OK | CHECK | FAIL | PLAN, "fail": [...], "issues": [...], "metrics": {...}, "review"?, "claims"?}
    """
    sb = storyboard.load(out_dir)
    scenes = sb["scenes"]
    issues, metrics = _length(sb)
    issues += sb.get("stats", {}).get("warnings", [])   # invented sources, scenes without sources ...
    issues += _screen_texts(scenes) + mayer_problems(scenes)
    fail, pii_issues = personal_data(sb)
    issues += pii_issues + repeated_chapters(sb)
    more_fail, more_issues, m = _safety_and_truth(scenes)
    fail += more_fail
    issues += more_issues
    metrics.update(m)
    more_fail, more_issues = _render_findings(out_dir, sb, visual)
    fail += more_fail
    issues += more_issues
    more_issues, m = _words_to_listen_to(scenes)
    issues += more_issues
    metrics.update(m)
    more_fail, more_issues, m, planned_only = _files_and_sync(out_dir)
    fail += more_fail
    issues += more_issues
    metrics.update(m)
    if hear and not planned_only:
        m, found = listen(out_dir, sb)
        metrics.update(m)
        issues += found
    result: dict[str, Any] = {"fail": list(dict.fromkeys(fail)), "issues": list(dict.fromkeys(issues)),
                              "metrics": metrics}
    _model_review(result, sb, store.read_json(out_dir / "quality.json", {}) or {}, review)
    result["storyboard_created"] = sb.get("created")
    result["status"] = _status(result, planned_only)
    store.write_json(out_dir / "quality.json", result)
    return result


def _status(result: dict, planned_only: bool) -> str:
    """FAIL if something is broken or the review finds invented content; PLAN if not rendered
    yet; CHECK if anything is worth a look; else OK."""
    review = result.get("review")
    if review and review["faithful"] <= 2:
        result["fail"].append(f"review: faithful {review['faithful']}/5")
    claims = result.get("claims") or {}
    if claims.get("unsupported"):
        result["fail"].append(f"claims the sources don't support ({len(claims['unsupported'])} of {claims['n_claims']}): "
                              + " | ".join(claims["unsupported"][:3])[:400])
    if claims.get("wrong_source"):
        result["issues"].append(f"claims credited to the wrong recording: {' | '.join(claims['wrong_source'][:3])[:300]}")
    if result["fail"]:
        return "FAIL"
    if planned_only:
        return "PLAN"
    if result["issues"] or (review and min(review["faithful"], review["level_fit"], review["clarity"]) <= 3):
        return "CHECK"
    return "OK"


def _excerpt(seg: dict) -> str:
    """What a reviewer sees of one excerpt: the slide on screen (its text and what it shows) and
    what was said. Without the slide, facts taken from it look invented."""
    slide = (seg.get("slide_text") or "")[:config.SLIDE_TEXT_CHARS]
    return (f"On screen: {slide}\n" if slide else "") + seg["text"][:1500]


SENTENCE = re.compile(r"(?<=[.!?])\s+")
MAX_CLAIM_SENTENCES = 60


def claim_check(units: list[tuple[str, list[str]]], sources: dict, title: str) -> dict:
    """Claim by claim, are the units (text, cited labels) supported by the excerpts they cite?
    The same judge and verdicts as the answers to questions (qa_eval.grounding)."""
    from studio.quality import qa_eval
    segments = store.all_segments()
    excerpts = {}
    for label, src in sources.items():
        seg = segments.get(src.get("segment_id", ""))
        if seg:
            excerpts[label] = {"title": seg.get("title", ""), "video_id": seg.get("video_id", ""),
                               "where": store.fmt_ts(seg.get("start", 0)) if seg.get("kind") != "document" else seg.get("where", ""),
                               "text": seg["text"], "slide_text": (seg.get("slide_text") or "")[:config.SLIDE_TEXT_CHARS]}
    sentences = []
    for text, cites in units:
        # a scene without sources (an intro, a summary) is checked against all the lesson's excerpts:
        # otherwise every claim in it would look credited to the wrong recording
        own = [c for c in cites if c in excerpts] or list(excerpts)
        for sent in SENTENCE.split(text.strip()):
            if len(sent.split()) >= 3 and not sent.rstrip().endswith("?"):   # a question claims nothing
                sentences.append({"text": sent, "sources": own})
    sentences = sentences[:MAX_CLAIM_SENTENCES]
    if not sentences or not excerpts:
        return {}
    rec = {"question": f"(a lesson) {title}", "excerpts": excerpts, "sentences": sentences}
    res = qa_eval.grounding(rec, qa_eval.judge_model(None))
    return {k: res[k] for k in ("n_claims", "faithfulness", "hallucination_rate", "unsupported", "wrong_source")}


def video_claims(sb: dict) -> dict:
    """The claim check of a video: narration and on-screen points of every scene. Not the title, nor a quiz
    question: it asks, its options are meant to be partly wrong, and the answer scene states the facts."""
    units = []
    for sc in sb["scenes"]:
        if sc["visual"] in ("title", "question"):
            continue
        screen = "; ".join(sc.get("items", []))
        units.append((sc["narration"], sc.get("sources", [])))
        if screen:
            units.append((f"On screen: {screen}.", sc.get("sources", [])))
    return claim_check(units, sb.get("sources", {}), sb.get("title", ""))


def document_claims(record: dict) -> dict:
    """The claim check of a written lesson: the text of every section against what it cites."""
    units = []
    for s in record["lesson"]["sections"]:
        text = " ".join([s["body"], *[p.rstrip(".") + "." for p in s.get("points", [])], s.get("example", ""),
                         s.get("remember", "")])
        units.append((text, s.get("sources", [])))
    return claim_check(units, record.get("sources", {}), record["lesson"].get("title", ""))


def model_review(sb: dict) -> dict:
    """Ask the review model to score the storyboard against the excerpts each scene cites."""
    segments = store.all_segments()
    blocks = []
    for i, sc in enumerate(sb["scenes"], 1):
        screen = sc["visual"] + (f" ({sc['heading']})" if sc.get("heading") else "")
        if sc.get("items"):
            screen += ": " + "; ".join(sc["items"])
        cited = []
        for label in sc.get("sources", []):
            seg = segments.get(sb.get("sources", {}).get(label, {}).get("segment_id", ""))
            if seg:
                cited.append(f"[{label}] {_excerpt(seg)}")
        blocks.append(f"SCENE {i}\nScreen: {screen}\nNarration: {sc['narration']}\n"
                      f"Excerpts:\n" + ("\n".join(cited) or "(none cited)"))
    prompt = f"Lesson: {sb['title']}\nGoal: {sb['goal']}\n\n" + "\n\n".join(blocks)
    level = sb.get("level", "beginner")
    data = llm.chat_json(prompt, REVIEW_SCHEMA, system=REVIEW_PROMPT.format(level=f"{level} ({lesson.LEVELS.get(level, '')})"),
                         step="review", model=config.REVIEW_MODEL or None, max_tokens=1500, temperature=0.0)
    for key in ("faithful", "level_fit", "clarity"):
        data[key] = max(1, min(5, int(data.get(key, 0) or 0)))
    data["issues"] = [i for i in data.get("issues", []) if isinstance(i, dict)][:15]
    return data


DOC_REVIEW_PROMPT = """You review a written lesson made from internal training material.
For each section you get its text and the source excerpts it cites. Score from 1 (bad) to 5 (very good):
- faithful: every statement is supported by the excerpts (no invented facts, numbers, names or examples)
- level_fit: suits a {level} learner
- clarity: easy to read and well structured
List concrete problems with the section number as "scene" (empty list if none). Be strict but fair."""


def document_review(record: dict) -> dict:
    """The review model scores a written lesson against the excerpts each section cites."""
    segments = store.all_segments()
    blocks = []
    for i, s in enumerate(record["lesson"]["sections"], 1):
        cited = [f"[{x}] {_excerpt(segments[record['sources'][x]['segment_id']])}" for x in s.get("sources", [])
                 if x in record["sources"] and record["sources"][x]["segment_id"] in segments]
        text = "\n".join([s["body"], *s.get("points", []), s.get("example", ""), s.get("remember", "")]
                         + [" | ".join(r) for r in ((s.get("table") or {}).get("rows") or [])])
        blocks.append(f"SECTION {i}: {s['heading']}\n{text}\nExcerpts:\n" + ("\n".join(cited) or "(none cited)"))
    les = record["lesson"]
    extra = "\n".join([les.get("overview", ""), *les.get("takeaways", []), les.get("summary", "")]
                      + [f"Q: {q['question']} A: {q['answer']}" for q in les.get("questions", [])])
    prompt = f"Lesson: {les['title']}\n\n" + "\n\n".join(blocks) + f"\n\nOVERVIEW, TAKEAWAYS, SUMMARY, QUIZ\n{extra}"
    level = record.get("level", "beginner")
    data = llm.chat_json(prompt, REVIEW_SCHEMA, system=DOC_REVIEW_PROMPT.format(level=f"{level} ({lesson.LEVELS.get(level, '')})"),
                         step="review", model=config.REVIEW_MODEL or None, max_tokens=1500, temperature=0.0)
    for key in ("faithful", "level_fit", "clarity"):
        data[key] = max(1, min(5, int(data.get(key, 0) or 0)))
    data["issues"] = [i for i in data.get("issues", []) if isinstance(i, dict)][:15]
    return data


def check_document(out_dir: Path, review: bool = False) -> dict:
    """Checks of a written lesson (lesson.json): inappropriate words, personal data, numbers not
    in the sources, sections without sources, length; optionally the review model. Saves quality.json."""
    record = store.read_json(out_dir / "lesson.json", {})
    st = record.get("stats", {})
    les = lesson.Lesson.model_validate(record["lesson"])
    text = lesson.lesson_text(les)
    fail, issues = [], []
    if safety.blocked_terms(text):
        fail.append(f"inappropriate words: {', '.join(safety.blocked_terms(text))}")
    if safety.sensitive_terms(text):
        issues.append(f"sensitive words, have a look: {', '.join(safety.sensitive_terms(text))}")
    if EMAIL.search(text):
        fail.append("contains an e-mail address")
    if PHONE.search(text):
        fail.append("contains a phone number")
    if st.get("unverified_numbers"):
        fail.append(f"numbers not found in the sources: {', '.join(st['unverified_numbers'])}")
    if st.get("invalid_citations"):
        issues.append(f"invented source labels were removed: {st['invalid_citations']}")
    if st.get("sections_without_sources"):
        issues.append(f"sections without sources: {', '.join(st['sections_without_sources'])}")
    if st and not st.get("length_ok", True):
        issues.append(f"length {st['words']} words vs target {st['target_words']}")
    result = {"kind": "document", "fail": fail, "issues": issues,
              "metrics": {k: st.get(k) for k in ("words", "target_words", "excerpts_cited")}}
    previous = store.read_json(out_dir / "quality.json", {}) or {}
    if review:
        try:
            result["review"] = document_review(record)
            result["claims"] = document_claims(record)
        except llm.LLMError as e:
            result["review_error"] = str(e)[:300]
            log.warning("Review failed: %s", e)
    elif previous.get("review"):
        result["review"] = previous["review"]
        if previous.get("claims"):
            result["claims"] = previous["claims"]
    result["status"] = _status(result, planned_only=False)
    store.write_json(out_dir / "quality.json", result)
    return result


def check_any(out_dir: Path, review: bool = False, visual: bool = False, hear: bool = False) -> dict:
    """The right checks for any output folder: a document, slides or a video. The verdict (and
    the cost of the review) is added to the result's run card."""
    from studio.core import runcard
    mark = llm.meter_mark()
    if (out_dir / "lesson.json").exists() and not (out_dir / "storyboard.json").exists():
        result = check_document(out_dir, review)
    else:
        result = check(out_dir, review, visual, hear)
    runcard.add_quality(out_dir, result, llm.calls_since(mark))
    return result


def video_folders() -> list[Path]:
    """Every output folder (videos, slides, documents), newest first."""
    if not config.OUTPUT_DIR.exists():
        return []
    found = {p.parent for pat in ("*/storyboard.json", "*/lesson.json") for p in config.OUTPUT_DIR.glob(pat)}
    return sorted(found, reverse=True)


def main() -> int:
    """Command line: check made results (--review, --visual, --listen). Returns the exit code."""
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("folder", nargs="?", type=Path, help="an output folder (video, slides or document)")
    ap.add_argument("--all", action="store_true", help="check every output folder")
    ap.add_argument("--review", action="store_true", help="also the model review and the claim check (~$0.02-0.05 each)")
    ap.add_argument("--visual", action="store_true", help="the vision model looks at every slide (~$0.005 per slide)")
    ap.add_argument("--listen", action="store_true", help="Whisper listens to the voice and compares it with the script (free, local)")
    args = ap.parse_args()
    config.setup_logging()
    folders = video_folders() if args.all else ([args.folder] if args.folder else [])
    if not folders:
        ap.error("give a folder or --all")
    worst = 0
    for folder in folders:
        try:
            r = check_any(folder, args.review, args.visual, args.listen)
        except (RuntimeError, ValueError, OSError) as e:
            log.error("%s: %s", folder.name, e)
            worst = 2
            continue
        print(f"\n[{r['status']}] {folder.name}")
        for line in r["fail"] + r["issues"]:
            print(f"   - {line}")
        if "review" in r:
            rv = r["review"]
            print(f"   review: faithful {rv['faithful']}/5, level {rv['level_fit']}/5, clarity {rv['clarity']}/5")
            for i in rv["issues"]:
                print(f"     scene {i.get('scene')}: {i.get('problem')}")
        if r.get("claims"):
            c = r["claims"]
            print(f"   claims: {c['n_claims']} checked, faithfulness {c['faithfulness']}, "
                  f"not supported {len(c['unsupported'])}")
        worst = max(worst, {"OK": 0, "PLAN": 0, "CHECK": 1, "FAIL": 2}[r["status"]])
    print("\nAll results side by side: uv run -m studio compare, or Lesson Studio (uv run -m studio app)")
    return 1 if worst == 2 else 0


if __name__ == "__main__":
    sys.exit(main())
