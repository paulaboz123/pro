"""
qa_eval.py - measures how good the text answers are (answer.py), on a set of test questions:
does it find the right information, is every statement true to the material (no hallucination),
is it complete and on the point, does it decline what the material doesn't cover, is it written
in own words, and does every sentence say where it comes from.

  uv run -m studio qa_eval --draft 20        # writes eval/qa_set.csv from your material: check and edit it in Excel
  uv run -m studio qa_eval                   # answers every question and scores it -> data/output/<time>-qa-eval/
  uv run -m studio qa_eval --compare         # the same set with each retrieval mode, side by side (before / after)
  uv run -m studio qa_eval --limit 5         # the first 5 questions; --ids q01,q07 for chosen ones
  uv run -m studio qa_eval --model <id> --judge <id>    # writer and judge models (default CHAT_MODEL, JUDGE_MODEL)
  uv run -m studio qa_eval --set "Video_Accuracy_Test_Plan.xlsx"    # a test plan in Excel, as it is (see below)

eval/qa_set.csv, one row per question (add questions any time):
  id                q01, q02 ...
  type              general | specific | out_of_scope (the material does not answer it: the right
                    result is "not covered", a test for hallucination)
  question          as a learner would ask it
  expected_answer   what a good answer says (optional; then correctness is scored)
  key_facts         facts a good answer must contain, separated by ';' (optional; the strongest check
                    that nothing important is lost)
  expected_sources  where the answer is: a title (or part of it), optionally @time, separated by ';'
                    e.g. "Scrum basics@03:10; Scrum Guide" (optional; then retrieval is scored)
  length            short | medium | long (optional, default short)
  notes

A test plan in Excel (.xlsx) is read as it is: the header row is found by its names (Test ID,
Category, Prompt, Source Video (ID+name), Expected fact; other columns are ignored). Rows with the
same Test ID (or the same prompt) are one question with several expected videos and facts; empty
merged cells take the value above. "4 - Data tools" is matched by its number 4 (catalog_id in
description.xlsx) or by its name. Categories such as "out of scope", "negative" or "hallucination"
expect the answer "not covered". The results are also written into a copy of the plan
(<name>_results.xlsx): the answer, its sources (video, time), whether each row's expected fact is in
the answer and its video was found, claims not in the sources, and the verdict.

Result folder: qa_report.html and qa_report.md (scorecard, failures with reasons, every answer with
its sources and timestamps, how each metric is measured and why), qa_results.csv (one row per
question, with empty columns for your own verdict), and each answer's own folder.
"""
from __future__ import annotations

import argparse
import csv
import html
import json
import logging
import random
import re
import sys
import time
from datetime import datetime
from functools import partial
from pathlib import Path
from typing import Any

from studio.core import config, llm, store
from studio.generation import answer as answer_mod
from studio.knowledge import retrieval

log = logging.getLogger("qa_eval")

def qa_set_path() -> Path:
    """The default test set (eval/qa_set.csv)."""
    return config.EVAL_DIR / "qa_set.csv"
SET_FIELDS = ["id", "type", "question", "expected_answer", "key_facts", "expected_sources", "length", "notes"]
TYPES = ("general", "specific", "out_of_scope")


# --- The judges ---------------------------------------------------------------------------------------
GROUNDING = """You check every claim of an answer against the training excerpts, strictly. The excerpts are grouped
by recording; each answer sentence says which excerpts it cites. Split each sentence into its separate factual
claims and decide for each, using ONLY the excerpts (spoken text and what was on screen), not your own knowledge:
supported = the cited excerpts, or other excerpts of the same recording, state it (a paraphrase, a summary or a
count of items they list is fine); partial = only part of it is stated, or it is stated more strongly than the
excerpts do; wrong_source = only a recording the sentence does NOT cite states it; unsupported = no excerpt states
it (even if it is true in general); contradicted = the excerpts say something different.
Only statements of fact are claims. A question to the learner, an instruction to the learner ("pause and think",
"try it yourself"), an announcement of what comes next ("here is a question", "let's look at") or a greeting states
nothing about the material: leave it out.
Give a short reason for anything not supported."""

GROUNDING_SCHEMA = {"type": "object", "properties": {"claims": {"type": "array", "items": {"type": "object", "properties": {
    "sentence": {"type": "integer"}, "claim": {"type": "string"},
    "verdict": {"type": "string", "enum": ["supported", "partial", "wrong_source", "unsupported", "contradicted"]},
    "reason": {"type": "string"}}, "required": ["sentence", "claim", "verdict"]}}}, "required": ["claims"]}

GRADING = """You grade an answer to a learner's question, strictly and fairly. You get the question, the answer, the
excerpts the system found in the training material, and (when there is one) the expected answer and key facts.
Score 1-5 (5 best):
relevance     it answers exactly what was asked, with the most important information first, nothing off the point
completeness  it contains the most important information that the excerpts give for this question
correctness   it agrees with the expected answer (0 if there is no expected answer)
clarity       clear, well structured, easy for a learner
For each key fact say: yes (contained, in any wording), partial, or no.
Some key facts are expectations, not facts ("should say this is not in the video", "must not give a
number", "should not invent tools", or starting with "PASS CRITERION"): a behaviour check. Say yes if the
answer behaves that way (it says the material does not cover it, corrects a false premise, or leaves the
thing out), no if it does not (it states the thing anyway).
For each fact that is contained, also give the numbers of the answer sentences that state it (from the
numbered list of answer sentences)."""

GRADING_SCHEMA = {"type": "object", "properties": {
    "relevance": {"type": "integer"}, "completeness": {"type": "integer"}, "correctness": {"type": "integer"},
    "clarity": {"type": "integer"},
    "facts": {"type": "array", "items": {"type": "object", "properties": {
        "fact": {"type": "string"}, "found": {"type": "string", "enum": ["yes", "partial", "no"]},
        "sentences": {"type": "array", "items": {"type": "integer"}}},
        "required": ["fact", "found"]}},
    "comment": {"type": "string"}}, "required": ["relevance", "completeness", "correctness", "clarity", "facts"]}

POINTS = {"supported": 1.0, "partial": 0.5, "wrong_source": 0.0, "unsupported": 0.0, "contradicted": 0.0}


def judge_model(args_judge: str | None = None) -> str:
    """The model that grades the answers: --judge, else JUDGE_MODEL, REVIEW_MODEL or CHAT_MODEL."""
    return args_judge or config.JUDGE_MODEL or config.REVIEW_MODEL or config.CHAT_MODEL


def judges_itself(judge: str, writer: str | None = None) -> bool:
    """True when the judge is the model that wrote the answers: models grade their own text more
    leniently (and share its blind spots), so its counts are less trustworthy."""
    return judge.strip().lower() == (writer or config.CHAT_MODEL).strip().lower()


def claim_rows(rec: dict, claims: list[dict]) -> list[dict]:
    """The judge's claims with what it saw, for a person to check (calibrate.py)."""
    sents = rec.get("sentences", [])
    out = []
    for c in claims:
        n = c.get("sentence")
        sent = sents[n - 1] if isinstance(n, int) and 1 <= n <= len(sents) else {}
        cites = [x for x in sent.get("sources", []) if x in rec["excerpts"]] or list(rec["excerpts"])[:3]
        evidence = "\n\n".join(f"[{x}] {rec['excerpts'][x].get('title', '')} ({rec['excerpts'][x].get('where', '')})\n"
                               f"{excerpt_text(rec['excerpts'][x])}" for x in cites)
        out.append({"sentence": sent.get("text", ""), "cites": ", ".join(sent.get("sources", [])),
                    "claim": c.get("claim", ""), "verdict": c.get("verdict", ""), "reason": c.get("reason", ""),
                    "evidence": evidence[:6000]})
    return out


def excerpt_text(e: dict) -> str:
    """An excerpt as the writer saw it: what was on screen, then what was said."""
    return (f"On screen: {e['slide_text']}\n" if e.get("slide_text") else "") + e.get("text", "")


def grounding(rec: dict, model: str) -> dict:
    """Claim by claim: do the excerpts of the cited recording say it? (The plan's rule: the right video.)"""
    by_rec: dict[str, list[str]] = {}
    for k, e in rec["excerpts"].items():
        by_rec.setdefault(e.get("title") or e.get("video_id", ""), []).append(f"[{k}] ({e.get('where', '')}) {excerpt_text(e)}")
    excerpts = "\n\n".join(f'## Recording "{t}"\n' + "\n".join(v) for t, v in by_rec.items())
    sentences = "\n".join(f"SENTENCE {n}: {s['text']}\n  cites: {', '.join(s['sources']) or 'nothing'}"
                          for n, s in enumerate(rec["sentences"], 1))
    out = llm.chat_json(f"Question: {rec['question']}\n\nEXCERPTS\n{excerpts}\n\nANSWER\n{sentences}", GROUNDING_SCHEMA,
                        system=GROUNDING, step="judge grounding", model=model, temperature=0.0, max_tokens=4000)
    claims = [c for c in out.get("claims", []) if c.get("verdict") in POINTS]
    n = len(claims)
    bad = [c for c in claims if c["verdict"] in ("unsupported", "contradicted")]
    wrong = [c for c in claims if c["verdict"] == "wrong_source"]
    return {"claims": claims, "n_claims": n,
            "faithfulness": round(sum(POINTS[c["verdict"]] for c in claims) / n, 3) if n else None,
            "hallucination_rate": round(len(bad) / n, 3) if n else None,
            "unsupported": [f"{c['claim']} ({c['verdict']}: {c.get('reason', '')})" for c in bad],
            "wrong_source": [f"{c['claim']} ({c.get('reason', '')})" for c in wrong]}


FOUND = {"yes": 1.0, "partial": 0.5, "no": 0.0}


def _key_facts(row: dict) -> list[str]:
    return row.get("_facts") or [f.strip() for f in (row.get("key_facts") or "").split(";") if f.strip()]


def _fact_verdicts(facts: list[str], judged: list[dict], n_sentences: int) -> tuple[list[tuple[str, str]], dict[str, list[int]]]:
    """The judge's verdict for each key fact (same text, else same position) and the answer sentences that say it."""
    per_fact: list[tuple[str, str]] = []
    where: dict[str, list[int]] = {}
    for i, fact in enumerate(facts):
        hit = next((f for f in judged if (f.get("fact") or "").strip().lower() == fact.lower()), None)
        hit = hit or (judged[i] if i < len(judged) else {})
        per_fact.append((fact, str(hit.get("found")) if hit.get("found") in FOUND else "no"))
        where[fact] = sorted({int(n) for n in hit.get("sentences") or [] if str(n).isdigit() and 1 <= int(n) <= n_sentences})
    return per_fact, where


def _score(v: Any) -> int:
    """A 0-5 grade, whatever the judge returned."""
    return max(0, min(5, int(v or 0)))


def grading(rec: dict, row: dict, model: str) -> dict:
    """The judge's grades of one answer: relevance, key facts and the claims checked against the excerpts."""
    facts = _key_facts(row)
    excerpts = "\n".join(f"[{k}] {excerpt_text(e)}" for k, e in rec["excerpts"].items())
    numbered = "\n".join(f"[{n}] {x['text']}" for n, x in enumerate(rec.get("sentences", []), 1)) or "(none)"
    prompt = (f"Question: {rec['question']}\n\nAnswer:\n{rec['text']}\n\nExcerpts found:\n{excerpts}\n\n"
              f"Answer sentences, numbered:\n{numbered}\n\n"
              f"Expected answer: {row.get('expected_answer') or '(none)'}\n"
              f"Key facts:\n" + ("\n".join(f"- {f}" for f in facts) or "(none)"))
    out = llm.chat_json(prompt, GRADING_SCHEMA, system=GRADING, step="judge grading", model=model, temperature=0.0,
                        max_tokens=1500)
    per_fact, where = _fact_verdicts(facts, out.get("facts", []), len(rec.get("sentences", [])))
    got = [FOUND[v] for _, v in per_fact]
    return {"relevance": _score(out.get("relevance")), "completeness": _score(out.get("completeness")),
            "correctness": _score(out.get("correctness")) if row.get("expected_answer") else None,
            "clarity": _score(out.get("clarity")),
            "key_fact_recall": round(sum(got) / len(facts), 3) if facts else None,
            "missing_facts": [f for f, v in per_fact if v == "no"], "fact_results": per_fact,
            "fact_sentences": where, "comment": out.get("comment", "")}


# --- Retrieval scores (no model) ------------------------------------------------------------------------
def parse_sources(spec: str) -> list[tuple[str, float | None]]:
    """'Scrum basics@03:10; Scrum Guide' -> [('scrum basics', 190.0), ('scrum guide', None)]."""
    out = []
    for part in (spec or "").split(";"):
        title, _, at = part.strip().partition("@")
        if not title.strip():
            continue
        seconds = None
        if at.strip():
            nums = [float(x) for x in re.findall(r"\d+(?:\.\d+)?", at)]
            seconds = sum(v * 60 ** i for i, v in enumerate(reversed(nums))) if nums else None
        out.append((title.strip().lower(), seconds))
    return out


def matches(seg: dict, title: str, seconds: float | None) -> bool:
    """Whether an excerpt is from the expected recording (and near the expected time, ±45 s)."""
    if title not in (seg.get("title", "") or "").lower() and title != seg.get("video_id", "").lower():
        return False
    return seconds is None or (seg.get("start", 0) - 45 <= seconds <= seg.get("end", 0) + 45)


def same_video(seg: dict, cid: str, name: str) -> bool:
    """"4 - Data tools": the recording with catalog_id 4, or with that name in its title."""
    if cid and str(seg.get("catalog_id", "")) == cid:
        return True
    a, b = set(re.findall(r"[a-z0-9]+", name.lower())), set(re.findall(r"[a-z0-9]+", (seg.get("title") or "").lower()))
    return bool(a) and len(a & b) / len(a) >= 0.75


def parse_video(spec: str) -> tuple[str, str]:
    """'4 - Data tools' -> ('4', 'Data tools'); 'Data tools' -> ('', 'Data tools')."""
    m = re.match(r"\s*#?(\d+)\s*[-\u2013\u2014.:)]*\s*(.*)$", spec or "")
    return (m.group(1), m.group(2).strip(" -\u2013\u2014")) if m else ("", (spec or "").strip(" -\u2013\u2014"))


def no_video(cell: str) -> bool:
    """'', '-', '—', '–', 'n/a', 'none' ... = the test names no video."""
    text = (cell or "").strip().lower()
    return not re.sub(r"[\W_]+", "", text) or text in ("n/a", "na", "none", "no video", "not applicable")


def _source_tests(row: dict, with_time: bool) -> list[tuple[str, Any]]:
    """(name, test of an excerpt) per expected source: whole videos by number or name in a test plan, else titles
    (near the given time when `with_time`)."""
    if row.get("_sources"):
        return [(f"{cid} - {name}".strip(" -"), partial(same_video, cid=cid, name=name)) for cid, name in row["_sources"]]
    found = parse_sources(row.get("expected_sources", ""))
    if not with_time:
        return [(title, partial(matches, title=title, seconds=None)) for title, _ in found]
    return [(title + (f"@{store.fmt_ts(s)}" if s is not None else ""), partial(matches, title=title, seconds=s))
            for title, s in found]


def retrieval_scores(rec: dict, row: dict) -> dict:
    """Did the search find where the answer is? hit = among the excerpts the answer was written
    from (every expected video, when there are several); rank = place of the first right excerpt
    among all candidates (1 = first); cited = the answer cites it. Per expected video too."""
    segs = store.all_segments()
    tests = _source_tests(row, with_time=True)
    if not tests:
        return {"retrieval_hit": None, "reciprocal_rank": None, "cited_expected": None, "source_results": []}
    kept = [i for i in rec.get("kept", []) if i in segs]
    cited_ids = {rec["excerpts"][x]["id"] for s in rec.get("sentences", []) for x in s["sources"] if x in rec.get("excerpts", {})}
    per: list[dict[str, Any]] = [{"source": name, "found": any(test(segs[i]) for i in kept),
            "cited": any(test(segs[i]) for i in cited_ids if i in segs)} for name, test in tests]
    ok = lambda sid: sid in segs and any(test(segs[sid]) for _, test in tests)  # noqa: E731
    rank = next((i for i, c in enumerate(rec.get("candidates", []), 1) if ok(c["id"])), None)
    return {"retrieval_hit": round(sum(p["found"] for p in per) / len(per), 3),
            "reciprocal_rank": round(1 / rank, 3) if rank else 0.0,
            "cited_expected": round(sum(p["cited"] for p in per) / len(per), 3) if rec.get("sentences") else 0.0,
            "source_results": per}


def missing_sources(row: dict, segs: dict | None = None) -> list[str]:
    """The expected recordings that are not in the library at all (never received or never processed):
    a test that needs them can't pass whatever the system does, so it is skipped, not failed."""
    segs = store.all_segments() if segs is None else segs
    tests = _source_tests(row, with_time=False)
    return [name for name, test in tests if not any(test(s) for s in segs.values())]


def skipped(row: dict, mode: str, missing: list[str]) -> dict:
    """The result of a test that cannot pass because its recording is not in the library."""
    return {"id": row["id"], "type": row.get("type", ""), "category": row.get("category", ""), "question": row["question"],
            "mode": mode, "answered": False, "abstain_correct": False, "answer": "", "sources": "",
            "invalid_labels": 0, "unsourced_sentences": 0, "numbers_not_in_sources": 0, "cost_usd": 0.0,
            "judge_cost_usd": 0.0, "seconds": 0.0, "passed": False, "skipped": True,
            "why": f"SKIP: expected recording not in the library: {', '.join(missing)} (add it to data/input, then run "
                   f"pipeline.py)", "folder": ""}


# --- One question -------------------------------------------------------------------------------------
def _source_list(rec: dict) -> str:
    return "; ".join(f"[{s['n']}] {s['title']} · {s['where']}" + (f" (quote at {', '.join(s['at'])})" if s.get("at") else "")
                     for s in rec.get("sources", []))


def _checked(row: dict, rec: dict, mode: str) -> dict:
    """An answer's result before the judge: what it said, the code checks and the retrieval scores."""
    answered = not rec["not_in_material"]
    c = rec.get("checks") or {}
    verified = c.get("verified") or {}
    return {"id": row["id"], "type": row.get("type", ""), "category": row.get("category", ""), "question": row["question"],
            "mode": rec.get("mode", mode), "answered": answered,
            "abstain_correct": answered != (row.get("type") == "out_of_scope"), "answer": rec["text"],
            "sources": _source_list(rec),
            "evidence_verified": c.get("evidence_verified"), "unsourced_sentences": c.get("unsourced_sentences", 0),
            "invalid_labels": len(c.get("invalid_labels", [])), "numbers_not_in_sources": len(c.get("numbers_not_in_sources", [])),
            "copy_rate": c.get("copy_rate"), "longest_copy_words": c.get("longest_copy_words"), "words": c.get("words", 0),
            "removed_by_check": len(verified.get("removed") or []) + int(verified.get("corrected") or 0),
            "searched_again": int(bool(rec.get("retried"))),
            "folder": Path(rec.get("folder", "")).name, **retrieval_scores(rec, row)}


def _judged(res: dict, rec: dict, row: dict, judge: str) -> None:
    """The judge's grounding and grades added to the result; a failing judge is noted, not raised."""
    try:
        g = grounding(rec, judge)
        res.update({k: g[k] for k in ("n_claims", "faithfulness", "hallucination_rate")},
                   unsupported_claims=" | ".join(g["unsupported"]), wrong_source_claims=" | ".join(g["wrong_source"]))
        res["_claims"] = claim_rows(rec, g["claims"])
        res.update(grading(rec, row, judge))
    except llm.LLMError as e:
        res["judge_error"] = str(e)[:200]
        log.warning("%s: the judge (%s) failed, so faithfulness and key facts are missing: %s",
                    row["id"], judge, str(e)[:300])


def _attributed(res: dict, rec: dict, row: dict) -> None:
    """Which recordings the answer cites for each fact, and cites outside the ones the question names."""
    excerpts = rec.get("excerpts", {})
    cited = [excerpts[x] for s in rec.get("sentences", []) for x in s["sources"] if x in excerpts]
    res["n_facts"] = len(_key_facts(row))
    res["fact_attribution"] = fact_attribution(rec, row, res)
    res["misattributed"] = "; ".join(f"'{a['fact'][:60]}' cited to {', '.join(a['titles']) or 'nothing'} instead of "
                                     f"{a['source']}" for a in res["fact_attribution"] if a["cited"] is False)
    named = set(rec.get("scope") or [])
    res["other_sources"] = sorted({e["title"] for e in cited if named and e["video_id"] not in named})
    res["attribution"] = attribution(res, bool(cited))
    res["other_sources"] = ", ".join(res["other_sources"])


def _why(res: dict, row: dict, rec: dict) -> None:
    """The verdict and its reasons, with a failed judge and a named recording not found added."""
    res["passed"], res["why"] = verdict(res, row)
    extra = []
    if res.get("judge_error"):
        extra.append("judge failed: " + res["judge_error"][:120])
    if rec.get("named_not_found"):   # the question names a recording we could not find: say so in the report
        extra.append("named recording not found: " + ", ".join(rec["named_not_found"]))
    res["why"] = "; ".join(x for x in (res["why"], *extra) if x)


def evaluate(row: dict, mode: str, model: str | None, judge: str, use_judge: bool = True) -> dict:
    """Answer one test question and score it (code checks, retrieval, the judge, the verdict)."""
    missing = missing_sources(row)
    if missing:   # nothing is paid for a test that can't pass
        log.warning("%s: SKIP, its expected recording is not in the library: %s", row["id"], ", ".join(missing))
        return skipped(row, mode, missing)
    t0 = time.perf_counter()
    rec = answer_mod.answer(row["question"], row.get("length") or "short", "beginner", mode, model,
                            use_cache=False)   # measured every time, never an answer made before
    res = _checked(row, rec, mode)
    mark = llm.meter_mark()
    if res["answered"] and use_judge:
        _judged(res, rec, row, judge)
    res.update(cost_usd=round(rec["cost_usd"], 5), judge_cost_usd=round(sum(x["cost_usd"] for x in llm.calls_since(mark)), 5),
               seconds=round(time.perf_counter() - t0, 1))
    _attributed(res, rec, row)
    _why(res, row, rec)
    if not res["answered"] and row.get("type") != "out_of_scope":
        log.warning("%s: no answer - %s", row["id"], rec["text"][:200].replace("\n", " "))
    return res


def fact_attribution(rec: dict, row: dict, res: dict) -> list[dict]:
    """For each expected fact that names its video (the Excel plan, one row per fact): do the
    answer sentences that state it cite that video? cited None = the fact is not in the answer, or
    the judge did not say where."""
    segs = store.all_segments()
    found = dict(res.get("fact_results") or [])
    where = res.get("fact_sentences") or {}
    out = []
    for place in row.get("_rows", []):
        if not place["fact"] or no_video(place["source"]):
            continue
        cid, name = parse_video(place["source"])
        nums = where.get(place["fact"]) or []
        ids = [rec["excerpts"][x]["id"] for n in nums for x in rec["sentences"][n - 1]["sources"] if x in rec["excerpts"]]
        cited = None
        if found.get(place["fact"]) in ("yes", "partial") and ids:
            cited = any(i in segs and same_video(segs[i], cid, name) for i in ids)
        out.append({"fact": place["fact"], "source": place["source"], "cited": cited,
                    "titles": sorted({segs[i]["title"] for i in ids if i in segs})})
    return out


def attribution(r: dict, cites: bool) -> str:
    """The test plan's 'Hallucination / wrong attribution noted?': Major = an invented or contradicted
    claim, a number not in the sources, an invented source, or content from a source the prompt did
    not name; Minor = a claim only partly supported; None; '' = not judged (no judge, or nothing said)."""
    if (r.get("other_sources") or r.get("misattributed") or r.get("wrong_source_claims") or r.get("hallucination_rate")
            or r.get("numbers_not_in_sources") or r.get("invalid_labels")):
        return "Major"
    if not r.get("answered") or not cites:
        return "None" if not r.get("answered") else ""
    if r.get("faithfulness") is None:
        return ""
    return "Minor" if r["faithfulness"] < 1 else "None"


def _out_of_scope_verdict(r: dict, plan: bool) -> tuple[bool, str]:
    """A question the material does not cover passes when it is declined (the Excel plan: or when the answer
    sticks to what the material has and says what it does not)."""
    if not r["answered"]:
        return True, ""
    if plan and r.get("key_fact_recall") == 1 and not r.get("hallucination_rate") and r.get("attribution") != "Major":
        return True, ""
    return False, "answered a question the material does not cover" + (
        "" if r.get("key_fact_recall") is None else f" (behaviour checks met: {r['key_fact_recall']:.0%})")


def _grounding_problems(r: dict) -> list[str]:
    """Wrong or invented sources, claims and numbers not in the sources, evidence not found."""
    why = []
    if r.get("other_sources"):
        why.append("content from a source the prompt did not name: " + ", ".join(r["other_sources"]))
    if r.get("misattributed"):
        why.append("fact credited to the wrong source: " + r["misattributed"])
    if r.get("wrong_source_claims"):
        why.append("claims credited to the wrong recording")
    if r.get("hallucination_rate"):
        why.append(f"{r['hallucination_rate']:.0%} of claims not in the sources")
    if r.get("evidence_verified") is not None and r["evidence_verified"] < 0.8:
        why.append(f"evidence found for only {r['evidence_verified']:.0%} of sentences")
    if r["invalid_labels"] or r["unsourced_sentences"]:
        why.append("sentences without a real source")
    if r["numbers_not_in_sources"]:
        why.append("numbers not in the sources")
    return why


def _coverage_problems(r: dict, plan: bool) -> list[str]:
    """Key facts missing, low relevance, the expected video not cited (the plan) or not found."""
    why = []
    if r.get("key_fact_recall") is not None and r["key_fact_recall"] < (1.0 if plan else 0.6):
        why.append(f"key facts {r['key_fact_recall']:.0%}")
    if r.get("relevance") is not None and r["relevance"] < 4:
        why.append(f"relevance {r['relevance']}/5")
    if plan and r.get("source_results"):   # the plan's key column: is the expected video CITED?
        missed = [p["source"] for p in r["source_results"] if not p["cited"]]
        if missed:
            why.append("expected video not cited: " + ", ".join(missed))
    elif r.get("retrieval_hit") is not None and r["retrieval_hit"] < 1:
        missed = [p["source"] for p in r.get("source_results", []) if not p["found"]]
        why.append("expected video not found: " + ", ".join(missed) if missed else "the expected source was not found")
    return why


def verdict(r: dict, row: dict) -> tuple[bool, str]:
    """Whether one test question passed, and why not (the rules are stated in the report).

    Out of scope: declined. In scope: answered, no unsupported or contradicted claim, evidence found, no invented
    source or number, key facts and relevance good enough. The client's test plan (rows with `_rows`) is stricter.

    Returns:
        (passed, the reasons it failed joined with "; ").
    """
    plan = bool(row.get("_rows"))
    if row.get("type") == "out_of_scope":
        return _out_of_scope_verdict(r, plan)
    if not r["answered"]:
        return False, "declined, but the material should cover it"
    why = _grounding_problems(r) + _coverage_problems(r, plan)
    return not why, "; ".join(why)


# --- Summary -------------------------------------------------------------------------------------------
def mean(rows: list[dict], key: str) -> float | None:
    """The mean of a column, or None when it is empty."""
    vals = [float(r[key]) for r in rows if r.get(key) not in (None, "")]
    return round(sum(vals) / len(vals), 3) if vals else None


def summary(rows: list[dict]) -> dict:
    """The scores of one run, without the skipped tests (listed apart)."""
    skipped_ids = [r["id"] for r in rows if r.get("skipped")]
    rows = [r for r in rows if not r.get("skipped")]
    return {**_summary(rows), "skipped": len(skipped_ids), "skipped_ids": skipped_ids}


def _answer_metrics(answered: list[dict]) -> dict:
    """The judge's and the code checks' scores over the answers given to questions in scope."""
    return {"faithfulness": mean(answered, "faithfulness"), "hallucination_rate": mean(answered, "hallucination_rate"),
            "answers_with_hallucination": sum(1 for r in answered if r.get("hallucination_rate")),
            "evidence_verified": mean(answered, "evidence_verified"),
            "key_fact_recall": mean(answered, "key_fact_recall"), "correctness": mean(answered, "correctness"),
            "relevance": mean(answered, "relevance"), "completeness": mean(answered, "completeness"),
            "clarity": mean(answered, "clarity"), "copy_rate": mean(answered, "copy_rate"),
            "invalid_or_unsourced": sum(r["invalid_labels"] + r["unsourced_sentences"] for r in answered),
            "numbers_not_in_sources": sum(r["numbers_not_in_sources"] for r in answered)}


def _summary(rows: list[dict]) -> dict:
    inscope = [r for r in rows if r["type"] != "out_of_scope"]
    oos = [r for r in rows if r["type"] == "out_of_scope"]
    passed = sum(r["passed"] for r in rows)
    return {"questions": len(rows), "passed": passed, "pass_rate": round(passed / len(rows), 3) if rows else None,
            "retrieval_hit": mean(inscope, "retrieval_hit"), "mrr": mean(inscope, "reciprocal_rank"),
            "cited_expected": mean(inscope, "cited_expected"),
            **_answer_metrics([r for r in inscope if r["answered"]]),
            "declined_out_of_scope": mean([{"x": float(not r["answered"])} for r in oos], "x"),
            "false_refusals": mean([{"x": float(not r["answered"])} for r in inscope], "x"),
            "removed_by_check": sum(int(r.get("removed_by_check") or 0) for r in rows),
            "searched_again": sum(int(r.get("searched_again") or 0) for r in inscope),
            "cost_per_answer_usd": mean(rows, "cost_usd"), "judge_cost_usd": round(sum(r["judge_cost_usd"] for r in rows), 4),
            "seconds_per_answer": mean(rows, "seconds"), **plan_scores(rows)}


def plan_scores(rows: list[dict]) -> dict:
    """The client's plan scoring, pooled over all expected facts: coverage = (Yes + 0.5 x Partly) / facts
    (a declined trap counts its checks as Yes), correct source cited per fact, Major / Minor counts."""
    got, n = 0.0, 0
    for r in rows:
        results = dict(r.get("fact_results") or [])
        if r.get("type") == "out_of_scope" and not r.get("answered"):
            got, n = got + (r.get("n_facts") or 0), n + (r.get("n_facts") or 0)
            continue
        n += r.get("n_facts") or len(results)
        got += sum({"yes": 1.0, "partial": 0.5}.get(v, 0.0) for v in results.values())
    cited = [a["cited"] for r in rows for a in r.get("fact_attribution") or [] if a.get("cited") is not None]
    return {"fact_coverage": round(got / n, 3) if n else None,
            "fact_source_ok": round(sum(cited) / len(cited), 3) if cited else None,
            "major": sum(r.get("attribution") == "Major" for r in rows),
            "minor": sum(r.get("attribution") == "Minor" for r in rows)}


METRICS = [   # key, area, name, how it is measured, why it matters, target, higher is better
    ("retrieval_hit", "Finding the information", "Retrieval hit rate",
     "share of questions where an excerpt from the expected source (and time) is among those the answer is written from",
     "if the right excerpt is not found, no model can answer well: this separates search problems from writing problems",
     ">= 90%", True),
    ("mrr", "Finding the information", "Mean reciprocal rank (MRR)",
     "1 / position of the first right excerpt among all candidates, averaged (1.0 = always first)",
     "how high the right information ranks; low values mean it is found by luck", ">= 0.7", True),
    ("cited_expected", "Finding the information", "Answer cites the expected source",
     "share of answers that cite an excerpt from the expected source", "the right source was not only found but used", ">= 85%", True),
    ("faithfulness", "No hallucination", "Faithfulness (claims supported)",
     "the judge model splits each answer into single claims and checks each one against the excerpts that sentence cites "
     "(supported 1, partial 0.5, unsupported or contradicted 0); average per answer",
     "the core measure that the answer says only what the material says", ">= 95%", True),
    ("hallucination_rate", "No hallucination", "Hallucination rate",
     "share of claims that the cited excerpts do not contain or contradict", "every such claim could teach something wrong",
     "0%", False),
    ("answers_with_hallucination", "No hallucination", "Answers with any unsupported claim",
     "number of answers with at least one unsupported or contradicted claim", "a single wrong claim spoils an answer", "0", False),
    ("evidence_verified", "No hallucination", "Evidence found word for word",
     "every sentence gives a short quote from its source; share of quotes found in that source (checked in code, no model)",
     "a check of the sources that does not depend on a model's judgement, and lets a person verify in seconds", ">= 95%", True),
    ("numbers_not_in_sources", "No hallucination", "Numbers not in the sources",
     "numbers in answers that the cited excerpts do not contain (code check; number words count too)",
     "invented numbers are the most damaging and the easiest to check", "0", False),
    ("invalid_or_unsourced", "No hallucination", "Invented or missing sources",
     "source labels the model invented, plus sentences that cite nothing (code check)", "every statement must be traceable",
     "0", False),
    ("removed_by_check", "No hallucination", "Sentences removed or corrected before showing",
     "sentences the answer check (VERIFY_ANSWERS) removed as unsupported or corrected as partly supported",
     "what the writer would have shown without the check; it should fall as the prompts improve", "low", False),
    ("searched_again", "Finding the information", "Questions searched a second time",
     "questions where nothing answered as asked and the search ran again in the material's words (RETRY_SEARCH)",
     "the second search saves answers that would be refused; many means the first search misses", "low", False),
    ("key_fact_recall", "Correct and complete", "Key-fact recall",
     "share of the key facts of the test question that the answer contains, in any wording (judge model)",
     "nothing important is lost; the strongest check of completeness", ">= 80%", True),
    ("correctness", "Correct and complete", "Correctness (1-5)",
     "agreement with the expected answer (judge model; only questions with an expected answer)", "", ">= 4", True),
    ("relevance", "Correct and complete", "Relevance (1-5)",
     "answers exactly what was asked, most important first (judge model)", "people get what they need, not a summary of everything", ">= 4", True),
    ("completeness", "Correct and complete", "Completeness (1-5)",
     "contains the most important information the found excerpts give (judge model)", "", ">= 4", True),
    ("clarity", "Correct and complete", "Clarity (1-5)", "clear and well structured for a learner (judge model)", "", ">= 4", True),
    ("declined_out_of_scope", "Knows what it doesn't know", "Declines out-of-scope questions",
     "share of out-of-scope questions answered with 'not covered' instead of an answer",
     "the clearest hallucination test: it must not answer from general knowledge", "100%", True),
    ("false_refusals", "Knows what it doesn't know", "False refusals",
     "share of answerable questions it declined", "too careful is also a failure", "<= 5%", False),
    ("copy_rate", "Own words", "Copied word for word",
     "share of the answer's 8-word sequences found word for word in the excerpts (code check)",
     "the answer should give the most important information in new sentences, not repeat the input", "<= 20%", False),
    ("cost_per_answer_usd", "Cost and time", "Cost per answer (USD)", "model calls of the answer (search, rerank, writing)", "", "", False),
    ("seconds_per_answer", "Cost and time", "Seconds per answer", "", "", "", False),
]


def fmt(key: str, v: float | None) -> str:
    """A score as the report shows it (percent, dollars, or the number)."""
    if v is None:
        return "-"
    if key in ("retrieval_hit", "cited_expected", "faithfulness", "hallucination_rate", "evidence_verified",
               "key_fact_recall", "declined_out_of_scope", "false_refusals", "copy_rate", "pass_rate"):
        return f"{v:.0%}"
    if key == "cost_per_answer_usd":
        return f"${v:.4f}"
    return f"{v:g}" if isinstance(v, float) else str(v)


# --- Report ---------------------------------------------------------------------------------------------
def _report_head(settings: dict, sums: dict[str, dict], modes: list[str], previous: dict | None) -> list[str]:
    """The title, notes on the setup and the skipped tests, the scorecard and the previous run."""
    md = [f"# Answer quality: {settings['questions']} questions", "",
          f"{settings['created']} · writer {settings['writer']} · judge {settings['judge']} · rerank {settings['rerank']} · "
          f"set {settings['set']}" + (f" · {settings['steps']}" if settings.get("steps") else ""), ""]
    if settings["writer"] == settings["judge"]:
        md += ["*Note: the writer and the judge are the same model. For an independent grade set JUDGE_MODEL to "
               "another model (e.g. Claude Opus when answers are written by Sonnet).*", ""]
    skipped_ids = sorted({i for m in modes for i in sums[m].get("skipped_ids", [])})
    if skipped_ids:
        md += [f"*Skipped (not counted): {', '.join(skipped_ids)}: their expected recording is not in the library. "
               "Add it to data/input and run pipeline.py, then run the test plan again.*", ""]
    md += ["## Scorecard", "", "| Area | Metric | " + " | ".join(modes) + " | Target |",
           "|---|---|" + "---|" * len(modes) + "---|"]
    md.append("| Overall | **Questions passed** | " + " | ".join(
        f"**{sums[m]['passed']}/{sums[m]['questions']} ({fmt('pass_rate', sums[m]['pass_rate'])})**"
        + (f" + {sums[m]['skipped']} skipped" if sums[m].get("skipped") else "") for m in modes) + " | |")
    for key, area, name, _how, _why, target, _up in METRICS:
        md.append(f"| {area} | {name} | " + " | ".join(fmt(key, sums[m][key]) for m in modes) + f" | {target} |")
    if previous:
        md += ["", "Previous run (same set, " + previous.get("created", "") + "): passed "
               f"{previous.get('passed')}/{previous.get('questions')}, faithfulness {fmt('faithfulness', previous.get('faithfulness'))}, "
               f"retrieval hit {fmt('retrieval_hit', previous.get('retrieval_hit'))}."]
    return md


def _report_groups(rows: list[dict], best: str) -> list[str]:
    """The best mode's results by question type and by category."""
    md = ["", f"## By question type ({best})", "", "| Type | Questions | Passed | Faithfulness | Key facts | Relevance |",
          "|---|---|---|---|---|---|"]
    for kind in TYPES:
        sel = [r for r in rows if r["type"] == kind]
        if sel:
            s = summary(sel)
            md.append(f"| {kind} | {len(sel)} | {s['passed']} | {fmt('faithfulness', s['faithfulness'])} | "
                      f"{fmt('key_fact_recall', s['key_fact_recall'])} | {fmt('relevance', s['relevance'])} |")
    cats = list(dict.fromkeys(r.get("category") for r in rows if r.get("category")))
    if cats:
        md += ["", f"## By category ({best})", "", "| Category | Questions | Passed | Retrieval hit | Faithfulness | Key facts |",
               "|---|---|---|---|---|---|"]
        for cat in cats:
            s = summary([r for r in rows if r.get("category") == cat])
            md.append(f"| {cat} | {s['questions']} | {s['passed']} | {fmt('retrieval_hit', s['retrieval_hit'])} | "
                      f"{fmt('faithfulness', s['faithfulness'])} | {fmt('key_fact_recall', s['key_fact_recall'])} |")
    return md


def _report_answers(rows: list[dict]) -> list[str]:
    """The questions to look at with their reasons, then every answer with its sources."""
    failed = [r for r in rows if not r["passed"]]
    md = ["", f"## Questions to look at ({len(failed)})", ""]
    for r in failed:
        md += [f"**{r['id']} ({r['type']}): {r['question']}**", f"- Why: {r['why']}"]
        if r.get("unsupported_claims"):
            md.append(f"- Claims not in the sources: {r['unsupported_claims']}")
        if r.get("missing_facts"):
            md.append(f"- Missing key facts: {'; '.join(r['missing_facts'])}")
        md += [f"- Answer: {r['answer']}", f"- Sources: {r['sources'] or '-'}", ""]
    md += ["## All answers", ""]
    for r in rows:
        md += [f"**{r['id']}: {r['question']}** ({'passed' if r['passed'] else 'look at it'})", "", r["answer"], "",
               f"Sources: {r['sources'] or '-'}", ""]
    return md


REPORT_METHOD = [
    "", "**Pass rule per question.** Out of scope: declined. In scope: answered; no unsupported or contradicted "
    "claim; evidence found for at least 80% of sentences; no sentence without a real source; no number missing "
    "from the sources; key-fact recall at least 60% and relevance at least 4/5 (when scored); and the expected "
    "source found (when given).", "",
    "**Why a model as judge, and its limits.** Claim-by-claim checking is what a careful reviewer does; a model "
    "does it for every answer at the cost of cents, with a reason for every claim it rejects. It can still err, "
    "so the code checks (evidence quotes, numbers, sources, copying) do not depend on a model, the judge is best a "
    "different model than the writer, and qa_results.csv has columns for your own verdict on a sample.", ""]


def report(folder: Path, runs: dict[str, list[dict]], settings: dict, previous: dict | None) -> None:
    """qa_report.md and qa_report.html: the scores, the comparison with the previous run, every answer."""
    sums = {m: summary(rows) for m, rows in runs.items()}
    modes = list(runs)
    best = modes[-1]
    md = _report_head(settings, sums, modes, previous) + _report_groups(runs[best], best) + _report_answers(runs[best])
    md += ["## How each metric is measured, and why", "", "| Metric | How | Why | Target |", "|---|---|---|---|"]
    md += [f"| {name} | {how} | {why} | {target} |" for key, _a, name, how, why, target, _u in METRICS if how]
    md += REPORT_METHOD
    (folder / "qa_report.md").write_text("\n".join(md), encoding="utf-8")
    (folder / "qa_report.html").write_text(html_page(md), encoding="utf-8")


def html_page(md: list[str]) -> str:
    """The markdown report as a simple page (tables, headings, bold), without extra packages."""
    out: list[str] = []
    table: list[str] = []

    def inline(t: str) -> str:
        t = html.escape(t)
        t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
        return re.sub(r"\*(.+?)\*", r"<i>\1</i>", t)

    def flush() -> None:
        if table:
            rows = [r for r in table if not re.fullmatch(r"\|[-| ]+\|", r)]
            cells = [[c.strip() for c in r.strip("|").split("|")] for r in rows]
            out.append("<table><thead><tr>" + "".join(f"<th>{inline(c)}</th>" for c in cells[0]) + "</tr></thead><tbody>"
                       + "".join("<tr>" + "".join(f"<td>{inline(c)}</td>" for c in r) + "</tr>" for r in cells[1:])
                       + "</tbody></table>")
            table.clear()
    for line in md:
        if line.startswith("|"):
            table.append(line)
            continue
        flush()
        if line.startswith("# "):
            out.append(f"<h1>{inline(line[2:])}</h1>")
        elif line.startswith("## "):
            out.append(f"<h2>{inline(line[3:])}</h2>")
        elif line.startswith("- "):
            out.append(f"<p class='li'>• {inline(line[2:])}</p>")
        elif line.strip():
            out.append(f"<p>{inline(line)}</p>")
    flush()
    css = ("body{font:15px/1.5 'Segoe UI',Arial,sans-serif;max-width:1200px;margin:24px auto;padding:0 16px;color:#14232a}"
           "table{border-collapse:collapse;width:100%;margin:8px 0 16px}th,td{border:1px solid #d9e2e3;padding:6px 8px;"
           "text-align:left;vertical-align:top}th{background:#eef3f4}h1{color:#0b6e79}h2{color:#0b6e79;margin-top:28px}"
           ".li{margin:2px 0 2px 12px}")
    return f"<!doctype html><meta charset='utf-8'><title>Answer quality</title><style>{css}</style>{''.join(out)}"


RESULT_FIELDS = ["id", "type", "category", "mode", "question", "passed", "skipped", "why", "attribution", "answered", "abstain_correct", "retrieval_hit",
                 "reciprocal_rank", "cited_expected", "n_claims", "faithfulness", "hallucination_rate", "unsupported_claims",
                 "evidence_verified", "numbers_not_in_sources", "invalid_labels", "unsourced_sentences", "removed_by_check",
                 "searched_again", "key_fact_recall",
                 "missing_facts", "correctness", "relevance", "completeness", "clarity", "copy_rate", "longest_copy_words",
                 "words", "cost_usd", "judge_cost_usd", "seconds", "answer", "sources", "folder", "judge_error", "misattributed", "wrong_source_claims", "other_sources",
                 "your_verdict", "comments"]


# --- Test set ---------------------------------------------------------------------------------------------
OUT_OF_SCOPE = re.compile(r"out[ -]?of[ -]?scope|negative|not (in|covered)|unanswerable|no answer|halluc|trap|outside|"
                          r"should (decline|refuse|say)", re.IGNORECASE)
HEADERS = {"id": ("test id", "test case", "id", "tc"), "category": ("category", "type"), "question": ("prompt", "question"),
           "source": ("source video", "source", "video"), "fact": ("expected fact", "expected facts", "expected result",
                                                                    "expected"), "answer": ("expected answer",)}


def _header_map(cells: list) -> dict[str, int]:
    """Column of each field in a header row, by its name ('Source Video (ID+name)' -> source)."""
    names = [str(c or "").strip().lower() for c in cells]
    out: dict[str, int] = {}
    for field, keys in HEADERS.items():
        for key in keys:   # most specific name first
            col = next((i for i, n in enumerate(names) if n and (n == key or n.startswith(key)) and i not in out.values()), None)
            if col is not None:
                out[field] = col
                break
    return out


PLAN_FIELDS = ("id", "category", "question", "source", "fact", "answer")


def _plan_header(rows: list[tuple]) -> tuple[int, dict[str, int]] | None:
    """The plan's header row in the first 20 rows (a question column and a fact or source column)."""
    for i, r in enumerate(rows[:20]):
        cols = _header_map(list(r))
        if "question" in cols and {"fact", "source"} & set(cols):
            return i, cols
    return None


def _plan_rows(rows: list[tuple], h: int, cols: dict[str, int]) -> list[tuple[int, dict[str, str]]]:
    """The plan's rows below its header as {field: text}, with the values of merged cells (id, category,
    question: only in a group's first row) carried down. Returns (Excel row number, values)."""
    def get(r: tuple, f: str) -> str:
        return str(r[cols[f]]).strip() if f in cols and cols[f] < len(r) and r[cols[f]] is not None else ""
    out = []
    last = {"id": "", "category": "", "question": ""}
    for i, r in enumerate(rows[h + 1:], h + 2):
        vals = {f: get(r, f) for f in PLAN_FIELDS}
        if not any(vals.values()):
            continue
        for f in ("id", "category", "question"):
            if vals[f]:
                last[f] = vals[f]
            elif vals["source"] or vals["fact"]:
                vals[f] = last[f]
        if vals["question"]:
            out.append((i, vals))
    return out


def _add_plan_row(tests: dict[str, dict], vals: dict[str, str], where: dict, notes: str) -> None:
    """One plan row into its test question: its expected fact and video, and where the row is."""
    key = vals["id"] or vals["question"]
    t = tests.setdefault(key, {"id": vals["id"] or f"q{len(tests) + 1:02d}", "category": vals["category"],
                               "question": vals["question"], "expected_answer": vals["answer"], "_facts": [],
                               "_sources": [], "_rows": [], "length": "medium", "notes": notes})
    if vals["fact"] and vals["fact"] not in t["_facts"]:
        t["_facts"].append(vals["fact"])
    if not no_video(vals["source"]):
        video = parse_video(vals["source"])
        if video not in t["_sources"]:
            t["_sources"].append(video)
    t["_rows"].append({**where, "source": vals["source"], "fact": vals["fact"]})


def _classify(t: dict) -> None:
    """Out of scope, about one recording (specific) or several (general); expected videos named in the prompt
    when the plan's column has none."""
    oos = OUT_OF_SCOPE.search(t["category"]) or (not t["_sources"] and any(OUT_OF_SCOPE.search(f) for f in t["_facts"]))
    if not t["_sources"] and not oos:   # no video in the column ('—'), but the prompt names one in quotes
        t["_sources"] = [(r.get("catalog_id", ""), r.get("title", "")) for r in answer_mod.quoted_recordings(t["question"])[0]]
        t["_from_prompt"] = bool(t["_sources"])
    t["type"] = "out_of_scope" if oos else ("general" if len(t["_sources"]) != 1 else "specific")
    t["key_facts"] = " ; ".join(t["_facts"])
    t["expected_sources"] = " ; ".join(f"{c} - {n}".strip(" -") for c, n in t["_sources"])


def load_test_plan(path: Path) -> list[dict]:
    """The client's test plan (.xlsx), as it is: one question per Test ID (or prompt), with all its expected
    videos and facts, and where each row is (to write the results back into a copy).

    Raises:
        ValueError: no sheet has a header row with a Prompt (or Question) column.
    """
    from openpyxl import load_workbook
    wb = load_workbook(path, data_only=True, read_only=True)
    tests: dict[str, dict] = {}
    for ws in wb.worksheets:
        rows = list(ws.iter_rows(values_only=True))
        head = _plan_header(rows)
        if not head:
            continue
        h, cols = head
        for i, vals in _plan_rows(rows, h, cols):
            _add_plan_row(tests, vals, {"sheet": ws.title, "row": i, "header": h + 1}, f"{path.name} / {ws.title}")
    wb.close()
    out = list(tests.values())
    for t in out:
        _classify(t)
    if not out:
        raise ValueError(f"No test plan found in {path.name}: no sheet has a header row with a 'Prompt' (or 'Question') column")
    return out


# the plan's own input columns (filled when empty, with its dropdown values; its formulas then score them)
THEIRS = {"fact": ("fact included",), "cited": ("correct source cited", "source cited"),
          "attribution": ("hallucination", "wrong attribution")}
FACT_WORD = {"yes": "Yes", "partial": "Partly", "no": "No"}


def _their_columns(ws: Any, head_row: int) -> dict[str, int]:
    names = [" ".join(str(c.value).split()).lower() if c.value is not None else "" for c in ws[head_row]]
    found = {}
    for key, starts in THEIRS.items():
        col = next((i + 1 for i, n in enumerate(names) if n and any(n.startswith(x) for x in starts)), None)
        if col:
            found[key] = col
    return found


WIDE = ("System answer", "Claims not in the sources")


def _plan_columns(ws: Any, header_row: int) -> tuple[int, dict[str, int], list[str]]:
    """The plan's own columns in its header row, and ours added on the right: (first of ours, theirs, ours)."""
    from openpyxl.styles import Font, PatternFill
    theirs = _their_columns(ws, header_row)
    cols = (["System answer", "Sources used (video · time)"]
            + ([] if "fact" in theirs else ["Expected fact in the answer"])
            + ([] if "cited" in theirs else ["Expected video found"])
            + ["Claims not in the sources", "Faithfulness", "Auto check", "Why"])
    first = ws.max_column + 1
    for k, name in enumerate(cols):
        c = ws.cell(row=header_row, column=first + k, value=name)
        c.font, c.fill = Font(bold=True), PatternFill("solid", fgColor="DCE8EA")
        ws.column_dimensions[c.column_letter].width = 60 if name in WIDE else 28
    return first, theirs, cols


def _row_video(place: dict, t: dict, videos: dict[str, dict]) -> dict | None:
    """The result for a row's expected video. A row with '—' checks behaviour (N/A), unless no row names a video
    and the prompt does."""
    cid, name = parse_video(place["source"])
    video = videos.get(f"{cid} - {name}".strip(" -"))
    if video is None and no_video(place["source"]) and t.get("_from_prompt") and len(videos) == 1:
        video = next(iter(videos.values()))
    return video


def _fact_word(fact: str, judged: str | None, out_of_scope: bool, answered: bool) -> str:
    """The plan's "Fact included?": declining is right for a question out of scope."""
    if not fact:
        return ""
    if not answered:
        return "Yes" if out_of_scope else "No"
    return FACT_WORD.get(judged or "", "")


def _cited_word(video: dict | None, per_fact: dict | None, answered: bool) -> str:
    """The plan's "Correct source cited?": per fact when the judge said so, else per video."""
    if video is None or not answered:
        return "N/A"
    if per_fact and per_fact["cited"] is not None:
        return "Yes" if per_fact["cited"] else "No"
    return "Yes" if video["cited"] else "No"


def _expected_fact(fact: str, judged: str | None, out_of_scope: bool, answered: bool) -> str:
    if out_of_scope:
        return "no (it answered)" if answered else "yes (declined)"
    return (judged or "-") if fact else "-"


def _row_values(t: dict, res: dict, place: dict) -> tuple[dict[str, str], dict[str, str]]:
    """One row of the plan: (values for the plan's own columns, values for ours)."""
    videos = {p["source"]: p for p in res.get("source_results") or []}
    oos, answered = t.get("type") == "out_of_scope", bool(res.get("answered"))
    video = _row_video(place, t, videos)
    judged = dict(res.get("fact_results") or []).get(place["fact"]) if place["fact"] else None
    per_fact = next((a for a in res.get("fact_attribution") or []
                     if a["fact"] == place["fact"] and a["source"] == place["source"]), None)
    level = res.get("attribution", "")
    attribution = ("Major" if per_fact and per_fact["cited"] is False
                   else level if place is t["_rows"][0] else "None" if level else "")
    theirs = {} if res.get("skipped") else {"fact": _fact_word(place["fact"], judged, oos, answered),
                                            "cited": _cited_word(video, per_fact, answered),
                                            "attribution": attribution}
    mine = {"System answer": res.get("answer", ""), "Sources used (video · time)": res.get("sources", ""),
            "Expected fact in the answer": _expected_fact(place["fact"], judged, oos, answered),
            "Expected video found": ("yes" if video["found"] else "no") if video else "-",
            "Claims not in the sources": res.get("unsupported_claims", "") or "none",
            "Faithfulness": fmt("faithfulness", res.get("faithfulness")),
            "Auto check": "SKIP" if res.get("skipped") else "PASS" if res.get("passed") else "CHECK",
            "Why": res.get("why", "")}
    return theirs, mine


def _fill_row(ws: Any, row: int, columns: tuple[int, dict[str, int], list[str]], theirs: dict[str, str],
              mine: dict[str, str]) -> None:
    """The plan's own columns where a tester left them empty (never overwritten), and ours."""
    from openpyxl.styles import Alignment, PatternFill
    first, their_cols, cols = columns
    for key, value in theirs.items():
        if key in their_cols and value:
            cell = ws.cell(row=row, column=their_cols[key])
            if cell.value in (None, ""):
                cell.value = value
    for k, name in enumerate(cols):
        c = ws.cell(row=row, column=first + k, value=mine[name])
        c.alignment = Alignment(wrap_text=True, vertical="top")
        if name == "Auto check":
            c.fill = PatternFill("solid", fgColor={"PASS": "E3F4E8", "SKIP": "EDEDED"}.get(mine[name], "F7E3E1"))


def write_back(plan: Path, rows: list[dict], results: list[dict], out: Path) -> Path:
    """A copy of the test plan with the results.

    The plan's own columns (Fact included?, Correct source cited?, Hallucination / wrong attribution noted?) are
    filled with its dropdown values when empty, so its formulas and Summary work; the answer, sources and reasons
    go into new columns on the right.
    """
    from openpyxl import load_workbook
    wb = load_workbook(plan)
    by_id = {r["id"]: r for r in results}
    columns: dict[str, tuple[int, dict[str, int], list[str]]] = {}
    for t in rows:
        res = by_id.get(t["id"])
        if not res:
            continue
        for place in t.get("_rows", []):
            ws = wb[place["sheet"]]
            if place["sheet"] not in columns:
                columns[place["sheet"]] = _plan_columns(ws, place["header"])
            theirs, mine = _row_values(t, res, place)
            _fill_row(ws, place["row"], columns[place["sheet"]], theirs, mine)
    wb.save(out)
    return out


def load_set(path: Path | None = None) -> list[dict]:
    """The test set: an Excel plan (.xlsx) or a CSV of questions."""
    path = path or qa_set_path()
    if path.suffix.lower() in (".xlsx", ".xlsm"):
        if not path.exists():
            raise FileNotFoundError(f"No test plan at {path.resolve()}. Give the file's full path in quotes, e.g. "
                                    f'--set "C:\\Users\\<you>\\Downloads\\{path.name}"')
        return load_test_plan(path)
    if not path.exists():
        if not path.suffix:   # e.g. --set xlsx: the format, not a file
            raise FileNotFoundError(f'--set takes the test file itself, not its format: "{path}" is not a file. E.g. '
                                    '--set "C:\\Users\\<you>\\Downloads\\Video_Accuracy_Test_Plan.xlsx", '
                                    "or no --set for eval/qa_set.csv")
        raise FileNotFoundError(f"No test set at {path.resolve()}. Make one: uv run -m studio qa_eval --draft 20 (then check "
                                "it in Excel), or give the path of an existing set with --set")
    rows = [r for r in store.read_csv(path) if r.get("question")]   # also as Excel saved it (';')
    for i, r in enumerate(rows, 1):
        r["id"] = r.get("id") or f"q{i:02d}"
        r["type"] = r.get("type") if r.get("type") in TYPES else "specific"
    return rows


DRAFT = """You write test questions for a question-answering system over a company's training material. For each
excerpt write ONE question a learner could ask that this excerpt alone answers well, the expected answer (1-2
sentences, from the excerpt only) and 2-4 key facts (short phrases from the excerpt). Questions must be natural (as a
learner asks, not "according to the excerpt"), and about the content, not about the meeting. Skip an excerpt that is
small talk or logistics (return an empty question)."""

DRAFT_SCHEMA = {"type": "object", "properties": {"items": {"type": "array", "items": {"type": "object", "properties": {
    "excerpt": {"type": "string"}, "question": {"type": "string"}, "expected_answer": {"type": "string"},
    "key_facts": {"type": "array", "items": {"type": "string"}}}, "required": ["excerpt", "question"]}}},
    "required": ["items"]}

DRAFT_GENERAL = """You write test questions for a question-answering system over a company's training material. From
the list of sources (titles, descriptions, slide titles) write broad questions a learner could ask, each answered by
one source (e.g. "What is ...?", "How does ... work?"), with the source title. Then write questions in the same
field that these sources clearly do NOT answer (near the topic, but not covered), to test that the system declines."""

DRAFT_GENERAL_SCHEMA = {"type": "object", "properties": {
    "general": {"type": "array", "items": {"type": "object", "properties": {"question": {"type": "string"},
                                                                            "source": {"type": "string"}},
                                           "required": ["question", "source"]}},
    "out_of_scope": {"type": "array", "items": {"type": "string"}}}, "required": ["general", "out_of_scope"]}


def _spread(by_source: dict[str, list[dict]], n: int, rng: random.Random) -> list[dict]:
    """n excerpts taken in turn from each source, so the questions cover every source."""
    picked: list[dict] = []
    pools = [rng.sample(v, len(v)) for v in by_source.values()]
    while len(picked) < n and any(pools):
        for pool in pools:
            if pool and len(picked) < n:
                picked.append(pool.pop())
    return picked


def _specific_rows(picked: list[dict]) -> list[dict]:
    """One question per excerpt, drafted five excerpts at a time; its source and time are known."""
    rows: list[dict] = []
    for i in range(0, len(picked), 5):
        batch = picked[i:i + 5]
        text = "\n\n".join(f"[E{k}] {s['title']} ({retrieval.where(s)}):\n{s['text']}" for k, s in enumerate(batch, 1))
        out = llm.chat_json(text, DRAFT_SCHEMA, system=DRAFT, step="qa draft", temperature=0.4)
        for item in out.get("items", []):
            m = re.fullmatch(r"E?(\d+)", str(item.get("excerpt", "")).strip())
            if not m or not item.get("question", "").strip() or not 1 <= int(m.group(1)) <= len(batch):
                continue
            s = batch[int(m.group(1)) - 1]
            at = "" if s.get("kind") == "document" else f"@{store.fmt_ts(s.get('start', 0))}"
            rows.append({"type": "specific", "question": item["question"].strip(),
                         "expected_answer": item.get("expected_answer", "").strip(),
                         "key_facts": "; ".join(x.strip() for x in item.get("key_facts", []) if x.strip()),
                         "expected_sources": f"{s['title']}{at}", "notes": f"drafted from {s['title']} {retrieval.where(s)}: check"})
    return rows


def _general_rows(by_source: dict[str, list[dict]], n_general: int, n_out: int) -> list[dict]:
    """Broad questions per source, and questions near the topic that the material does not answer."""
    listing = []
    for items in by_source.values():
        first = items[0]
        slides = sorted({ln.strip() for s in items for ln in (s.get("slide_text") or "").splitlines()[:1] if ln.strip()})[:8]
        listing.append(f"- {first['title']}: {first.get('description', '')} Slides: {', '.join(slides)}")
    out = llm.chat_json(f"Write {n_general} general and {n_out} out-of-scope questions.\n\nSources:\n" + "\n".join(listing),
                        DRAFT_GENERAL_SCHEMA, system=DRAFT_GENERAL, step="qa draft", temperature=0.4)
    rows = [{"type": "general", "question": g["question"].strip(), "expected_answer": "", "key_facts": "",
             "expected_sources": g.get("source", "").strip(), "notes": "drafted: add key facts"}
            for g in out.get("general", [])[:n_general]]
    rows += [{"type": "out_of_scope", "question": str(q).strip(), "expected_answer": "", "key_facts": "",
              "expected_sources": "", "notes": "drafted: check the material really doesn't cover it"}
             for q in out.get("out_of_scope", [])[:n_out]]
    return rows


def draft(n: int, path: Path | None = None, seed: int = 7) -> Path:
    """A first test set from the material, to check and edit before trusting the scores.

    About 70% specific questions (each from one excerpt, so its source and time are known), 20% general ones (per
    source) and 10% (at least 3) that the material does not answer. An existing set is never overwritten.
    """
    path = path or qa_set_path()
    every = list(store.all_segments().values())
    segs = [s for s in every if s.get("words", 0) >= 60] or [s for s in every if s.get("words", 0) >= 8]
    if not segs:
        raise ValueError("No processed material yet: run pipeline.py first")
    by_source: dict[str, list[dict]] = {}
    for s in segs:
        by_source.setdefault(s["video_id"], []).append(s)
    n_specific, n_general = max(1, round(n * 0.7)), max(1, round(n * 0.2))
    rows = _specific_rows(_spread(by_source, n_specific, random.Random(seed)))
    rows += _general_rows(by_source, n_general, max(3, n - n_specific - n_general))
    for i, r in enumerate(rows, 1):
        r.update(id=f"q{i:02d}", length="short")
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        path = path.with_name(f"qa_set_draft_{datetime.now():%Y%m%d-%H%M%S}.csv")
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=SET_FIELDS)
        w.writeheader()
        w.writerows(rows)
    return path


# --- Run ---------------------------------------------------------------------------------------------------
def _evaluated(row: dict, mode: str, model: str | None, judge: str, use_judge: bool) -> dict:
    """One question's result; a question that breaks is noted as an error and the run goes on."""
    try:
        return evaluate(row, mode, model, judge, use_judge)
    except Exception as e:   # noqa: BLE001 - isolation point: one broken question must not stop the others
        log.error("%s failed: %s", row["id"], e, exc_info=not isinstance(e, (llm.LLMError, RuntimeError, OSError)))
        return {"id": row["id"], "type": row.get("type", ""), "question": row["question"], "mode": mode,
                "answered": False, "abstain_correct": False, "answer": f"(error: {e})", "sources": "",
                "invalid_labels": 0, "unsourced_sentences": 0, "numbers_not_in_sources": 0,
                "cost_usd": 0.0, "judge_cost_usd": 0.0, "seconds": 0.0, "passed": False,
                "why": f"error: {str(e)[:200]}", "folder": ""}


def _write_results(folder: Path, runs: dict[str, list[dict]]) -> None:
    """claims.jsonl (every judged claim, for calibrate.py) and qa_results.csv (one row per question and mode)."""
    with open(folder / "claims.jsonl", "w", encoding="utf-8") as f:
        for mode, results in runs.items():
            for r in results:
                for c in r.get("_claims") or []:
                    f.write(json.dumps({"id": r["id"], "mode": mode, "question": r["question"], **c},
                                       ensure_ascii=False) + "\n")
    with open(folder / "qa_results.csv", "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=RESULT_FIELDS, extrasaction="ignore")
        w.writeheader()
        for results in runs.values():
            w.writerows([{**r, "missing_facts": "; ".join(r.get("missing_facts") or [])} for r in results])


def _run_settings(created: str, n: int, set_name: str, model: str | None, judge: str, use_judge: bool,
                  modes: list[str]) -> dict:
    """What the run was made with, for the report."""
    check = (f"on ({config.VERIFY_MODEL or config.JUDGE_MODEL or config.CHAT_MODEL})" if config.VERIFY_ANSWERS
             else "off")
    return {"created": created, "questions": n, "set": set_name, "writer": model or config.CHAT_MODEL,
            "judge": judge, "judge_is_writer": use_judge and judges_itself(judge, model),
            "rerank": config.RERANK_MODEL or config.CHAT_MODEL, "modes": modes,
            "steps": f"contexts {'on' if config.CONTEXTUAL else 'off'} · answer check {check}"
                     f" · second search {'on' if config.RETRY_SEARCH else 'off'}"}


def run(rows: list[dict], modes: list[str], model: str | None, judge: str, use_judge: bool = True,
        set_name: str = "qa_set.csv", plan: Path | None = None) -> Path:
    """Run the test set in each retrieval mode and write the results and the report. Returns the folder."""
    created = datetime.now().strftime("%Y%m%d-%H%M%S")
    folder = config.OUTPUT_DIR / f"{created}-qa-eval"
    folder.mkdir(parents=True, exist_ok=True)
    if use_judge and judges_itself(judge, model):
        log.warning("The judge (%s) is the model that writes the answers: it grades its own work, so its Major / "
                    "hallucination counts are less reliable. Set JUDGE_MODEL in .env to another model (e.g. Opus), "
                    "and check a sample by hand: uv run -m studio calibrate export", judge)
    runs: dict[str, list[dict]] = {}
    for mode in modes:
        runs[mode] = []
        for k, row in enumerate(rows, 1):
            log.info("[%s %s/%s] %s", mode, k, len(rows), row["question"][:80])
            runs[mode].append(_evaluated(row, mode, model, judge, use_judge))
    _write_results(folder, runs)
    settings = _run_settings(created, len(rows), set_name, model, judge, use_judge, modes)
    old = sorted(p for p in config.OUTPUT_DIR.glob("*-qa-eval") if p != folder and (p / "summary.json").exists())
    report(folder, runs, settings, store.read_json(old[-1] / "summary.json", None) if old else None)
    if plan and plan.suffix.lower() in (".xlsx", ".xlsm"):
        try:
            write_back(plan, rows, runs[modes[-1]], folder / f"{plan.stem}_results.xlsx")
        except (OSError, KeyError, ValueError) as e:   # e.g. the plan is open in Excel: the report is still there
            log.error("Could not write the results into a copy of %s (%s); see qa_report.html and qa_results.csv",
                      plan.name, e)
    store.write_json(folder / "summary.json", {**summary(runs[modes[-1]]), "created": created, "mode": modes[-1],
                                               "by_mode": {m: summary(r) for m, r in runs.items()}, "settings": settings})
    return folder


# The release gate (--gate): an answer change (prompt, model, setting) goes live only if the test set still
# meets these. Hallucination is the hard line: zero answers with an invented claim, zero invented numbers.
GATE = {"faithfulness": (">=", 0.95), "answers_with_hallucination": ("<=", 0), "numbers_not_in_sources": ("<=", 0),
        "invalid_or_unsourced": ("<=", 0), "evidence_verified": (">=", 0.95), "declined_out_of_scope": (">=", 1.0),
        "false_refusals": ("<=", 0.10)}


def gate(summary_: dict, previous: dict | None = None) -> list[str]:
    """What fails the release gate: a metric past its line, or fewer questions passed than the previous run."""
    bad = []
    for key, (op, line) in GATE.items():
        v = summary_.get(key)
        if v is None:
            continue
        if (op == ">=" and v < line) or (op == "<=" and v > line):
            bad.append(f"{key} {fmt(key, v)} (must be {op} {fmt(key, line)})")
    if previous and previous.get("passed") is not None and previous.get("questions") == summary_.get("questions") \
            and summary_.get("passed", 0) < previous["passed"]:
        bad.append(f"passed {summary_['passed']}/{summary_['questions']}, fewer than the previous run ({previous['passed']})")
    return bad


def _arguments() -> argparse.Namespace:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--draft", type=int, metavar="N", help="write a first test set of about N questions from the material")
    ap.add_argument("--set", type=Path, help="the test set (default eval/qa_set.csv)")
    ap.add_argument("--compare", action="store_true", help="every retrieval mode: meaning, hybrid, hybrid+rerank")
    ap.add_argument("--mode", choices=retrieval.MODES, help="one retrieval mode (default RETRIEVAL in .env)")
    ap.add_argument("--limit", type=int, help="only the first N questions")
    ap.add_argument("--ids", help="only these ids, comma-separated")
    ap.add_argument("--model", help="the writer (default CHAT_MODEL)")
    ap.add_argument("--judge", help="the judge (default JUDGE_MODEL, else REVIEW_MODEL)")
    ap.add_argument("--no-judge", action="store_true", help="only the code checks (no model grading; cheaper)")
    ap.add_argument("--gate", action="store_true", help="exit code 2 if the results fail the release gate (GATE)")
    args = ap.parse_args()
    args.set = args.set or qa_set_path()
    return args


def _chosen(rows: list[dict], ids: str | None, limit: int | None) -> list[dict]:
    if ids:
        wanted = {x.strip() for x in ids.split(",")}
        rows = [r for r in rows if r["id"] in wanted]
    return rows[:limit] if limit else rows


def _print_modes(s: dict) -> None:
    for m, x in s.get("by_mode", {}).items():
        print(f"{m:<14} passed {x['passed']}/{x['questions']}"
              + (f" (+{x['skipped']} skipped: expected recording not in the library)" if x.get("skipped") else "")
              + f"  faithfulness {fmt('faithfulness', x['faithfulness'])}  "
              f"hallucination {fmt('hallucination_rate', x['hallucination_rate'])}  retrieval hit "
              f"{fmt('retrieval_hit', x['retrieval_hit'])}  key facts {fmt('key_fact_recall', x['key_fact_recall'])}  "
              f"declined out-of-scope {fmt('declined_out_of_scope', x['declined_out_of_scope'])}")


def _print_questions(folder: Path) -> None:
    """Major findings by reason, then every question with its result and why."""
    with open(folder / "qa_results.csv", encoding="utf-8-sig") as f:
        results = list(csv.DictReader(f))

    def count(test: Any) -> int:
        return sum(1 for r in results if test(r))

    major = {"invented or contradicted claim": count(lambda r: float(r.get("hallucination_rate") or 0) > 0),
             "claim credited to the wrong recording": count(lambda r: bool(r.get("wrong_source_claims"))),
             "fact credited to the wrong video": count(lambda r: bool(r.get("misattributed"))),
             "content from a video the prompt did not name": count(lambda r: bool(r.get("other_sources"))),
             "number not in the sources": count(lambda r: float(r.get("numbers_not_in_sources") or 0) > 0)}
    print("\nMajor, by reason (tests): " + "; ".join(f"{k} {v}" for k, v in major.items()))
    for m in dict.fromkeys(r["mode"] for r in results):
        print(f"\n{m}:")
        for r in (x for x in results if x["mode"] == m):
            status = "SKIP " if r.get("skipped") == "True" else "PASS " if r["passed"] == "True" else "CHECK"
            print(f"  {r['id']:<8} {status}  {r.get('why') or ''}"[:220])
    print(f"\nReport: {folder / 'qa_report.html'}\nRate in Excel: {folder / 'qa_results.csv'}")
    for x in folder.glob("*_results.xlsx"):
        print(f"Your test plan with the results: {x}")


def _gate_code(folder: Path, s: dict) -> int:
    """2 when the run fails the release gate (against the run before it), else 0."""
    old = sorted(p for p in config.OUTPUT_DIR.glob("*-qa-eval") if p != folder and (p / "summary.json").exists())
    previous = store.read_json(old[-1] / "summary.json", None) if old else None
    best = list(s.get("by_mode", {}).values())[-1] if s.get("by_mode") else {}
    failed = gate(best, previous)
    print("\nRelease gate: " + ("PASSED" if not failed else "FAILED: " + "; ".join(failed)))
    return 2 if failed else 0


def main() -> int:
    """Command line: draft, run or gate the answer evaluation. Returns the exit code (2 = gate failed)."""
    args = _arguments()
    config.setup_logging()
    try:
        if args.draft:
            path = draft(args.draft, args.set)
            print(f"Draft written: {path}\nCheck it in Excel (questions, key facts, expected sources), add your own, "
                  f"then run: uv run -m studio qa_eval" + (f" --set \"{path}\"" if path != args.set else ""))
            return 0
        rows = _chosen(load_set(args.set), args.ids, args.limit)
        modes = list(retrieval.MODES) if args.compare else [args.mode or config.RETRIEVAL]
        folder = run(rows, modes, args.model, judge_model(args.judge), not args.no_judge, args.set.name, args.set)
    except (FileNotFoundError, ValueError, llm.LLMError) as e:
        log.error("%s", e)
        return 1
    s = store.read_json(folder / "summary.json", {})
    _print_modes(s)
    _print_questions(folder)
    return _gate_code(folder, s) if args.gate else 0


if __name__ == "__main__":
    sys.exit(main())
