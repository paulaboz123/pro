"""Cost estimates before a request and the price tables of the page."""
from __future__ import annotations

import logging
import re
import statistics
from typing import Any

from studio.core import addons, config, llm, store
from studio.costs import measured
from studio.video import tools
from studio.web import compare
from studio.web.catalog import FORMATS, course_min, defaults, models
from studio.web.views import file_url

log = logging.getLogger("app")


# --- cost estimate and report -----------------------------------------------------------------
BASE = {"document": (0.02, 0.01), "slides": (0.06, 0.04), "video": (0.06, 0.06), "dialogue": (0.08, 0.07),
        "audio": (0.06, 0.06), "course": (0.10, 0.07)}   # rough $ fixed + per minute, default model


def kind_of(fmt_id: str, minutes: float) -> str:
    """What a format and length make: document, slides, video, dialogue, audio or course."""
    f = next((f for f in FORMATS if f["id"] == fmt_id), FORMATS[0])
    kind = str(f.get("kind", "video"))
    if kind in ("video", "dialogue") and minutes >= course_min():
        return "course"
    return kind


def estimate(fmt_id: str, minutes: float, model_id: str, voice: str) -> dict[str, Any]:
    """Cost of a lesson before making it: the average of earlier results of the same kind and
    model (per minute), else a rough figure from the model's price; plus a paid voice."""
    minutes = minutes or 2
    kind = kind_of(fmt_id, minutes)
    same = [r for r in compare.rows(kind=kind) if r["writing_model"].startswith(model_id) and r["cost_usd"]
            and r.get("minutes")]
    if same:
        per_min = statistics.median(float(r["cost_usd"]) / max(0.5, float(r["minutes"])) for r in same)
        cost, basis = per_min * minutes, f"median of {len(same)} earlier {kind} result(s) with this model"
    else:
        fixed, per = BASE.get(kind, BASE["video"])
        backend = next((m["backend"] for m in models() if m["id"] == model_id), defaults()["CHAT_BACKEND"])
        p_in, p_out = llm.price(model_id, backend)
        ref_in, ref_out = llm.price(defaults()["CHAT_MODEL"], defaults()["CHAT_BACKEND"])   # BASE is measured with it
        ratio = 0.0 if not (p_in + p_out) else (p_in + p_out) / (ref_in + ref_out) if (ref_in + ref_out) else 1.0
        cost, basis = (fixed + per * minutes) * ratio, "rough estimate from the model's price (no earlier results yet)"
    if voice == "elevenlabs" and kind not in ("document", "slides"):
        rate = config.ELEVENLABS_USD_PER_1K_CHARS
        cost += 900 * minutes / 1000 * rate * (1.15 if kind == "dialogue" else 1)
        basis += f"; voice ~{900 * minutes:,.0f} characters"
    if config.COST_MARGIN_PCT and cost:   # on the high side, to be safe
        cost *= 1 + config.COST_MARGIN_PCT / 100
        basis += f"; +{config.COST_MARGIN_PCT:g}% safety margin"
    return {"usd": round(cost, 3), "basis": basis, "kind": kind}


PACED = ("video", "course", "dialogue", "audio")   # made scene by scene: the time grows with the length
RECENT = 20                                          # the results the time estimate looks at (this machine, lately)


def expected_seconds(fmt: str, minutes: float) -> int | None:
    """How long a request like this usually takes here, from the latest results of the same kind: those of the same
    length if there are any, else the time per minute of the others; None before anything was made.
    fmt: the format as the request was understood (answer, text, slides, video, dialogue, audio)."""
    kind = {"text": "document"}.get(fmt, fmt)
    if kind in ("video", "dialogue") and minutes >= course_min():
        kind = "course"
    made = [r for r in compare.rows(kind=kind) if isinstance(r.get("total_s"), (int, float)) and r["total_s"] > 0]
    made = made[:RECENT]
    if not made:
        return None
    if kind not in PACED:
        return int(statistics.median(r["total_s"] for r in made))
    same = [r["total_s"] for r in made if r.get("minutes") and float(r["minutes"]) == float(minutes)]
    if same:
        return int(statistics.median(same))
    per_min = [r["total_s"] / max(0.5, float(r["minutes"])) for r in made if r.get("minutes")]
    return int(statistics.median(per_min) * max(0.5, minutes)) if per_min else None


# What Lesson Studio makes, as the price list shows it: id, name, example, kind of result (run cards),
# minutes, spoken (a narrator), presenter ("" | "cartoon")
OFFER = [
    ("answer", "Answer", "a few sentences with their sources", "answer", 0, False, ""),
    ("document", "Written lesson", "about 5 minutes to read", "document", 5, False, ""),
    ("slides", "Slides to present", "about 10 slides: PDF + PowerPoint with speaker notes", "slides", 10, False, ""),
    ("video", "Video with narrator", "a 2-minute video", "video", 2, True, ""),
    ("presenter", "Video with a cartoon presenter", "a 2-minute video", "video", 2, True, "cartoon"),
    ("silent", "Video without voice", "a 2-minute video", "video", 2, False, ""),
]
CHARS_PER_MIN = 900   # spoken characters in a minute of narration

# What AWS costs a month is not worked out here: it comes only from the AWS Pricing Calculator's export in
# data/aws (aws_estimate.py).


def price_table(m: dict[str, tuple[Any, str]]) -> list[dict[str, Any]]:
    """One request of each kind Lesson Studio makes: the cost with a free voice (Kokoro, or none) and with
    ElevenLabs; made of Claude (measured on this project's runs where there are any), the voice, the
    presenter and the server's time; the safety margin included. Licences and plans: see subscriptions."""
    margin = 1 + config.COST_MARGIN_PCT / 100
    server_min = measured.server_per_min(m, tools.CLOUD_PER_S)    # making one minute of video
    kokoro_min = tools.KOKORO_RTF * 60 * tools.CLOUD_PER_S
    eleven_min = CHARS_PER_MIN / 1000 * config.ELEVENLABS_USD_PER_1K_CHARS
    rows = []
    for key, what, example, kind, minutes, spoken, presenter in OFFER:
        if kind == "answer":
            ai, basis = m["answer"]
        else:
            per, basis = m[f"per_min_{kind}"]
            ai = per * minutes
        base = ai + (server_min * minutes if kind == "video" else 0.0)
        if presenter == "cartoon":
            base += server_min * minutes * 0.5                    # the presenter takes longer to draw
        free = base + (kokoro_min * minutes if spoken else 0.0)
        eleven = base + eleven_min * minutes if spoken else None
        rows.append({"key": key, "what": what, "example": example, "usd": round(free * margin, 3),
                     "usd_eleven": round(eleven * margin, 3) if eleven is not None else None,
                     "voice": "Kokoro voice (free)" if spoken else "no voice", "basis": basis})
    return rows


def prices() -> dict[str, Any]:
    """The price list, what each step costs, the subscriptions, spend so far, the full cost report, and AWS a
    month as the AWS Pricing Calculator's export says (nothing about AWS without one)."""
    from studio.costs import aws_estimate
    m = measured.measured(measured.library())
    spent = m["_spent_total"][0]   # every logged model call, as "today" is counted
    report_file = config.OUTPUT_DIR / "costs" / "costs.html"
    steps = step_costs(m["per_min_video"][0])
    return {"rows": price_table(m), "steps": steps["steps"], "subscriptions": steps["subscriptions"],
            "aws": aws_estimate.summary(),
            "checked": steps["checked"], "margin_pct": config.COST_MARGIN_PCT,
            "eleven_rate": config.ELEVENLABS_USD_PER_1K_CHARS, "today": round(llm.spent_today(), 3),
            "daily": config.DAILY_BUDGET_USD, "total": round(spent, 2),
            "report": file_url(str(report_file)) if report_file.exists() else "", "lengths": lengths()}


def step_costs(content_usd_per_min: float) -> dict[str, Any]:
    """What each step of a minute of video costs: with every tool's measured time when there is a comparison
    (experiments add-on), else with the list prices."""
    if addons.experiments_on():
        compare_video = addons.experiment("compare_video")
        try:
            folder = compare_video.latest()
            data = store.read_json(folder / "comparison.json", {}) or {}
            compare_video.video_costs(folder, data)
            return tools.cost_report(data, content_usd_per_min)
        except (OSError, ValueError, KeyError, TypeError) as e:   # no comparison yet
            log.info("Step costs without a comparison: %s", e)
    return tools.cost_report({}, content_usd_per_min)


def lengths() -> dict[str, Any]:
    """What one video costs by length (length_costs.py), with links to the videos and the Excel file."""
    from studio.costs import length_costs
    try:
        rep = length_costs.report()
    except (OSError, ValueError, KeyError, TypeError, ZeroDivisionError) as e:   # information only
        log.info("Costs by length not worked out: %s", e)
        return {"rows": []}
    for r in rep.get("rows", []) + rep.get("scratch", []):
        v = config.OUTPUT_DIR / r["folder"] / "lesson_video.mp4"
        r["url"] = file_url(str(v)) if v.exists() else ""
        m = re.search(r"-v(\d+)-", r["folder"])
        r["version"] = int(m.group(1)) if m else None
    x = length_costs.folder() / "length_costs.xlsx"
    rep["xlsx"] = file_url(str(x)) if x.exists() else ""
    return rep
