"""The job line: requests wait, run one at a time with their own settings, can be stopped and resumed."""
from __future__ import annotations

import contextlib
import logging
import queue
import threading
import time
import uuid
from collections.abc import Callable, Iterator
from typing import Any

from studio.core import config, llm
from studio.generation import ask, lesson, storyboard
from studio.quality import monitoring
from studio.web import chats
from studio.web.catalog import (
    FORMATS,
    LENGTHS,
    LEVELS,
    LOOKS,
    SWITCHED,
    course_min,
    defaults,
    elevenlabs_left,
    models,
    suggestions,
    tool_settings,
    voice_settings,
    voices,
)
from studio.web.pricing import expected_seconds
from studio.web.views import public, readable_error

log = logging.getLogger("app")
JOBS: dict[str, dict[str, Any]] = {}
# Requests wait in line and are made one after another: making a video uses the whole processor, so two at once
# would each take twice as long. A request's own settings stay in its context (chosen()). Nobody is turned away.
QUEUE: queue.Queue[dict[str, Any]] = queue.Queue()
_worker: threading.Thread | None = None
MAX_WAITING_PER_USER = 3


def _work_forever() -> None:
    while True:
        job = QUEUE.get()
        try:
            if STOPPING.is_set() or job["status"] == "stopped":   # app stopping / stopped on the page while waiting
                continue
            work(job)   # looked up on each run (tests replace it)
        except Exception:   # noqa: BLE001 - isolation point: one broken job must not stop the line
            log.exception("Job %s failed outside its own handling", job.get("id"))
        finally:
            QUEUE.task_done()


def enqueue(job: dict[str, Any]) -> None:
    """Put a request in line; start the worker that makes them one at a time if it is not running."""
    global _worker
    QUEUE.put(job)
    if _worker is None or not _worker.is_alive():
        _worker = threading.Thread(target=_work_forever, name="job-worker", daemon=True)
        _worker.start()


def ahead_of(job: dict[str, Any]) -> int:
    """How many requests are made before this one (the one being made included)."""
    return sum(1 for j in JOBS.values() if j is not job and j["status"] in ("queued", "running")
               and j["started"] <= job["started"])
BUSY = threading.Lock()


class JobLog(logging.Handler):
    """Collects the log lines while a job runs (shown as progress on the page). One job runs
    at a time, so every line belongs to it, also those of the parallel chapter threads."""

    def __init__(self, job: dict[str, Any]) -> None:
        super().__init__(logging.INFO)
        self.job = job
        self.setFormatter(logging.Formatter("%(asctime)s %(message)s", "%H:%M:%S"))

    def emit(self, record: logging.LogRecord) -> None:
        """Keep the log line on the job, for the page's progress (the last 200 lines)."""
        if record.name in ("httpx", "urllib3"):
            return
        self.job["log"].append(self.format(record)[:300])
        del self.job["log"][:-200]


def running(owner: str = "") -> str:
    """This browser's request that is waiting or being made (never someone else's)."""
    return next((j["id"] for j in JOBS.values() if j["status"] in ("queued", "running")
                 and j.get("owner", "") == owner), "")


def state(owner: str = "") -> dict[str, Any]:
    """What the chat page needs on load: this browser's request being made, spend today."""
    job = JOBS.get(running(owner)) or {}
    return {"running": job.get("id", ""), "running_request": job.get("request", ""), "running_chat": job.get("chat", ""),
            "today": round(llm.spent_today(), 3), "daily": config.DAILY_BUDGET_USD}


def options(owner: str = "") -> dict[str, Any]:
    """Everything the page's choices need: formats, looks, levels, models, voices, topics, budget."""
    return {"formats": FORMATS, "looks": LOOKS, "levels": LEVELS, "lengths": LENGTHS, "models": models(),
            "voices": voices(), "topics": suggestions(), "course_from": course_min(), "labels": ask.LABELS,
            "default_voice": defaults()["TTS_ENGINE"], "running": running(owner),
            "budget": {"today": round(llm.spent_today(), 3), "daily": config.DAILY_BUDGET_USD},
            "elevenlabs": elevenlabs_left()}


@contextlib.contextmanager
def chosen(model: dict[str, Any] | None, voice: str | None, extra: dict[str, Any] | None = None) -> Iterator[None]:
    """The model, voice and tool picked on the page, for this job only (config.overridden: other requests and
    threads keep the configured ones). A local model also does the review (it must use the same backend)."""
    values = {k: v for k, v in (extra or {}).items() if k in SWITCHED}
    if model:
        values.update(CHAT_MODEL=model["id"], CHAT_BACKEND=model["backend"])
        if model["backend"] != config.CHAT_BACKEND:
            values["REVIEW_MODEL"] = model["id"]
    if voice:
        values["TTS_ENGINE"] = voice
    with config.overridden(**values):
        yield


def chat_history(job: dict[str, Any]) -> list[dict[str, Any]]:
    """The chat's earlier finished turns [{request, answer}] (the answer's text, or what was made), so a
    follow-up question ("and who owns it?") is understood as a full one."""
    chat = chats.load(job.get("chat") or "", job.get("owner", "")) if job.get("chat") else None
    out = []
    for m in (chat or {}).get("messages", []):
        if m.get("job") == job.get("id"):
            break
        if m.get("status") != "done":
            continue
        r = m.get("result") or {}
        a = r.get("answer") or {}
        made = a.get("text") or (f"a {r.get('format', 'result')}: {r.get('title', '')}" if r else "")
        out.append({"request": m.get("request", ""), "answer": made})
    return out[-config.CHAT_HISTORY_TURNS:] if config.CHAT_HISTORY_TURNS > 0 else []


def _understood(job: dict[str, Any], settings: dict[str, Any]) -> None:
    """What Claude read from the request, and how long such a request usually takes here (for the page)."""
    job["understood"] = settings
    try:
        job["expected_s"] = expected_seconds(str(settings.get("format", "")), float(settings.get("minutes") or 0))
    except (OSError, KeyError, TypeError, ValueError) as e:   # an odd run card must not stop the request
        log.info("No time estimate: %s", e)


def work(job: dict[str, Any]) -> None:
    """Make one request (in the worker thread) and keep its progress, result or error on the job."""
    handler = JobLog(job)
    logging.getLogger().addHandler(handler)
    result: dict[str, Any] | None = None
    failure: BaseException | None = None
    try:
        with BUSY:
            llm.STOP.clear()   # a Stop meant for the request before this one
            storyboard.last_saved = None
            job["status"] = "running"
            if job["kind"] == "topics":
                from studio.knowledge import topics
                topics.run()
                job.update(status="done", result={"topics": suggestions()})
                return
            with chosen(job.get("model"), job.get("voice"), job.get("config")):
                if job["kind"] == "resume":   # a stopped video, finished from its folder
                    result = ask.resume(config.OUTPUT_DIR / job["folder"], job["review"], job.get("audio_only", False))
                else:
                    result = ask.run(job["request"], review=job["review"], overrides=job["overrides"],
                                     on_understood=lambda s: _understood(job, s), history=chat_history(job))
            job.update(status="done", result=public(result))
    except ask.RequestRefused as e:
        job.update(status="refused", error=str(e))
    except lesson.NotEnoughMaterial as e:
        job.update(status="not_covered", error=str(e))
    except llm.Stopped as e:
        log.info("Job %s stopped on the page", job.get("id"))
        job.update(status="stopped", error=str(e), resume_folder=_resumable())
    except Exception as e:   # noqa: BLE001 - isolation point: show any failure on the page instead of crashing the server
        log.exception("Job failed")
        failure = e
        job.update(status="error", error=readable_error(e), resume_folder=_resumable())
    finally:
        logging.getLogger().removeHandler(handler)
        job["finished"] = time.time()
        if job.get("chat"):   # kept with the chat, so it is there after a restart
            chats.add_result(job["chat"], job["id"], job["status"], job.get("result"), job.get("error", ""),
                             job["finished"] - job["started"])
        monitoring.request_finished(job, result, failure)


def forget_old_jobs(after_s: float = 3600) -> None:
    """Finished jobs leave memory after an hour: their results are kept in their chat and in data/output."""
    now = time.time()
    for jid in [j["id"] for j in JOBS.values() if j.get("finished") and now - j["finished"] > after_s]:
        JOBS.pop(jid, None)


def _request_overrides(body: dict[str, Any], fmt: dict[str, Any]) -> dict[str, Any]:
    """What the clicked options ask of the request: format, length, level, look, a new version."""
    overrides = dict(fmt["settings"])
    if body.get("minutes"):
        overrides["minutes"] = float(body["minutes"])
    if body.get("level") not in (None, "", "auto"):
        overrides["level"] = body["level"]
    if body.get("look") not in (None, "", "auto") and fmt["id"] in ("auto", "video", "audio"):
        overrides["style"] = body["look"]
        if body["look"] == "presenter":
            overrides["characters"] = "cartoon"
    if body.get("fresh"):   # "Make a new version": not the one from the library
        overrides["fresh"] = True
    return overrides


def _tool_and_voice(body: dict[str, Any], fmt: dict[str, Any], overrides: dict[str, Any]) -> tuple[dict[str, Any], str | None]:
    """The job's own settings for the picked tool and narrator, and the voice engine left to choose (or None)."""
    cfg: dict[str, Any] = {}
    tool = body.get("tool") or "default"
    if tool != "default" and fmt["id"] not in ("answer", "document", "slides"):
        cfg, tool_over = tool_settings(tool)
        if fmt["id"] != "dialogue":
            overrides.update(tool_over)
    voice = body.get("voice") or None
    if voice and ":" in voice:   # a narrator: engine + voice
        cfg.update(voice_settings(voice))
        voice = None
    if fmt.get("config"):   # e.g. animated slides: no voice, whatever narrator is picked
        cfg.update(fmt["config"])
        voice = None
    return cfg, voice


def _lesson(job: dict[str, Any], body: dict[str, Any], owner: str) -> str:
    """The request and its options into the job, and into its chat. Returns an error, or ""."""
    request = " ".join(str(body.get("request", "")).split())[:1000]
    if not request:
        return "Write a topic or what you want to learn."
    fmt = next((f for f in FORMATS if f["id"] == body.get("format", "auto")), FORMATS[0])
    overrides = _request_overrides(body, fmt)
    cfg, voice = _tool_and_voice(body, fmt, overrides)
    model = next((m for m in models() if m["id"] == body.get("model")), None)
    job.update(request=request, review=bool(body.get("review", True)), overrides=overrides, model=model,
               voice=voice, config=cfg)
    picks = {k: str(body[k]) for k in ("format", "tool", "voice", "level") if body.get(k)}
    job["chat"] = chats.add_request(str(body.get("chat") or ""), owner, request, picks, job["id"])
    return ""


def new_job(body: dict[str, Any], owner: str = "") -> tuple[dict[str, Any] | None, str, int]:
    """A job from the page's form (request + clicked options), or (None, error, code).

    It goes into the chat body["chat"] (a new chat when there is none), which belongs to `owner` (the browser).
    """
    kind = body.get("kind", "lesson")
    forget_old_jobs()
    waiting = sum(1 for j in JOBS.values() if j.get("owner", "") == owner and j["status"] in ("queued", "running"))
    if waiting >= MAX_WAITING_PER_USER:
        return None, f"You already have {MAX_WAITING_PER_USER} requests waiting. Wait until one is finished.", 429
    if kind not in ("lesson", "topics"):
        return None, "Unknown job.", 400
    job = {"id": uuid.uuid4().hex[:10], "kind": kind, "status": "queued", "log": [], "started": time.time(),
           "owner": owner}
    if kind == "lesson":
        error = _lesson(job, body, owner)
        if error:
            return None, error, 400
    JOBS[job["id"]] = job
    enqueue(job)
    return job, "", 200


def _resumable() -> str:
    """The folder (its name) of the video the stopped or failed request was making, when its storyboard (the paid
    part) is there: the page offers Resume. "" for anything else (an answer, a document, slides)."""
    folder = storyboard.last_saved
    if not folder or not (folder / "storyboard.json").exists() or (folder / "lesson.json").exists():
        return ""
    return folder.name


def resume_job(job_id: str, owner: str) -> tuple[dict[str, Any] | None, str, int]:
    """The page's Resume: a new request in the same chat that finishes the stopped video, with the same choices.

    Only for the browser that asked; the folder comes from the stopped request on the server, never from the browser.

    Returns:
        (the new job, "", 200), or (None, why not, the HTTP status).
    """
    old = JOBS.get(job_id)
    if not old or old.get("owner", "") not in ("", owner):
        return None, "Unknown request.", 404
    folder = old.get("resume_folder") or ""
    if old["status"] not in ("stopped", "error") or not folder or \
            not (config.OUTPUT_DIR / folder / "storyboard.json").exists():
        return None, "Nothing to resume.", 409
    if sum(1 for j in JOBS.values() if j.get("owner", "") == owner and j["status"] in ("queued", "running")) \
            >= MAX_WAITING_PER_USER:
        return None, f"You already have {MAX_WAITING_PER_USER} requests waiting. Wait until one is finished.", 429
    job = {"id": uuid.uuid4().hex[:10], "kind": "resume", "status": "queued", "log": [], "started": time.time(),
           "owner": owner, "request": old.get("request", ""), "review": old.get("review", True),
           "overrides": old.get("overrides", {}), "model": old.get("model"), "voice": old.get("voice"),
           "config": old.get("config", {}), "folder": folder,
           "audio_only": (old.get("understood") or {}).get("format") == "audio"}
    if old.get("chat"):
        job["chat"] = chats.add_request(old["chat"], owner, f"Resume: {old.get('request', '')}", {}, job["id"])
    old["resume_folder"] = ""   # resumed once
    JOBS[job["id"]] = job
    enqueue(job)
    return job, "", 200


def stop_job(job_id: str, owner: str) -> bool:
    """The page's Stop button, only for the browser that asked.

    A request still waiting leaves the line; the one being made stops before its next paid call or the next part of
    its video (llm.check_stop), and what it made so far is not shown. Returns whether there was one to stop.
    """
    job = JOBS.get(job_id)
    if not job or job.get("owner", "") not in ("", owner):
        return False
    if job["status"] == "queued":
        job.update(status="stopped", error="Stopped before it started.", finished=time.time())
        if job.get("chat"):
            chats.add_result(job["chat"], job["id"], "stopped", None, job["error"], 0)
        return True
    if job["status"] == "running":
        llm.STOP.set()
        log.info("Stop asked for job %s", job_id)
        return True
    return False


def chat_action(path: str, body: dict[str, Any], owner: str) -> bool:
    """/api/chats/<id>/rename {title}, /delete, /feedback {job, rating, comment}: only on the owner's chat.
    Returns whether it was done."""
    _, _, _, chat_id, action = (path.split("/") + [""])[:5]
    if action == "rename":
        return chats.rename(chat_id, owner, str(body.get("title", "")))
    if action == "delete":
        return chats.delete(chat_id, owner)
    if action == "feedback":
        return chats.add_feedback(chat_id, owner, str(body.get("job", "")), str(body.get("rating", "")),
                                  str(body.get("comment", "")))
    return False
STOPPING = threading.Event()   # set on SIGTERM: no new requests, the one being made may finish


def waiting_gauges() -> dict[str, tuple[str, Callable[[], float]]]:
    """The app's own values for /metrics: requests waiting in line and being made."""
    return {"lesson_studio_requests_waiting": ("Requests waiting in line", QUEUE.qsize),
            "lesson_studio_requests_running": ("Requests being made", lambda: sum(j["status"] == "running"
                                                                              for j in list(JOBS.values())))}
