"""
make_video.py - end to end: a request in, a short narrated video lesson out.

  request: a topic (searched in all recordings) or one recording, plus minutes and level
   1. material    the transcript excerpts and slides that cover it
   2. storyboard  the chat model plans the scenes: narration + what the screen shows
   3. voice       each scene's narration spoken locally (Kokoro)
   4. pictures    each scene drawn as an image: original slide, key points or steps
   5. video       ffmpeg puts pictures and voice together: lesson_video.mp4 + .srt subtitles,
                  and the narration alone as lesson_audio.mp3 (the audio lesson)

Usage:
  uv run -m studio make_video "joining data" --minutes 2
  uv run -m studio make_video --recording 13 --minutes 3 --level intermediate   # id from description.xlsx
  uv run -m studio make_video "joining data" --plan-only           # storyboard only, to check it first
  uv run -m studio make_video --rerender data/output/<folder>      # after editing storyboard.json by hand
  uv run -m studio make_video "joining data" --check               # plus the quality checks (quality.py)
  The same request through every tool, side by side: benchmark.py

Output in data/output/<time>-<topic>-video-<n>m/:
  lesson_video.mp4   the video (subtitles included as a track)
  lesson_video.srt   subtitles (also for editing or translation)
  lesson_audio.mp3   audio-only lesson
  script.md          the narration and on-screen text, scene by scene, with sources
  storyboard.json    the same as data: edit it and use --rerender
  quiz.md/quiz.json  the check-yourself question(s) with answers, for a learning platform
  scenes/, audio/    the image and the voice of each scene
  info.json          timings, word counts, estimated model cost
"""
from __future__ import annotations

import argparse
import hashlib
import json
import logging
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

import numpy as np

from studio.core import addons, config, llm, resources, store
from studio.generation import lesson, storyboard
from studio.video import animation, images, media, render, tts

log = logging.getLogger("make_video")


# --- 1 + 2: material and storyboard -------------------------------------------------------------
def plan(topic: str | None, recording: str | None, minutes: float, level: str,
         model: str | None, wishes: str = "", style: str | None = None, characters: str | None = None) -> Path:
    """Find the material, ask for a storyboard, save it. Returns the output folder."""
    mark = llm.meter_mark()   # search, writing, review, conversation: all on the run card
    summary_of = ""
    if recording:
        video_ids = store.resolve_recordings(recording)
        segments = lesson.recording_segments(video_ids, int(round(minutes)))
        titles = list(dict.fromkeys(s["title"] for s in segments))
        summary_of = ", ".join(f'"{t}"' for t in titles)
        topic = topic or "; ".join(titles)
    else:
        if not topic:
            raise ValueError("A topic or a recording is needed")
        segments, best = lesson.retrieve(topic, int(round(minutes)))
        log.info("Search: best match %.2f", best)
    if not segments:
        raise lesson.NotEnoughMaterial("No transcript segments found. Run pipeline.py first.")
    cost_before = llm.spent_this_run()
    sb = storyboard.make(topic, minutes, level, segments, model=model, summary_of=summary_of, wishes=wishes,
                         style=style)
    if sb["style"] == "dialogue":   # the narration becomes a conversation of a host and an expert
        from studio.generation import dialogue
        sb.setdefault("stats", {})["dialogue_warnings"] = dialogue.add_lines(sb, model)
    sb["characters"] = characters if characters in ("cartoon", "people") else config.CHARACTERS
    sb["request"] = {"topic": topic, "recording": recording or "", "minutes": minutes, "level": level,
                     "wishes": wishes, "style": sb["style"], "characters": sb["characters"]}
    sb["plan_cost_usd_est"] = round(llm.spent_this_run() - cost_before, 4)
    sb["plan_calls"] = llm.calls_since(mark)   # for the run card: what planning this result cost
    name, sb["version"] = store.versioned(sb["created"], f"{store.slugify(topic, 40)}-video-{minutes:g}m")
    out_dir = config.OUTPUT_DIR / name
    storyboard.save(sb, out_dir)
    log.info("Storyboard: %s scenes, %s words (target %s) -> %s", sb["stats"]["scenes"],
             sb["stats"]["words"], sb["stats"]["target_words"], out_dir / "script.md")
    return out_dir


# --- subtitles ---------------------------------------------------------------------------------
def _srt_time(t: float) -> str:
    """Seconds -> SRT timestamp, e.g. 62.345 -> '00:01:02,345'."""
    ms = int(round(t * 1000))
    h, ms = divmod(ms, 3_600_000)
    m, ms = divmod(ms, 60_000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def _chunks(text: str, max_words: int = 12) -> list[str]:
    """Split narration into subtitle-sized pieces at sentence ends, then commas, then length."""
    out: list[str] = []
    for sentence in re.split(r"(?<=[.!?])\s+", text.strip()):
        words = sentence.split()
        while len(words) > max_words:
            cut = next((i + 1 for i in range(max_words - 1, 3, -1) if words[i].endswith((",", ";", ":"))),
                       max_words)
            out.append(" ".join(words[:cut]))
            words = words[cut:]
        if words:
            out.append(" ".join(words))
    return out


def subtitles(scenes: list[dict], starts: list[float], durations: list[float]) -> str:
    """SRT with each scene's narration spread over its speaking time (by length of text)."""
    lines, n = [], 0
    for sc, start, dur in zip(scenes, starts, durations, strict=True):
        pieces = _chunks(tts.clean_text(sc["narration"]))
        speak_from, speak_to = start + 0.15, start + max(dur - tts.PAUSE_AFTER_S, 0.5)
        total = sum(len(p) for p in pieces) or 1
        t = speak_from
        for p in pieces:
            end = t + (speak_to - speak_from) * len(p) / total
            n += 1
            lines += [str(n), f"{_srt_time(t)} --> {_srt_time(end)}", p, ""]
            t = end
    return "\n".join(lines)


def audio_checks(texts: list[str], audios: list, rate: int, pauses: list[float], scene_of: list[int]) -> list[str]:
    """The voice, part by part: silence where there should be speech, distortion (clipping), and a
    speaking pace far from normal speech (2-3.5 words per second), which points to a voice glitch
    or a garbled text."""
    issues = []
    for text, a, pause, sc in zip(texts, audios, pauses, scene_of, strict=True):
        words = len(text.split())
        speech = a[int(0.15 * rate): max(int(len(a) - pause * rate), int(0.15 * rate) + 1)]
        secs = len(speech) / rate
        if words and (speech.size == 0 or float(np.sqrt(np.mean(speech.astype(np.float64) ** 2))) < 1e-4):
            issues.append(f"scene {sc + 1}: silent where it should speak ({text[:40]}...)")
            continue
        if speech.size and float(np.max(np.abs(speech))) >= 0.999:
            issues.append(f"scene {sc + 1}: the voice is distorted (clipping)")
        if words >= 6 and secs > 0:
            wps = words / secs
            if wps < 1.6 or wps > 4.0:
                issues.append(f"scene {sc + 1}: unusual speaking pace ({wps:.1f} words/s) - listen to it")
    return issues


LINE_PAUSE_S = 0.3   # dialogue: the breath between one person's line and the other's


def scene_beats(sc: dict, style: str) -> list[dict]:
    """What is spoken in a scene, part by part. Dialogue style: one part per line, in the voice
    of the person who says it; otherwise the narration split for the animation (animation.py)."""
    pause = sc.get("pause_after", tts.PAUSE_AFTER_S)
    if style == "dialogue":
        from studio.generation import dialogue
        lines = [x for x in dialogue.lines_of(sc, style) if x["text"].strip()]
        if lines:
            voices = {"host": tts.role_voice("host"), "expert": tts.role_voice("expert")}
            out = [{"text": x["text"], "styles": None, "pause": LINE_PAUSE_S, "speaker": x["speaker"],
                    "voice": voices[x["speaker"]]} for x in lines]
            out[-1]["pause"] = pause
            return out
    return animation.beats(sc, pause)


def voice_fingerprint() -> str:
    """What the voice depends on besides the text: engine, voice, speed and pronunciations."""
    pron = config.PRONUNCIATION_FILE.read_text(encoding="utf-8") if config.PRONUNCIATION_FILE.exists() else ""
    engine = {"elevenlabs": f"{config.ELEVENLABS_MODEL}|{config.ELEVENLABS_VOICE}|{config.ELEVENLABS_STABILITY}|"
                            f"{config.ELEVENLABS_SIMILARITY}|{config.ELEVENLABS_STYLE}|{config.ELEVENLABS_SEED}|"
                            f"{config.ELEVENLABS_CONTEXT}|{config.ELEVENLABS_FORMAT}"}.get(config.TTS_ENGINE, config.TTS_VOICE)
    return f"{config.TTS_ENGINE}|{engine}|{getattr(config, 'TTS_SPEED', '')}|{pron}"


def neighbours(plan: list[tuple[int, dict]], n: int) -> dict:
    """What the same voice says just before and just after part n (a cloud voice uses it to speak
    the parts as one flowing narration)."""
    voice = plan[n][1].get("voice")
    before = next((b["text"] for _, b in reversed(plan[:n]) if b.get("voice") == voice), "")
    after = next((b["text"] for _, b in plan[n + 1:] if b.get("voice") == voice), "")
    return {"before": before, "after": after}


def chapter_marks(scenes: list[dict], starts: list[float], durations: list[float]) -> list[tuple]:
    """(start s, end s, title) for each 'section' of a course storyboard; [] for a short video."""
    marks: list[list] = []
    for sc, start, dur in zip(scenes, starts, durations, strict=True):
        name = sc.get("section")
        if not name:
            continue
        if marks and marks[-1][2] == name:
            marks[-1][1] = start + dur
        else:
            marks.append([float(start), float(start + dur), name])
    return [tuple(m) for m in marks] if len(marks) > 1 else []


# --- 3-5: voice, pictures, video ------------------------------------------------------------------
FPS = config.VIDEO_FPS


def check_voice_quota(minutes: float) -> None:
    """Before any model is paid for a script: will a paid voice have enough characters for it?"""
    if config.TTS_ENGINE != "elevenlabs":
        return
    from studio.costs import usage
    try:
        usage.reserve_elevenlabs(int(minutes * usage.CHARS_PER_MINUTE * 1.1), take=False)
    except usage.QuotaExceeded as e:
        raise tts.TTSError(f"{e} Nothing was spent: checked before the script is written.") from None


def remotion_or_fallback() -> tuple[str, str]:
    """(renderer, note): Remotion when it can render here, else the designer slides, with the reason.
    Never raises: a missing or broken Remotion must not stop the video (or waste the voice made for it)."""
    try:
        remotion_render = addons.experiment("remotion_render")
        remotion_render.ensure_installed()   # a fresh copy of the project: its packages, once
        ok, why = remotion_render.available()
    except (addons.NotInstalled, OSError, subprocess.SubprocessError, ValueError) as e:
        ok, why = False, f"Remotion check failed: {e}"
    if ok:
        return config.RENDERER, ""
    log.warning("Remotion unavailable (%s); the video is made with the designer slides. To stop this message: "
                "RENDERER=html in .env", why)
    return "pillow", f"{config.RENDERER} unavailable, made with the designer slides instead: {why}"


DECK_ENGINES = ("manim", "revideo", "motion-canvas", "hyperframes")   # free engines: their slides + our narration


def deck_engine_or_fallback() -> tuple[str, str]:
    """(renderer, note): Manim / Revideo / Motion Canvas when it can run here, else the designer slides."""
    try:
        if config.RENDERER == "manim":
            ok, why = addons.experiment("manim_render").available()
        elif config.RENDERER == "hyperframes":
            ok, why = addons.experiment("hyperframes_render").available()
        else:
            ok, why = addons.experiment("deck_js").available(config.RENDERER)
    except Exception as e:   # noqa: BLE001 - isolation point: a broken engine must not stop the video
        ok, why = False, str(e)[:300]
    if ok:
        return config.RENDERER, ""
    log.warning("%s unavailable (%s); the video is made with the designer slides", config.RENDERER, why)
    return "pillow", f"{config.RENDERER} unavailable, made with the designer slides instead: {why}"


def deck_engine_video(out_dir: Path, sb: dict, scene_seconds: list[float], wav: Path, engine: str) -> Path:
    """The slides drawn by Manim / Revideo / Motion Canvas, each scene as long as its narration, then the
    narration added."""
    silent = out_dir / f"slides_{engine}_silent.mp4"
    manim_render = addons.experiment("manim_render")
    if engine == "manim":
        manim_render.render(out_dir, sb, scene_seconds, silent)
    elif engine == "hyperframes":
        addons.experiment("hyperframes_render").render(manim_render.deck_data(sb, scene_seconds), silent)
    else:
        addons.experiment("deck_js").render(engine, manim_render.deck_data(sb, scene_seconds), silent)
    try:
        return media.add_audio(silent, wav, out_dir / "lesson_video.mp4", seconds=sum(scene_seconds))
    finally:
        silent.unlink(missing_ok=True)


def voice_key(voice_id: str, part: dict) -> str:
    """The name of a spoken part's file: the same voice, pause and text give the same file (it is reused)."""
    raw = f"{voice_id}|{part.get('voice') or ''}|{part['pause']}|{part['text']}"
    return hashlib.sha1(raw.encode(), usedforsecurity=False).hexdigest()[:16]


def _choose_renderer(audio_only: bool) -> tuple[str, str]:
    """The tool that draws the video (RENDERER), checked before the voice is made, since the voice may be paid.
    Returns (renderer, why another one is used: '' when none)."""
    if audio_only:
        return "pillow", ""
    if config.RENDERER in ("remotion", "remotion-ai", "remotion-pro"):
        return remotion_or_fallback()
    if config.RENDERER in DECK_ENGINES:
        return deck_engine_or_fallback()
    return "pillow", ""


def speak_parts(out_dir: Path, plan: list) -> list[Path]:
    """The voice of every spoken part, one wav per text: a part whose text and voice did not change is reused,
    so a re-render after editing one scene only speaks what changed (the voice is the slowest step). Voices of
    texts that are gone are deleted.

    Raises:
        tts.TTSError: when the voice cannot be made (ElevenLabs: not enough characters left).
    """
    voice_id = voice_fingerprint()
    if config.TTS_ENGINE == "elevenlabs":   # enough characters left for the parts still to speak?
        from studio.costs import usage
        need = sum(len(tts.clean_for_speech(b["text"])) for _, b in plan
                   if not (out_dir / "audio" / f"voice_{voice_key(voice_id, b)}.wav").exists())
        try:
            usage.reserve_elevenlabs(need, take=False)
        except usage.QuotaExceeded as e:
            raise tts.TTSError(str(e)) from None
    wavs, reused = [], 0
    for n, (i, b) in enumerate(plan, 1):
        llm.check_stop()   # the Stop button on the page
        wav = out_dir / "audio" / f"voice_{voice_key(voice_id, b)}.wav"
        if wav.exists():
            reused += 1
        else:
            context = neighbours(plan, n - 1) if config.TTS_ENGINE == "elevenlabs" else None
            tts.speak_to_wav(b["text"], wav, pause_after_s=b["pause"], voice=b.get("voice"), context=context)
            log.info("voice %s/%s (scene %s)", n, len(plan), i + 1)
        wavs.append(wav)
    used = {w.name for w in wavs}
    for old_wav in (out_dir / "audio").glob("*.wav"):
        if old_wav.name not in used and old_wav.name != "narration.wav":
            old_wav.unlink(missing_ok=True)
    if reused:
        log.info("voice: %s of %s parts unchanged, reused", reused, len(plan))
    return wavs


def _read_voice(wavs: list[Path], plan: list, style: str) -> tuple[list, int, list[float]]:
    """The spoken parts as samples, their sample rate and exact durations; for presenters, each part's mouth
    movement from its loudness. Returns (parts, rate, durations)."""
    parts = [tts._read_wav(w) for w in wavs]
    rates = {r for _, r in parts}
    if len(rates) != 1:
        raise tts.TTSError(f"Scenes have different sample rates {rates}; use one TTS engine")
    rate = rates.pop()
    durations = [len(a) / rate for a, _ in parts]   # exact, from the samples
    if style in ("presenter", "dialogue"):
        from studio.video import cartoon
        for (_, b), (a, _) in zip(plan, parts, strict=True):
            b["mouth"] = cartoon.mouth_envelope(a, rate, FPS)
    return parts, rate, durations


def _draw(out_dir: Path, sb: dict, plan: list, durations: list[float],
          renderer: str) -> tuple[list | None, list | None, str]:
    """The video's pictures: the designer slides (HTML), else the simple ones; none when another tool draws
    the whole video. Returns (images, image durations, renderer)."""
    if renderer.startswith("remotion") or renderer in DECK_ENGINES:
        return None, None, renderer
    if config.RENDERER in ("html", "remotion", "remotion-ai", "remotion-pro") + DECK_ENGINES:
        try:
            images, image_durations = pictures_html(out_dir, sb, plan, durations)
            return images, image_durations, "html"
        except ImportError:
            log.warning("Designer slides need playwright (uv add playwright); using the simple slides")
        except Exception as e:   # noqa: BLE001 - isolation point: e.g. the browser can't start: the simple slides still make a video
            log.warning("Designer slides unavailable (%s); using the simple slides", str(e)[:300])
    images, image_durations = pictures(out_dir, sb, plan, durations)
    return images, image_durations, renderer


def _narration_files(out_dir: Path, plan: list, parts: list, rate: int, durations: list[float],
                     scenes: list[dict]) -> tuple[Path, Path, list[float], list]:
    """The whole narration (wav), its subtitles (srt) and, for a long course, chapter marks and chapters.txt.
    Returns (narration wav, srt, each scene's duration, chapters)."""
    full_wav = out_dir / "audio" / "narration.wav"
    tts._write_wav(full_wav, tts.normalize(np.concatenate([a for a, _ in parts]), rate), rate)
    starts = list(np.cumsum([0.0] + durations[:-1]))
    srt = out_dir / "lesson_video.srt"
    srt.write_text(subtitles([{"narration": b["text"]} for _, b in plan], starts, durations), encoding="utf-8")
    scene_starts = [next(s for (i, _), s in zip(plan, starts, strict=True) if i == k) for k in range(len(scenes))]
    scene_durs = [sum(d for (i, _), d in zip(plan, durations, strict=True) if i == k) for k in range(len(scenes))]
    chapters = chapter_marks(scenes, scene_starts, scene_durs)
    if chapters:
        (out_dir / "chapters.txt").write_text(
            "".join(f"{store.fmt_ts(a)} {t}\n" for a, _, t in chapters), encoding="utf-8")
    return full_wav, srt, scene_durs, chapters


def _designer_slides_instead(out_dir: Path, sb: dict, plan: list, durations: list[float]) -> tuple[list, list, str]:
    """When another tool failed after the voice was made: the designer slides, else the simple ones."""
    try:
        images, image_durations = pictures_html(out_dir, sb, plan, durations)
        return images, image_durations, "html"
    except Exception:   # noqa: BLE001 - isolation point: the simple slides always work
        images, image_durations = pictures(out_dir, sb, plan, durations)
        return images, image_durations, "pillow"


def _other_tool_video(out_dir: Path, sb: dict, plan: list, durations: list[float], scene_durs: list[float],
                      full_wav: Path, renderer: str) -> tuple[Path | None, dict]:
    """The video made by a tool of the comparison (Remotion, a deck engine). If it breaks, the voice is already
    made, so the designer slides finish the video. Returns (video or None, what changed: renderer, images,
    image durations, fallback)."""
    try:
        if renderer in DECK_ENGINES:
            return deck_engine_video(out_dir, sb, scene_durs, full_wav, renderer), {}
        remotion_render = addons.experiment("remotion_render")
        return remotion_render.render(out_dir, sb, plan, durations, full_wav, ai=renderer == "remotion-ai",
                                      pro=renderer == "remotion-pro"), {}
    except Exception as e:   # noqa: BLE001 - isolation point: whatever breaks in the tool, finish the video
        log.warning("%s; using the designer slides instead", str(e)[:600])
        images, image_durations, used = _designer_slides_instead(out_dir, sb, plan, durations)
        return None, {"renderer": used, "images": images, "image_durations": image_durations,
                      "fallback": f"{renderer} failed, made with the designer slides instead: {str(e)[:400]}"}


def produce(out_dir: Path, audio_only: bool = False) -> dict:
    """Voice, pictures and video for the storyboard in out_dir (no model calls).

    Animated scenes are spoken and drawn part by part (animation.py), so every element appears exactly when the
    voice gets to it; new elements and new scenes fade in.

    Args:
        out_dir: the folder with storyboard.json; the voice, frames and video are written there.
        audio_only: only the narration (mp3 + subtitles), no pictures or video (much faster).

    Returns:
        info.json's content: paths, duration, scenes, renderer, timings, audio issues.
    """
    sb = storyboard.load(out_dir)
    scenes = sb["scenes"]
    timings: dict[str, float] = {}
    plan = [(i, b) for i, sc in enumerate(scenes) for b in scene_beats(sc, sb.get("style", "clean"))]
    renderer, fallback = _choose_renderer(audio_only)

    t0 = time.perf_counter()
    resources.mark("voice")
    wavs = speak_parts(out_dir, plan)
    timings["voice_s"] = round(time.perf_counter() - t0, 1)

    t0 = time.perf_counter()
    parts, rate, durations = _read_voice(wavs, plan, sb.get("style", "clean"))
    silent = config.TTS_ENGINE == "silent"
    audio_issues = [] if silent else audio_checks([b["text"] for _, b in plan], [a for a, _ in parts], rate,
                                                  [b["pause"] for _, b in plan], [i for i, _ in plan])
    if audio_only:
        resources.mark("audio")
        return produce_audio(out_dir, sb, plan, parts, rate, durations, timings, audio_issues)
    resources.mark("pictures")
    images, image_durations, renderer = _draw(out_dir, sb, plan, durations, renderer)
    timings["pictures_s"] = round(time.perf_counter() - t0, 1)

    t0 = time.perf_counter()
    resources.mark("video")
    full_wav, srt, scene_durs, chapters = _narration_files(out_dir, plan, parts, rate, durations, scenes)
    video = None
    if renderer in DECK_ENGINES or renderer.startswith("remotion"):
        video, changed = _other_tool_video(out_dir, sb, plan, durations, scene_durs, full_wav, renderer)
        renderer = changed.get("renderer", renderer)
        images, image_durations = changed.get("images", images), changed.get("image_durations", image_durations)
        fallback = changed.get("fallback", fallback)
    if video is None:
        if images is None or image_durations is None:
            raise RuntimeError("No pictures were drawn for the video")
        try:
            video = media.stills_to_video(images, image_durations, full_wav, out_dir / "lesson_video.mp4",
                                          None if silent else srt, fps=FPS, chapters=chapters or None)
        finally:
            shutil.rmtree(out_dir / "frames", ignore_errors=True)   # the frames are only needed for the encode
    if renderer != "html":   # the HTML slides draw the company logo themselves; the other tools get it put on
        from studio.video import brand
        brand.stamp(Path(video))
    audio = "" if silent else media.to_mp3(full_wav, out_dir / "lesson_audio.mp3")
    timings["video_s"] = round(time.perf_counter() - t0, 1)

    info = {"title": sb["title"], "version": sb.get("version"), "video": str(video), "audio": str(audio),
            "duration_s": round(sum(durations), 1), "scenes": len(scenes),
            "animated_scenes": sum(1 for sc in scenes if len(animation.beats(sc, 0)) > 1),
            "speakers": sorted({b["speaker"] for _, b in plan if b.get("speaker")}),
            "words": sum(len(s["narration"].split()) for s in scenes),
            "tts": tts.engine_label(), "renderer": renderer, "timings": timings,
            "audio_issues": audio_issues,
            "storyboard_stats": sb.get("stats", {})}
    if fallback:
        info["fallback"] = fallback
    return info


def produce_audio(out_dir: Path, sb: dict, plan: list, parts: list, rate: int, durations: list[float],
                  timings: dict, audio_issues: list[str]) -> dict:
    """The audio lesson: the narration as mp3 with subtitles (and the script), no video."""
    t0 = time.perf_counter()
    full_wav = out_dir / "audio" / "narration.wav"
    tts._write_wav(full_wav, tts.normalize(np.concatenate([a for a, _ in parts]), rate), rate)
    starts = list(np.cumsum([0.0] + durations[:-1]))
    (out_dir / "lesson_audio.srt").write_text(subtitles([{"narration": b["text"]} for _, b in plan], starts, durations),
                                              encoding="utf-8")
    audio = media.to_mp3(full_wav, out_dir / "lesson_audio.mp3")
    timings["audio_s"] = round(time.perf_counter() - t0, 1)
    return {"title": sb["title"], "video": "", "audio": str(audio), "audio_only": True,
            "duration_s": round(sum(durations), 1), "scenes": len(sb["scenes"]),
            "speakers": sorted({b["speaker"] for _, b in plan if b.get("speaker")}),
            "words": sum(len(s["narration"].split()) for s in sb["scenes"]), "tts": tts.engine_label(),
            "renderer": "none (audio only)", "timings": timings, "audio_issues": audio_issues,
            "storyboard_stats": sb.get("stats", {})}


def _scene_shots(browser: object, frames: Path, i: int, page_html: str, tl: dict,
                 total: float) -> tuple[list[tuple[Path, float]], list[str]]:
    """The pictures of scene i and its layout issues: drawn by the browser, or, when this very scene (the same page,
    timeline, length, size and frame rate) was drawn before and its pictures are still there (a stopped run that is
    resumed), taken from frames/s<NNN>.json without drawing it again."""
    key = hashlib.sha256(json.dumps([page_html, tl, round(total, 3), FPS, config.VIDEO_WIDTH],
                                    sort_keys=True, default=str).encode("utf-8")).hexdigest()[:20]
    saved = frames / f"s{i + 1:03d}.json"
    old = store.read_json(saved, {}) if saved.exists() else {}
    if old.get("key") == key and old.get("shots") and all((frames / n).exists() for n, _ in old["shots"]):
        log.info("pictures %s: ready from the stopped run", i + 1)
        return [(frames / n, float(d)) for n, d in old["shots"]], list(old.get("issues", []))
    shots = browser.scene_frames(page_html, tl, total, frames, f"s{i + 1:03d}")   # type: ignore[attr-defined]
    issues = list(browser.issues)   # type: ignore[attr-defined]
    store.write_json(saved, {"key": key, "shots": [[p.name, d] for p, d in shots], "issues": issues})
    return shots, issues


def pictures_html(out_dir: Path, sb: dict, plan: list[tuple[int, dict]], durations: list[float]) -> tuple[list, list]:
    """Designer slides with motion (slides_html.py): per scene, frames while something moves and
    one picture per still stretch; between scenes the old picture fades to the clean background
    of the next scene, whose content then animates in. Also writes scenes/scene_NN.png."""
    from PIL import Image

    from studio.video import slides_html
    scenes = sb["scenes"]
    frames = out_dir / "frames"
    frames.mkdir(parents=True, exist_ok=True)   # kept from a stopped run: its finished scenes are reused
    (out_dir / "scenes").mkdir(exist_ok=True)
    for stale in (out_dir / "scenes").glob("scene_*.png"):
        stale.unlink(missing_ok=True)
    style = sb.get("style", "clean")
    if images.enabled():   # AI pictures for the scenes that have an illustration with a subject
        for sc in scenes:
            ill = sc.get("illustration")
            if ill and ill.get("prompt"):
                try:
                    ill["image"] = str(images.generate(ill["prompt"]))
                except llm.LLMError as e:
                    log.warning("AI picture failed, using the drawing: %s", str(e).splitlines()[0])
    browser = slides_html.Browser()   # RuntimeError when no browser can be started
    layout_issues: dict[str, list[str]] = {}
    pics: list[Path] = []
    image_durations: list[float] = []
    try:
        for i, sc in enumerate(scenes):
            llm.check_stop()   # the Stop button on the page
            idx = [k for k, (j, _) in enumerate(plan) if j == i]
            beats, durs = [plan[k][1] for k in idx], [durations[k] for k in idx]
            slide = Path(sc["slide_image"]) if sc.get("slide_image") else None
            page_html, n = slides_html.scene_html(sc, lesson_title=sb["title"], goal=sb.get("goal", ""),
                                                  page=f"{i + 1} / {len(scenes)}", slide_image=slide,
                                                  caption=sc.get("caption", ""), style=style,
                                                  characters=sb.get("characters"),
                                                  source=slides_html.source_note(sc, sb.get("sources", {})))
            tl = (slides_html.dialogue_timeline(beats, durs, n, [e["title"] for e in slides_html.elements(sc)])
                  if style == "dialogue"
                  else slides_html.timeline(sc, beats, durs, n))
            if style in ("presenter", "dialogue"):
                tl.update(slides_html.speech_track(beats, durs))
            shots, issues = _scene_shots(browser, frames, i, page_html, tl, sum(durs))
            if issues:
                layout_issues[str(i + 1)] = issues
                log.warning("scene %s layout: %s", i + 1, "; ".join(issues[:3]))
            if pics:   # fade the previous scene out into this scene's empty first picture
                fade = animation.SCENE_FADE_S
                if image_durations[-1] > fade + 0.2:
                    image_durations[-1] -= round(fade * FPS) / FPS
                    with Image.open(pics[-1]) as a, Image.open(shots[0][0]) as b:
                        for k, frame in enumerate(animation.blend_frames(a.convert("RGB"), b.convert("RGB"), fade, FPS)):
                            path = frames / f"x{i + 1:03d}_{k:02d}.jpg"
                            frame.save(path, quality=92)
                            pics.append(path)
                            image_durations.append(1 / FPS)
            for path, d in shots:
                pics.append(path)
                image_durations.append(d)
            with Image.open(shots[-1][0]) as last:   # the scene in its final state, for the report
                last.convert("RGB").save(out_dir / "scenes" / f"scene_{i + 1:02d}.png")
            log.info("pictures %s/%s: %s frames", i + 1, len(scenes), len(shots))
    finally:
        browser.close()
    store.write_json(out_dir / "layout.json", layout_issues)   # read by quality.py
    return pics, image_durations


def pictures(out_dir: Path, sb: dict, plan: list[tuple[int, dict]], durations: list[float]) -> tuple[list, list]:
    """The pictures of the video and how long each is shown: per part of a scene one picture,
    with fade frames before it when something new appears. Also writes scenes/scene_NN.png
    (each scene in its final state) for the report."""
    from PIL import Image
    scenes = sb["scenes"]
    frames = out_dir / "frames"
    shutil.rmtree(frames, ignore_errors=True)
    frames.mkdir(parents=True)
    (out_dir / "scenes").mkdir(exist_ok=True)
    for stale in (out_dir / "scenes").glob("scene_*.png"):   # the scene count may have changed
        stale.unlink(missing_ok=True)
    images: list[Path] = []
    image_durations: list[float] = []
    prev_img, prev_key = None, None
    for n, ((i, b), dur) in enumerate(zip(plan, durations, strict=True)):
        sc = scenes[i]
        slide = Path(sc["slide_image"]) if sc.get("slide_image") else None
        if sc["visual"] == "slide" and (slide is None or not slide.exists()):
            log.warning("scene %s: slide image missing (%s), showing key points", i + 1, slide)
        png = render.render_scene(sc, frames / f"s{i + 1:03d}_{n:04d}.png", lesson_title=sb["title"],
                                  goal=sb.get("goal", ""), page=f"{i + 1} / {len(scenes)}", slide_image=slide,
                                  caption=sc.get("caption", ""), styles=b["styles"])
        last_of_scene = n + 1 == len(plan) or plan[n + 1][0] != i
        if last_of_scene:
            shutil.copyfile(png, (out_dir / "scenes").joinpath(f"scene_{i + 1:02d}.png"))
        with Image.open(png) as im:
            img = im.convert("RGB")
        png.unlink()
        key = (i, json.dumps(b["styles"]))
        fade = 0.0
        if prev_img is not None and prev_key is not None and key != prev_key:
            fade = animation.SCENE_FADE_S if prev_key[0] != i else animation.INNER_FADE_S
            fade = min(fade, dur * 0.4)
        if fade and prev_img is not None:
            for k, frame in enumerate(animation.blend_frames(prev_img, img, fade, FPS)):
                path = frames / f"f{n:04d}_{k:02d}.jpg"
                frame.save(path, quality=93)
                images.append(path)
                image_durations.append(1 / FPS)
        hold = frames / f"h{n:04d}.jpg"
        img.save(hold, quality=95)
        images.append(hold)
        image_durations.append(max(dur - (round(fade * FPS) / FPS if fade else 0.0), 1 / FPS))
        prev_img, prev_key = img, key
    return images, image_durations


def make(topic: str | None = None, recording: str | None = None, minutes: float = 2,
         level: str = "beginner", model: str | None = None, plan_only: bool = False,
         rerender: Path | None = None, wishes: str = "", style: str | None = None,
         characters: str | None = None, audio_only: bool = False) -> tuple[Path, dict]:
    """The whole flow for one request (or a re-render of an existing folder). Writes info.json
    and returns (output folder, info). Raises on errors; see main() for the readable handling."""
    t_start = time.perf_counter()
    if not rerender and not plan_only:
        check_voice_quota(minutes)
    # absolute: the designer slides are opened in a browser by file:// address, which a relative path can't be
    out_dir = Path(rerender).resolve() if rerender else plan(topic, recording, minutes, level, model, wishes, style, characters)
    mark = llm.meter_mark()
    sb = storyboard.load(out_dir)
    base = {"title": sb["title"], "request": sb.get("request", {}),
            "model": sb.get("model", ""), "model_cost_usd_est": sb.get("plan_cost_usd_est", 0.0)}
    if plan_only:
        info = {**base, "plan_only": True, "storyboard_stats": sb.get("stats", {})}
    else:
        try:
            info = {**base, **produce(out_dir, audio_only=audio_only)}
        except (media.MediaError, tts.TTSError) as e:   # the paid part (script) is done: don't pay for it again
            raise type(e)(f"{e}\nThe script is kept (and every voice part already made): make the video again "
                          f"without paying for it: uv run -m studio make_video --rerender \"{out_dir}\"") from e
    info["total_s"] = round(time.perf_counter() - t_start, 1)
    store.write_json(out_dir / "info.json", info)
    write_run_card(out_dir, sb, info, llm.calls_since(mark))
    return out_dir, info


def write_run_card(out_dir: Path, sb: dict, info: dict, production_calls: list[dict]) -> None:
    """What this video was made from and with, and what it cost (runcard.py)."""
    from studio.core import runcard
    req = sb.get("request", {})
    kind = ("audio" if info.get("audio_only") else "course" if req.get("kind") == "course"
            else "dialogue" if sb.get("style") == "dialogue" else "video")
    timings = {**info.get("timings", {}), "total_s": info["total_s"]}
    if info.get("duration_s"):
        timings["video_length_s"] = info["duration_s"]
    runcard.write(out_dir, kind=kind, title=sb["title"], request=req, sources=sb.get("sources", {}),
                  calls=sb.get("plan_calls", []) + production_calls, timings=timings, style=sb.get("style", ""),
                  characters=sb.get("characters", ""), renderer=info.get("renderer", ""), settings=sb.get("settings"),
                  extra={"plan_only": True} if info.get("plan_only") else None)


def main() -> int:
    """Command line: make a video (or only its plan, or render a plan again). Returns the exit code."""
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("topic", nargs="?", help="what the lesson is about (searched in all recordings)")
    ap.add_argument("--recording", help="make the video from one recording: Excel id (e.g. 13), "
                                        "video_id or part of the title; several: 13,14")
    ap.add_argument("--minutes", type=float, default=2, help="target length (default 2)")
    ap.add_argument("--level", choices=list(lesson.LEVELS), default="beginner")
    ap.add_argument("--style", choices=list(storyboard.STYLES),
                    help="clean | illustrated | presenter | dialogue (default: STYLE in .env)")
    ap.add_argument("--characters", choices=["cartoon", "people"],
                    help="presenter/dialogue: cartoon bear and fox, or drawn people (default: CHARACTERS in .env)")
    ap.add_argument("--model", help="override CHAT_MODEL from .env")
    ap.add_argument("--plan-only", action="store_true", help="stop after the storyboard")
    ap.add_argument("--rerender", type=Path, help="output folder: voice + video again from its storyboard.json")
    ap.add_argument("--check", action="store_true", help="run the quality checks afterwards (quality.py)")
    ap.add_argument("--review", action="store_true", help="with --check: plus the model review and the claim-by-claim "
                                                         "check against the sources (~$0.02-0.05)")
    ap.add_argument("--listen", action="store_true", help="with --check: Whisper listens to the voice and compares it "
                                                         "with the script (free, local, needs faster-whisper)")
    args = ap.parse_args()
    config.setup_logging()

    if not (args.topic or args.recording or args.rerender):
        ap.error("give a topic, --recording or --rerender")
    try:
        out_dir, info = make(args.topic, args.recording, args.minutes, args.level, args.model,
                             args.plan_only, args.rerender, style=args.style, characters=args.characters)
    except lesson.NotEnoughMaterial as e:
        log.error("%s", e)
        return 2
    except (RuntimeError, ValueError, OSError) as e:   # model, voice, ffmpeg, index or file problems
        log.error("%s", e)
        return 1

    if args.plan_only:
        print(f"\nStoryboard ready. Read {out_dir / 'script.md'}")
        print(f"Then make the video: uv run -m studio make_video --rerender \"{out_dir}\"")
        print(f"Estimated model cost: ${info['model_cost_usd_est']:.3f}")
        return 0
    m, s = divmod(int(info["duration_s"]), 60)
    print(f"\nVideo:  {info['video']}  ({m}:{s:02d}, {info['scenes']} scenes)")
    print(f"Audio:  {info['audio']}")
    print(f"Script: {out_dir / 'script.md'}")
    for w in info["storyboard_stats"].get("warnings", []):
        print(f"Check:  {w}")
    print(f"Time {info['total_s']:.0f}s (voice {info['timings']['voice_s']:.0f}s), "
          f"estimated model cost ${info['model_cost_usd_est']:.3f}")
    if args.check:
        from studio.quality import quality
        r = quality.check(out_dir, review=args.review, hear=args.listen)
        print(f"\nQuality: {r['status']}" + ("" if args.review else
              "  (the claims were not checked against the sources: add --review for that)"))
        for line in r["fail"] + r["issues"]:
            print(f"   - {line}")
    return 0


if __name__ == "__main__":
    code = main()
    from studio.costs import usage
    usage.report()   # spent today, ElevenLabs characters left, Remotion
    sys.exit(code)
