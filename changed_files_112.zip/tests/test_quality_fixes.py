"""The fixes from the review of the whole solution: videos and lessons use the answers' search, slides
are not cut short, a video's claims are checked one by one, the judge can be calibrated against a
person, Whisper's inventions are dropped, the voice is checked by listening, and the ablation says
whether a difference could be chance."""
from __future__ import annotations

from types import SimpleNamespace

import pytest

from studio.core import config, store
from studio.experiments import ablation
from studio.generation import lesson
from studio.knowledge import retrieval, transcribe
from studio.quality import calibrate, qa_eval, quality


def _seg(i: int, words: int = 100, section: int | None = None, vid: str = "v1") -> dict:
    return {"id": f"{vid}#{i}", "video_id": vid, "idx": i, "title": "Joining data", "text": f"piece {i}",
            "words": words, "section": section, "start": i * 60.0, "end": i * 60.0 + 60}


def test_lessons_use_the_answers_search_and_take_whole_topics(monkeypatch):
    segs = {s["id"]: s for s in [_seg(i, section=(1 if i in (4, 5, 6) else None)) for i in range(12)]}
    monkeypatch.setattr(store, "all_segments", lambda: segs)
    asked = {}

    def fake_retrieve(topic, mode=None, keep=8, video_ids=None):
        asked.update(topic=topic, keep=keep)
        return {"kept": [{"segment": segs["v1#5"], "meaning": 0.7}, {"segment": segs["v1#10"], "meaning": 0.6}],
                "candidates": [{"segment": segs["v1#5"], "meaning": 0.7}], "parts": [topic], "mode": "hybrid+rerank"}
    monkeypatch.setattr(retrieval, "retrieve", fake_retrieve)
    monkeypatch.setattr(lesson, "material_budget", lambda minutes, whole_recording=False: 500)
    got, best = lesson.retrieve("how to join two tables", 2)
    ids = [s["id"] for s in got]
    assert asked["topic"] == "how to join two tables" and asked["keep"] == lesson.LESSON_KEEP
    assert {"v1#5", "v1#10", "v1#4", "v1#6"} <= set(ids)       # both kept pieces, the whole topic section of #5
    assert sum(s["words"] for s in got) <= 500 and ids == sorted(ids, key=lambda x: int(x.split("#")[1]))
    assert best == 0.7

    monkeypatch.setattr(retrieval, "retrieve", lambda *a, **k: {"kept": [], "candidates": [], "parts": [], "mode": "x"})
    with pytest.raises(lesson.NotEnoughMaterial):
        lesson.retrieve("coffee machines", 2)


def test_slides_are_not_cut_at_400_characters():
    long_slide = "Step " + " / ".join(f"point {i}" for i in range(120))   # ~1300 characters
    assert config.SLIDE_TEXT_CHARS >= 2000
    shown = quality._excerpt({"text": "what was said", "slide_text": long_slide})
    assert "point 119" in shown and shown.endswith("what was said")


def test_a_video_claim_the_sources_do_not_support_fails_it(gateway, monkeypatch):
    seg = {**_seg(1), "text": "Joining combines two tables on a key column.", "slide_text": "Join = shared key"}
    monkeypatch.setattr(store, "all_segments", lambda: {seg["id"]: seg})
    sb = {"title": "Joins", "sources": {"S1": {"segment_id": seg["id"]}},
          "scenes": [{"visual": "title", "narration": "Welcome to this lesson on joins.", "sources": []},
                     {"visual": "bullets", "narration": "A join combines two tables on a key column. "
                                                         "And 73 percent of analysts use joins daily.",
                      "items": ["Shared key", "Two tables"], "sources": ["S1"]}]}
    c = quality.video_claims(sb)
    assert c["n_claims"] == 3 and len(c["unsupported"]) == 1 and "73 percent" in c["unsupported"][0]
    result = {"fail": [], "issues": [], "claims": c}
    assert quality._status(result, planned_only=False) == "FAIL" and "don't support" in result["fail"][0]


def test_the_judge_is_flagged_when_it_grades_itself(monkeypatch):
    monkeypatch.setattr(config, "CHAT_MODEL", "bedrock/sonnet")
    assert qa_eval.judges_itself("bedrock/sonnet") and qa_eval.judges_itself("Bedrock/Sonnet ", None)
    assert not qa_eval.judges_itself("bedrock/opus") and not qa_eval.judges_itself("bedrock/sonnet", "bedrock/haiku")


def test_judge_calibration_sample_export_and_score(project):
    claims = ([{"id": f"T{i}", "question": "q", "sentence": "s", "cites": "S1", "claim": f"bad {i}",
                "verdict": "unsupported", "reason": "r", "evidence": "e"} for i in range(10)]
              + [{"id": f"T{i}", "question": "q", "sentence": "s", "cites": "S1", "claim": f"ok {i}",
                  "verdict": "supported", "reason": "", "evidence": "e"} for i in range(30)])
    picked = calibrate.sample(claims, 20)
    assert len(picked) == 20 and sum(c["verdict"] == "unsupported" for c in picked) == 10   # flags up to half
    assert calibrate.kappa([("a", "a"), ("b", "b"), ("a", "b"), ("b", "a")]) == 0.0
    assert calibrate.kappa([("a", "a"), ("b", "b")]) == 1.0

    run = config.OUTPUT_DIR / "20260101-000000-qa-eval"
    run.mkdir(parents=True)
    import json
    (run / "claims.jsonl").write_text("\n".join(json.dumps(c) for c in claims[:6] + claims[10:16]), encoding="utf-8")
    assert calibrate.newest_run() == run
    path = calibrate.export(run, 12)
    from openpyxl import load_workbook
    wb = load_workbook(path)
    ws = wb["Claims"]
    head = [c.value for c in ws[1]]
    j, y = head.index("judge verdict") + 1, head.index("YOUR VERDICT") + 1
    for r in range(2, ws.max_row + 1):   # the person agrees with "supported", finds half the flags were false alarms
        judge = ws.cell(r, j).value
        ws.cell(r, y).value = judge if judge == "supported" or r % 2 else "supported"
    wb.save(path)
    s = calibrate.score(path)
    assert s["n"] == 12 and 0 < s["flags_confirmed"] < 1 and s["problems_caught"] == 1.0
    assert (run / "calibration_report.md").exists()


def test_whisper_inventions_are_dropped():
    ok = SimpleNamespace(text=" We join the tables on the customer ID.", no_speech_prob=0.05, avg_logprob=-0.3,
                         compression_ratio=1.4)
    assert transcribe.suspicious(ok, []) is None
    silence = SimpleNamespace(text=" Thank you.", no_speech_prob=0.7, avg_logprob=-1.2, compression_ratio=1.0)
    assert transcribe.suspicious(silence, []) == "probably silence"
    thanks = SimpleNamespace(text="Thanks for watching!", no_speech_prob=0.4, avg_logprob=-0.5, compression_ratio=1.0)
    assert "silence" in transcribe.suspicious(thanks, [])
    loop = SimpleNamespace(text="and then and then and then and then", no_speech_prob=0.0, avg_logprob=-0.2,
                           compression_ratio=3.1)
    assert transcribe.suspicious(loop, []) == "repeats itself"
    again = SimpleNamespace(text="Click on the join tool.", no_speech_prob=0.0, avg_logprob=-0.2, compression_ratio=1.2)
    assert transcribe.suspicious(again, ["click on the join tool", "click on the join tool"]) == "same line again"


def test_listening_to_the_voice_finds_misheard_terms():
    script = "Open Alteryx and check the KPI. Then add 2 tables."
    same = quality.heard_vs_script(script, "Open Alteryx and check the K P I. Then add two tables.", {"Alteryx", "KPI"})
    assert same["wer"] == 0 and same["misheard_terms"] == []
    wrong = quality.heard_vs_script(script, "Open all tricks and check the KPI. Then add tables.", {"Alteryx", "KPI"})
    assert wrong["wer"] > 0.1 and wrong["misheard_terms"] == ["alteryx (heard: all tricks)"]


def test_glossary_terms_become_words_to_listen_to(project):
    config.GLOSSARY_FILE.write_text("term,kind,include\nAlteryx,name,yes\nDigi,name,no\n", encoding="utf-8")
    assert quality.glossary_terms_in("In Alteryx and Digi you join data.") == ["Alteryx"]


def test_ablation_says_when_a_difference_could_be_chance():
    base = {f"T{i}": 1.0 for i in range(20)}
    worse = {**base, **{f"T{i}": 0.0 for i in range(8)}}
    mean, lo, hi = ablation.diff_interval(worse, base)
    assert mean == -0.4 and hi < 0                                      # clearly worse
    noisy = {**base, "T0": 0.0}
    mean, lo, hi = ablation.diff_interval(noisy, base)
    assert lo < 0 <= hi or hi == 0                                      # one test: could be chance
    assert ablation.diff_interval({"T1": 1.0}, base) is None
    assert ablation.per_test([[{"id": "a", "passed": True}], [{"id": "a", "passed": False}]]) == {"a": 0.5}


def test_word_index_follows_recut_transcripts(monkeypatch):
    old = {"v#0": {"id": "v#0", "title": "T", "text": "joining tables on a key", "slide_text": ""},
           "v#1": {"id": "v#1", "title": "T", "text": "filters and sorting", "slide_text": ""}}
    monkeypatch.setattr(store, "all_segments", lambda: old)
    assert retrieval.bm25().search("trim spaces") == []
    new = {"v#0": {**old["v#0"], "text": "joining tables, trim spaces first"}, "v#1": old["v#1"]}   # same ids
    monkeypatch.setattr(store, "all_segments", lambda: new)
    assert retrieval.bm25().search("trim spaces")[0][0] == "v#0"


def test_a_scene_without_sources_is_checked_against_the_whole_lesson(monkeypatch):
    seen = {}

    def fake_grounding(rec, model):
        seen["sentences"] = rec["sentences"]
        return {"n_claims": 1, "faithfulness": 1.0, "hallucination_rate": 0.0, "unsupported": [], "wrong_source": []}
    monkeypatch.setattr(qa_eval, "grounding", fake_grounding)
    segs = {"v#1": {**_seg(1), "id": "v#1", "text": "a"}, "v#2": {**_seg(2), "id": "v#2", "text": "b"}}
    monkeypatch.setattr(store, "all_segments", lambda: segs)
    sb = {"title": "T", "sources": {"S1": {"segment_id": "v#1"}, "S2": {"segment_id": "v#2"}},
          "scenes": [{"visual": "bullets", "narration": "In short, joins combine two tables.", "items": [], "sources": []}]}
    quality.video_claims(sb)
    assert seen["sentences"][0]["sources"] == ["S1", "S2"]


def test_listening_compares_with_what_the_voice_was_given(monkeypatch, tmp_path):
    (tmp_path / "lesson_audio.mp3").write_bytes(b"x")
    monkeypatch.setattr(transcribe, "transcribe_audio", lambda path: "Welcome to engine x and the KPI report.")
    monkeypatch.setattr(quality.tts, "load_pronunciations", lambda: {"Nginx": "engine x"})
    monkeypatch.setattr(quality, "glossary_terms_in", lambda text: ["Nginx"])
    sb = {"scenes": [{"narration": "Welcome to Nginx and the KPI report."}]}
    metrics, issues = quality.listen(tmp_path, sb)
    assert metrics["voice_wer"] == 0 and not issues


def test_two_people_agreement(project):
    import json
    run = config.OUTPUT_DIR / "20260101-000000-qa-eval"
    run.mkdir(parents=True)
    claims = [{"id": f"T{i}", "question": "q", "sentence": "s", "cites": "S1", "claim": f"c{i}",
               "verdict": "supported" if i % 2 else "unsupported", "reason": "", "evidence": "e"} for i in range(8)]
    (run / "claims.jsonl").write_text("\n".join(json.dumps(c) for c in claims), encoding="utf-8")
    path = calibrate.export(run, 8)
    from openpyxl import load_workbook
    files = []
    for who, flip in (("a", False), ("b", True)):
        wb = load_workbook(path)
        ws = wb["Claims"]
        y = [c.value for c in ws[1]].index("YOUR VERDICT") + 1
        for r in range(2, ws.max_row + 1):
            ws.cell(r, y).value = "unsupported" if (flip and r == 2) else "supported"
        out = run / f"calibration_{who}.xlsx"
        wb.save(out)
        files.append(out)
    s = calibrate.agree(*files)
    assert s["n"] == 8 and s["agreement"] == 7 / 8


def test_a_broken_remotion_is_found_before_the_voice_is_made(monkeypatch):
    from studio.experiments import remotion_render
    from studio.video import make_video

    def boom():
        raise OSError("npm crashed")
    monkeypatch.setattr(remotion_render, "ensure_installed", boom)
    monkeypatch.setattr(config, "RENDERER", "remotion")
    renderer, note = make_video.remotion_or_fallback()
    assert renderer == "pillow" and "npm crashed" in note
    monkeypatch.setattr(remotion_render, "ensure_installed", lambda: None)
    monkeypatch.setattr(remotion_render, "available", lambda: (True, "Remotion 4"))
    assert make_video.remotion_or_fallback() == ("remotion", "")


def test_personal_env_choices_do_not_reach_the_tests(project):
    assert config.JUDGE_MODEL == "" and config.RERANK_MODEL == "" and config.TTS_ENGINE == "kokoro"


def test_a_named_recording_that_is_not_found_is_reported(gateway, caplog):
    from helpers import prepare_one_recording

    from studio.generation import answer
    prepare_one_recording()
    rec = answer.answer("Using the video 'Totally Unknown Session', how do I join two tables on a key column?")
    assert rec["named_not_found"] == ["Totally Unknown Session"] and "searching all recordings instead" in caplog.text
    caplog.clear()
    answer.answer("What does 'inner join' do with two tables?")                 # a quote, but no recording named
    assert "not among the processed recordings" not in caplog.text


def test_glossary_hint_survives_a_hand_edited_count(project):
    from studio.knowledge import glossary
    config.GLOSSARY_FILE.write_text("term,kind,count,include\nAlteryx,name,12 times,yes\nBI DW,acronym,5,yes\n",
                                    encoding="utf-8")
    assert glossary.whisper_hint().startswith("Terms used in these recordings: BI DW, Alteryx")


def test_a_plain_quote_is_not_a_missing_recording(gateway):
    from helpers import prepare_one_recording

    from studio.generation import answer
    prepare_one_recording()
    assert answer.answer("What does 'inner join' do with two tables?")["named_not_found"] == []


def test_the_index_embeds_only_new_or_changed_pieces(gateway):
    from helpers import prepare_one_recording

    from studio.core import llm
    from studio.knowledge import index
    vid = prepare_one_recording()                                      # builds the index once
    before = store.load_index()[0].copy()
    mark = llm.meter_mark()
    assert index.build() == 0
    assert not [c for c in llm.calls_since(mark) if c["step"] == "index_build"]   # nothing changed: no embedding
    segs = store.load_segments(vid)
    segs[0]["text"] += " Trim the spaces first."
    store.write_json(store.video_dir(vid) / "segments.json", segs)
    mark = llm.meter_mark()
    assert index.build() == 0
    assert len([c for c in llm.calls_since(mark) if c["step"] == "index_build"]) == 1
    after = store.load_index()[0]
    assert (after[1:] == before[1:]).all() and not (after[0] == before[0]).all()


def test_calibration_takes_the_newest_run_that_has_claims(project):
    from studio.quality import calibrate
    full = config.OUTPUT_DIR / "20260101-100000-qa-eval"
    few = config.OUTPUT_DIR / "20260101-110000-qa-eval"
    full.mkdir(parents=True)
    few.mkdir()
    (full / "claims.jsonl").write_text('{"verdict": "supported", "claim": "x"}\n', encoding="utf-8")
    (few / "claims.jsonl").write_text("", encoding="utf-8")                   # a few tests, all declined
    assert calibrate.newest_run() == full


def test_a_quiz_question_and_learner_instructions_are_not_claims(monkeypatch):
    seen = {}

    def fake_grounding(rec, model):
        seen["sentences"] = [s["text"] for s in rec["sentences"]]
        return {"n_claims": 1, "faithfulness": 1.0, "hallucination_rate": 0.0, "unsupported": [], "wrong_source": []}
    monkeypatch.setattr(qa_eval, "grounding", fake_grounding)
    monkeypatch.setattr(store, "all_segments", lambda: {"v#1": {**_seg(1), "id": "v#1", "text": "a"}})
    sb = {"title": "T", "sources": {"S1": {"segment_id": "v#1"}},
          "scenes": [{"visual": "bullets", "narration": "Joins combine two tables.", "items": [], "sources": ["S1"]},
                     {"visual": "question", "narration": "Here is a question to check your understanding. Pause and think.",
                      "items": ["A wrong option on purpose", "Another option"], "sources": ["S1"]}]}
    quality.video_claims(sb)
    assert seen["sentences"] == ["Joins combine two tables."]
    assert "pause and think" in qa_eval.GROUNDING and "Only statements of fact are claims" in qa_eval.GROUNDING
