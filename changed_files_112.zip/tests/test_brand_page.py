"""The page's Company look (the settings behind the gear at the top right): single files and the .zip packages of the company's brand site go to
data/brand (only what is needed is taken from a package) and the next result uses them."""
from __future__ import annotations

import io
import zipfile

import pytest
from helpers import serve_app
from test_brand import _template

from studio.core import config
from studio.video import brand


def _png(colour: tuple[int, int, int], size: tuple[int, int] = (300, 100)) -> bytes:
    from PIL import Image
    buf = io.BytesIO()
    Image.new("RGBA", size, colour + (255,)).save(buf, "PNG")
    return buf.getvalue()


SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/></svg>'


def _packages(tmp_path):
    logos = tmp_path / "Logo package.zip"
    with zipfile.ZipFile(logos, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("Logo/CMYK/Logo_CMYK_colour_horizontal.png", _png((200, 0, 0)))     # print
        z.writestr("Logo/RGB/Logo_RGB_colour_horizontal.png", _png((11, 65, 205)))     # the one for screens
        z.writestr("Logo/RGB/Logo_RGB_white_negative.png", _png((255, 255, 255)))       # for dark backgrounds
        z.writestr("Logo/RGB/Logo_motto_RGB_colour.png", _png((0, 120, 0)))             # a variant
        z.writestr("Logo/Symbol/Symbol_RGB_colour.png", _png((11, 65, 205), (64, 64)))  # the square mark: browser tab
        z.writestr("Logo/Symbol/Symbol_CMYK_colour.png", _png((200, 0, 0), (64, 64)))
        z.writestr("Logo/Logo.eps", b"%!PS-Adobe")
        z.writestr("Logo/Logo guide.pdf", b"%PDF-1.4")
        z.writestr("__MACOSX/Logo/RGB/._Logo_RGB_colour_horizontal.png", b"junk")
    masters = tmp_path / "PowerPoint master.zip"
    with zipfile.ZipFile(masters, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("PowerPoint/Presentation checklist.pptx", _template(tmp_path / "c.pptx", "111111", "222222").read_bytes())
        z.writestr("PowerPoint/Corporate Master.potx", _template(tmp_path / "m.pptx").read_bytes())
        z.writestr("PowerPoint/preview.png", _png((0, 0, 0)))                          # not a logo: left out
    icons = tmp_path / "PowerPoint Icons.zip"
    with zipfile.ZipFile(icons, "w", zipfile.ZIP_STORED) as z:
        z.writestr("Icons/Money.svg", SVG)
        z.writestr("Icons/Team.svg", SVG)
        z.writestr("Icons/Unsafe.svg", '<svg xmlns="http://www.w3.org/2000/svg" onload="alert(1)"></svg>')
        z.writestr("Icons/Money.png", _png((0, 0, 0), (32, 32)))                        # icons only as SVG
    plans = tmp_path / "Wall layout.zip"
    with zipfile.ZipFile(plans, "w") as z:
        z.writestr("Wall/plan.dwg", b"AC1027")
        z.writestr("Wall/plan.dxf", b"0\nSECTION")
    return logos, masters, icons, plans


def test_one_button_takes_every_package_and_puts_each_file_where_it_belongs(project, tmp_path):
    pytest.importorskip("playwright")
    from playwright.sync_api import sync_playwright
    logos, masters, icons, plans = _packages(tmp_path)
    server, base = serve_app()
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page(viewport={"width": 1280, "height": 900})
            errors = []
            page.on("pageerror", lambda e: errors.append(str(e)))
            page.goto(base + "/")
            page.click("#settings-open")                                     # the gear at the top right
            page.wait_for_selector("#settings[open] #brand-now:has-text('No company files yet')")

            page.set_input_files("#brand-files", [str(logos), str(masters), str(icons), str(plans)])   # all at once
            page.wait_for_selector("#brand-msg:has-text('The next result uses them')", timeout=30_000)
            msg = page.inner_text("#brand-msg")
            assert "logo: Logo_RGB_colour_horizontal.png" in msg and "browser tab icon: Symbol_RGB_colour.png" in msg
            assert "PowerPoint template: Corporate Master.potx" in msg and "2 icons" in msg
            assert "1 could not be used" in msg and "Left out" in msg                      # the unsafe icon; PDF, DWG ...
            with zipfile.ZipFile(logos) as z:
                assert (config.BRAND_DIR / "logo.png").read_bytes() == z.read("Logo/RGB/Logo_RGB_colour_horizontal.png")
                assert (config.BRAND_DIR / "favicon.png").read_bytes() == z.read("Logo/Symbol/Symbol_RGB_colour.png")
            assert brand.template().name == "template.potx" and config.THEME_ACCENT == "#0b41cd"
            assert set(brand.icons()) == {"money", "team"} and not brand.images()
            assert sorted(brand.files()) == ["favicon.png", "icons/money.svg", "icons/team.svg", "logo.png", "template.potx"]
            page.wait_for_selector("header .brand img")                       # the logo in the page header too
            assert "/brand/favicon?v=" in page.get_attribute("link[rel=icon]", "href")   # and in the browser tab
            assert page.locator(".brandfiles li").count() == 5

            page.click(".brandfiles button[data-del='icons/team.svg']")              # a wrong file: removed
            page.wait_for_selector("#brand-msg:has-text('Removed icons/team.svg')")
            assert set(brand.icons()) == {"money"} and page.locator(".brandfiles li").count() == 4
            single = tmp_path / "Our logo 2027.png"                                   # one file: by its name
            single.write_bytes(_png((0, 90, 160)))
            page.set_input_files("#brand-files", str(single))
            page.wait_for_selector("#brand-msg:has-text('logo: Our logo 2027.png')")
            assert (config.BRAND_DIR / "logo.png").read_bytes() == single.read_bytes()
            page.keyboard.press("Escape")                                       # closes like any window
            page.wait_for_selector("#settings", state="hidden")
            assert not errors, errors
            browser.close()
    finally:
        server.shutdown()
