"""
Shared test setup. Every test runs in its own temporary project folder with a fake gateway
and a fake voice, so the tests are offline, free, fast, and never touch your real data.
"""
from __future__ import annotations

import faulthandler
import os
import sys
from pathlib import Path

import httpx
import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))   # the project folder

# Videos in the tests: the same slides and timing, drawn smaller and with fewer frames. The slides are laid out
# at 1280x720 and only scaled to VIDEO_WIDTH, so the layout and every check are the same; drawing a ninth of the
# pixels at 12 instead of 30 frames a second makes the renders several times faster. Read before config is
# imported (module constants such as slides_html.FPS are taken from it then); a value set in the shell wins.
os.environ["LESSON_STUDIO_ENV_FILE"] = ""   # a local .env must not change what the tests check
os.environ.setdefault("TEST_VIDEO_WIDTH", "640")
os.environ.setdefault("TEST_VIDEO_FPS", "12")
os.environ["VIDEO_WIDTH"] = os.environ["TEST_VIDEO_WIDTH"]
os.environ["VIDEO_FPS"] = os.environ["TEST_VIDEO_FPS"]

from studio.core import config  # noqa: E402
from studio.core import llm  # noqa: E402
from studio.video import tts  # noqa: E402
from fake_gateway import Gateway  # noqa: E402



# Tests of the renderer comparison: not in the default run; they run with -m experiment and in the full
# run (-m "slow or not slow").
EXPERIMENT_FILES = {"test_benchmark.py", "test_ai_clips.py", "test_eleven_video.py", "test_compare_video.py",
                    "test_deck_js.py", "test_deck_video.py", "test_hyperframes.py", "test_react_scenes.py",
                    "test_remotion_pro.py", "test_tiers_and_avatar.py", "test_looks.py"}
EXPERIMENT_TESTS = {"test_benchmark_skips_elevenlabs_when_too_few_characters_are_left"}


def pytest_collection_modifyitems(config, items):   # noqa: ARG001 - pytest's hook signature
    for item in items:
        if item.path.name in EXPERIMENT_FILES or item.name in EXPERIMENT_TESTS:
            item.add_marker(pytest.mark.experiment)


# one log per process: with pytest -n auto (pytest-xdist) each worker writes its own, and a stuck test stops only
# its worker (xdist reports it and goes on with the others)
_WORKER = os.environ.get("PYTEST_XDIST_WORKER", "")
TIMEOUT_LOG = Path(__file__).resolve().parents[1] / (f"pytest_timeout_{_WORKER}.log" if _WORKER else "pytest_timeout.log")


@pytest.fixture(autouse=True)
def watchdog(request):
    """If one test runs longer than its limit (3 minutes; a @pytest.mark.slow(seconds) test its own), write
    which test it was and where every thread is stuck to pytest_timeout.log, then stop, instead of hanging
    (Ctrl+C can't always interrupt on Windows). pytest's own output is lost when the run is stopped like
    this, so the log file is the place to look."""
    mark = request.node.get_closest_marker("slow")
    limit = mark.args[0] if mark and mark.args else 180
    log = open(TIMEOUT_LOG, "w", encoding="utf-8")   # noqa: SIM115 - must stay open for faulthandler
    log.write(f"{request.node.nodeid} ran longer than {limit} s; the run was stopped. Where it was:\n")
    log.flush()
    faulthandler.dump_traceback_later(limit, exit=True, file=log)
    yield
    faulthandler.cancel_dump_traceback_later()
    log.close()
    TIMEOUT_LOG.unlink(missing_ok=True)


@pytest.fixture(autouse=True)
def fresh_context():
    """Every test starts with no job context: no request text, no measured job, no setting overrides."""
    from studio.core import resources, runcard
    tokens = [runcard.REQUEST.set(""), resources.CURRENT.set(None)]
    yield
    runcard.REQUEST.reset(tokens[0])
    resources.CURRENT.reset(tokens[1])


@pytest.fixture
def project(tmp_path, monkeypatch):
    """Point every data folder to an empty temporary project and reset model-call state."""
    # Company laptops often set a proxy for all web traffic. The stand-in gateway runs on this
    # computer, so requests to it must not go through the proxy (they would hang until timeout).
    for name in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "http_proxy", "https_proxy", "all_proxy"):
        monkeypatch.delenv(name, raising=False)
    monkeypatch.setenv("NO_PROXY", "127.0.0.1,localhost")
    monkeypatch.setenv("no_proxy", "127.0.0.1,localhost")
    data = tmp_path / "data"
    for name, path in {"DATA_DIR": data, "INPUT_DIR": data / "input", "PROCESSED_DIR": data / "processed",
                       "INDEX_DIR": data / "index", "OUTPUT_DIR": data / "output",
                       "MANIFEST": data / "manifest.csv", "GLOSSARY_FILE": data / "glossary.csv", "COST_LOG": tmp_path / "cost_log.csv",
                       "PRONUNCIATION_FILE": tmp_path / "pronunciation.csv", "EVAL_DIR": tmp_path / "eval",
                       "AVATARS_DIR": data / "avatars", "BRAND_DIR": data / "brand"}.items():
        monkeypatch.setattr(config, name, path)
    # the default colours; a test that adds or removes brand files changes them, and they come back after it
    monkeypatch.setattr(config, "THEME_ACCENT", config.THEME_ACCENT_DEFAULTS[0])
    monkeypatch.setattr(config, "THEME_ACCENT_2", config.THEME_ACCENT_DEFAULTS[1])
    from studio.video import brand
    from studio.video import slides_html
    brand.info.cache_clear()          # no company brand unless a test puts one in data/brand
    slides_html.css.cache_clear()
    (data / "input").mkdir(parents=True)
    # a connection that ignores every proxy setting (also the Windows system proxy)
    monkeypatch.setattr(llm, "_client", httpx.Client(trust_env=False, timeout=httpx.Timeout(10, connect=5)))
    for name, value in {"_spent_today": None, "_spent_session": 0.0, "_route": None,
                        "_structured_ok": True, "_embed_one_by_one": False, "_cache_ok": True}.items():
        monkeypatch.setattr(llm, name, value)
    monkeypatch.setattr(config, "DAILY_BUDGET_USD", 20.0)
    monkeypatch.setattr(config, "COST_MARGIN_PCT", 10.0)   # a margin set, so the tests see it added (default 0)
    # the extra model steps of an answer (on by default) are off here, so the other tests see the writer's own
    # answer and count its calls; tests/test_answer_quality.py switches them on
    monkeypatch.setattr(config, "VERIFY_ANSWERS", False)
    monkeypatch.setattr(config, "RETRY_SEARCH", False)
    monkeypatch.setattr(config, "ANSWER_CACHE", False)   # every test answers anew; test_costs_saved switches it on
    monkeypatch.setattr(config, "RENDERER", "pillow")   # fast and needs no browser; test_slides_html covers html
    # the person's own choices in .env must not reach the tests (their judge or relevance model is not
    # known to the stand-in gateway, their paid voice must never be called)
    for name, value in {"JUDGE_MODEL": "", "RERANK_MODEL": "", "TTS_ENGINE": "kokoro", "MODEL_CHOICES": "",
                        "LOCAL_MODEL": ""}.items():
        if hasattr(config, name):
            monkeypatch.setattr(config, name, value)
    monkeypatch.setattr(config, "RUN_BUDGET_USD", 5.0)
    from studio.costs import usage
    monkeypatch.setattr(usage, "_quota", None)                  # ElevenLabs usage: asked fresh per test
    monkeypatch.setattr(config, "ELEVENLABS_BASE_URL", "http://127.0.0.1:9")   # never the real service
    return tmp_path


@pytest.fixture
def gateway(project, monkeypatch):
    """A fake Bifrost gateway; all model jobs go to it."""
    gw = Gateway()
    settings = {"BIFROST_BASE_URL": gw.url, "BIFROST_API_KEY": "test-key", "BIFROST_AUTH_HEADER": "auto",
                "GATEWAY_API": "auto", "CHAT_BACKEND": "bifrost", "VISION_BACKEND": "bifrost",
                "EMBED_BACKEND": "bifrost", "CHAT_MODEL": "bedrock/eu.anthropic.claude-sonnet-5-test",
                "VISION_MODEL": "bedrock/eu.anthropic.claude-sonnet-5-test", "REVIEW_MODEL": "",
                "EMBED_MODEL": "bedrock/amazon.titan-embed-text-v2:0", "MIN_SCORE": 0.0,
                "MAX_MATERIAL_WORDS": 9000, "LLM_TIMEOUT_S": 10.0, "CA_BUNDLE": ""}
    for name, value in settings.items():
        monkeypatch.setattr(config, name, value)
    yield gw
    gw.stop()


@pytest.fixture
def fake_voice(monkeypatch):
    """Replace the voice with a quiet tone: 0.3 s per word, so no model files are needed.
    Returns the list of voices asked for (None = the default voice)."""
    voices = []

    def synthesize(text: str, voice: str | None = None, context: dict | None = None):
        voices.append(voice)
        rate = 24000
        n = int(len(tts.clean_for_speech(text).split()) * 0.3 * rate)
        return (0.1 * np.sin(np.arange(n) / rate * 2 * np.pi * 220)).astype(np.float32), rate
    monkeypatch.setattr(tts, "synthesize", synthesize)
    return voices


# --- shared fixtures ----------------------------------------------------------------------------------------
KINDS = [("what does", "answer", None), ("presentation", "slides", None), ("listen", "audio", None), ("two characters", "dialogue", "dialogue"),
         ("cartoon", "video", "presenter"), ("document", "text", None), ("video", "video", None)]


@pytest.fixture
def understands(monkeypatch):
    """The request model, by keywords (the stand-in model always answers 'video'); a chat's earlier turns are
    passed as `history` from the second request on."""
    from studio.generation import ask

    def understand(request, history=None):
        fmt, style = next(((f, s) for k, f, s in KINDS if k in request.lower()), ("video", None))
        return {"format": fmt, "topic": "how to join two tables", "recordings": [], "minutes": 1, "level": "beginner",
                "wishes": "", "style": style, "characters": "cartoon" if style == "presenter" else None}
    monkeypatch.setattr(ask, "understand", understand)


VOICES = [{"voice_id": "f1", "name": "Anna", "labels": {"gender": "female"}},
          {"voice_id": "m1", "name": "Ben", "labels": {"gender": "male"}}]


@pytest.fixture
def cloud_voices(project, monkeypatch):
    """ElevenLabs and Kokoro without network or model files; the Windows voice reported as not set up.
    In the test project, so the made-up voices never reach your real cost_log.csv."""
    import numpy as np

    from studio.video import tts
    spoken = {"elevenlabs": [], "kokoro": []}

    def eleven(text, voice_id, before="", after=""):
        spoken["elevenlabs"].append((voice_id, text))
        return np.zeros(int(len(text.split()) * 0.3 * 24000), dtype=np.float32), 24000, {"chars": None}

    class FakeKokoro:
        def get_voices(self):
            return {"af_heart", "am_michael"}

        def create(self, text, voice, speed, lang):
            spoken["kokoro"].append((voice, text))
            return np.zeros(int(len(text.split()) * 0.3 * 24000), dtype=np.float32), 24000

    real_check = tts.check

    def check(engine=None):
        engine = engine or config.TTS_ENGINE
        if engine == "kokoro":
            return True, "kokoro (test)"
        if engine == "system":
            return False, "pyttsx3 not installed (test)"
        return real_check(engine)
    monkeypatch.setattr(config, "ELEVENLABS_API_KEY", "test-key")
    monkeypatch.setattr(tts, "_elevenlabs", eleven)
    monkeypatch.setattr(tts, "_elevenlabs_voices", lambda: VOICES)
    monkeypatch.setattr(tts, "_get_kokoro", lambda: FakeKokoro())
    monkeypatch.setattr(tts, "check", check)
    return spoken
