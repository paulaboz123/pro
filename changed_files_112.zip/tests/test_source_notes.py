"""Every slide of a video or presentation says where its content comes from (a footnote: the training and the
time), and the page lists the sources under the result, as under an answer."""
from __future__ import annotations

from studio.video import slides_html

SOURCES = {"S1": {"title": "Joining data", "video_id": "v1", "start": 750, "end": 790},
           "S2": {"title": "Joining data", "video_id": "v1", "start": 845, "end": 870},
           "S3": {"title": "A very long training title about month-end closing in the finance team", "video_id": "v2",
                  "start": 3725, "end": 3760},
           "D1": {"title": "Close checklist", "video_id": "d1", "where": "page 3"}}


def test_the_footnote_names_the_training_and_the_time():
    assert slides_html.source_note({"sources": ["S1", "S2"]}, SOURCES) == "Source: Joining data, 12:30 · 14:05"
    two = slides_html.source_note({"sources": ["S1", "S3"]}, SOURCES)
    assert two.startswith("Sources: Joining data, 12:30; A very long training title about month-end") and "1:02:05" in two
    assert "…" in two and len(two) < 110                                            # a long title is shortened
    assert slides_html.source_note({"sources": ["D1"]}, SOURCES) == "Source: Close checklist, page 3"
    assert slides_html.source_note({"sources": []}, SOURCES) == "" and slides_html.source_note({"sources": ["X"]}, SOURCES) == ""


def test_the_footnote_is_on_the_slide_but_not_on_the_title():
    scene = {"visual": "bullets", "heading": "Joins", "items": ["One", "Two"], "sources": ["S1"]}
    html, _ = slides_html.scene_html(scene, lesson_title="T", goal="", page="2 / 5",
                                     source=slides_html.source_note(scene, SOURCES))
    assert '<span class="srcnote">Source: Joining data, 12:30</span>' in html and ".srcnote{" in html
    title, _ = slides_html.scene_html({"visual": "title", "heading": "Joins"}, lesson_title="T", goal="", page="1 / 5",
                                      source="Source: x")
    assert "srcnote\">" not in title
