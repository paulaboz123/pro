"""What the page offers under the chat box (only the tools that work here, HTML slides by default) and how long a
request usually takes, from the latest results of the same kind."""
from __future__ import annotations

from studio.core import config, store
from studio.web import catalog, jobs, pricing


def test_only_the_html_tool_is_offered_unless_every_tool_is_asked_for(project, monkeypatch):
    monkeypatch.setattr(catalog, "_quick_ok", lambda sol: (sol["renderer"] in ("html", "pillow"), "not set up here"))
    catalog._choices.clear()
    assert [t["id"] for t in catalog.choices()["tools"]] == ["html"]
    monkeypatch.setattr(config, "PAGE_TOOLS", ["all"])                  # e.g. on the laptop, for the experiments
    catalog._choices.clear()
    offered = catalog.choices()["tools"]
    assert len(offered) > 2 and any(not t["ok"] for t in offered)        # the others shown, those not set up disabled
    monkeypatch.setattr(config, "PAGE_TOOLS", ["remotion"])               # asked for, but not set up here
    catalog._choices.clear()
    assert catalog.choices()["tools"] == []


def _card(name: str, kind: str, minutes: float, seconds: float) -> None:
    store.write_json(config.OUTPUT_DIR / name / "run_card.json", {
        "created": name, "kind": kind, "request": {"topic": "joins", "minutes": minutes},
        "cost": {"model_calls": 1, "in_tokens": 1, "out_tokens": 1, "total_usd": 0.1, "model_seconds": 1},
        "time": {"total_s": seconds}})


def test_how_long_a_request_usually_takes(project):
    assert pricing.expected_seconds("video", 1) is None                                  # nothing made yet
    _card("20261101-a", "video", 1, 100)
    _card("20261102-b", "video", 1, 140)
    _card("20261103-c", "video", 2, 300)
    _card("20261104-d", "answer", 0, 12)
    _card("20261105-e", "document", 5, 50)
    assert pricing.expected_seconds("video", 1) == 120                    # the same length: their middle value
    assert pricing.expected_seconds("video", 3) == 420                    # else per minute: middle of 100, 140, 150 x 3
    assert pricing.expected_seconds("answer", 0) == 12 and pricing.expected_seconds("text", 2) == 50
    assert pricing.expected_seconds("slides", 0) is None


def test_the_job_carries_the_estimate_once_the_request_is_understood(project):
    _card("20261101-a", "video", 2, 200)
    job: dict = {}
    jobs._understood(job, {"format": "video", "minutes": 2, "level": "beginner"})
    assert job["understood"]["minutes"] == 2 and job["expected_s"] == 200
    jobs._understood(job, {"format": "video", "minutes": "odd"})                           # a strange value: no estimate
    assert job["understood"]["minutes"] == "odd"
